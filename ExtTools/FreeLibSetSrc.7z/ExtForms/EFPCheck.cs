﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;

/*
 * The BSD License
 * 
 * Copyright (c) 2006-2015, Ageyev A.V.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

// Система проверки корректности введенных значений

namespace AgeyevAV.ExtForms
{
  #region EFPErrorInfo

  /// <summary>
  /// Информация об одной ошибке или предупреждении
  /// </summary>
  public class EFPErrorInfo
  {
    #region Конструктор

    /// <summary>
    /// Устанавливает значения свойств.
    /// </summary>
    /// <param name="message">Строка сообщения</param>
    /// <param name="isError">true- ошибка, false - предупреждение</param>
    /// <param name="focusedControl">Управляющий элемент, которому должен быть передан фокус ввода.
    /// Может быть null.</param>
    public EFPErrorInfo(string message, bool isError, Control focusedControl)
    {
#if DEBUG
      if (String.IsNullOrEmpty(message))
        throw new ArgumentNullException("message");
#endif
      _Message = message;
      _IsError = isError;
      _FocusedControl = focusedControl;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Текст сообщения об ошибке
    /// </summary>
    public string Message { get { return _Message; } }
    private string _Message;

    /// <summary>
    /// True, если сообщение об ошибке, False - если предупрежедение
    /// </summary>
    public bool IsError { get { return _IsError; } }
    private bool _IsError;

    /// <summary>
    /// Управляющий элемент, которому надо передать фокус ввода
    /// </summary>
    public Control FocusedControl { get { return _FocusedControl; } }
    private Control _FocusedControl;

    /// <summary>
    /// Возвращает свойство Message
    /// </summary>
    /// <returns>Текстовое представление</returns>
    public override string ToString()
    {
      return _Message; ;
    }

    #endregion
  }

  #endregion

  #region IEFPCheckItem

  /// <summary>
  /// Интерфейс объекта, который можно проверять и который может устанавливать состояние ошибки или предупреждения
  /// </summary>
  public interface IEFPCheckItem
  {
    /// <summary>
    /// Выполнить проверку ошибок
    /// </summary>
    void Validate();

    /// <summary>
    /// Получить количество ошибок
    /// </summary>
    int ErrorCount { get; }

    /// <summary>
    /// Получить количество предупреждений
    /// </summary>
    int WarningCount { get; }

    /// <summary>
    /// Добавить в список сообщения об ошибках и предупреждениях
    /// </summary>
    /// <param name="errorList">Список, куда надо добавить сообщения</param>
    /// <param name="recurse">Если true, то должны быть возвращены все сообщения об ошибках, включая дочерние элементы. Если false, то должны быть возвращены только сообщения этого элемента</param>
    void GetErrorMessages(List<EFPErrorInfo> errorList, bool recurse);

    /// <summary>
    /// Этот метод вызывается, когда меняется цепочка провайдеров, к которой 
    /// подключена данный элемент. Не вызывается после присоединения элемента к 
    /// провайдеру. В реализации метода следует установить всплывающие подсказки
    /// </summary>
    void ParentProviderChanged();

    /// <summary>
    /// Название элемента (для отладочных целей)
    /// </summary>
    string DisplayName { get; }

    /// <summary>
    /// Вызывается, когда форма выводится на экран или скрывается
    /// Метод может выполнить чтение или запись конфигурации
    /// </summary>
    void FormVisibleChanged(bool visible);
  }

  #endregion

  /// <summary>
  /// "Базовый" провайдер, к которому можно присоединять управляющие элементы.
  /// Баззовые провайдеры могут образовывать в форме иерархию.
  /// Корнем иерархии для формы является EFPFormProvider.
  /// </summary>
  public class EFPBaseProvider : IEFPCheckItem, IEnumerable<IEFPCheckItem>
  {
    #region Конструктор

    /// <summary>
    /// Создает базовый провайдер, не прекрепленный ни к чему и не имеющи дочерних элементов.
    /// Для присоединения к родительскому провайдеру или к EFPFormProvider должно быть установлено свойство Parent.
    /// </summary>
    public EFPBaseProvider()
    {
      _Items = new List<IEFPCheckItem>();
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Корневой провайдер в дереве (провайдер формы) или null, если его нет
    /// </summary>
    public virtual EFPFormProvider FormProvider
    {
      get
      {
        if (Parent == null)
          return null;
        else
          return Parent.FormProvider;
      }
    }

    /// <summary>
    /// True, если провайдер подключен к форме и форма выведена на экран
    /// </summary>
    public bool IsFormVisible
    {
      get
      {
        EFPFormProvider fp = FormProvider;
        if (fp == null)
          return false;
        if (fp.Form == null)
          return false;
        return fp.Form.Visible;
      }
    }

    /// <summary>
    /// Используемый блокировкщик
    /// </summary>
    public virtual IEFPReentranceLocker ReentranceLocker
    {
      get
      {
        if (Parent == null)
          return EFPDummyReentranceLocker.TheLocker;
        else
          return Parent.ReentranceLocker;
      }
    }

    #endregion

    #region Добавление / удаление дочерних элементов

    /// <summary>
    /// Добавляет дочерний элемент.
    /// Это может быть провайдер управляющего элементв EFPControlBase или другой EFPBaseProvider.
    /// Обычно не используется в пользовательском коде.
    /// </summary>
    /// <param name="item">Добавляемый элемент</param>
    public virtual void Add(IEFPCheckItem item)
    {
      if (item == null)
        throw new ArgumentNullException("item");
      EFPBaseProvider Item2 = item as EFPBaseProvider;
      if (Item2 != null)
      {
        if (Item2.Parent != null)
          Item2.Parent.Remove(Item2);
      }
      _Items.Add(item);
      if (Item2 != null)
        Item2._Parent = this;
      item.ParentProviderChanged();
      ItemStateChanged();
    }

    /// <summary>
    /// Удаление элемента из списка.
    /// Обычно не используется в пользовательском коде.
    /// </summary>
    /// <param name="item">Удаляемый элемент</param>
    public virtual void Remove(IEFPCheckItem item)
    {
      if (item == null)
        throw new ArgumentNullException("item");
      _Items.Remove(item);
      EFPBaseProvider Item2 = item as EFPBaseProvider;
      if (Item2 != null)
        Item2._Parent = null;
      item.ParentProviderChanged();

      ItemStateChanged();
    }

    private List<IEFPCheckItem> _Items;

    /// <summary>
    /// Этот метод вызывается точкой проверки, когда состояние ошибки меняется
    /// </summary>
    public virtual void ItemStateChanged()
    {
      if (Parent != null)
        Parent.ItemStateChanged();
    }

    #endregion

    #region Средства для вывода сообщений

    #region Буферизация подсказок

    private class SetToolTipInfo
    {
      #region Поля

      public string Title;
      public string MainInfo;
      public string ValueInfo;
      public EFPValidateState State;
      public string ErrorMessage;

      #endregion
    }

    /// <summary>
    /// Отложенные подсказки.
    /// Используется, когда свойство Parent не установлено. Когда родительский провайдер присоединяется позднее,
    /// для него выполняется вызов SetToolTip
    /// (20.05.2015)
    /// </summary>
    private Dictionary<Control, SetToolTipInfo> _DelayedToolTips;

    #endregion

    /// <summary>
    /// Установка подсказки для управляющего элемента
    /// </summary>
    /// <param name="control">Управляющий элемент (не может быть null)</param>
    /// <param name="title">Заголовок</param>
    /// <param name="mainInfo">Основная подсказка для элемента (назначение элемента)</param>
    /// <param name="valueInfo">Подсказка по текущему значению</param>
    /// <param name="state">Наличие ошибки или предупреждения</param>
    /// <param name="errorMessage">Сообщение об ошибке или предупреждении</param>
    public virtual void SetToolTip(Control control, string title, string mainInfo, string valueInfo, EFPValidateState state, string errorMessage)
    {
#if DEBUG
      if (control == null)
        throw new ArgumentNullException("control");
#endif

      if (Parent != null)
        // Немедленная установка
        Parent.SetToolTip(control, title, mainInfo, valueInfo, state, errorMessage);
      else
      {
        // Отложенная установка
        if (_DelayedToolTips == null)
          _DelayedToolTips = new Dictionary<Control, SetToolTipInfo>();

        // Убираем предыдущую подсказку
        if (_DelayedToolTips.ContainsKey(control))
          _DelayedToolTips.Remove(control);

        SetToolTipInfo Info = new SetToolTipInfo();
        Info.Title = title;
        Info.MainInfo = mainInfo;
        Info.ValueInfo = valueInfo;
        Info.State = state;
        Info.ErrorMessage = errorMessage;

        _DelayedToolTips.Add(control, Info);
      }
    }

    /// <summary>
    /// Сброс отложенных подсказок родителю
    /// </summary>
    private void FlushToolTipsToParent()
    {
      if (_DelayedToolTips == null)
        return;

      foreach (KeyValuePair<Control, SetToolTipInfo> Pair in _DelayedToolTips)
        Parent.SetToolTip(Pair.Key, Pair.Value.Title, Pair.Value.MainInfo, Pair.Value.ValueInfo,
          Pair.Value.State, Pair.Value.ErrorMessage);

      _DelayedToolTips = null;
    }

    #endregion

    #region Родительский список

    /// <summary>
    /// Родительский элемент в иерархии провайдеров.
    /// Обычно не требуется устанавливать свойство в пользовательском коде.
    /// </summary>
    public EFPBaseProvider Parent
    {
      get { return _Parent; }
      set
      {
        // Основная часть действий выполняется в Add/Remove(), а не здесь
        if (value == _Parent)
          return;
        if (_Parent != null)
          _Parent.Remove(this);
        //FParent = value;
        if (value != null)
          value.Add(this);
      }
    }
    private EFPBaseProvider _Parent;

    #endregion

    #region Менеджер конфигурации

    /// <summary>
    /// Менеджер конфигурации.
    /// Если свойство не было установлено явно, возвращается свойство родительского элемента. 
    /// Если родительского элемента нет (EFPFFormProvider), возвращается значение EFPApp.ConfigManager
    /// Свойство никогда не возвращает null
    /// </summary>
    public IEFPConfigManager ConfigManager
    {
      get
      {
        if (_ConfigManager == null)
        {
          if (Parent == null)
            return EFPApp.ConfigManager;
          else
            return Parent.ConfigManager;
        }
        else
          return _ConfigManager;
      }
      set
      {
        _ConfigManager = value;
      }
    }
    private IEFPConfigManager _ConfigManager;

    #endregion

    #region IEFPCheckItem Members

    /// <summary>
    /// Проверка корректости.
    /// Вызывает IEFPCheckItem.Validate() для всех дочерних элементов.
    /// </summary>
    public void Validate()
    {
      for (int i = 0; i < _Items.Count; i++)
        _Items[i].Validate();
    }

    /// <summary>
    /// Возвращает значение EFPFormProvider.ValidateReason или Unknown, если текущий провайдер не присоединен к форме.
    /// </summary>
    public EFPFormValidateReason ValidateReason
    {
      get
      {
        if (FormProvider == null)
          return EFPFormValidateReason.Unknown;
        else
          return FormProvider.ValidateReason;
      }
    }

    /// <summary>
    /// Возвращает количество дочерних элементов с ошибками.
    /// Поучает сумму свойств IEFPCheckItem.ErrorCount.
    /// </summary>
    public int ErrorCount
    {
      get
      {
        int n = 0;
        for (int i = 0; i < _Items.Count; i++)
          n += _Items[i].ErrorCount;
        return n;
      }
    }

    /// <summary>
    /// Возвращает количество дочерних элементов с предупреждениями.
    /// Поучает сумму свойств IEFPCheckItem.WarningCount.
    /// </summary>
    public int WarningCount
    {
      get
      {
        int n = 0;
        for (int i = 0; i < _Items.Count; i++)
          n += _Items[i].WarningCount; // исправлено 06.11.2018
        return n;
      }
    }

    /// <summary>
    /// Получает список сообщений об ошибках и предупреждений.
    /// Выполняет вызов IEFPCheckItem.GetErrorMessages.
    /// </summary>
    /// <param name="errorList">Заполняемый список</param>
    /// <param name="recurse">Признак рекурсивного обхода.
    /// Должно быть задано true, иначе метод не выполняет никаких действий</param>
    public void GetErrorMessages(List<EFPErrorInfo> errorList, bool recurse)
    {
      if (recurse)
      {
        for (int i = 0; i < _Items.Count; i++)
          _Items[i].GetErrorMessages(errorList, recurse);
      }
    }

    /// <summary>
    /// Вызывает при смене одного из родительских провайдеров в цепочке.
    /// Посылает извещение всем дочерним элементам.
    /// </summary>
    public void ParentProviderChanged()
    {
      for (int i = 0; i < _Items.Count; i++)
        _Items[i].ParentProviderChanged();

      if (_Parent != null)
        FlushToolTipsToParent();
    }

    /// <summary>
    /// Отображаемое имя.
    /// Если свойство не задано в явном виде, возращает Type.ToString()
    /// </summary>
    public virtual string DisplayName
    {
      get
      {
        if (String.IsNullOrEmpty(_DisplayName))
          return GetType().ToString();
        else
          return _DisplayName;
      }
      set
      {
        _DisplayName = value;
      }
    }
    private string _DisplayName;

    /// <summary>
    /// Посылает дочерним элементам уведомление об изменении видимости формы.
    /// </summary>
    /// <param name="visible">Видимость формы</param>
    public virtual void FormVisibleChanged(bool visible)
    {
      for (int i = 0; i < _Items.Count; i++)
        _Items[i].FormVisibleChanged(visible);
    }

    #endregion

    #region IEnumerable<IEFPCheckItem> Members

    /// <summary>
    /// Возвращает перечислитель по дочерним элементам.
    /// Перечислитель не является рекурсивным.
    /// Текущий объект EFPBaseProvider не входит в перечисление.
    /// </summary>
    /// <returns>Перечислитель</returns>
    public IEnumerator<IEFPCheckItem> GetEnumerator()
    {
      return _Items.GetEnumerator();
    }

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
    {
      return _Items.GetEnumerator();
    }

    #endregion

    #region FindControlProvider

    /// <summary>
    /// Выполняет рекурсивный поиск провайдера для управляющего элемента, начиная с текущего EFPBaseProvider.
    /// Если нет провайдера для этого элемента, возвращает null.
    /// Поиск в родительском провайдере, если он задан, не выполняется
    /// </summary>
    /// <param name="control">Управляющий элемент, для которого выполняется поиск</param>
    /// <returns>Найденный провайдер или null</returns>
    public EFPControlBase FindControlProvider(Control control)
    {
      if (control == null)
        return null;

      for (int i = 0; i < _Items.Count; i++)
      {
        EFPBaseProvider Child = _Items[i] as EFPBaseProvider;
        if (Child != null)
        {
          EFPControlBase Res = Child.FindControlProvider(control); // рекурсиный вызов
          if (Res != null)
            return Res;
        }
        else
        {
          EFPControlBase Res = _Items[i] as EFPControlBase;
          if (Res != null)
            return Res;
        }
      }
      return null;
    }

    #endregion

    #region Рекурсивный поиск элментов

    /// <summary>
    /// Рекурсивный поиск всех элементов заданного вида
    /// </summary>
    /// <typeparam name="T">Тип элементов. Для поиска всех провайдеров управляющих элементов используйте тип EFPControlBase</typeparam>
    /// <param name="list">Заполняемый список</param>
    public void GetItems<T>(ICollection<T> list)
      where T : IEFPCheckItem
    {
      if (list == null)
        throw new ArgumentNullException("list");

      if (this is T)
        list.Add((T)(IEFPCheckItem)this);
      for (int i = 0; i < _Items.Count; i++)
      {
        if (_Items[i] is EFPBaseProvider)
          ((EFPBaseProvider)(_Items[i])).GetItems<T>(list); // себя они тоже в список могут добавить
        else if (_Items[i] is T)
          list.Add((T)(_Items[i]));
      }
    }

    /// <summary>
    /// Рекурсивный поиск первого элемента заданного вида
    /// </summary>
    /// <typeparam name="T">Тип элемента. Для поиска провайдера управляющего элемента используйте тип EFPControlBase</typeparam>
    /// <returns>Первый найденный элемент или null</returns>
    public T GetFirstItem<T>()
      where T : class, IEFPCheckItem
    {
      if (this is T)
        return (T)(IEFPCheckItem)this;
      for (int i = 0; i < _Items.Count; i++)
      {
        if (_Items[i] is EFPBaseProvider)
        {
          T Res = ((EFPBaseProvider)(_Items[i])).GetFirstItem<T>();
          if (Res != null)
            return Res;
        }
        else if (_Items[i] is T)
        {
          T Res = (T)(_Items[i]);
          if (Res != null)
            return Res;
        }
      }
      return null;
    }

    #endregion

    #region Список команд меню

    /// <summary>
    /// Этот метод вызывается в EFPControlBase.InitLocalMenu(), чтобы добавить в контекстное меню команды, относящиеся к родительским элементам.
    /// Если производный класс переопределяет метод, он должен вызвать базовый метод в конце, чтобы команды располагались в правильном порядке.
    /// Непереопределенный метод вызывает метод родительского объекта Parent.
    /// </summary>
    /// <param name="list">Заполняемый список команд</param>
    public virtual void InitCommandItemList(List<EFPCommandItems> list)
    {
      if (Parent != null)
        Parent.InitCommandItemList(list);
    }

    #endregion

    #region Отладочные свойства

#if DEBUG

    /// <summary>
    /// Отладочное свойство.
    /// Не должно использоваться.
    /// </summary>
    public IEFPCheckItem[] DebugCheckItems { get { return _Items.ToArray(); } set { } }

    /// <summary>
    /// Отладочное свойство.
    /// Не должно использоваться.
    /// </summary>
    public object[] DebugAllCheckItems
    {
      get
      {
        List<object> a = new List<object>();
        for (int i = 0; i < _Items.Count; i++)
        {
          a.Add((object)(_Items[i]));
          if (_Items[i] is EFPBaseProvider)
            a.AddRange(((EFPBaseProvider)(_Items[i])).DebugAllCheckItems);
        }
        return a.ToArray();
      }
      set
      {
      }
    }
#endif

    #endregion
  }

  #region Перечисление EFPValidateState

  /// <summary>
  /// Результат проверки ошибок
  /// </summary>
  [Serializable]
  public enum EFPValidateState
  {
    /// <summary>
    /// Ошибок не найдено
    /// </summary>
    Ok = 0,

    /// <summary>
    /// Предупреждение
    /// </summary>
    Warning = 1,

    /// <summary>
    /// Ошибка
    /// </summary>
    Error = 2
  }

  #endregion

  #region Интерфейс объекта, поддерживающего проверку ошибок

  /// <summary>
  /// Интерфейс объекта, поддерживающего проверку ошибок.
  /// Реализуется EFPControlBase, EFPValidatingEventArgs и некоторыми другими классами.
  /// </summary>
  public interface IEFPValidator
  {
    /// <summary>
    /// Установить ошибку
    /// </summary>
    /// <param name="message">Сообщение</param>
    void SetError(string message);

    /// <summary>
    /// Установить предупреждение.
    /// </summary>
    /// <param name="message">Сообщение</param>
    void SetWarning(string message);

    /// <summary>
    /// Получить текущее состояние проверки
    /// </summary>
    EFPValidateState ValidateState { get; }
  }

  /// <summary>
  /// Простой класс для реализации одноразовой проверки
  /// </summary>
  public class EFPSimpleValidator : IEFPValidator
  {
    #region Конструктор

    /// <summary>
    /// Создает объект
    /// </summary>
    public EFPSimpleValidator()
    {
      Clear();
    }

    #endregion

    #region Методы

    /// <summary>
    /// Устанавливает состояние Ok
    /// </summary>
    public void Clear()
    {
      _ValidateState = EFPValidateState.Ok;
      _Message = null;
    }

    /// <summary>
    /// Устанавливает состояние ошибки.
    /// Если уже установлена ошибка, вызов игнорируется.
    /// </summary>
    /// <param name="message">Текст сообщения</param>
    public void SetError(string message)
    {
      if (ValidateState != EFPValidateState.Error)
      {
        _ValidateState = EFPValidateState.Error;
        _Message = message;
      }
    }

    /// <summary>
    /// Устанавливает предупреждение
    /// Если уже установлена ошибка или предупреждение, вызов игнорируется.
    /// </summary>
    /// <param name="message">Текст сообщения</param>
    public void SetWarning(string message)
    {
      if (ValidateState == EFPValidateState.Ok)
      {
        _ValidateState = EFPValidateState.Warning;
        _Message = message;
      }
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Текущее состояние
    /// </summary>
    public EFPValidateState ValidateState { get { return _ValidateState; } }
    private EFPValidateState _ValidateState;

    /// <summary>
    /// Текст сообщения об ошибке или предупреждения
    /// </summary>
    public string Message { get { return _Message; } }
    private string _Message;

    #endregion
  }

  #endregion

  #region Делегат для проверки ошибок

  /// <summary>
  /// Аргумент для события проверки
  /// </summary>
  public class EFPValidatingEventArgs : IEFPValidator
  {
    /// <summary>
    /// Создание объекта
    /// </summary>
    /// <param name="validator">Объект, запросивший проверку. Ему передаются сообщения об ошибке или предупреждении</param>
    public EFPValidatingEventArgs(IEFPValidator validator)
    {
      _Validator = validator;
    }

    /// <summary>
    /// Объект, запросивший проверку. Ему передаются сообщения об ошибке или предупреждении
    /// </summary>
    public IEFPValidator Validator { get { return _Validator; } }
    private IEFPValidator _Validator;

    /// <summary>
    /// Установить сообщение об ошибке
    /// </summary>
    /// <param name="message">Сообщение</param>
    public void SetError(string message)
    {
      _Validator.SetError(message);
    }

    /// <summary>
    /// Установить предупреждение
    /// </summary>
    /// <param name="message">Сообщение</param>
    public void SetWarning(string message)
    {
      _Validator.SetWarning(message);
    }

    /// <summary>
    /// Определить текущее состояние проверки: наличие ошибок или предупреждений
    /// </summary>
    public EFPValidateState ValidateState { get { return _Validator.ValidateState; } }

    /// <summary>
    /// Вспомогательный метод, вызывающий SetError() или SetWarning()
    /// </summary>
    /// <param name="state">Состояние</param>
    /// <param name="message">Сообщение</param>
    public void SetState(EFPValidateState state, string message)
    {
      if (ValidateState == EFPValidateState.Error)
        return;

      switch (state)
      {
        case EFPValidateState.Error:
          SetError(message);
          break;
        case EFPValidateState.Warning:
          if (ValidateState == EFPValidateState.Ok)
            SetWarning(message);
          break;
      }
    }
  }

  /// <summary>
  /// Делегат события проверки
  /// </summary>
  /// <param name="sender"></param>
  /// <param name="args"></param>
  public delegate void EFPValidatingEventHandler(object sender, EFPValidatingEventArgs args);

  /// <summary>
  /// Расширение обработчика проверки полем значения произвольного типа
  /// </summary>
  /// <typeparam name="T">Тип значения, подлежащего проверке</typeparam>
  public class EFPValidatingValueEventArgs<T> : EFPValidatingEventArgs
  {
    #region Конструктор

    /// <summary>
    /// Создание объекта
    /// </summary>
    /// <param name="validator">Объект, запросивший проверку. Ему передаются сообщения об ошибке или предупреждении</param>
    /// <param name="value">Проверяемое значение</param>
    public EFPValidatingValueEventArgs(IEFPValidator validator, T value)
      : base(validator)
    {
      _Value = value;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Проверяемое значение
    /// </summary>
    public T Value { get { return _Value; } }
    private T _Value;

    #endregion
  }

  /// <summary>
  /// Делегат события проверки введенного значения произвольного типа
  /// </summary>
  /// <typeparam name="T">Тип вводимого значения</typeparam>
  /// <param name="sender"></param>
  /// <param name="args"></param>
  public delegate void EFPValidatingValueEventHandler<T>(object sender, EFPValidatingValueEventArgs<T> args);

  /// <summary>
  /// Расширение обработчика проверки полем двух значений произвольных типа
  /// </summary>
  /// <typeparam name="T1">Тип первого значения, подлежащего проверке</typeparam>
  /// <typeparam name="T2">Тип второго значения, подлежащего проверке</typeparam>
  public class EFPValidatingTwoValuesEventArgs<T1, T2> : EFPValidatingEventArgs
  {
    #region Конструктор

    /// <summary>
    /// Создание объекта
    /// </summary>
    /// <param name="validator">Объект, запросивший проверку. Ему передаются сообщения об ошибке или предупреждении</param>
    /// <param name="value1">Первое проверяемое значение</param>
    /// <param name="value2">Второе проверяемое значение</param>
    public EFPValidatingTwoValuesEventArgs(IEFPValidator validator, T1 value1, T2 value2)
      : base(validator)
    {
      _Value1 = value1;
      _Value2 = value2;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Первое проверяемое значение
    /// </summary>
    public T1 Value1 { get { return _Value1; } }
    private T1 _Value1;

    /// <summary>
    /// Второе проверяемое значение
    /// </summary>
    public T2 Value2 { get { return _Value2; } }
    private T2 _Value2;

    #endregion
  }

  /// <summary>
  /// Делегат события проверки пары значений
  /// </summary>
  /// <typeparam name="T1">Тип первого значения, подлежащего проверке</typeparam>
  /// <typeparam name="T2">Тип второго значения, подлежащего проверке</typeparam>
  /// <param name="sender"></param>
  /// <param name="args"></param>
  public delegate void EFPValidatingTwoValuesEventHandler<T1, T2>(object sender, EFPValidatingTwoValuesEventArgs<T1, T2> args);

  #endregion


  /// <summary>
  /// Класс для проверки ошибок формы, не связанных с управляющими элементами
  /// </summary>
  public class EFPFormCheck : IEFPCheckItem, IEFPValidator
  {
    #region Конструктор

    /// <summary>
    /// Создает пустой объект
    /// </summary>
    public EFPFormCheck()
    {
    }

    #endregion

    #region IEFPCheckItem Members

    /// <summary>
    /// Выполнить проверку значений
    /// </summary>
    public void Validate()
    {
      EFPValidateState PrevState = _ValidateState;

      _ValidateState = EFPValidateState.Ok;
      _ErrorMessage = null;

      if (Validating != null)
      {
        if (_ValidatingArgs == null)
          _ValidatingArgs = new EFPValidatingEventArgs(this);
        Validating(this, _ValidatingArgs);
      }
      if (_ValidateState != PrevState)
      {
        // Состояние ошибки изменилось
        if (ErrorBase != null)
          ErrorBase.ItemStateChanged();

      }
    }

    /// <summary>
    /// Возращает 1, если установлено состояние ошибки
    /// </summary>
    public int ErrorCount
    {
      get { return (ValidateState == EFPValidateState.Error) ? 1 : 0; }
    }

    /// <summary>
    /// Возращает 1, если установлено предупреждение
    /// </summary>
    public int WarningCount
    {
      get { return (ValidateState == EFPValidateState.Warning) ? 1 : 0; }
    }

    /// <summary>
    /// Добавляет в список единственное сообшение об ошибке или предупреждение.
    /// Для состояния OK не выполняет никаких действий
    /// </summary>
    /// <param name="errorList">Заполняемый список</param>
    /// <param name="recurse">Игнорируется</param>
    public void GetErrorMessages(List<EFPErrorInfo> errorList, bool recurse)
    {
      if (ValidateState == EFPValidateState.Ok)
        return;
      EFPErrorInfo Info = new EFPErrorInfo(ErrorMessage, ValidateState == EFPValidateState.Error, FocusControl);
      errorList.Add(Info);
    }

    void IEFPCheckItem.ParentProviderChanged()
    {
    }

    /// <summary>
    /// Отображаемое имя.
    /// Непереопределенный метод возвращает Type.ToString()
    /// </summary>
    public virtual string DisplayName
    {
      get { return GetType().ToString(); }
    }

    /// <summary>
    /// Вызывается при изменении видимости формы.
    /// Непереопределенный метод ничего не делает.
    /// </summary>
    /// <param name="visible">Видимость формы</param>
    public virtual void FormVisibleChanged(bool visible)
    {
    }

    #endregion

    #region IEFPValidator Members

    /// <summary>
    /// Установить сообщение об ошибке.
    /// Если уже было установлена ошибка, вызов игнорируется.
    /// </summary>
    /// <param name="message">Текст сообщений</param>
    public void SetError(string message)
    {
      if (_ValidateState == EFPValidateState.Error)
        return;
      _ValidateState = EFPValidateState.Error;
      _ErrorMessage = message;
    }


    /// <summary>
    /// Установить предупреждение.
    /// Если уже было установлена ошибка или предупреждение, вызов игнорируется.
    /// </summary>
    /// <param name="message">Текст сообщений</param>
    public void SetWarning(string message)
    {
      if (_ValidateState != EFPValidateState.Ok)
        return;
      _ValidateState = EFPValidateState.Error;
      _ErrorMessage = message;
    }

    /// <summary>
    /// Текущее состояние проверки ошибок
    /// </summary>
    public EFPValidateState ValidateState { get { return _ValidateState; } }
    private EFPValidateState _ValidateState;

    #endregion

    #region Прочие свойства, методы и события проверки ошибок

    /// <summary>
    /// Используем один объект аргументов, чтобы не создавать каждый раз
    /// </summary>
    private EFPValidatingEventArgs _ValidatingArgs;

    /// <summary>
    /// Текущее сообщение об ошибке или предупреждении
    /// </summary>
    public string ErrorMessage { get { return _ErrorMessage; } }
    private string _ErrorMessage;

    /// <summary>
    /// Пользовательский обработчик для проверки ошибок
    /// </summary>
    public event EFPValidatingEventHandler Validating;

    /// <summary>
    /// Список, в который будет добавляться сообщения об ошибке
    /// </summary>
    public EFPBaseProvider ErrorBase
    {
      get { return _ErrorBase; }
      set
      {
        if (value == _ErrorBase)
          return;

        if (_ErrorBase != null)
          _ErrorBase.Remove(this);
        _ErrorBase = value;
        if (_ErrorBase != null)
          _ErrorBase.Add(this);
        Validate();
      }
    }
    private EFPBaseProvider _ErrorBase;

    /// <summary>
    /// Необязательный управляющий элемент, куда будет передаваться фокус ввода
    /// при выводе сообщения об ошибке
    /// </summary>
    public Control FocusControl
    {
      get { return _FocusControl; }
      set { _FocusControl = value; }
    }
    private Control _FocusControl;

    /// <summary>
    /// Произвольные пользовательские данные
    /// </summary>
    public object Tag { get { return _Tag; } set { _Tag = value; } }
    private object _Tag;

    #endregion
  }

  /// <summary>
  /// Интерфейс объекта, выполняющего блокировку реентрантного вызова.
  /// Реализуется EFPReentranceLocker
  /// </summary>
  public interface IEFPReentranceLocker
  {
    /// <summary>
    /// Выполнить попытку входа и установки блокировки
    /// </summary>
    /// <param name="displayName">Наименование действия, которое предполагается выполнить</param>
    /// <returns>true в случае успеха</returns>
    bool TryLock(string displayName);

    /// <summary>
    /// Завершение входа и снятие блокировки.
    /// </summary>
    void Unlock();
  }

  /// <summary>
  /// Блокировщик вложенного выполнения команд.
  /// В отличие от System.Monitor и других блокирующих классов Net Framework, этот класс предназначен
  /// для работы с одним потоком (основным потоком приложения).
  /// Используется EFPFormProvider, чтобы предотвратить закрытие формы, пока выполняется обработки нажатия
  /// кнопки, или предотвратить нажатие другой кнопки, если предыдущая обработка еще не выполнена
  /// </summary>
  /// <remarks>
  /// Обработчик нажатия кнопки или другого события должен выполнить следующие действия:
  /// 1. Получить доступ к EFPReentranceLocker.
  /// 2. Вызвать EFPReentranceLocker.TryLock(). Если метод вернул false, обработчик завершается без выполнения действий
  /// 3. Выполнить основное действие.
  /// 4. Вызвать EFPReentranceLocker.Unlock(). 
  /// Должен использоваться try-finally блок
  /// </remarks>
  public class EFPReentranceLocker : IEFPReentranceLocker
  {
    #region Конструктор

    /// <summary>
    /// Конструктор
    /// </summary>
    public EFPReentranceLocker()
    {
    }


    #endregion

    #region Проверка потока

#if DEBUG

    private void CheckThread()
    {
      EFPApp.CheckMainThread();
    }

#endif

    #endregion

    #region Выполнение блокировки

    /// <summary>
    /// Выполнить попытку блокировки. Возвращает true, если блокировщик не занят.
    /// Иначе пользователю выводится сообщение с помощью EFPApp.ShowTempMessage() и возвращается false.
    /// </summary>
    /// <param name="displayName">Наименование действия, которое предполагается выполнить</param>
    /// <returns>true в случае успеха</returns>
    public bool TryLock(string displayName)
    {
#if DEBUG
      CheckThread();
#endif

      if (String.IsNullOrEmpty(displayName))
        displayName = "Неизвестное действие";

      if (_LockedDisplayName != null)
      {
        EFPApp.ShowTempMessage("Предыдущая операция еще не закончена: " + _LockedDisplayName);
        return false;
      }

      _LockedDisplayName = displayName;
      return true;
    }

    /// <summary>
    /// Снять ранее установленную блокировку
    /// </summary>
    public void Unlock()
    {
#if DEBUG
      CheckThread();
#endif
      if (_LockedDisplayName == null)
        throw new InvalidOperationException("Не было вызова TryLock()");
      _LockedDisplayName = null;
    }

    /// <summary>
    /// Наименование действия, которое удерживает блокировку.
    /// Это поле используется как флан блокировки
    /// </summary>
    private string _LockedDisplayName;

    /// <summary>
    /// Возвращает true, если есть установленная блокировка
    /// </summary>
    public bool IsLocked { get { return _LockedDisplayName != null; } }

    #endregion
  }

  /// <summary>
  /// Фиктивный блокировщик
  /// </summary>
  public sealed class EFPDummyReentranceLocker : IEFPReentranceLocker
  {
    #region IEFPReentranceLocker Members

    /// <summary>
    /// Возвращает true
    /// </summary>
    /// <param name="displayName">Игнорируется</param>
    /// <returns>Всегда true</returns>
    public bool TryLock(string displayName)
    {
      return true;
    }

    /// <summary>
    /// Ничего не делает
    /// </summary>
    public void Unlock()
    {
    }

    #endregion

    #region Статический экземпляр

    /// <summary>
    /// Статический экземпляр объекта
    /// </summary>
    public static readonly EFPDummyReentranceLocker TheLocker = new EFPDummyReentranceLocker();

    #endregion
  }
}
