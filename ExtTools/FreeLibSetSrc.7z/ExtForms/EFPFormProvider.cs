﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.ComponentModel;
using AgeyevAV.DependedValues;
using System.Drawing;
using AgeyevAV.Config;
using AgeyevAV.Logging;

/*
 * The BSD License
 * 
 * Copyright (c) 2006-2015, Ageyev A.V.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace AgeyevAV.ExtForms
{
  #region Перечисление EFPFormValidateReason

  /// <summary>
  /// Причина проверки формы (свойство EFPFormProvider.ValidateReason)
  /// </summary>
  public enum EFPFormValidateReason
  {
    /// <summary>
    /// Проверка сейчас не выполняется, вызвана при изменении состоянии управляющих элементов,
    /// или программный вызов метода ValidateForm()
    /// </summary>
    Unknown,

    /// <summary>
    /// Начальная проверка при выводе формы на экран
    /// </summary>
    Shown,

    /// <summary>
    /// Проверка перед закрытием формы
    /// </summary>
    Closing
  }

  #endregion

  /// <summary>
  /// Расширение для работы с формой (класс Form) в EFPApp.
  /// Этот объект должен создается в конструкторе форме.
  /// </summary>
  public class EFPFormProvider : EFPBaseProvider, IEFPAppTimeHandler, IEFPStatusBarControl, IEFPConfigurable
  {
    #region Конструктор

    /// <summary>
    /// Создает провайдер для формы
    /// </summary>
    /// <param name="form">Форма Windows Forms, еще не выведенная на экран</param>
    public EFPFormProvider(Form form)
    {
#if DEBUG
      if (form == null)
        throw new ArgumentNullException("form");
      if (form.IsDisposed)
        throw new ObjectDisposedException("form");
#endif

      _Form = form;
      _Form.FormClosing += new FormClosingEventHandler(FForm_FormClosing);
      _Form.Closing += new CancelEventHandler(Form_Closing);
      _Form.FormClosed += new FormClosedEventHandler(Form_FormClosed);
      _Form.VisibleChanged += new EventHandler(Form_VisibleChanged);
      _Form.Activated += new EventHandler(Form_Activated);

      _SyncProviderDefined = false;

      if (EFPApp.ShowToolTips)
      {
        _ToolTipIcons = new Dictionary<Control, ToolTipIcon>();
        _ToolTipTitles = new Dictionary<Control, string>();

        _TheToolTip = new ToolTip();
        _TheToolTip.ToolTipIcon = ToolTipIcon.None;
        _TheToolTip.Popup += new PopupEventHandler(TheToolTip_Popup);
        _TheToolTip.ShowAlways = true;
        _TheToolTip.AutoPopDelay = 10000;
        //TheToolTip.InitialDelay = 50;
        //TheToolTip.ReshowDelay = 100;

      }
      _Form.KeyPreview = true;
      _Form.KeyDown += new KeyEventHandler(FormKeyDown);

      _Form.Disposed += new EventHandler(Form_Disposed);

      ToolFormsEnabled = true;

      EFPApp.InitFormImages(form);

#if DEBUG
      DebugFormDispose.Add(_Form);

      _DebugCreateTime = DateTime.Now;
#endif

      _ValidateReason = EFPFormValidateReason.Unknown;

      _CloseModalFormByEscape = true;
      _ReentranceLocker = new EFPReentranceLocker();

      _ProviderList.Add(this);

      _ConfigHandler = new EFPConfigHandler();
      _ConfigHandler.Sources.Add(this);
      // DesignAutoScaleDimensions = Form.AutoScaleBaseSize; 
    }

    #endregion

    #region Обработка нажатий мыши в TabControl

    private static void InitControl(Control control)
    {
      if (control is DataGrid)
        return; // Там бяка - есть вложенный текстбокс, который мне не нужен
      // Рекурсивная функция


      //if (Control is TabPage)
      //  ((TabPage)Control).MouseClick += new MouseEventHandler(TabPage_MouseClick);
      if (control is TabControl)
        ((TabControl)control).MouseClick += new MouseEventHandler(TabControl_MouseClick);

      if (control.HasChildren)
      {
        foreach (Control ChildControl in control.Controls)
          InitControl(ChildControl);
      }
    }

    static void TabControl_MouseClick(object sender, MouseEventArgs args)
    {
      TabControl TheControl = (TabControl)sender;
      WinFormsTools.CorrectTabControlActivation(TheControl);
    }

    #endregion

    #region Основные свойства

    /// <summary>
    /// Форма (задается в конструкторе)
    /// </summary>
    public Form Form { get { return _Form; } }
    private Form _Form;

    /// <summary>
    /// Провайдер синхронизации значений. К нему будет подключен объект Syncs
    /// на время запуска формы
    /// Значение по-умолчанию можно переопределить для использования чужого
    /// </summary>
    [Browsable(true)]
    public DepSyncProvider SyncProvider
    {
      get
      {
        if (!_SyncProviderDefined)
        {
          _SyncProviderDefined = true;
          _SyncProvider = new DepSyncProvider();
        }
        return _SyncProvider;
      }
      set
      {
        _SyncProviderDefined = true;
        _SyncProvider = value;
      }
    }
    private DepSyncProvider _SyncProvider;
    private bool _SyncProviderDefined;

    /// <summary>
    /// Список для добавления объектов синхронизации.
    /// Объекты будут подключены к SyncProvider на время запуска формы
    /// </summary>
    [Browsable(true)]
    public DepSyncCollection Syncs
    {
      get
      {
        if (_Syncs == null)
          _Syncs = new DepSyncCollection();
        return _Syncs;
      }
    }
    private DepSyncCollection _Syncs;

    /// <summary>
    /// Возвращает true, если список объектов синхронизации пустой.
    /// Не требует создания дополнительго объекта
    /// </summary>
    public bool HasSyncs
    {
      get
      {
        if (_Syncs == null)
          return false;
        else
          return _Syncs.Count > 0;
      }
    }

    /// <summary>
    /// Возвращает указатель на сам текущий объект
    /// </summary>
    public override EFPFormProvider FormProvider
    {
      get
      {
        return this;
      }
    }

    /// <summary>
    /// Показывать ли открытые панели инструментов при выводе блока диалога
    /// (по умолчанию - true). Действительно только при запуске формы в модальном
    /// режиме (с помощью EFPApp.ShowDialog())
    /// Свойство может быть выключено в false для окон предварительного просмотра
    /// и других, где загромождение экрана не желательно
    /// </summary>
    public bool ToolFormsEnabled { get { return _ToolFormsEnabled; } set { _ToolFormsEnabled = value; } }
    private bool _ToolFormsEnabled;

    /// <summary>
    /// Сюда могут быть добавлены команды локального меню для формы в-целом
    /// Если задано свойство HelpContext, то будет добавлена команда меню "Справка"
    /// </summary>
    public EFPControlCommandItems CommandItems
    {
      get
      {
        if (_CommandItems == null)
          _CommandItems = GetCommandItems();
        return _CommandItems;
      }
      set
      {
        _CommandItems = value;
      }
    }
    private EFPControlCommandItems _CommandItems;

    /// <summary>
    /// Команды локального меню для формы в-целом
    /// </summary>
    /// <returns></returns>
    protected virtual EFPControlCommandItems GetCommandItems()
    {
      return new EFPControlCommandItems();
    }

    /// <summary>
    /// Добавляет команды для формы в-целом в список <paramref name="list"/>.
    /// </summary>
    /// <param name="list">Заполняемый список</param>
    public override void InitCommandItemList(List<EFPCommandItems> list)
    {
      if (CommandItems.Count > 0)
        list.Add(CommandItems);
      //base.InitCommandItemList(List);
    }

    /// <summary>
    /// Для отладки
    /// </summary>
    /// <returns>Текстовое представление</returns>
    public override string ToString()
    {
      string s = "Форма " + Form.ToString();
#if DEBUG
      s += ", создана: " + _DebugCreateTime.ToString("G");
#endif
      return s;
    }

    /// <summary>
    /// Возвращает ссылку на объект EFPReentranceLocker, относящийся к данной форме.
    /// Объект создается в конструкторе EFPFormProvider.
    /// </summary>
    public override IEFPReentranceLocker ReentranceLocker
    {
      get { return _ReentranceLocker; }
    }
    private EFPReentranceLocker _ReentranceLocker;

    #endregion

    #region Проверка ошибок в форме

    /// <summary>
    /// True (по умолчанию), если нужно использовать объект ErrorProvider для форм
    /// </summary>
    public static bool UseErrorProvider { get { return _UseErrorProvider; } set { _UseErrorProvider = value; } }
    private static bool _UseErrorProvider = true;

    /// <summary>
    /// Текущая причина вызова метода ValidateForm.
    /// Свойство может использоваться в обработчике события Validating, если требуется различная реакция
    /// при проверке формы.
    /// Например, может потребоваться пропускать проверку при открытии формы
    /// </summary>
    public new EFPFormValidateReason ValidateReason { get { return _ValidateReason; } }
    private EFPFormValidateReason _ValidateReason;

    /// <summary>
    /// Выполняем проверку ошибок. Если есть ошибки, выдаем сообщение о первой из
    /// них и позиционируемся на управляющий элемент с ошибкой.
    /// Метод может вызываться, например, при обработке нажатия кнопки, при которой
    /// нужны корректные введенные значения
    /// </summary>
    /// <returns>True, если нет ошибок (возможно, есть предупреждение).
    /// False, если есть ошибка</returns>
    public bool ValidateForm()
    {
      EFPApp.ShowTempMessage(null);
      base.Validate();
      if (UseErrorProvider)
        InitErrorProvider();

      if (ErrorCount > 0)
      {
        EFPErrorInfo Info = GetFirstError();
        if (Info == null)
          throw new Exception("Потеряно сообщение об ошибке");
        WinFormsTools.FocusToControl(Info.FocusedControl);
        EFPApp.ShowTempMessage(Info.Message);
        return false;
      }
      return true;

    }

    /// <summary>
    /// Инициализация объекта ErrorProvider
    /// </summary>
    private void InitErrorProvider()
    {
      if (_TheErrorProvider == null)
        _TheErrorProvider = new ErrorProvider(Form);
      _TheErrorProvider.Clear();

      List<EFPErrorInfo> ErrorList = new List<EFPErrorInfo>();
      GetErrorMessages(ErrorList, true);

      for (int i = 0; i < ErrorList.Count; i++)
      {
        if (ErrorList[i].FocusedControl != null)
        {
          _TheErrorProvider.SetError(ErrorList[i].FocusedControl, ErrorList[i].Message);
        }
      }
    }

    private ErrorProvider _TheErrorProvider;

    /// <summary>
    /// Поиск первого сообщения об ошибке
    /// </summary>
    /// <returns></returns>
    public EFPErrorInfo GetFirstError()
    {
      List<EFPErrorInfo> ErrorList = new List<EFPErrorInfo>();
      GetErrorMessages(ErrorList, true);
      for (int i = 0; i < ErrorList.Count; i++)
      {
        if (ErrorList[i].IsError)
          return ErrorList[i];
      }
      return null;
    }


    /// <summary>
    /// Упрощенный способ добавления проверки ошибки в форме
    /// </summary>
    /// <param name="validating">Обработчик, выполняющий проверку</param>
    /// <param name="focusControl">Управляющий элемент, который получит фокус ввода в случае ошибки</param>
    public void AddFormCheck(EFPValidatingEventHandler validating, Control focusControl)
    {
#if DEBUG
      if (validating == null)
        throw new ArgumentNullException("Validating");
#endif
      EFPFormCheck Check = new EFPFormCheck();
      Check.Validating += validating;
      Check.FocusControl = focusControl;
      Add(Check);
    }

    /// <summary>
    /// Упрощенный способ добавления проверки ошибки в форме
    /// </summary>
    /// <param name="validating">Обработчик, выполняющий проверку</param>
    public void AddFormCheck(EFPValidatingEventHandler validating)
    {
      AddFormCheck(validating, null);
    }

    #endregion

    #region Всплывающие подсказки для элементов

    /// <summary>
    /// Если флаг установлен, то в локальное меню формы добавляется команда
    /// отладки объект EFPFormProvider
    /// </summary>
    public static bool DebugFormProvider { get { return _DebugFormProvider; } set { _DebugFormProvider = value; } }
    private static bool _DebugFormProvider = false;

    /// <summary>
    /// Создание команды в главном меню, которая будет переключать наличие подсказок
    /// </summary>
    /// <param name="parentMenu"></param>
    /// <returns></returns>
    public static EFPCommandItem CreateToolTipsVisibleCommandItem(EFPCommandItem parentMenu)
    {
      EFPCommandItem ci = new EFPCommandItem("View", "ShowToolTips");
      ci.MenuText = "Всплывающие подсказки";
      ci.Parent = parentMenu;
      ci.Checked = EFPApp.ShowToolTips;
      ci.Click += new EventHandler(ciShowToolTips_Click);
      return ci;
    }

    static void ciShowToolTips_Click(object sender, EventArgs args)
    {
      EFPCommandItem ci = (EFPCommandItem)sender;
      EFPApp.ShowToolTips = !EFPApp.ShowToolTips;
      ci.Checked = EFPApp.ShowToolTips;
    }

    private ToolTip _TheToolTip;

    private Dictionary<Control, ToolTipIcon> _ToolTipIcons;
    private Dictionary<Control, string> _ToolTipTitles;

    /// <summary>
    /// Инициализация всплывающей подсказки для управляющего элемента
    /// </summary>
    /// <param name="control">Управляющий элемент</param>
    /// <param name="title">Заголовок подсказки (EFPControlBase.DisplayName)</param>
    /// <param name="mainInfo">Основной текст всплывающей подсказки (EFPControlBase.ToolTipText)</param>
    /// <param name="valueInfo">Информация о текущем введенном значении (обычно, пустая строка)</param>
    /// <param name="state">Наличие ошибки или предупреждения</param>
    /// <param name="errorMessage">Текст ошибки или предупреждения</param>
    public override void SetToolTip(Control control, string title, string mainInfo, string valueInfo, EFPValidateState state, string errorMessage)
    {
      if (control == null)
        throw new ArgumentNullException("Не задан управляющий элемент", "control");

      // Проверяем объект TheToolTip, а не флаг ShowToolTips, т.к. флаг может
      // быть переключен в процессе вывода формы, а объект не создается в конструкторе
      // при выключенном ShowToolTips
      if (_TheToolTip == null)
        // Вывод подсказок запрещен
        return;

      if (state == EFPValidateState.Ok)
        errorMessage = "";

      StringBuilder sb = new StringBuilder();

      if (!String.IsNullOrEmpty(errorMessage))
        sb.Append(errorMessage);
      if (!String.IsNullOrEmpty(mainInfo))
      {
        if (sb.Length > 0)
        {
          sb.Append(Environment.NewLine);
          sb.Append(Environment.NewLine);
        }
        sb.Append(mainInfo);
      }
      if (!String.IsNullOrEmpty(valueInfo))
      {
        if (sb.Length > 0)
        {
          sb.Append(Environment.NewLine);
          sb.Append(Environment.NewLine);
        }
        sb.Append(valueInfo);
      }


      ToolTipIcon Icon;
      switch (state)
      {
        case EFPValidateState.Error:
          Icon = ToolTipIcon.Error;
          title += " - Ошибка";
          break;
        case EFPValidateState.Warning:
          Icon = ToolTipIcon.Warning;
          title += " - Предупреждение";
          break;
        default:
          Icon = ToolTipIcon.Info;
          break;
      }

      // Рекурсивная функция
      DoSetToolTip(control, sb.ToString(), Icon, title);
    }

    /// <summary>
    /// Рекурсивная процедура установки ToolTip'а для управляющего элемента.
    /// Если управляющий элемент составной, то устанавливаем подсказки для всех
    /// входящих в него элементов
    /// </summary>
    /// <param name="control">Управляющий элемент</param>
    /// <param name="text">Текст подсказки</param>
    /// <param name="icon">Вид значка</param>
    /// <param name="title">Заголовок</param>
    private void DoSetToolTip(Control control, string text, ToolTipIcon icon, string title)
    {
      _TheToolTip.SetToolTip(control, text);
      _ToolTipIcons[control] = icon;
      _ToolTipTitles[control] = title;
      if (control.HasChildren)
      {
        foreach (Control ChildControl in control.Controls)
        {
          // Для кнопок панели инструментов не устанавливаем
          if (ChildControl is ToolStrip)
            continue;
          DoSetToolTip(ChildControl, text, icon, title);
        }
      }
    }
    void TheToolTip_Popup(object sender, PopupEventArgs args)
    {
      ToolTipIcon Icon = _ToolTipIcons[args.AssociatedControl];
      _TheToolTip.ToolTipIcon = Icon;
      _TheToolTip.ToolTipTitle = _ToolTipTitles[args.AssociatedControl];
    }

    /// <summary>
    /// Полное перестроение списка подсказок для всех управляющих элементов формы
    /// </summary>
    public void RefreshToolTips()
    {
      if (_TheToolTip == null) // 14.03.08 - подсказки могут быть отключены
        return;
      _TheToolTip.RemoveAll();
      _ToolTipIcons.Clear();
      _ToolTipTitles.Clear();

      // Заставляем все управляющие элементы переустановить подсказки
      ParentProviderChanged();
    }

    #endregion

    #region Вызов справки

    /// <summary>
    /// Контекст справки для формы в-целом
    /// </summary>
    public string HelpContext
    {
      get { return GetHelpContext(_Form); }
      set { SetHelpContext(_Form, value); }
    }

    /// <summary>
    /// Задание контекста справки для управляющего элемента
    /// </summary>
    /// <param name="control">Управляющий элемент</param>
    /// <param name="value">Контекст справки</param>
    public void SetHelpContext(Control control, string value)
    {
      if (_Form == null)
        throw new Exception("Форма должна быть присоединена до задания контекстов справок");
      if (control == null)
        throw new ArgumentNullException("control");
      if (_HelpContextItems == null)
        _HelpContextItems = new Dictionary<Control, string>();
      _HelpContextItems[control] = value;
      if (!String.IsNullOrEmpty(value)) // 26.10.2015
        InitFormHelp();
    }
    private Dictionary<Control, String> _HelpContextItems;

    /// <summary>
    /// Получение контекста справки для управляющего элемента. Сначала извлекается
    /// контекст для самого элемента. Если его нет, то берется контекст родительского
    /// элемента и т.д. до контекста формы в-целом
    /// </summary>
    /// <param name="control">Управляющий элемент</param>
    /// <returns>Контекст справки</returns>
    public string GetHelpContext(Control control)
    {
      if (_HelpContextItems == null)
        return null;
      while (control != null)
      {
        string HelpContext;
        if (_HelpContextItems.TryGetValue(control, out HelpContext))
        {
          if (!String.IsNullOrEmpty(HelpContext)) // условие добавлено 09.10.2017
            return HelpContext;
        }
        control = control.Parent;
      }
      return null;
    }

    /// <summary>
    /// Этот метод при первом вызове инициализирует подсистему обработки клавиши
    /// F1 для формы и наличие "?" в заголовке.
    /// Вызывается при установке контекста справки
    /// </summary>
    private void InitFormHelp()
    {
      if (_FormHelpButtonClickedHandler != null)
        return; // не первый вызов
      if (CommandItems.Control != null)
        throw new InvalidOperationException("Нельзя первоначально инициализировать контекст справки, когда форма уже выведена");

      _FormHelpButtonClickedHandler = new CancelEventHandler(FormHelpButtonClickedProc);
      _Form.HelpButton = true;

      // Создание команды локального меню
      EFPCommandItem ciHelp;

      ciHelp = EFPApp.CommandItems.CreateContext(EFPAppStdCommandItems.ContextHelp);
      ciHelp.MenuText = "Справка";
      ciHelp.Enabled = true;
      ciHelp.Click += new EventHandler(ciHelp_Click);
      CommandItems.Add(ciHelp);

      EFPCommandItem ciDebug = null;
      if (DebugFormProvider)
      {
        ciDebug = new EFPCommandItem("Debug", "EFPFormProvider");
        ciDebug.MenuText = "Просмотр объекта EFPFormProvider";
        ciDebug.Click += new EventHandler(ciDebug_Click);
        CommandItems.Add(ciDebug);
      }
    }

    /// <summary>
    /// Обработчик нажатия кнопки "?" на заголовке формы
    /// </summary>
    private CancelEventHandler _FormHelpButtonClickedHandler;

    private void FormHelpButtonClickedProc(object sender, CancelEventArgs args)
    {
      args.Cancel = true;
      PerformCallHelp();
    }

    /// <summary>
    /// Реализация запроса справки
    /// </summary>
    public void PerformCallHelp()
    {
      Control Ctrl = _Form.ActiveControl;
      if (Ctrl == null)
        Ctrl = _Form;
      if (Ctrl is TabControl)
      {
        // Если активен сам управляющий элемент с закладками, то надо выбрать 
        // текущую страницу. Так бывает, когда фокус ввода имеет непосредственно 
        // корешок закладки
        TabControl TabCtrl = (TabControl)Ctrl;
        if (TabCtrl.TabPages.Count > 0)
          Ctrl = TabCtrl.SelectedTab;
      }
      string ctx = GetHelpContext(Ctrl);
      EFPApp.ShowHelp(ctx);
    }

    #endregion

    #region Вспомогательные методы

    /// <summary>
    /// Закрыть форму, открытую в модальном или немодальном редиме.
    /// Выполняются все обычные действия по закрытию формы, в частности, вызывается
    /// обработчик Form.Closing.
    /// Метод возвращает true, если форма успешноь закрыта. Возвращается false,
    /// если обработчик отверг закрытие формы, при этом свойство Form.DialogResult
    /// сбрасывается в None
    /// </summary>
    /// <param name="dialogResult">Код закрытия формы</param>
    /// <returns>true, если форма была успешно закрыта</returns>
    public bool CloseForm(DialogResult dialogResult)
    {
      _Form.DialogResult = dialogResult;
      _TempFormClosingFlag = false;
      // Добавляем временный обработчик FormClosing. Он будет последним в цепочке,
      // поэтому можно будет узнать значение Cancel
      FormClosingEventHandler TempFormClosingHandler = new FormClosingEventHandler(Temp_FormClosing);
      _Form.FormClosing += TempFormClosingHandler;
      try
      {
        _Form.Close();
      }
      catch (Exception e)
      {
        EFPApp.ShowException(e, "Ошибка при закрытии формы");
        _Form.DialogResult = DialogResult.None;
        _TempFormClosingFlag = false;
      }
      _Form.FormClosing -= TempFormClosingHandler;
      if (!_TempFormClosingFlag)
        _Form.DialogResult = DialogResult.None;
      return _TempFormClosingFlag;
    }

    private bool _TempFormClosingFlag;

    /// <summary>
    /// Флаг выполнения проверки закрытия формы должен выставляться в последнюю
    /// очередь, поэтому используем обработчик FormClosing, т.к. он вызывается
    /// после Closing
    /// </summary>
    private void Temp_FormClosing(object sender, FormClosingEventArgs args)
    {
      if (!args.Cancel)
        _TempFormClosingFlag = true;
    }

    #endregion

    #region Обработка нажатия клавиш

    void FormKeyDown(object sender, KeyEventArgs args)
    {
      try
      {
        EFPCommandItems.PerformKeyDown(sender, args);
        if (EFPApp.ShowToolTips && _TheToolTip != null)
        {
          _TheToolTip.Active = false;
          _TheToolTip.Active = true;
        }
      }
      catch (Exception e)
      {
        EFPApp.ShowException(e, "Ошибка обработчика Form.KeyDown");
      }
    }

    #endregion

    #region События закрытия формы

    #region Closing

    /// <summary>
    /// Есть два события: Form.Closing (старое) и Form.FormClosing (новое в Net Framework 2).
    /// Closing вызывается до FormClosing
    /// Проверка корректности полей формы должна выполняться ДО выполнения других
    /// действий пользователя, поэтому ее надо поместить в обработчик Closing
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="args"></param>
    private void Form_Closing(object sender, CancelEventArgs args)
    {
      if (args.Cancel)
        return;
      try
      {
        if (_InsideFormClosing1)
        {
          args.Cancel = true;
          Form.DialogResult = DialogResult.None;
          EFPApp.ShowTempMessage("Повторное закрытие формы");
        }
        else
        {
          _InsideFormClosing1 = true;
          try
          {
            if (ReentranceLocker.TryLock("Закрытие формы"))
            {
              try
              {
                OnClosing(args);
              }
              finally
              {
                ReentranceLocker.Unlock();
              }
            }
            else
              args.Cancel = true;
          }
          finally
          {
            _InsideFormClosing1 = false;
          }
        }
      }
      catch (Exception e)
      {
        args.Cancel = true;
        Form.DialogResult = DialogResult.None;
        EFPApp.ShowException(e, "Ошибка обработки события Form.Closing");
      }
    }

    private bool _InsideFormClosing1;

    /// <summary>
    /// Обработчик события Form.Closing
    /// </summary>
    /// <param name="args">Аргументы события</param>
    protected virtual void OnClosing(CancelEventArgs args)
    {
      switch (Form.DialogResult)
      {
        case DialogResult.OK:
        case DialogResult.Yes:
          bool Res;
          _ValidateReason = EFPFormValidateReason.Closing;
          try
          {
            Res = ValidateForm();
          }
          finally
          {
            _ValidateReason = EFPFormValidateReason.Unknown;
          }
          if (!Res)
          {
            args.Cancel = true;
            Form.DialogResult = DialogResult.None;
          }
          break;
      }
    }

    #endregion

    #region FormClosing

    private void FForm_FormClosing(object sender, FormClosingEventArgs args)
    {
      if (args.Cancel)
        return;
      try
      {
        if (_InsideFormClosing2)
        {
          args.Cancel = true;
          Form.DialogResult = DialogResult.None;
          EFPApp.ShowTempMessage("Повторное закрытие формы");
        }
        else
        {
          // 20.03.2018
          // Если в данный момент обрабатывается событие EFPApp.Closing, то вместо CloseReason.UserClosing
          // надо использовать ApplicationExitCall
          CloseReason Reason = args.CloseReason;
          if (Reason == CloseReason.UserClosing && EFPApp.IsClosing)
            Reason = CloseReason.ApplicationExitCall;
          FormClosingEventArgs Args2 = new FormClosingEventArgs(Reason, false);

          _InsideFormClosing2 = true;
          try
          {
            OnFormClosing(Args2);
          }
          finally
          {
            _InsideFormClosing2 = false;
          }
          if (Args2.Cancel)
          {
            Form.DialogResult = DialogResult.None; // 19.09.2017
            args.Cancel = true;
          }
        }
      }
      catch (Exception e)
      {
        args.Cancel = true;
        Form.DialogResult = DialogResult.None;
        EFPApp.ShowException(e, "Ошибка обработки события Form.FormClosing");
      }
    }

    private bool _InsideFormClosing2;

    /// <summary>
    /// Дублирует событие Form.FormClosing с перехватом исключений и блокировкой вложенного вызова,
    /// если обработка события выполняется долго
    /// </summary>
    public event FormClosingEventHandler FormClosing;

    /// <summary>
    /// Вызывает обработчик события FormClosing, если он присоединен
    /// </summary>
    /// <param name="args">Аргументы события</param>
    protected virtual void OnFormClosing(FormClosingEventArgs args)
    {
      if (FormClosing != null && (!args.Cancel))
        FormClosing(this, args);
    }

    #endregion

    #region Closed

    void Form_FormClosed(object sender, FormClosedEventArgs args)
    {
      try
      {
        if (_InsideFormClosed)
          EFPApp.ShowTempMessage("Повторное закрытие формы");
        else
        {
          // 20.03.2018
          // Если в данный момент обрабатывается событие EFPApp.Closing, то вместо CloseReason.UserClosing
          // надо использовать ApplicationExitCall
          CloseReason Reason = args.CloseReason;
          if (Reason == CloseReason.UserClosing && EFPApp.IsClosing)
            Reason = CloseReason.ApplicationExitCall;
          FormClosedEventArgs Args2 = new FormClosedEventArgs(Reason);

          _InsideFormClosed = true;
          try
          {
            OnFormClosed(Args2);
          }
          finally
          {
            _InsideFormClosed = false;
          }
        }
      }
      catch (Exception e)
      {
        EFPApp.ShowException(e, "Ошибка обработки события Form.FormClosed");
      }
    }

    /// <summary>
    /// Дублирует событие Form.FormClosed с перехватом исключений
    /// </summary>
    public event FormClosedEventHandler FormClosed;

    private void OnFormClosed(FormClosedEventArgs args)
    {
      DoForm_VisibleChanged(false);

      if (FormClosed != null)
        FormClosed(this, args);
    }

    private bool _InsideFormClosed;

    #endregion

    void Form_Disposed(object sender, EventArgs args)
    {
      _ProviderList.Remove(this);
    }

    #endregion

    #region VisibleChanged

    private void Form_VisibleChanged(object sender, EventArgs args)
    {
      try
      {
        DoForm_VisibleChanged(_Form.Visible);
      }
      catch (Exception e)
      {
        EFPApp.ShowException(e, "Ошибка обработки события Form.VisibleChanged");
      }
    }

    private bool _PrevVisible = false;

    private void DoForm_VisibleChanged(bool isVisible)
    {
      if (isVisible == _PrevVisible)
        return;

      _PrevVisible = isVisible;

      // Начальная проверка ошибок для всех элементов
      if (isVisible)
      {
        _ValidateReason = EFPFormValidateReason.Shown;
        try
        {
          Validate();
        }
        finally
        {
          _ValidateReason = EFPFormValidateReason.Unknown;
        }

        if (!HasBeenShown) // 24.09.2018
        {
          if (_Form.WindowState == FormWindowState.Normal)
          {
            // 06.11.2009
            // Изменение размеров формы помогает форме красиво выглядеть на экране с нестандартным DPI
            // (когда управляющие элементы выходят за края, пока не изменишь размер формы)
            // PerformLayout() почему-то не помогает
            // Наверное, есть какой-нибудь способ получше
            _Form.SetBounds(_Form.Left, _Form.Top, _Form.Width, _Form.Height - 1);
            _Form.SetBounds(_Form.Left, _Form.Top, _Form.Width, _Form.Height + 1);
          }

          if (CommandItems.Control == null)
          {
            CommandItems.CallBeforeControlAssigned();
            CommandItems.SetControl(_Form);
            CommandItems.CallAfterControlAssigned();

            if (CommandItems.Count > 0)
            {
              EFPContextMenu ccm = new EFPContextMenu();
              ccm.Add(CommandItems);
              ccm.Attach(_Form);
            }
          }

          //bool AdjustFormSize = (FBounds == null); // нужно ли увеличивать размер формы при добавлении статусной строки?

          try
          {
            if (!_OwnStatusBar.HasValue)
              _OwnStatusBar = GetDefaultOwnStatusBar(); // фиксация значения свойства
            if (OwnStatusBar && _StatusStripControl == null)
              InitOwnStatusBar(/*AdjustFormSize*/ true); // должно быть до вызова Form.Activate(), иначе первый элемент не инициализирует статусную строку
            if (_StatusStripControl != null)
              _StatusBarHandler = new EFPStatusBarHandler(_StatusStripControl);
          }
          catch (Exception e)
          {
            EFPApp.ShowException(e, "Ошибка инициализации статусной строки формы");
          }


          // Должно быть обязательно после инициализации собственной статусной строки
          EFPFormBounds Bounds = GetSavedBounds();
          if (Bounds != null)
            Bounds.WriteValues(_Form);

          OnShown();
          _HasBeenShown = true;
        }

        // Подключение форм инструментов
        if (_Form.Modal && ToolFormsEnabled)
        {
          try
          {
            foreach (Form ToolForm in EFPApp.ToolFormsForDialogs)
            {
              if (ToolForm.IsDisposed)
                continue;
              ToolForm.Owner = _Form;
              ToolForm.Visible = true;
            }
          }
          catch (Exception e)
          {
            DebugTools.LogoutException(e, "Включение tool forms"); // без вывода диалога
          }
          Form.Activate(); // добавлено 17.12.2010 для работы формы предварительного просмотра
        }
      }
      else
      {
        // Отключение форм инструментов
        if (_Form.Modal && ToolFormsEnabled)
        {
          try
          {
            foreach (Form ToolForm in EFPApp.ToolFormsForDialogs)
            {
              if (ToolForm.IsDisposed)
                continue;
              ToolForm.Visible = false;
              ToolForm.Owner = null;
            }
          }
          catch (Exception e)
          {
            DebugTools.LogoutException(e, "Отключение tool forms");
          }
        }

        if (HasBeenShown)
        {
          if (_Form.Modal && (!String.IsNullOrEmpty(ConfigSectionName)))
          {
            EFPFormBounds Bounds = new EFPFormBounds();
            Bounds.ReadValues(_Form);
            _ModalFormBounds[ConfigSectionName] = Bounds;
          }


          OnHidden();
        }
      }
      // Подключение или отключение списка синхронизации к провайдеру
      if (HasSyncs)
      {
        if (SyncProvider != null)
        {
          if (isVisible)
            Syncs.Provider = SyncProvider;
          else
            Syncs.Provider = null;
        }
      }
      if (_FormHelpButtonClickedHandler != null)
      {
        // Присоединение обработчика кнопки "?" в заголовке 
        if (isVisible)
          _Form.HelpButtonClicked += _FormHelpButtonClickedHandler;
        else
          _Form.HelpButtonClicked -= _FormHelpButtonClickedHandler;
      }

      base.FormVisibleChanged(isVisible);
    }

    private EFPFormBounds GetSavedBounds()
    {
      if (_Form.Modal && (!String.IsNullOrEmpty(ConfigSectionName)))
      {
        EFPFormBounds Bounds;
        if (_ModalFormBounds.TryGetValue(ConfigSectionName, out Bounds))
          return Bounds;
      }

      return null;
    }

    void Form_Activated(object sender, EventArgs args)
    {
      Control StartActiveControl = Form.ActiveControl;
      if (StartActiveControl == null)
        StartActiveControl = Form.GetNextControl(null, true); // 24.08.2016
      if (StartActiveControl is TabControl)
        WinFormsTools.CorrectTabControlActivation((TabControl)(StartActiveControl));
    }

    #endregion

    #region Событие Shown

    /// <summary>
    /// Свойство возврашает true, если управляющий элемент был выведен на экран
    /// Свойство однократно переходит из false в true. Перед этим вызывается событие Shown
    /// Свойство Control.Visible может многократно изменяться еще до вывода элемента на экран
    /// </summary>
    public bool HasBeenShown { get { return _HasBeenShown; } }
    private bool _HasBeenShown;

    /// <summary>
    /// Событие вызывается при первом появлении элемента на экране
    /// </summary>
    public event EventHandler Shown;

    /// <summary>
    /// Метод вызывается при первом появлении элемента на экране
    /// Вызывает событие Shown и подготавливает команды локального меню
    /// Переопределенный метод обязательно должен вызывать базовый метод.
    /// На момент вызова, свойство HasBeenShown еще не установлено
    /// </summary>
    protected virtual void OnShown()
    {
      FirstReadConfig(); // перенесено в начало метода 04.10.2018

      if (Shown != null)
        Shown(this, EventArgs.Empty);

      InitControl(Form); // перенесено из конструктора 24.09.2018

      if (_UpdateByTimeHandlers != null)
      {
        CallUpdateByTime(); // сразу выполняем обновление
        EFPApp.Timers.Add(this);
      }

      if (CloseModalFormByEscape && Form.Modal)
        FormButtonStub.AssignCancel(Form);


      //if (!FClientMinimumSize.IsEmpty)
      //{
      //  int w = (int)(((float)FClientMinimumSize.Width) * AutoScaleFactor.Width);
      //  int h = (int)(((float)FClientMinimumSize.Height) * AutoScaleFactor.Height);
      //  WinFormsTools.SetFormClientMinimumSize(Form, new Size(w, h));
      //  FClientMinimumSize = Size.Empty;
      //}

      DelayedSetFocus();
    }

    /// <summary>
    /// Если свойство HasBeenShown установлено в true, генерирует исключение InvalidOperationException
    /// </summary>
    public void CheckHasNotBeenShown()
    {
      if (HasBeenShown)
        throw new InvalidOperationException("Форма " + _Form.ToString() + " уже была выведена на экран");
    }

    #endregion

    #region Событие Hidden

    /// <summary>
    /// Событие вызывается при закрытии формы с элементом при условии, что событие Shown было вызвано
    /// </summary>
    public event EventHandler Hidden;

    /// <summary>
    /// Вызывается при скрытии формы с экрана
    /// </summary>
    protected virtual void OnHidden()
    {
      EFPApp.Timers.Remove(this);

      if (Hidden != null)
        Hidden(this, EventArgs.Empty);

      if (_StatusBarHandler != null)
      {
        _StatusBarHandler.Dispose();
        _StatusBarHandler = null;
      }

      if (ConfigHandler != null)
        ConfigHandler.WriteConfigChanges(this.ConfigManager);
    }

    #endregion

    #region Обработка команд

    void ciHelp_Click(object sender, EventArgs args)
    {
      PerformCallHelp();
    }

    void ciDebug_Click(object sender, EventArgs args)
    {
      DebugTools.DebugObject(this, "Объект EFPFormProvider");
    }

    #endregion

    #region ChangeInfo

    /// <summary>
    /// Присоединение списка изменений
    /// Когда есть изменения, в заголовке рисуется звездочка
    /// </summary>
    public DepChangeInfo ChangeInfo
    {
      get { return _ChangeInfo; }
      set
      {
        if (_ChangeInfo != null)
        {
          // Отсоединяем обработчик
          _ChangeInfo.ChangedChanged -= _EHChangeInfo_ChangedChanged;
        }
        _ChangeInfo = value;
        if (value != null)
        {
          if (_EHChangeInfo_ChangedChanged == null)
            _EHChangeInfo_ChangedChanged = new EventHandler(ChangeInfo_ChangedChanged);
          value.ChangedChanged += _EHChangeInfo_ChangedChanged;
        }

        if (_ChangeInfo == null)
          ChangedFlag = false;
        else
          ChangedFlag = _ChangeInfo.Changed;
      }
    }
    private DepChangeInfo _ChangeInfo;

    private EventHandler _EHChangeInfo_ChangedChanged;

    private void ChangeInfo_ChangedChanged(object sender, EventArgs args)
    {
      ChangedFlag = _ChangeInfo.Changed;
    }

    internal bool ChangedFlag
    {
      get { return _ChangedFlag; }
      set
      {
        if (value == _ChangedFlag)
          return;
        _ChangedFlag = value;

        if (value)
          _Form.Text = "(*) " + _Form.Text;
        else if (_Form.Text.StartsWith("(*) "))
          _Form.Text = _Form.Text.Substring(4);
      }
    }
    private bool _ChangedFlag;

    #endregion

    #region Положения форм

    /// <summary>
    /// Сохраненные положения блоков диалога в течение сеанса работы программы.
    /// Ключ - имя секции конфигурации (EFPFormProvbider.ConfigSectionName)
    /// Значение - положение, размер и состояние формы
    /// </summary>
    private static Dictionary<string, EFPFormBounds> _ModalFormBounds = new Dictionary<string, EFPFormBounds>();

    #endregion

    #region Сохранение конфигурации

    /// <summary>
    /// Если свойство возвращает непустую строку, то форма умеет сохранять собственные
    /// данные в секциях конфигурации.
    /// Реализуется через ConfigHandler
    /// </summary>
    public string ConfigSectionName
    {
      get
      {
        if (ConfigHandler == null)
          return String.Empty;
        else
          return ConfigHandler.ConfigSectionName;
      }
      set
      {
        if (ConfigHandler != null)
          ConfigHandler.ConfigSectionName = value;
      }
    }


    /// <summary>
    /// Обработчик конфигурации. Равен null до вызова InitConfigHandler()
    /// Чтобы зарегистрировать категорию, для которой будут записываться данные секции конфигурации, конструктор производного класса вызывает ConfigHandler.Categories.Add(“Filters”). Методы коллекции могут вызываться только до OnShown().
    /// Если нужно записать конфигурацию, то должен быть установлен флаг для категории вызовом ConfigHandler.Changed[“Filters”]=true.
    /// </summary>
    public EFPConfigHandler ConfigHandler { get { return _ConfigHandler; } }
    private EFPConfigHandler _ConfigHandler;

    /// <summary>
    /// Вызывает ConfigHandler.ReadConfig() для чтения значений.
    /// Ничего не делает, если свойство ConfigSectionName не установлено.
    /// Повторные вызовы метода игнорируются
    /// Первоначальное чтение конфигурации формы.
    /// Как правило, этот метод вызывается из OnShown(), но может быть вызван досрочно внешним кодом.
    /// Не вызывайте этот метод из конструктора производного класса, так как конструктор класса-наследника
    /// (если он есть) может вызвать ошибку. К тому же, внешний код может, например, изменить ConfigManager.
    /// Не рекомендуется использовать этот метод без крайней необходимости.
    /// </summary>
    public void FirstReadConfig()
    {
      if (_FirstReadConfigCalled)
        return;
      _FirstReadConfigCalled = true;

      //if (ConfigHandler == null)
      //  return;

      if (!EFPApp.InsideLoadComposition)
      {
        PreloadConfigSections(EFPConfigMode.Read);
        ConfigHandler.ReadConfig(this.ConfigManager);
      }
    }
    private bool _FirstReadConfigCalled;

    /// <summary>
    /// Этот метод собирается список EFPPreloadConfigSectionInfo и вызывает EFPApp.ConfigManager.Preload()
    /// </summary>
    /// <param name="rwMode"></param>
    private void PreloadConfigSections(EFPConfigMode rwMode)
    {
      SingleScopeList<EFPConfigSectionInfo> ConfigInfos = new SingleScopeList<EFPConfigSectionInfo>();
      ConfigHandler.GetPreloadConfigSections(ConfigInfos, rwMode);

      List<EFPControlBase> Controls = new List<EFPControlBase>();
      base.GetItems<EFPControlBase>(Controls);
      for (int i = 0; i < Controls.Count; i++)
      {
        if (Controls[i].ConfigHandler != null)
          Controls[i].ConfigHandler.GetPreloadConfigSections(ConfigInfos, rwMode);
      }

      if (ConfigInfos.Count >= 2) // иначе смысла нет
        ConfigManager.Preload(ConfigInfos.ToArray(), rwMode);
    }

    #endregion

    #region IEFPConfigurable Members

    /// <summary>
    /// Добавляет в список <paramref name="categories"/> категории, для которых будут создаваться секции конфигурации.
    /// Непереопределенный метод добавляет только категорию "FormBounds".
    /// Не следует добавлять категории, которые записываются самими управляющими элементами.
    /// </summary>
    /// <param name="categories">Список для добавления категорий</param>
    /// <param name="rwMode">Режим чтения или записи</param>
    /// <param name="actionInfo">Информация о действии</param>
    public virtual void GetConfigCategories(ICollection<string> categories, EFPConfigMode rwMode, EFPConfigActionInfo actionInfo)
    {
      categories.Add(EFPConfigCategories.FormBounds);
    }

    /// <summary>
    /// Записывает секцию конфигурации
    /// </summary>
    /// <param name="category">Категория</param>
    /// <param name="cfg">Доступ к секции конфигурации</param>
    /// <param name="actionInfo">Информация о действии</param>
    public virtual void WriteConfigPart(string category, CfgPart cfg, EFPConfigActionInfo actionInfo)
    {
      if (category == EFPConfigCategories.FormBounds)
      {
        CfgPart cfg2;
        if (actionInfo.Purpose == EFPConfigPurpose.Composition)
          cfg2 = cfg;
        else
          cfg2 = cfg.GetChild(Form.Modal ? "Modal" : "Modeless", true);

        EFPFormBounds Bounds = new EFPFormBounds();
        Bounds.ReadValues(Form);
        Bounds.WriteConfig(cfg2);
      }
    }

    /// <summary>
    /// Читает секцию конфигурации
    /// </summary>
    /// <param name="category">Категория</param>
    /// <param name="cfg">Доступ к секции конфигурации</param>
    /// <param name="actionInfo">Информация о действии</param>
    public virtual void ReadConfigPart(string category, CfgPart cfg, EFPConfigActionInfo actionInfo)
    {
      if (category == EFPConfigCategories.FormBounds)
      {
        CfgPart cfg2;
        if (actionInfo.Purpose == EFPConfigPurpose.Composition)
          cfg2 = cfg;
        else
          cfg2 = cfg.GetChild(Form.Modal ? "Modal" : "Modeless", false);
        if (cfg2 != null)
        {
          EFPFormBounds Bounds = new EFPFormBounds();
          Bounds.ReadConfig(cfg2);
          Bounds.WriteValues(Form);
        }
      }
    }

    #endregion

    #region Чтение и запись композиции

    /// <summary>
    /// Имя класс для записи композиции окон.
    /// По умолчанию возвращает имя класса.
    /// Если свойство установлено как пустая строка, то окно не будет сохранять композицию
    /// </summary>
    public string ConfigClassName
    {
      get
      {
        if (_ConfigClassName == null)
          return Form.GetType().ToString();
        else
          return _ConfigClassName;
      }
      set { _ConfigClassName = value; }
    }
    private string _ConfigClassName = null; // различаем null и пустую строку

    /// <summary>
    /// Записывает композицию рабочего стола.
    /// Записываются как параметры самой формы, так и управляющих элементов,
    /// для которых это предусмотрено.
    /// Этот метод вызывается классом EFPAppInterface.
    /// </summary>
    /// <param name="cfg">Секция конфигурации</param>
    public void WriteComposition(CfgPart cfg)
    {
#if DEBUG
      if (cfg == null)
        throw new ArgumentNullException("cfg");
#endif

      cfg.SetString("Class", ConfigClassName);
      if (!String.IsNullOrEmpty(ConfigSectionName))
        cfg.SetString("ConfigSectionName", ConfigSectionName);
      cfg.SetString("Title", Form.Text);

      ConfigHandler.WriteComposition(cfg);

      List<EFPControlBase> Controls = new List<EFPControlBase>();
      GetItems<EFPControlBase>(Controls);
      for (int i = 0; i < Controls.Count; i++)
      {
        if (Controls[i].ConfigHandler == null)
          continue;

        if (String.IsNullOrEmpty(Controls[i].Control.Name))
          continue;
        CfgPart cfgControl = cfg.GetChild(Controls[i].Control.Name, true);
        Controls[i].ConfigHandler.WriteComposition(cfgControl);
      }
    }

    /// <summary>
    /// Восстанавливает композицию рабочего стола.
    /// Читаются как параметры самой формы, так и управляющих элементов,
    /// для которых это предусмотрено.
    /// Этот метод вызывается классом EFPAppInterface.
    /// </summary>
    /// <param name="cfg">Секция конфигурации</param>
    public void ReadComposition(CfgPart cfg)
    {
#if DEBUG
      if (cfg == null)
        throw new ArgumentNullException("cfg");
#endif

      ConfigHandler.ReadComposition(cfg);

      List<EFPControlBase> Controls = new List<EFPControlBase>();
      GetItems<EFPControlBase>(Controls);
      for (int i = 0; i < Controls.Count; i++)
      {
        Controls[i].LoadConfig(); // чтобы предотвратить отложенную инициализацию после EFPApp.InsideLoadComposition=true
        // Также инициализируются, например, фильтры.
        // Загружаются значения по умолчанию, т.к. ConfigHandler.LoadConfig() не вызывается

        if (Controls[i].ConfigHandler != null)
        {
          if (!String.IsNullOrEmpty(Controls[i].Control.Name))
          {
            CfgPart cfgControl = cfg.GetChild(Controls[i].Control.Name, false);
            if (cfgControl != null)
              Controls[i].ConfigHandler.ReadComposition(cfgControl);
          }
        }
      }
    }

    #endregion

    #region Минимальный размер формы
#if XXX // так не работает
    private SizeF DesignAutoScaleDimensions;


    /// <summary>
    /// Дублирует защищенное свойство Form.AutoScaleFactor
    /// </summary>
    private SizeF AutoScaleFactor
    {
      get 
      {
        SizeF sz1 = DesignAutoScaleDimensions;
        SizeF sz2=Form.CurrentAutoScaleDimensions;
        if (sz1.Width == 0 || sz1.Height == 0)
          return new SizeF(1, 1);
        else
          return new SizeF(sz2.Width / sz1.Width, sz2.Height / sz1.Height);
      }
    }

    public Size ClientMinimumSize
    {
      get
      {
        if (FClientMinimumSize.IsEmpty)
          return WinFormsTools.GetFormClientMinimumSize(Form);
        else
          return FClientMinimumSize;
      }
      set
      {
        CheckHasNotBeenShown();
        FClientMinimumSize = value;
      }
    }
    private Size FClientMinimumSize;
#endif

    #endregion

    #region Обновление по таймеру

    /// <summary>
    /// Пользовательские обработчики обновления формы по времени.
    /// Предотвращается вложенный вызов обработчиков.
    /// События могут не вызываться, если окно свернуто или закрыто другими окнами.
    /// 
    /// Если требуется обработка по таймеру, независимая от видимости формы на экране, то следует:
    /// 1. Реализовать интерфейс IEFPAppTimeHandler в программе
    /// 2. Переопределить OnVisibleChanged() и присоединить/отсоединить в нем форму к EFPApp.Timers
    /// </summary>
    public ICollection<EFPUpdateByTimeHandler> UpdateByTimeHandlers
    {
      get
      {
        if (_UpdateByTimeHandlers == null)
        {
          _UpdateByTimeHandlers = new List<EFPUpdateByTimeHandler>();
          if (HasBeenShown)
            EFPApp.Timers.Add(this);
        }
        return _UpdateByTimeHandlers;
      }
    }
    private List<EFPUpdateByTimeHandler> _UpdateByTimeHandlers;


    /// <summary>
    /// Вызывает событие UpdateByTime для всех присоединенных обработчиков, независимо от того, вышло требуемое время или нет.
    /// Значения свойств EFPUpdateByTimeHandler.Enabled игнорируется.
    /// </summary>
    public void CallUpdateByTime()
    {
      if (_UpdateByTimeHandlers == null)
        return;
      for (int i = 0; i < _UpdateByTimeHandlers.Count; i++)
        _UpdateByTimeHandlers[i].CallTick();
    }

    void IEFPAppTimeHandler.TimerTick()
    {
      if (_UpdateByTimeHandlers == null)
        return;
      if (_UpdateByTimeHandlers.Count == 0)
        return;

      // 20.10.2016
      // Не посылаем сигнал таймера, если окно свернуто
      if (Form.WindowState == FormWindowState.Minimized)
        return;
      if (Form.MdiParent != null)
      {
        if (Form.MdiParent.WindowState == FormWindowState.Minimized)
          return;
        if (Form.MdiParent.ActiveMdiChild != Form && Form.MdiParent.ActiveMdiChild != null) // активно другое MDI-окно
        {
          if (Form.MdiParent.ActiveMdiChild.WindowState == FormWindowState.Maximized)
            return;
        }
      }

      for (int i = 0; i < _UpdateByTimeHandlers.Count; i++)
        _UpdateByTimeHandlers[i].TimerTick();
    }

    #endregion

    #region Статусная строка

    /// <summary>
    /// Использовать собственную статусную строку для формы.
    /// Это - Ambient-свойство.
    /// Свойство может устанавливаться только до вывода формы на экран
    /// </summary>
    public bool OwnStatusBar
    {
      get
      {
        if (_OwnStatusBar.HasValue)
          return _OwnStatusBar.Value;
        else
          return GetDefaultOwnStatusBar();
      }
      set
      {
        if (HasBeenShown)
          throw new InvalidOperationException();
        _OwnStatusBar = value;
      }
    }
    private bool? _OwnStatusBar;

    /// <summary>
    /// Сброс ambient-свойства OwnStatusBar в значение по умолчанию
    /// </summary>
    public void ResetOwnStatusBar()
    {
      if (HasBeenShown)
        throw new InvalidOperationException();
      _OwnStatusBar = null;
    }


    private bool GetDefaultOwnStatusBar()
    {
      bool Res;
      try
      {
        Res = DoGetDefaultOwnStatusBar();
      }
      catch (Exception e) // 23.11.2018
      {
        LogoutTools.LogoutException(e, "EFPFormProvider.GetDefaultOwnStatusBar()");
        Res = false;
      }
      return Res;
    }

    private bool DoGetDefaultOwnStatusBar()
    {
      if (!EFPApp.AppWasInit)
        return false; // 13.12.2016

      if (!EFPApp.OwnStatusBarsIfNeeded)
        return false;

      if (EFPApp.ExternalDialogOwnerWindow == null) // 14.03.2017
      {
        // 14.01.2017
        // Проверяем, что уже есть максимизированный блок диалога
        if (EFPApp.IsMainThread) // наверное, не нужно
        {
          Form[] dlgs = EFPApp.GetDialogStack(); // наша форма тоже может быть в списке
          for (int i = 0; i < dlgs.Length; i++)
          {
#if DEBUG
            if (dlgs[i] == null)
              throw new NullReferenceException("Дырка в стеке блоков диалога");
#endif
            if (Object.ReferenceEquals(dlgs[i], this.Form)) // 06.12.2018 пропускаем себя в списке, т.к. определяем ниже
              continue;

            if (dlgs[i].WindowState == FormWindowState.Maximized)
              return ContainsControlWantedStatusBar(this);
          }
        }

        bool IsMaximized;
        EFPFormBounds Bounds = GetSavedBounds();
        if (Bounds != null)
          IsMaximized = (Bounds.WindowState == FormWindowState.Maximized); // исправлено 06.12.2018
        else
          IsMaximized = _Form.WindowState == FormWindowState.Maximized;

        bool IsFullScreenModal = _Form.Modal && IsMaximized;

        if (!IsFullScreenModal)
        {
          if (EFPApp.StatusBar != null) // 23.11.2018
          {
            if (EFPApp.StatusBar.StatusStripControl != null)
              return false;
          }
        }
      }

      if (ContainsControlWantedStatusBar(this))
        return true;
      return false;
    }

    private static bool ContainsControlWantedStatusBar(EFPBaseProvider baseProvider)
    {
      foreach (IEFPCheckItem item in baseProvider)
      {
        EFPControlBase efp = item as EFPControlBase;
        if (efp != null)
        {
          foreach (EFPCommandItem ci in efp.CommandItems)
          {
            if (ci.StatusBarUsage && ci.Visible /* 21.02.2020 */)
              return true;
          }
        }

        EFPBaseProvider Child = item as EFPBaseProvider;
        if (Child != null)
        {
          if (ContainsControlWantedStatusBar(Child)) // рекурсия
            return true;
        }
      }

      return false;
    }

    /// <summary>
    /// Управляющий элемент статусной строки для добавления панелек.
    /// Если для формы не предусмотрена собственная статусная строка, возвращается 
    /// EFPApp.StatusBar.Control.
    /// Свойство может быть установлено вручную (до вывода формы на экран) или статусная строка
    /// может быть создана автоматически, установкой свойства OwnStatusBar
    /// </summary>
    public StatusStrip StatusStripControl
    {
      get
      {
        if (_StatusStripControl == null)
          return EFPApp.StatusBar.StatusStripControl;
        else
          return _StatusStripControl;
      }
      set
      {
        if (HasBeenShown)
          throw new InvalidOperationException();

        _OwnStatusBar = (value != null);
        _StatusStripControl = value;
      }
    }
    private StatusStrip _StatusStripControl;

    /// <summary>
    /// Добавление внизу формы панели статусной строки
    /// </summary>                                                             
    private void InitOwnStatusBar(bool adjustFormSize)
    {
      _StatusStripControl = new StatusStrip();
      _StatusStripControl.Dock = DockStyle.Bottom;
      if (EFPApp.AppWasInit) // 24.11.2016
        _StatusStripControl.ImageList = EFPApp.MainImages;
      //FStatusStripControl.ShowItemToolTips = true;
      _StatusStripControl.AutoSize = false;
      //Form.PerformAutoScale();
      if (Form.CurrentAutoScaleDimensions.Height > 0)
        _StatusStripControl.Height = (int)Math.Round(24 * Form.CurrentAutoScaleDimensions.Height / 13F); // 18.02.2020
      else
        _StatusStripControl.Height = 24;
      Form.Controls.Add(_StatusStripControl);
      if (adjustFormSize)
      {
        if (Form.WindowState == FormWindowState.Normal) // ? более сложная проверка
          Form.Height += _StatusStripControl.Height;
      }
    }

    /// <summary>
    /// Обработчик локальной строки формы.
    /// </summary>
    public EFPStatusBarHandler StatusBarHandler
    {
      get
      {
        if (_StatusStripControl == null)
        {
          if (EFPApp.StatusBar == null)
            return null; // 22.07.2019
          else
            return EFPApp.StatusBar.StatusBarHandler;
        }
        else
          return _StatusBarHandler;
      }
    }
    private EFPStatusBarHandler _StatusBarHandler;


    #endregion

    #region Закрытие формы по нажатию клавиши Cancel

    /// <summary>
    /// Если свойство установлено в true (по умолчанию), свойство Form.CancelButton не установлено 
    /// (нет кнопки "Отмена") в блоке диалога) и форма выводится в модальном режиме, 
    /// то форма будет закрываться нажатием кнопки "Отмена"
    /// </summary>
    public bool CloseModalFormByEscape
    {
      get { return _CloseModalFormByEscape; }
      set { _CloseModalFormByEscape = value; }
    }
    private bool _CloseModalFormByEscape;

    #endregion

    #region Отложенная установка фокуса ввода

    /// <summary>
    /// Запоминается вызов EFPControlBase.SetFocus(), если форма или управляющий элемент еще не выведен на экран
    /// </summary>
    internal EFPControlBase DelayedSetFocusControlProvider;

    private void DelayedSetFocus()
    {
      if (DelayedSetFocusControlProvider != null)
      {
        if (DelayedSetFocusControlProvider.HasBeenShown)
        {
          WinFormsTools.FocusToControl(DelayedSetFocusControlProvider.Control);
          DelayedSetFocusControlProvider = null;
        }
      }
    }

    #endregion

    #region Поиск провайдера для формы

    private static WeakReferenceCollection<EFPFormProvider> _ProviderList = new WeakReferenceCollection<EFPFormProvider>();

    /// <summary>
    /// Поиск объекта EFPFormProvider, созданного для указанной формы.
    /// Если провадер не найден, возвращает null.
    /// Этот метод является потокобезопасным
    /// </summary>
    /// <param name="form">Форма, для которой нужно найти провайдер. Может быть null</param>
    /// <returns>Найденный провайдер или null</returns>
    public static EFPFormProvider FindFormProvider(Form form)
    {
      if (form == null)
        return null;
      foreach (EFPFormProvider Provider in _ProviderList)
      {
        if (Object.ReferenceEquals(Provider.Form, form))
          return Provider;
      }
      return null;
    }

    /// <summary>
    /// Возавращает полный список созданных объектов EFPFormProvider
    /// </summary>
    /// <returns>Массив объектов</returns>
    public static EFPFormProvider[] GetAllFormProviders()
    {
      return _ProviderList.ToArray();
    }

    #endregion

    #region Отладочные свойства

#if DEBUG

    /// <summary>
    /// Время создания объекта (для отладки)
    /// </summary>
    public DateTime DebugCreateTime { get { return _DebugCreateTime; } }
    private DateTime _DebugCreateTime;

    /// <summary>
    /// Отладочное свойство.
    /// Не использовать в прикладном коде.
    /// </summary>
    public ToolTip DebugTheToolTip { get { return _TheToolTip; } set { } }

    /// <summary>
    /// Отладочное свойство.
    /// Не использовать в прикладном коде.
    /// </summary>
    public Control[] DebugToolTipControls
    {
      get
      {
        Control[] a = new Control[_ToolTipTitles.Keys.Count];
        _ToolTipTitles.Keys.CopyTo(a, 0);
        return a;
      }
      set
      {
      }
    }

    /// <summary>
    /// Отладочное свойство.
    /// Не использовать в прикладном коде.
    /// </summary>
    public string[] DebugToolTipTitles
    {
      get
      {
        Control[] dc = DebugToolTipControls;
        string[] a = new string[dc.Length];
        for (int i = 0; i < dc.Length; i++)
          a[i] = _ToolTipTitles[dc[i]];
        return a;
      }
      set
      {
      }
    }

    /// <summary>
    /// Отладочное свойство.
    /// Не использовать в прикладном коде.
    /// </summary>
    public string[] DebugToolTipStrings
    {
      get
      {
        Control[] dc = DebugToolTipControls;
        string[] a = new string[dc.Length];
        for (int i = 0; i < dc.Length; i++)
          a[i] = _TheToolTip.GetToolTip(dc[i]);
        return a;
      }
      set
      {
      }
    }

    /// <summary>
    /// Отладочное свойство.
    /// Не использовать в прикладном коде.
    /// </summary>
    public ISite DebugTheToolTipSite { get { return _TheToolTip.Site; } set { } }

    /// <summary>
    /// Отладочное свойство.
    /// Не использовать в прикладном коде.
    /// </summary>
    public IContainer DebugTheToolTipContainer { get { return _TheToolTip.Container; } set { } }

#endif

    #endregion
  }

  /// <summary>
  /// Обработчик обновления формы по времени.
  /// Вызывает пользовательское событие с заданным интервалом времени для обновления формы.
  /// Событие не вызывается, если форма свернута или закрыта другими окнами.
  /// Пользовательский код может создать объект класса EFPFormUpdateByTimeHandler или производного от него и присоединить к
  /// списку EFPFormProvider.UpdateByTimeHandlers.
  /// Также обработчик можно присоединить к провайдеру любого управляющего элемента, используя EFPControlBase.UpdateByTimeHandlers
  /// </summary>
  public class EFPUpdateByTimeHandler
  {
    #region Конструкторы

    /// <summary>
    /// Создает объект без присоединенного обработчика события.
    /// Обновление будет вызываться 1 раз в секунду
    /// </summary>
    public EFPUpdateByTimeHandler()
    {
      _Enabled = true;
    }

    /// <summary>
    /// Создает объет с заданным интервалом обновления и присоединяет к нему пользовательский обработчик события
    /// </summary>
    /// <param name="tick">Пользовательский обработчик</param>
    /// <param name="interval">Период вызова обработчика события Tick. См. примечания к свойству Interval.</param>
    public EFPUpdateByTimeHandler(EventHandler tick, int interval)
      : this()
    {
      if (tick != null)
        this.Tick += tick;
      this.Interval = interval;
    }

    /// <summary>
    /// Создает объет с интервалом обновления 1 секунда и присоединяет к нему пользовательский обработчик события
    /// </summary>
    /// <param name="tick">Пользовательский обработчик</param>
    public EFPUpdateByTimeHandler(EventHandler tick)
      : this()
    {
      if (tick != null)
        this.Tick += tick;
    }

    #endregion

    #region Обновление по таймеру

    /// <summary>
    /// Обработчик для обновления формы по таймеру.
    /// Вызывается с интервалом, заданным свойством Interval
    /// Ошибки перехватываются. При первой ошибке выдается окно ShowException, далее выдается сообщение
    /// в статусной строке
    /// Предотвращается вложенный вызов события.
    /// Событие может не вызываться, если окно свернуто или закрыто другими окнами
    /// </summary>
    public event EventHandler Tick;

    /// <summary>
    /// Вызывает обработчик события Tick.
    /// </summary>
    /// <param name="args">Фиктивный объект. Передается обработчику события</param>
    protected virtual void OnTick(EventArgs args)
    {
      if (Tick != null)
        Tick(this, args);
    }

    /// <summary>
    /// Вызывает событие Tick, не взирая, прошло ли требуемое время.
    /// Исключения перехватываются.
    /// Свойство Enabled не учитывается. Событие вызывается, даже если обновление по таймеру отключено.
    /// </summary>
    public void CallTick()
    {
      if (Tick == null)
        return;

      // Убрано 04.09.2019
      // if (!Enabled)
      //  return;

      _Counter = 0;

      try
      {
        OnTick(EventArgs.Empty);
      }
      catch (Exception e)
      {
        if (_ErrorWasShown)
          EFPApp.ShowTempMessage("Ошибка обновления формы. " + e.Message);
        else
        {
          _ErrorWasShown = true;
          EFPApp.ShowException(e, "Ошибка обновления формы");
        }
      }
    }

    /// <summary>
    /// Внутренний счетчик пропущенных 1-секундных тиков таймера для реализации делителя
    /// </summary>
    private int _Counter;

    private bool _ErrorWasShown;

    /// <summary>
    /// Если сбросить в false, событие Tick вызываться не будет.
    /// Позволяет выполнять временное отключение обновления формы.
    /// По умолчанию свойство установлено в true.
    /// Событие Tick может быть вызвано при Enabled=false, если вызов выполняется программным способом, а не по таймеру.
    /// </summary>
    public bool Enabled
    {
      get { return _Enabled; }
      set
      {
        if (value == _Enabled)
          return;
        _Enabled = value;
        OnEnabledChanged(EventArgs.Empty);
        if (value)
          _Counter = 0;
      }
    }
    private bool _Enabled;

    /// <summary>
    /// Событие вызывается после изменения свойства Enabled
    /// </summary>
    public event EventHandler EnabledChanged;

    /// <summary>
    /// Вызывает обработчик события EnabledChanged
    /// </summary>
    /// <param name="args">Фиктивные аргументы</param>
    protected virtual void OnEnabledChanged(EventArgs args)
    {
      if (EnabledChanged != null)
        EnabledChanged(this, args);
    }

    /// <summary>
    /// Период обновления формы в миллисекундах с помощью события UpdateByTime.
    /// В текущей реализация периодичность задается с точностью до одной секунды.
    /// Свойство может динамически меняться в процессе работы.
    /// </summary>
    public int Interval
    {
      get { return (_PeriodDivider + 1) * 1000; }
      set
      {
        int NewPeriodDivider = value / 1000 - 1;
        if (NewPeriodDivider < 0)
          NewPeriodDivider = 0;
        if (NewPeriodDivider == _PeriodDivider)
          return;
        _PeriodDivider = NewPeriodDivider;
        OnIntervalChanged(EventArgs.Empty);
      }
    }
    private int _PeriodDivider;

    /// <summary>
    /// Событие вызыается при изменении значения свойства Interval
    /// </summary>
    public event EventHandler IntervalChanged;

    /// <summary>
    /// Вызывает обработчик события IntervalChanged
    /// </summary>
    /// <param name="args">Фиктивные аргументы</param>
    protected virtual void OnIntervalChanged(EventArgs args)
    {
      if (IntervalChanged != null)
        IntervalChanged(this, args);
    }

    internal void TimerTick()
    {
      _Counter++;
      if (Enabled /*04.09.2019 */ && _Counter > _PeriodDivider)
      {
        //System.Console.Beep(1000, 200);
        CallTick();
      }
    }

    #endregion
  }
}
