﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Data;

/*
 * The BSD License
 * 
 * Copyright (c) 2006-2015, Ageyev A.V.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace AgeyevAV.ExtForms
{
  /// <summary>
  /// Описание порядка сортировки для табличного просмотра
  /// Структура содержит имя основного столбца сортировки и порядок сортировки
  /// </summary>
  public struct EFPDataGridViewSortInfo
  {
    #region Конструктор

    /// <summary>
    /// Инициализация структуры
    /// </summary>
    /// <param name="columnNames">Имена столбцов EFPDataGridViewColumn.Name. Если задать несколько столбцов, 
    /// тогда будет использоваться тот столбец, который расположен ближе к левому краю просмотра</param>
    /// <param name="descend">false - сортировка по возрастанию (обычная), true - по убыванию</param>
    public EFPDataGridViewSortInfo(string[] columnNames, bool descend)
    {
#if DEBUG
      if (columnNames == null)
        throw new ArgumentNullException("ColumnNames");
#endif

      _ColumnNames = columnNames;
      _Descend = descend;
    }


    /// <summary>
    /// Инициализация структуры
    /// </summary>
    /// <param name="columnNames">Имена столбцов EFPDataGridViewColumn.Name. Можно задать несколько столбцов, разделенных запятыми,
    /// тогда будет использоваться тот столбец, который расположен ближе к левому краю просмотра</param>
    /// <param name="descend">false - сортировка по возрастанию (обычная), true - по убыванию</param>
    public EFPDataGridViewSortInfo(string columnNames, bool descend)
    {
#if DEBUG
      if (String.IsNullOrEmpty(columnNames))
        throw new ArgumentNullException("columnNames");
#endif

      _ColumnNames = columnNames.Split(',');
      _Descend = descend;
    }

    /// <summary>
    /// Инициализация структуры.
    /// Используется сортировка по возрастанию
    /// </summary>
    /// <param name="columnName">Имя столбца EFPDataGridViewColumn.Name</param>
    public EFPDataGridViewSortInfo(string columnName)
      : this(columnName, false)
    {
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Имена столбцов EFPDataGridViewColumn.Name, однин из которых можно использовать для сортировки.
    /// Если в просмотре есть несколько столбцов из списка, то выбирается тот, который виден ближе к левому краю просмотра.
    /// Если в просмотре нет ни одного видимого столбца, который можно использовать, то порядок сортировки нельзя задать
    /// щелчком мыши по заголовку, но можно выбрать с помощью локального меню
    /// </summary>
    public string[] ColumnNames
    {
      get
      {
        if (_ColumnNames == null)
          return DataTools.EmptyStrings;
        else
          return _ColumnNames;
      }
    }
    private string[] _ColumnNames;

    ///// <summary>
    ///// Имя столбца EFPDataGridViewColumn.Name
    ///// </summary>
    //public string ColumnName { get { return FColumnName; } }

    /// <summary>
    /// false - сортировка по возрастанию (обычная), true - по убыванию
    /// </summary>
    public bool Descend { get { return _Descend; } }
    private bool _Descend;

    /// <summary>
    /// Возвращает true, если структура не инициализирована
    /// </summary>
    public bool IsEmpty { get { return ColumnNames.Length == 0; } }

    /// <summary>
    /// Текстовое представление.
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
      if (IsEmpty)
        return "[не задано]";
      else
        return String.Join(",", _ColumnNames) + (_Descend ? "(по убыванию)" : String.Empty);
    }

    #endregion

    #region Статическое свойство

    /// <summary>
    /// Пустое значение
    /// </summary>
    public static readonly EFPDataGridViewSortInfo Empty = new EFPDataGridViewSortInfo();

    #endregion
  }

  /// <summary>
  /// Абстрактный базовый класс для задания порядка сортировки строк в табличном просмотре
  /// </summary>
  public abstract class EFPDataGridViewOrder
  {
    #region Свойства

    /// <summary>
    /// Название для позиции меню.
    /// Наличие символа "амперсанд" не допускается
    /// </summary>
    public string DisplayName
    {
      get
      {
        if (String.IsNullOrEmpty(_DisplayName))
          return ConfigValue;
        else
          return _DisplayName;
      }
      set
      {
        _DisplayName = value;
      }
    }
    private string _DisplayName;

    /// <summary>
    /// Строка, используемое для идентификации текущего порядка в секции конфигурации
    /// Может либо генерироваться автоматически (обычно), либо задаваться вручную
    /// </summary>
    public string ConfigValue
    {
      get
      {
        if (String.IsNullOrEmpty(_ConfigValue))
        {
          string s = GetDefaultConfigValue();
#if DEBUG
          if (String.IsNullOrEmpty(s))
            throw new NullReferenceException("Метод GetDefaultConfigValue() вернул пустую строку");
#endif
          return s;
        }
        else
          return _ConfigValue;
      }
      set
      {
        _ConfigValue = value;
      }
    }
    private string _ConfigValue;

    /// <summary>
    /// Возвращает строку, используемую для идентификации текущего порядка в секции конфигурации,
    /// если свойство ConfigValue не установлено в явном виде
    /// </summary>
    /// <returns>Непустая строка для идентификации</returns>
    protected abstract string GetDefaultConfigValue();

    /// <summary>
    /// Столбец для сортировки
    /// </summary>
    public EFPDataGridViewSortInfo SortInfo { get { return _SortInfo; } set { _SortInfo = value; } }
    private EFPDataGridViewSortInfo _SortInfo;

    /// <summary>
    /// Переопределенный метод должен выполнить требуемую сортировку
    /// </summary>
    /// <param name="controlProvider">Провайдер табличного просмотра, для которого нужно установить порядок сортировки</param>
    public abstract void PerformSort(EFPDataGridView controlProvider);

    /// <summary>
    /// Возвращает свойство DisplayName
    /// </summary>
    /// <returns>Текстовое представление</returns>
    public override string ToString()
    {
      return DisplayName;
    }

    /// <summary>
    /// Изображение для меню (треугольник)
    /// </summary>
    public string ImageKey
    {
      get
      {
        return SortInfo.Descend ? "Down" : "Up";
      }
    }

    #endregion
  }

  /// <summary>
  /// Неабстрактная реализация порядка сортировки строк в табличном просмотре, основанная на свойстве DataView.Sort
  /// </summary>
  public class EFPDataGridViewDVOrder : EFPDataGridViewOrder
  {
    #region Конструктор

    /// <summary>
    /// Создает порядок сортировки
    /// </summary>
    /// <param name="sort">Порядок сортировки в формате DataView.Sort</param>
    /// <param name="displayName">Отображаемое имя для меню</param>
    /// <param name="sortInfo">Описатель столбца табличного просмотра, используемого для щелчка мышью</param>
    public EFPDataGridViewDVOrder(string sort, string displayName, EFPDataGridViewSortInfo sortInfo)
    {
      _Sort = sort;

      base.DisplayName = displayName;

      if (sortInfo.IsEmpty && (!String.IsNullOrEmpty(sort)))
      {
        bool[] Descends;
        string[] FieldNames = DataTools.GetDataViewSortFieldNames(sort, out Descends);
        base.SortInfo = new EFPDataGridViewSortInfo(FieldNames[0], Descends[0]);

        if (String.IsNullOrEmpty(displayName))
          base.DisplayName = FieldNames[0] + (Descends[0] ? " (по убыванию)" : "");
      }
      else
        base.SortInfo = sortInfo;

    }

    #endregion

    #region Свойства

    /// <summary>
    /// Устанавливаемый порядок сортировки для свойства DataView.Sort (список полей через запятую; после имени поля может идти ASC или DESC)
    /// </summary>
    public string Sort { get { return _Sort; } }
    private string _Sort;

    /// <summary>
    /// Возвращает строку, используемую для идентификации текущего порядка в секции конфигурации,
    /// если свойство ConfigValue не установлено в явном виде.
    /// Возвращает свойство Sort.
    /// </summary>
    /// <returns>Свойство Sort</returns>
    protected override string GetDefaultConfigValue()
    {
      return _Sort;
    }

    #endregion

    #region Установка порядка сортировки

    /// <summary>
    /// Выполняет сортировку, устанавливая свойство DataView.Sort
    /// </summary>
    /// <param name="controlProvider">Провадер табличного просмотра</param>
    public override void PerformSort(EFPDataGridView controlProvider)
    {
      DataView dv = controlProvider.SourceAsDataView;
      if (dv == null)
        throw new Exception("Источником данных просмотра не является DataView");

      dv.Sort = Sort;
    }

    #endregion
  }

  /// <summary>
  /// Реализация свойства GridHanler.Orders
  /// </summary>
  public class EFPDataGridViewOrders : IEnumerable<EFPDataGridViewOrder>
  {
    #region Конструктор

    /// <summary>
    /// Создает пустой список
    /// </summary>
    /// <param name="owner">Объект EFPDataGridView, для которого создается список</param>
    public EFPDataGridViewOrders(EFPDataGridView owner)
    {
#if DEBUG
      if (owner == null)
        throw new ArgumentNullException("owner");
#endif
      _Owner = owner;
      _Items = new List<EFPDataGridViewOrder>();
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Объект - владелец
    /// </summary>
    public EFPDataGridView Owner { get { return _Owner; } }
    private EFPDataGridView _Owner;

    private List<EFPDataGridViewOrder> _Items;

    /// <summary>
    /// Возвращает количество элементов в списке
    /// </summary>
    public int Count { get { return _Items.Count; } }

    /// <summary>
    /// Возвращает элемент в заданной позиции
    /// </summary>
    /// <param name="index"></param>
    /// <returns></returns>
    public EFPDataGridViewOrder this[int index] { get { return _Items[index]; } }

    #endregion

    #region Методы добавления

    /// <summary>
    /// Очищает список
    /// </summary>
    public void Clear()
    {
      _Items.Clear();
      _Owner.DisableOrdering();
    }


    /// <summary>
    /// Добавляет новый порядок сортировки
    /// </summary>
    /// <param name="item">Описатель сортировки</param>
    public void Add(EFPDataGridViewOrder item)
    {
      if (item == null)
        throw new ArgumentNullException("item");

      _Items.Add(item);
      // Если первое поле в порядке сортировки присутствует в просмотре, то столбец
      // можно щелкать по заголовку
      EFPDataGridViewColumn Column = GetUsedColumn(item);
      if (Column != null)
        Column.GridColumn.SortMode = DataGridViewColumnSortMode.Programmatic;
    }

    /// <summary>
    /// Добавляет новый порядок сортировки
    /// </summary>
    /// <param name="sort">Порядок сортировки в формате DataView.Sort</param>
    /// <param name="displayName">Отображаемое название для меню</param>
    /// <param name="sortInfo">Описатель столбца табличного просмотра</param>
    /// <returns>Объект сортировки</returns>
    public EFPDataGridViewDVOrder Add(string sort, string displayName, EFPDataGridViewSortInfo sortInfo)
    {
      EFPDataGridViewDVOrder Item = new EFPDataGridViewDVOrder(sort, displayName, sortInfo);
      Add(Item);
      return Item;
    }

    /// <summary>
    /// Добавляет новый порядок сортировки.
    /// Описатель столбца табличного просмотра, используемого для щелчка мышью, создается автоматически.
    /// </summary>
    /// <param name="sort">Порядок сортировки в формате DataView.Sort</param>
    /// <param name="displayName">Отображаемое название для меню</param>
    /// <returns>Объект сортировки</returns>
    public EFPDataGridViewDVOrder Add(string sort, string displayName)
    {
      return Add(sort, displayName, EFPDataGridViewSortInfo.Empty);
    }

    /// <summary>
    /// Добавляет новый порядок сортировки.
    /// Отображаемое название для меню равно имени первого столбца.
    /// Описатель столбца табличного просмотра, используемого для щелчка мышью, создается автоматически.
    /// </summary>
    /// <param name="sort">Порядок сортировки в формате DataView.Sort</param>
    /// <returns>Объект сортировки</returns>
    public EFPDataGridViewDVOrder Add(string sort)
    {
      return Add(sort, String.Empty, EFPDataGridViewSortInfo.Empty);
    }

    #endregion

    #region IEnumerable<EFPDataGridOrder> Members

    /// <summary>
    /// Возвращает перечислитель по объектам EFPDataGridViewOrder в списке.
    /// </summary>
    /// <returns>Перечислитель</returns>
    public IEnumerator<EFPDataGridViewOrder> GetEnumerator()
    {
      return _Items.GetEnumerator();
    }

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
    {
      return _Items.GetEnumerator();
    }

    #endregion

    #region Другие методы

    /// <summary>
    /// Поиск объекта
    /// </summary>
    /// <param name="item">Описание порядка сортировки</param>
    /// <returns>Индекс в списке или (-1)</returns>
    public int IndexOf(EFPDataGridViewOrder item)
    {
      return _Items.IndexOf(item);
    }

    #region Индекс используемого столбца

    /// <summary>
    /// Возвращает индекс столбца табличного просмотра (DataGridViewColumn.Index), который будет использоваться для щелчка мыши для заданного порядка сортировки.
    /// Если в просмотре нет ни одного подходящего столбца, возвращается (-1)
    /// </summary>
    /// <param name="item">Порядок сортировки</param>
    /// <returns>Индекс столбца</returns>
    public int IndexOfUsedColumnName(EFPDataGridViewOrder item)
    {
      if (item == null)
        return (-1);

      if (item.SortInfo.IsEmpty)
        return -1;

      int BestColumnIndex = -1;
      int BestDisplayIndex = -1;
      for (int i = 0; i < item.SortInfo.ColumnNames.Length; i++)
      {
        int ColumnIndex = Owner.Columns.IndexOf(item.SortInfo.ColumnNames[i]);
        if (ColumnIndex < 0)
          continue;
        DataGridViewColumn Col = Owner.Control.Columns[ColumnIndex];
        if (!Col.Visible)
          continue; // скрытые столбцы не считаются

        int DisplayIndex = Col.DisplayIndex;
        if (BestColumnIndex < 0 || DisplayIndex < BestDisplayIndex)
        {
          BestColumnIndex = ColumnIndex;
          BestDisplayIndex = DisplayIndex;
        }
      }

      return BestColumnIndex;
    }

    /// <summary>
    /// Возвращает имя столбца табличного просмотра (EFPDataGridViewColumn.Name), который будет использоваться для щелчка мыши для заданного порядка сортировки.
    /// Если в просмотре нет ни одного подходящего столбца, возвращается пустая строка
    /// </summary>
    /// <param name="item">Порядок сортировки</param>
    /// <returns>Индекс столбца</returns>
    public string GetUsedColumnName(EFPDataGridViewOrder item)
    {
      int p = IndexOfUsedColumnName(item);
      if (p < 0)
        return String.Empty;
      else
        return Owner.Columns[p].Name;
    }

    /// <summary>
    /// Возвращает столбец EFPDataGridViewColumn, который будет использоваться для щелчка мыши для заданного порядка сортировки.
    /// Если в просмотре нет ни одного подходящего столбца, возвращается null
    /// </summary>
    /// <param name="item">Порядок сортировки</param>
    /// <returns>Индекс столбца</returns>
    public EFPDataGridViewColumn GetUsedColumn(EFPDataGridViewOrder item)
    {
      int p = IndexOfUsedColumnName(item);
      if (p < 0)
        return null;
      else
        return Owner.Columns[p];
    }

    #endregion

    /// <summary>
    /// Возвращает первый подходящий объект EFPDataGridViewOrder, который выбирается при щелчке мыши
    /// на заголовке столбца с заданным именем. См.IndexOfFirstColumnName.
    /// Возвращает null, если столбец не предназначен для щелкания.
    /// </summary>
    /// <param name="columnName">Имя столбца (EFPDataGridViewColumn.Name)</param>
    /// <returns>EFPDataGridViewOrder или null</returns>
    public EFPDataGridViewOrder FindFirstColumnName(string columnName)
    {
      int p = IndexOfFirstColumnName(columnName);
      if (p < 0)
        return null;
      else
        return _Items[p];
    }

    /// <summary>
    /// Выполняет поиск по имени столбца табличного просмотра, щелчок мыши на котором выполняет сортировку.
    /// Используется свойство EFPDataGridViewSortInfo.ColumnName.
    /// Возвращается индекс первого подходящего порядка сортировки. В списке может быть несколько
    /// порядков сортировки, переключаемых щелчком на этом столбце.
    /// Возвращает (-1), если столбец не предназначен для щелкания.
    /// </summary>
    /// <param name="columnName">Имя столбца (EFPDataGridViewColumn.Name)</param>
    /// <returns>Индекс первого подходящего EFPDataGridViewOrder или (-1)</returns>
    public int IndexOfFirstColumnName(string columnName)
    {
      if (String.IsNullOrEmpty(columnName))
        return -1;

      for (int i = 0; i < _Items.Count; i++)
      {
        if (GetUsedColumnName(_Items[i]) == columnName)
          return i;
      }
      return -1;
    }

    /// <summary>
    /// Возвращает строку "Count=XXX" для отладки
    /// </summary>
    /// <returns>Текстовое предсталение</returns>
    public override string ToString()
    {
      return "Count=" + _Items.Count.ToString();
    }

    #endregion

    #region Диалог выбора порядка строк

    /// <summary>
    /// Показать окно выбора порядка строк.
    /// Реальный порядок строк в просмотре не меняется
    /// </summary>
    /// <param name="orderIndex">Индекс выбранного порядка строк (вход и выход)</param>
    /// <returns>true, если выбор сделан</returns>
    public bool ShowSelectDialog(ref int orderIndex)
    {
      ListSelectDialog dlg = new ListSelectDialog();
      dlg.Title = "Порядок строк";
      dlg.ImageKey = "OrderAZ";
      dlg.Items = new string[_Items.Count];
      dlg.ImageKeys = new string[_Items.Count];
      for (int i = 0; i < _Items.Count; i++)
      {
        dlg.Items[i] = (i + 1).ToString() + ". " + _Items[i].DisplayName;
        dlg.ImageKeys[i] = _Items[i].ImageKey;
      }
      dlg.SelectedIndex = orderIndex;
      bool Res = dlg.ShowDialog() == DialogResult.OK;
      if (Res)
        orderIndex = dlg.SelectedIndex;
      return Res;
    }

    #endregion
  }
}
