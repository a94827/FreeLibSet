﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using AgeyevAV.DependedValues;
using AgeyevAV.IO;

/*
 * The BSD License
 * 
 * Copyright (c) 2006-2015, Ageyev A.V.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace AgeyevAV.ExtForms
{
  /*
   * Провайдеры управляющих элементов для полей выбора файлов и каталогов
   */

  /// <summary>
  /// Провайдер комбоблока с историей, предназначенного для выбора каталога на диске.
  /// Обычно этот комбоблок сопровождается кнопкой "Обзор", к которой присоединяется EFPFolderBrowserButton.
  /// Не проверяет наличие каталога на диске.
  /// </summary>
  public class EFPFolderHistComboBox : EFPHistComboBox
  {
    #region Конструктор

    /// <summary>
    /// Создает провайдер
    /// </summary>
    /// <param name="baseProvider">Базовый провайдер</param>
    /// <param name="control">Управляющий элемент</param>
    public EFPFolderHistComboBox(EFPBaseProvider baseProvider, ComboBox control)
      : base(baseProvider, control)
    {
    }

    #endregion

    #region Переопределенные методы

    /// <summary>
    /// Проверка введенного значения.
    /// Кроме проверки пустого значения, выполняемой базовым классом, проверяет наличие недопустимых символов.
    /// </summary>
    protected override void OnValidate()
    {
      base.OnValidate();
      if (ValidateState == EFPValidateState.Error)
        return;

      if (String.IsNullOrEmpty(Text))
        return;

      int p = Text.IndexOfAny(Path.GetInvalidPathChars());
      if (p >= 0)
        SetError("Недопустимый символ \"" + Text.Substring(p, 1) + "\" в позиции " + (p + 1).ToString());
    }

    #endregion
  }

  /// <summary>
  /// Провайдер комбоблока с историей, предназначенного для выбора файла на диске.
  /// Обычно этот комбоблок сопровождается кнопкой "Обзор", к которой присоединяется EFPFileDialogButton.
  /// Не проверяет наличие файла на диске.
  /// </summary>
  public class EFPFileHistComboBox : EFPHistComboBox
  {
    #region Конструктор

    /// <summary>
    /// Создает провайдер
    /// </summary>
    /// <param name="baseProvider">Базовый провайдер</param>
    /// <param name="control">Управляющий элемент</param>
    public EFPFileHistComboBox(EFPBaseProvider baseProvider, ComboBox control)
      : base(baseProvider, control)
    {
    }

    #endregion

    #region Переопределенные методы

    /// <summary>
    /// Проверка введенного значения.
    /// Кроме проверки пустого значения, выполняемой базовым классом, проверяет наличие недопустимых символов.
    /// </summary>
    protected override void OnValidate()
    {
      base.OnValidate();
      if (ValidateState == EFPValidateState.Error)
        return;

      if (String.IsNullOrEmpty(Text))
        return;

      string DirName = String.Empty;
      string FileName = Text;
      int p1 = Text.LastIndexOf('\\');
      if (p1 >= 0)
      {
        DirName = Text.Substring(0, p1);
        FileName = Text.Substring(p1 + 1);
      }
      int p = DirName.IndexOfAny(Path.GetInvalidPathChars());
      if (p >= 0)
        SetError("Недопустимый символ \"" + Text.Substring(p, 1) + "\" в позиции " + (p + 1).ToString());
      else
      {
        p = FileName.IndexOfAny(Path.GetInvalidFileNameChars());
        if (p >= 0)
          SetError("Недопустимый символ \"" + Text.Substring(p, 1) + "\" в позиции " + (DirName.Length + p + 1).ToString());

      }
    }

    #endregion
  }

  /// <summary>
  /// Кнопка "Обзор" для выбора каталога, имя которого вводится в поле ввода
  /// или комбоблоке с историей.
  /// Кнопка также может использоваться совместно с текстовым полем только для чтения, когда обработка каталога должна выполнятся 
  /// после выбора каталога, а не при закрытии формы.
  /// Событие EFPButton.Click вызывается только после того, как пользователь выбрал файл.
  /// </summary>
  public class EFPFolderBrowserButton : EFPButton
  {
    #region Конструктор

    /// <summary>
    /// Создает провайдер управляющего элемента кнопки
    /// </summary>
    /// <param name="mainProvider">Провайдер основного управляющего элемента,
    /// предназначенного для ввода пути. Обычно это EFPTextBox или EFPFolderHistComboBox</param>
    /// <param name="control">Управляющий элемент - кнопка "Обзор"</param>
    public EFPFolderBrowserButton(IEFPTextBox mainProvider, Button control)
      : base(mainProvider.BaseProvider, control)
    {
      _MainProvider = mainProvider;
      control.Image = EFPApp.MainImages.Images["Open"];
      control.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      VisibleEx = mainProvider.VisibleEx;
      EnabledEx = mainProvider.EnabledEx;
      ToolTipText = "Выбор папки с помощью стандартного блока диалога Windows";

      _AllowPathValidating = true;
      ((EFPControlBase)mainProvider).Validating += MainProvider_Validating;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Провайдер основного поля ввода иди комбоблока (задается в конструкторе)
    /// </summary>
    public IEFPTextBox MainProvider { get { return _MainProvider; } }
    private IEFPTextBox _MainProvider;

    /// <summary>
    /// Описание, появляющееся в блоке диалога выбора папки при нажатии кнопки
    /// Если свойство не задано, то в качестве пояснения будет использовано
    /// MainProvider.DisplayName
    /// </summary>
    public string Description { get { return _Description; } set { _Description = value; } }
    private string _Description;

    /// <summary>
    /// Наличие кнопки "Создать папку" в блоке диалога
    /// </summary>
    public bool ShowNewFolderButton { get { return _ShowNewFolderButton; } set { _ShowNewFolderButton = value; } }
    private bool _ShowNewFolderButton;

    /// <summary>
    /// Если свойство установлено в true (по умолчанию), то выполняется проверка
    /// корректности введенного имени каталога (отсутствие недопустимых символов,
    /// наличие завершающего разделителя). Реальное существование пути не проверяется
    /// Проверка на пустое значение не выполняется. Используйте свойство CanBeEmpty основного элемента
    /// </summary>
    public bool AllowPathValidating
    {
      get { return _AllowPathValidating; }
      set
      {
        if (value != _AllowPathValidating)
        {
          _AllowPathValidating = value;
          MainProvider.Validate();
        }
      }
    }
    private bool _AllowPathValidating;

    #endregion

    #region Проверка введенного текста

    void MainProvider_Validating(object sender, EFPValidatingEventArgs args)
    {
      if (args.ValidateState == EFPValidateState.Error)
        return;
      string Path = MainProvider.Text;
      if (String.IsNullOrEmpty(Path))
        return;

      string ErrorText;
      if (!FileTools.TestDirSlashedPath(Path, out ErrorText))
        args.SetError(ErrorText);
    }

    #endregion

    #region Обработчики

    /// <summary>
    /// Выводит стандартный блок диалога выбора каталога FolderBrowserDialog.
    /// Если пользователь закрыл диалог кнопкой "ОК", устанавливается свойство MainProvider.Text.
    /// Затем вызывается обработчик события EFPButton.Click.
    /// </summary>
    protected override void OnClick()
    {
      using (FolderBrowserDialog dlg = new FolderBrowserDialog())
      {
        if (String.IsNullOrEmpty(Description))
          dlg.Description = MainProvider.DisplayName;
        else
          dlg.Description = Description;
        dlg.ShowNewFolderButton = ShowNewFolderButton;
        dlg.SelectedPath = FileTools.RemoveDirNameSlash(MainProvider.Text);
        if (EFPApp.ShowDialog(dlg) == DialogResult.OK)
        {
          AbsPath Path = new AbsPath(dlg.SelectedPath);
          MainProvider.Text = Path.SlashedPath;
          base.OnClick();
        }
      }
    }

    #endregion
  }

  /// <summary>
  /// Кнопка "Обзор" для выбора файла, имя которого вводится в поле ввода
  /// или комбоблоке с историей.
  /// Кнопка также может использоваться совместно с текстовым полем только для чтения, когда обработка файла должна выполнятся 
  /// после выбора файла, а не при закрытии формы.
  /// Событие EFPButton.Click вызывается только после того, как пользователь выбрал файл.
  /// </summary>
  public class EFPFileDialogButton : EFPButton
  {
    #region Конструктор

    /// <summary>
    /// Создает провайдер управляющего элемента кнопки
    /// </summary>
    /// <param name="mainProvider">Провайдер основного управляющего элемента,
    /// предназначенного для ввода пути. Обычно это EFPTextBox или EFPFileHistComboBox</param>
    /// <param name="control">Управляющий элемент - кнопка "Обзор"</param>
    public EFPFileDialogButton(IEFPTextBox mainProvider, Button control)
      : base(mainProvider.BaseProvider, control)
    {
      _MainProvider = mainProvider;
      control.Image = EFPApp.MainImages.Images["Open"];
      control.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      VisibleEx = mainProvider.VisibleEx;
      EnabledEx = mainProvider.EnabledEx;
      ToolTipText = "Выбор файла с помощью стандартного блока диалога Windows";
      Mode = FileDialogMode.Read;

      _AllowPathValidating = true;
      ((EFPControlBase)mainProvider).Validating += MainProvider_Validating;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Провайдер основного поля ввода иди комбоблока (задается в конструкторе)
    /// </summary>
    public IEFPTextBox MainProvider { get { return _MainProvider; } }
    private IEFPTextBox _MainProvider;

    /// <summary>
    /// Описание, появляющееся в блоке диалога выбора папки при нажатии кнопки
    /// Если свойство не задано, то в качестве пояснения будет использовано
    /// MainProvider.DisplayName
    /// </summary>
    public string Title { get { return _Title; } set { _Title = value; } }
    private string _Title;

    /// <summary>
    /// Значение для свойства Filter (с разделителями "|")
    /// </summary>
    public string Filter { get { return _Filter; } set { _Filter = value; } }
    private string _Filter;

    /// <summary>
    /// Вариант диалога для выбора существующего файла или записи
    /// </summary>
    public FileDialogMode Mode { get { return _Mode; } set { _Mode = value; } }
    private FileDialogMode _Mode;

    /// <summary>
    /// Каталог.
    /// При открытии диалога используется в качестве свойства FileDialog.InitialDirectory,
    /// если в поле ввода не задано имя файла.
    /// После того, как файл выбран в диалоге, содержит каталог, соответствующий FileDialog.FileName
    /// </summary>
    public AbsPath Directory
    {
      get { return _Directory; }
      set { _Directory = value; }
    }
    private AbsPath _Directory;

    /// <summary>
    /// Если свойство установлено в true (по умолчанию), то выполняется проверка
    /// корректности введенного имени файла (отсутствие недопустимых символов,
    /// отсутствие завершающего разделителя). Реальное существование пути не проверяется.
    /// Проверка на пустое значение не выполняется. Используйте свойство CanBeEmpty основного элемента
    /// </summary>
    public bool AllowPathValidating
    {
      get { return _AllowPathValidating; }
      set
      {
        if (value != _AllowPathValidating)
        {
          _AllowPathValidating = value;
          MainProvider.Validate();
        }
      }
    }
    private bool _AllowPathValidating;

    #endregion

    #region Проверка введенного текста

    void MainProvider_Validating(object sender, EFPValidatingEventArgs args)
    {
      if (args.ValidateState == EFPValidateState.Error)
        return;
      string Path = MainProvider.Text;
      if (String.IsNullOrEmpty(Path))
        return;

      string ErrorText;
      if (!FileTools.TestFilePath(Path, out ErrorText))
        args.SetError(ErrorText);
    }

    #endregion

    #region Обработчики

    /// <summary>
    /// Выводит стандартный блок диалога выбора файла OpenFileDialog или SaveFileDialog,
    /// в зависимости от свойства Mode. Свойство FileName устанавливается равным текущему значению в поле ввода.
    /// Если диалог закрыт нажатием кнопки "ОК" (файл выбран пользователем), устанавливается свойство MainProvider.Text.
    /// Затем вызывается обработчик события EFPButton.Click.
    /// </summary>
    protected override void OnClick()
    {
      FileDialog dlg;
      if (Mode == FileDialogMode.Read)
        dlg = new OpenFileDialog();
      else
        dlg = new SaveFileDialog();

      using (dlg)
      {
        if (String.IsNullOrEmpty(Title))
          dlg.Title = MainProvider.DisplayName;
        else
          dlg.Title = Title;
        dlg.Filter = Filter;
        dlg.FileName = MainProvider.Text;
        if (String.IsNullOrEmpty(dlg.FileName))
          dlg.InitialDirectory = Directory.Path;
        else
        {
          try
          {
            AbsPath p = new AbsPath(dlg.FileName);
            dlg.InitialDirectory = p.ParentDir.Path;
          }
          catch { }
        }

        if (EFPApp.ShowDialog(dlg) == DialogResult.OK)
        {
          MainProvider.Text = dlg.FileName;
          AbsPath p = new AbsPath(dlg.FileName);
          Directory = p.ParentDir;
          base.OnClick();
        }
      }
    }

    #endregion
  }

  /// <summary>
  /// Кнопка "Проводник Windows" для просмотра каталогов с помощью Windows
  /// Имя каталога или файла вводится в присоединенном поле ввода
  /// или комбоблоке с историей.
  /// Кнопка проводника может (и, обычно, должна, если только поле ввода не используется
  /// исключительно в режиме просмотра (ReadOnly=true)) использоваться совместно с кнопкой "Обзор"
  /// и провайдером EFPFolderBrowserButton.
  /// </summary>
  public class EFPWindowsExplorerButton : EFPButton
  {
    #region Конструктор

    /// <summary>
    /// Создает провайдер управляющего элемента
    /// </summary>
    /// <param name="mainProvider">Основной провайдер для поля ввода каталога.
    /// Обычно это EFPTextBox или EFPFolderHistComboBox</param>
    /// <param name="control">Управляющий элемент кнопки</param>
    public EFPWindowsExplorerButton(IEFPTextBox mainProvider, Button control)
      : base(mainProvider.BaseProvider, control)
    {
      _MainProvider = mainProvider;
      control.Image = EFPApp.MainImages.Images["WindowsExplorer"];
      control.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
      VisibleEx = mainProvider.VisibleEx;
      if (EFPApp.IsWindowsExplorerSupported)
      {
        EnabledEx = new DepExpr2<bool, bool, string>(mainProvider.EnabledEx, mainProvider.TextEx,
          new DepFunction2<bool, bool, string>(CalcEnabled));
        ToolTipText = "Открытие выбранной папки с помощью Проводника Windows";
      }
      else
      {
        Enabled = false;
        ToolTipText = "Открытие выбранной папки не поддерживается операционной системой";
      }
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Провайдер основного поля ввода иди комбоблока (задается в конструкторе)
    /// </summary>
    public IEFPTextBox MainProvider { get { return _MainProvider; } }
    private IEFPTextBox _MainProvider;

    /// <summary>
    /// Что вводится в строке: имя файла или имя каталога.
    /// Если свойство не установлено, то определяется автоматически, исходя из
    /// существования файла или каталога и наличия расширении в имени.
    /// Если введенное имя заканчивается на "\", то свойство игнорируется и
    /// предполагается каталог
    /// </summary>
    public bool? IsFileName { get { return _IsFileName; } set { _IsFileName = value; } }
    private bool? _IsFileName;

    #endregion

    #region Обработчики

    private static bool CalcEnabled(bool arg1, string arg2)
    {
      if (arg1)
        return (!String.IsNullOrEmpty(arg2));
      else
        return false;
    }

    /// <summary>
    /// Сначала вызывается обработчик события EFPButton.Click, если он установлен.
    /// Затем вызывается метод EFPApp.ShowWindowsExplorer() для открытия окна проводника
    /// </summary>
    protected override void OnClick()
    {
      string s = MainProvider.Text;
      if (String.IsNullOrEmpty(s))
      {
        EFPApp.ShowTempMessage("Имя не задано");
        return;
      }

      bool IsSlashed = s[s.Length - 1] == System.IO.Path.DirectorySeparatorChar;
      s = FileTools.RemoveDirNameSlash(s);
      s = Path.GetFullPath(s);
      if (!IsSlashed)
      {
        if (IsFileName.HasValue)
        {
          if (IsFileName.Value)
            s = Path.GetDirectoryName(s);
        }
        else
        {
          if (!Directory.Exists(s))
          {
            string s1 = Path.GetDirectoryName(s);
            if (File.Exists(s) || Directory.Exists(s1))
              s = s1;
            else
            {
              if (!String.IsNullOrEmpty(Path.GetExtension(s)))
                s = s1; // раз есть расширение, значит введено, наверное, имя файла
            }
          }
        }
      }

      if (EFPApp.ShowWindowsExplorer(new AbsPath(s)))
        base.OnClick();
    }

    #endregion
  }
}
