﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Data;

/*
 * The BSD License
 * 
 * Copyright (c) 2006-2015, Ageyev A.V.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace AgeyevAV.ExtForms
{
  /// <summary>
  /// Реализация свойства EFPDataTreeView.Orders
  /// Использует объекты EFPDataGridViewOrder от табличного просмотра
  /// </summary>
  public class EFPDataTreeViewOrders : IEnumerable<EFPDataGridViewOrder>
  {
    #region Конструктор

    /// <summary>
    /// Создает объект
    /// </summary>
    /// <param name="owner">Провайдер просмотра</param>
    public EFPDataTreeViewOrders(EFPDataTreeView owner)
    {
      _Owner = owner;
      _Items = new List<EFPDataGridViewOrder>();
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Провайдер просмотра
    /// </summary>
    public EFPDataTreeView Owner { get { return _Owner; } }
    private EFPDataTreeView _Owner;

    private List<EFPDataGridViewOrder> _Items;

    /// <summary>
    /// Возвращает количество присоединенных порядков сортировки
    /// </summary>
    public int Count { get { return _Items.Count; } }

    /// <summary>
    /// Доступ к порядку сортировки по индексу
    /// </summary>
    /// <param name="index">Индекс от 0 до (Count-1)</param>
    /// <returns>Объект EFPDataGridViewOrder</returns>
    public EFPDataGridViewOrder this[int index] { get { return _Items[index]; } }

    #endregion

    #region Методы добавления

    /// <summary>
    /// Удаляет все порядки сортировки
    /// </summary>
    public void Clear()
    {
      _Items.Clear();
      _Owner.DisableOrdering();
    }


    /// <summary>
    /// Добавить порядок сортировки
    /// </summary>
    /// <param name="item">Описание порядка</param>
    public void Add(EFPDataGridViewOrder item)
    {
      if (item == null)
        throw new ArgumentNullException("item");

      _Items.Add(item);
      // Если первое поле в порядке сортировки присутствует в просмотре, то столбец
      // можно щелкать по заголовку

      /*
      EFPDataGridViewColumn Column = FOwner.Columns[Item.SortInfo.ColumnName];
      if (Column != null)
        Column.GridColumn.SortMode = DataGridViewColumnSortMode.Programmatic;*/
    }

    /// <summary>
    /// Добавить порядок сортировки для DataView
    /// </summary>
    /// <param name="sort">Порядок сортировки в формате DataView.Sort</param>
    /// <param name="displayName">Отображаемое название порядка для локального меню</param>
    /// <param name="sortInfo">Описатель столбца просмотра для сортировки</param>
    /// <returns>Описатель порядка сортировки</returns>
    public EFPDataGridViewDVOrder Add(string sort, string displayName, EFPDataGridViewSortInfo sortInfo)
    {
      EFPDataGridViewDVOrder Item = new EFPDataGridViewDVOrder(sort, displayName, sortInfo);
      Add(Item);
      return Item;
    }

    /// <summary>
    /// Добавить порядок сортировки для DataView
    /// </summary>
    /// <param name="sort">Порядок сортировки в формате DataView.Sort</param>
    /// <param name="displayName">Отображаемое название порядка для локального меню</param>
    /// <returns>Описатель порядка сортировки</returns>
    public EFPDataGridViewDVOrder Add(string sort, string displayName)
    {
      return Add(sort, displayName, EFPDataGridViewSortInfo.Empty);
    }

    /// <summary>
    /// Добавить порядок сортировки для DataView.
    /// Отображаемое название порядка для локального меню определяется из <paramref name="sort"/>.
    /// </summary>
    /// <param name="sort">Порядок сортировки в формате DataView.Sort</param>
    /// <returns>Описатель порядка сортировки</returns>
    public EFPDataGridViewDVOrder Add(string sort)
    {
      return Add(sort, String.Empty, EFPDataGridViewSortInfo.Empty);
    }

    #endregion

    #region IEnumerable<EFPDataGridOrder> Members

    /// <summary>
    /// Возвращает перечислитель по порядкам сортировки
    /// </summary>
    /// <returns></returns>
    public IEnumerator<EFPDataGridViewOrder> GetEnumerator()
    {
      return _Items.GetEnumerator();
    }

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
    {
      return _Items.GetEnumerator();
    }

    #endregion

    #region Другие методы

    /// <summary>
    /// Поиск описателя порядка сортировки по ссылке
    /// </summary>
    /// <param name="item">Искомый объект</param>
    /// <returns>Индекс или (-1)</returns>
    public int IndexOf(EFPDataGridViewOrder item)
    {
      return _Items.IndexOf(item);
    }

    #region Индекс используемого столбца

    /// <summary>
    /// Возвращает индекс столбца табличного просмотра (DataGridViewColumn.Index), который будет использоваться для щелчка мыши для заданного порядка сортировки.
    /// Если в просмотре нет ни одного подходящего столбца, возвращается (-1)
    /// </summary>
    /// <param name="item">Порядок сортировки</param>
    /// <returns>Индекс столбца</returns>
    public int IndexOfUsedColumnName(EFPDataGridViewOrder item)
    {
      if (item == null)
        return (-1);

      if (item.SortInfo.IsEmpty)
        return -1;

      int BestColumnIndex = -1;

      // TODO: 19.06.2019
      //int BestDisplayIndex = -1;
      //for (int i = 0; i < Item.SortInfo.ColumnNames.Length; i++)
      //{
      //  int ColumnIndex = Owner.Columns.IndexOf(Item.SortInfo.ColumnNames[i]);
      //  if (ColumnIndex < 0)
      //    continue;
      //  DataGridViewColumn Col = Owner.Control.Columns[ColumnIndex];
      //  if (!Col.Visible)
      //    continue; // скрытые столбцы не считаются

      //  int DisplayIndex = Col.DisplayIndex;
      //  if (BestColumnIndex < 0 || DisplayIndex < BestDisplayIndex)
      //  {
      //    BestColumnIndex = ColumnIndex;
      //    BestDisplayIndex = DisplayIndex;
      //  }
      //}

      return BestColumnIndex;
    }

    /// <summary>
    /// Возвращает имя столбца табличного просмотра (EFPDataGridViewColumn.Name), который будет использоваться для щелчка мыши для заданного порядка сортировки.
    /// Если в просмотре нет ни одного подходящего столбца, возвращается пустая строка
    /// </summary>
    /// <param name="item">Порядок сортировки</param>
    /// <returns>Индекс столбца</returns>
    public string GetUsedColumnName(EFPDataGridViewOrder item)
    {
      return String.Empty;
      // TODO: 19.06.2019
      //int p = IndexOfUsedColumnName(Item);
      //if (p < 0)
      //  return String.Empty;
      //else
      //  return Owner.Columns[p].Name;
    }

    /// <summary>
    /// Возвращает столбец EFPDataGridViewColumn, который будет использоваться для щелчка мыши для заданного порядка сортировки.
    /// Если в просмотре нет ни одного подходящего столбца, возвращается null
    /// </summary>
    /// <param name="item">Порядок сортировки</param>
    /// <returns>Индекс столбца</returns>
    public EFPDataGridViewColumn GetUsedColumn(EFPDataGridViewOrder item)
    {
      return null;
      // TODO: 19.06.2019
      //int p = IndexOfUsedColumnName(Item);
      //if (p < 0)
      //  return null;
      //else
      //  return Owner.Columns[p];
    }

    #endregion

    /// <summary>
    /// Возвращает (первый) порядок сортировки, для которого в SortInfo задан указанный столбец.
    /// </summary>
    /// <param name="columnName">Имя столбца для поиска</param>
    /// <returns>Объект EFPDataGridViewOrder или null</returns>
    public EFPDataGridViewOrder FindFirstColumnName(string columnName)
    {
      int p = IndexOfFirstColumnName(columnName);
      if (p < 0)
        return null;
      else
        return _Items[p];
    }

    /// <summary>
    /// Возвращает (первый) порядок сортировки, для которого в SortInfo задан указанный столбец.
    /// Возвращает позицию порядка сортировки в списке или (-1).
    /// </summary>
    /// <param name="columnName">Имя столбца для поиска</param>
    /// <returns>Индекс порядка сортировки</returns>
    public int IndexOfFirstColumnName(string columnName)
    {
      if (String.IsNullOrEmpty(columnName))
        return -1;

      for (int i = 0; i < _Items.Count; i++)
      {
        if (GetUsedColumnName(_Items[i]) == columnName)
          return i;
      }
      return -1;
    }

    /// <summary>
    /// Возвращает "Count=XXX" для отладки
    /// </summary>
    /// <returns>Текстовое представление</returns>
    public override string ToString()
    {
      return "Count=" + _Items.Count.ToString();
    }

    #endregion

    #region Диалог выбора порядка строк

    /// <summary>
    /// Показать окно выбора порядка строк.
    /// Реальный порядок строк в просмотре не меняется
    /// </summary>
    /// <param name="orderIndex">Индекс выбранного порядка строк (вход и выход)</param>
    /// <returns>true, если выбор сделан</returns>
    public bool ShowSelectDialog(ref int orderIndex)
    {
      ListSelectDialog dlg = new ListSelectDialog();
      dlg.Title = "Порядок строк";
      dlg.ImageKey = "OrderAZ";
      dlg.Items = new string[_Items.Count];
      dlg.ImageKeys = new string[_Items.Count];
      for (int i = 0; i < _Items.Count; i++)
      {
        dlg.Items[i] = (i + 1).ToString() + ". " + _Items[i].DisplayName;
        dlg.ImageKeys[i] = _Items[i].ImageKey;
      }
      dlg.SelectedIndex = orderIndex;
      bool Res = dlg.ShowDialog() == DialogResult.OK;
      if (Res)
        orderIndex = dlg.SelectedIndex;
      return Res;
    }

    #endregion
  }
}
