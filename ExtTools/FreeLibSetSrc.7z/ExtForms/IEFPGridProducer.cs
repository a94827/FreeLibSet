﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

/*
 * The BSD License
 * 
 * Copyright (c) 2006-2015, Ageyev A.V.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace AgeyevAV.ExtForms
{
  // Интерфейсы генераторов табличных просмотров

  #region IEFPGridProducer

  /// <summary>
  /// Обобщенный интерфейс генератора табличного просмотра
  /// Не уточняет способа, каким инициализируются столбцы табличного просмотра
  /// </summary>
  public interface IEFPGridProducer
  {
    /// <summary>
    /// Возвращает количество возможных вариантов сортировки для определения видимости команд меню.
    /// </summary>
    int OrderCount { get;}

    /// <summary>
    /// Метод должен создать столбцы в табличном просмотре в соответствии с установленной конфигурацией
    /// (установки свойства EFPDataGridView.CurrentConfig)
    /// На момент вызова табличный просмотр не содержит столбцов
    /// После вызова этого метода следует вызвать EFPDataGridView.PerformGridProducerPostInit()
    /// </summary>
    /// <param name="controlProvider">Заполняемый просмотр</param>
    /// <param name="reInit">true, если свойство устанавливается повторно</param>
    void InitGrid(EFPDataGridView controlProvider, bool reInit);
  }

  #endregion

  #region IEFPGridProducerColumn

  /// <summary>
  /// Интерейс объекта, управляющего поведением столбца, созданного генератором табличного просмотра
  /// Реализация IEFPGridProducer может не использовать этот интерфейс, или использовать его не для всех
  /// столбцов, или использовать один объект для нескольких столбцов
  /// </summary>
  public interface IEFPGridProducerColumn
  {
    /// <summary>
    /// Возращает имя столбца
    /// </summary>
    string ColumnName { get; }

    /// <summary>
    /// Вызывается из EFPDataGridView.PerformRefresh() для сброса буферизации, если она используется столбцом
    /// </summary>
    void Refresh();

    /// <summary>
    /// Выполнить редактирование для ячейки.
    /// Вызывается из EFPDataGridView.PerformEditData()
    /// Если метод выполнил действия, связанные с редактированием, следует вернуть true. В этом случае дальнейшая обработрка не выполняется
    /// Если следует выполнить обычные действия по редактированию, в частности, вызвать событие EFPDataGridView.EditData,
    /// следует вернуть false
    /// </summary>
    /// <param name="column">Текущий столбец в табличном просмотре</param>
    /// <param name="rowIndex">Индекс текущей строки в табличном просмотре</param>
    /// <returns>true, если обработка выполнена</returns>
    bool CellEdit(EFPDataGridViewColumn column, int rowIndex);

    /// <summary>
    /// Методы вызывается при щелчке мыши на ячейке
    /// </summary>
    /// <param name="column">Столбец табличного просмотра</param>
    /// <param name="rowIndex">Индекс строки в табличном просмотре</param>
    void OnCellClick(EFPDataGridViewColumn column, int rowIndex);

    /// <summary>
    /// Свойство возвращает true, если для столбца должен вызываться метод OnGetCellAttributes()
    /// </summary>
    bool HasGetCellAttributes { get; }

    /// <summary>
    /// Выполнить форматирование ячейки.
    /// Если метод определен, свойство HasGetCellAttributes должно возвращать true
    /// </summary>
    /// <param name="cetCellAttributesArgs"></param>
    void OnGetCellAttributes(EFPDataGridViewCellAttributesEventArgs cetCellAttributesArgs);
  }

  #endregion

  #region IEFPConfigurableGridProducer

  /// <summary>
  /// Интерфейс настраиваемого генератора табличного просмотра.
  /// В отличие от IEFPGridProducer, предполагает возможность пользователя настраивать индивидуальные столбцы
  /// на уровне EFPDataGrifViewConfig
  /// Интерфейс используется на уровне EFPDataGridViewWithFilters, а не EFPDataGridView.
  /// </summary>
  public interface IEFPConfigurableGridProducer : IEFPGridProducer
  {
    /// <summary>
    /// Инициализация редактора настройки столбцов табличного просмотра.
    /// Метод должен добавить управляющие элементы в форму редактора и вернуть интерфейс управления.
    /// Загружать начальные значения в редактор не следует
    /// </summary>
    /// <param name="parentControl">Панель в окне настройки формы для размещения элементов редактора</param>
    /// <param name="baseProvider">Базовый провайдер редактора настроек</param>
    /// <param name="callerControlProvider">Провайдер настраиваемого табличного просмотра</param>
    /// <returns>Интерфейс объекта редактора</returns>
    IEFPGridProducerEditor CreateEditor(Control parentControl, EFPBaseProvider baseProvider, IEFPGridControl callerControlProvider);
  }

  #endregion

  #region IEFPGridProducerEditor

  /// <summary>
  /// Редактор настройки табличного просмотра с настройкой индивидуальных столбцов
  /// </summary>
  public interface IEFPGridProducerEditor
  {
    /// <summary>
    /// Перенести значения из <paramref name="config"/> в форму редактора.
    /// Метод вызывается при открытии формы, а также при выборе пользователем конфигурации из списка истории
    /// </summary>
    /// <param name="config">Настройка, откуда должны быть извлечены данные</param>
    void WriteFormValues(EFPDataGridViewConfig config);

    /// <summary>
    /// Перенести значения из формы редактора в <paramref name="config"/>.
    /// При этом выполняется проверка формы
    /// Метод вызывается при нажатии кнопки "ОК"
    /// </summary>
    /// <param name="config">Настройка, откуда должны быть извлечены данные</param>
    /// <param name="errorText">Сюда записывается сообщение об ошибке, если результат вызова метода - false</param>
    /// <returns>true, если значения в форме правильные и успешно прочитаны. false, если выбранная настройка является некорректной</returns>
    bool ReadFormValues(EFPDataGridViewConfig config, out String errorText);

    /// <summary>
    /// Получить список вариантов настроек по умолчанию.
    /// Метод возвращает два массива одинаковой длины - коды и соответствующие им настройки.
    /// </summary>
    /// <param name="defaultConfigCodes">Сюда записываются коды</param>
    /// <param name="defaultConfigs">Сюда записываются настройки</param>
    void GetDefaultConfigs(out string[] defaultConfigCodes, out EFPDataGridViewConfig[] defaultConfigs);
  }

  #endregion
}
