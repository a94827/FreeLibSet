﻿using System;
using System.Collections.Generic;
using System.Text;

/*
 * The BSD License
 * 
 * Copyright (c) 2015, Ageyev A.V.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace AgeyevAV.Russian
{
  #region Перечисление RusFullNamePart

  /// <summary>
  /// Один из трех компонентов Ф.И.О.
  /// </summary>
  public enum RusFullNamePart
  {
    /// <summary>
    /// Фамилия
    /// </summary>
    Surname,

    /// <summary>
    /// Имя
    /// </summary>
    Name,

    /// <summary>
    /// Отчество
    /// </summary>
    Patronymic
  }

  #endregion

  #region Перечисление SexOfPerson

  /// <summary>
  /// Пол человека
  /// </summary>
  public enum SexOfPerson
  {
    /*
     * По поводу различия между "sex" и "gender" в английском языке, см. статью в Википедии
     * "Sex and gender distinction"
     * http://en.wikipedia.org/wiki/Sex_and_gender_distinction
     */

    /// <summary>
    /// Мужской
    /// </summary>
    Male = 0,

    /// <summary>
    /// Женский                                 
    /// </summary>
    Female = 1,

    /// <summary>
    /// Неизвестный
    /// </summary>
    Undefined = -1
  }

  #endregion

  #region Перечисление RusFullNameValidateOptions

  /// <summary>
  /// Опции проверки корректности Ф.И.О.
  /// </summary>
  [Flags]
  public enum RusFullNameValidateOptions
  {
    /// <summary>
    /// Режим проверки по умолчанию
    /// </summary>
    Default = 0,

    /// <summary>
    /// Если флан задан, то имя и отчество могут быть заданы одной буквой
    /// </summary>
    InitialsAllowed = 1,
  }

  #endregion

  /// <summary>
  /// Фамилия, Имя и Отчество человека
  /// </summary>
  [Serializable]
  public struct RusFullName
  {
    #region Конструктор

    /// <summary>
    /// Инициализирует структуры заданными Ф.И.О.
    /// Компоненты не проверяются и не модифицируются
    /// </summary>
    /// <param name="surname">Фамилия</param>
    /// <param name="name">Имя</param>
    /// <param name="patronymic">Отчество</param>
    public RusFullName(string surname, string name, string patronymic)
    {
      _Surname = surname;
      _Name = name;
      _Patronymic = patronymic;
    }

    #endregion

    #region Основные свойства

    /// <summary>
    /// Фамилия
    /// </summary>
    public string Surname { get { return _Surname; } }
    private string _Surname;

    /// <summary>
    /// Имя
    /// </summary>
    public string Name { get { return _Name; } }
    private string _Name;

    /// <summary>
    /// Отчество
    /// </summary>
    public string Patronymic { get { return _Patronymic; } }
    private string _Patronymic;

    #endregion

    #region Получение текста

    /// <summary>
    /// Полное имя в виде "Иванов Иван Иванович"
    /// </summary>
    public string FullName
    {
      get
      {
        string Surname2 = MyStr(Surname);
        if (String.IsNullOrEmpty(Surname2))
          return String.Empty;

        string s = Surname2;

        if (String.IsNullOrEmpty(Name) || Name == "_")
          return s;

        s += " " + MyStr(Name);

        if (String.IsNullOrEmpty(Patronymic) || Patronymic == "_")
          return s;

        s += " " + MyStr(Patronymic);
        return s;
      }
    }

    private static string MyStr(string s)
    {
      if (String.IsNullOrEmpty(s))    
        return String.Empty;
      if (s[0] == '_')
        return s.Substring(1);
      else
        return s;
    }

    /// <summary>
    /// Строка в виде "Иванов И.И."
    /// </summary>
    public string NameWithInitials
    {
      get
      {
        string Surname2 = MyStr(Surname);
        string Name2 = MyStr(Name);
        string Patronymic2 = MyStr(Patronymic);

        if (String.IsNullOrEmpty(Surname2))
        {
          if (String.IsNullOrEmpty(Name2))
          {
            if (String.IsNullOrEmpty(Patronymic2))
              return String.Empty;
            else
              return Patronymic2;
          }

          StringBuilder sb = new StringBuilder();
          sb.Append(Name2);

          if (!String.IsNullOrEmpty(Patronymic2))
          {
            sb.Append(" ");
            sb.Append(Patronymic2, 0, 1);
            sb.Append(".");
          }
          return sb.ToString();
        }
        else
        {
          StringBuilder sb = new StringBuilder();
          sb.Append(Surname2);

          if (!String.IsNullOrEmpty(Name2))
          {
            sb.Append(" ");
            sb.Append(Name2, 0, 1);
            sb.Append(".");

            if (!String.IsNullOrEmpty(Patronymic2))
            {
              sb.Append(Patronymic2, 0, 1);
              sb.Append(".");
            }
          }
          return sb.ToString();
        }
      }
    }

    /// <summary>
    /// Строка в обратном порядке "И.И.Иванов"
    /// </summary>
    public string InvNameWithInitials
    {
      get
      {
        if (String.IsNullOrEmpty(Surname))
          return String.Empty;

        StringBuilder sb = new StringBuilder();
        if (!String.IsNullOrEmpty(Name))
        {
          sb.Append(Name, 0, 1);
          sb.Append(".");

          if (!String.IsNullOrEmpty(Patronymic))
          {
            sb.Append(Patronymic, 0, 1);
            sb.Append(".");
          }
        }
        sb.Append(Surname);
        return sb.ToString();
      }
    }

    /// <summary>
    /// Возвращает свойство FullName
    /// </summary>
    /// <returns>Текстовое представление</returns>
    public override string ToString()
    {
      return FullName;
    }

    #endregion

    #region Другие свойства

    /// <summary>
    /// Определение пола человека по Ф.И.О.
    /// </summary>
    public SexOfPerson Sex
    {
      get
      {
        string s;
        // Шаг 1. - по отчеству
        if (!String.IsNullOrEmpty(Patronymic))
        {
          s = Patronymic.ToUpperInvariant();
          if (s.EndsWith("ИЧ"))
            return SexOfPerson.Male;
          if (s.EndsWith("ВНА") || s.EndsWith("ЧНА"))
            return SexOfPerson.Female;
        }

        // 19.07.2018
        // Определение пола по фамилии отключено.
        // Например, фамилия "Шин" не обязательно относится к мужскому полу.
        // Можно было бы проверять проверять наличие гласной перед окончанием,
        // но это не дает гарантии для иностранных фамилий, например, китайских.
#if XXX
        // Шаг 2. - по фамилии
        if (!String.IsNullOrEmpty(Surname))
        {
          s = Surname.ToUpperInvariant();
          if (s.EndsWith("ОВ") || s.EndsWith("ЕВ") || s.EndsWith("ИН") ||
            s.EndsWith("ЫЙ") || s.EndsWith("ИЙ"))
          {
            if (HasVowelInBase(s, 2)) // 19.07.2018
              return SexOfPerson.Male;
          }
          else if (s.EndsWith("ОВА") || s.EndsWith("ЕВА") ||
            s.EndsWith("ИНА"))
          {
            if (HasVowelInBase(s, 3)) // 19.07.2018
              return SexOfPerson.Female;
          }
          else if (s.EndsWith("АЯ")) // 19.07.2018
          {
            if (HasVowelInBase(s, 2))
              return SexOfPerson.Female;
          }
        }
#endif

        // Неизвестно
        return SexOfPerson.Undefined;
      }
    }

    /// <summary>
    /// Пустой объект
    /// </summary>
    public static readonly RusFullName Empty = new RusFullName();

    /// <summary>
    /// Возвращает true, если фамилия не заполнена
    /// </summary>
    public bool IsEmpty { get { return String.IsNullOrEmpty(Surname); } }

    /// <summary>
    /// Получить структуру Ф.И.О. с сокращенным именем и отчеством.
    /// То есть, если текущее Ф.И.О. - "Иванов Иван Иванович", то будет
    /// возвращена структура "Иванов И И"
    /// </summary>
    public RusFullName NameWithInitalsObj
    {
      get
      {
        RusFullName res = new RusFullName();
        res._Surname = Surname;
        if (!String.IsNullOrEmpty(Name))
          res._Name = Name.Substring(0, 1);
        if (!String.IsNullOrEmpty(Patronymic))
          res._Patronymic = Patronymic.Substring(0, 1);
        return res;
      }
    }

    /// <summary>
    /// Возвращает требуемый компонент Ф.И.О.
    /// </summary>
    /// <param name="part">Требуемый компонент</param>
    /// <returns>Значение свойства</returns>
    public string this[RusFullNamePart part]
    {
      get
      {
        switch (part)
        {
          case RusFullNamePart.Surname: return Surname;
          case RusFullNamePart.Name: return Name;
          case RusFullNamePart.Patronymic: return Patronymic;
          default:
            throw new ArgumentOutOfRangeException("Part");
        }
      }
    }

    #endregion

    #region Разбиение строки

    /// <summary>
    /// Извлечение компонентов Ф.И.О. из строки в максимально возможной степени
    /// </summary>
    /// <param name="s">Строка для преобразования</param>
    /// <returns></returns>
    public static RusFullName Parse(string s)
    {
      if (String.IsNullOrEmpty(s))
        return Empty;

      s = s.Trim();
      // Убираем двойные пробелы и черточки, а также пробелы рядом с черточкой
      while (s.Contains("  "))
        s = s.Replace("  ", " ");
      s = s.Replace("- ", "-");
      s = s.Replace(" -", "-");
      while (s.Contains("--"))
        s = s.Replace("--", "-");


      string Surname = GetNextPart(ref s);
      string Name = GetNextPart(ref s);
      string Patronymic = GetNextPart(ref s);
      // Отчество может быть из двух частей с пробелом вместо черточки
      string Pat2 = GetNextPart(ref s);
      if (!String.IsNullOrEmpty(Pat2))
        Patronymic += " " + Pat2;

      RusFullName res = new RusFullName(Surname, Name, Patronymic);
      return res.Normalized;
    }

    private static string GetNextPart(ref string s)
    {
      int p;
      string res;

      if (String.IsNullOrEmpty(s))
        return null;

      p = 0;
      while (p < s.Length)
      {
        if (IsValidChar(s[p]))
          p++;
        else
          break;
      }

      if (p > 0)
      {
        res = s.Substring(0, p);
        if (p == s.Length)
          s = String.Empty; // больше символов нет
        else
        {
          // Убираем ненужные символы
          s = s.Substring(p + 1).Trim();
          p = 0;
          while (p < s.Length)
          {
            if (IsValidChar(s[p]))
              break;
            else
              p++;
          }
          if (p > 0)
            s = s.Substring(p);
        }
        return res;
      }

      return null;
    }

    /// <summary>
    /// Относится ли символ к фамилии, имени или отчеству
    /// </summary>
    /// <param name="c">Символ</param>
    /// <returns>true, если c-буква или знак "-"</returns>
    private static bool IsValidChar(char c)
    {
      return RussianTools.IsAlphaChar(c) || c == '-';
    }

    /// <summary>
    /// Преобразование регистров Ф.И.О., удаление точек и лишних пробелов
    /// Буква "Ё" сохраняется
    /// </summary>
    public RusFullName Normalized
    {
      get
      {
        StringBuilder sb = new StringBuilder(30);
        RusFullName res = this;
        ValidatePart(sb, ref res._Surname, true);
        ValidatePart(sb, ref res._Name, true);
        ValidatePart(sb, ref res._Patronymic, true);
        return res;
      }
    }

    /// <summary>
    /// Преобразование регистров Ф.И.О без преобразования символов
    /// ("ИВАНОВ ИВАН ИВАНОВИЧ" -> "Иванов Иван Иванович")
    /// </summary>
    public RusFullName NormalCased
    {
      get
      {
        StringBuilder sb = new StringBuilder(30);
        RusFullName res = this;
        ValidatePart(sb, ref res._Surname, false);
        ValidatePart(sb, ref res._Name, false);
        ValidatePart(sb, ref res._Patronymic, false);
        return res;
      }
    }

    private static void ValidatePart(StringBuilder sb, ref string s, bool replace)
    {
      if (string.IsNullOrEmpty(s))
        return;

      sb.Length = 0;
      sb.Append(s);

      if (replace)
      {
        // Убираем точки
        sb.Replace(".", "");
        // Убираем двойные пробелы
        sb.Replace("  ", " ");
        // Убираем пробелы вокруг дефиса
        sb.Replace(" -", "-");
        sb.Replace("- ", "-");
      }
      // Исправляем регистр
      RussianTools.ToUpperWords(sb);

      s = sb.ToString();
    }

    /// <summary>
    /// Преобразование к верхнему регистру
    /// </summary>
    public RusFullName UpperCased
    {
      get
      {
        RusFullName res = this;
        if (!String.IsNullOrEmpty(res._Surname))
          res._Surname = res._Surname.ToUpperInvariant();
        if (!String.IsNullOrEmpty(res._Name))
          res._Name = res._Name.ToUpperInvariant();
        if (!String.IsNullOrEmpty(res._Patronymic))
          res._Patronymic = res._Patronymic.ToUpperInvariant();
        return res;
      }
    }

    /// <summary>
    /// Замена букв "Ё" на "Е"
    /// </summary>
    public RusFullName YoReplaced
    {
      get
      {
        return new RusFullName(ReplaceYo(Surname), ReplaceYo(Name), ReplaceYo(Patronymic));
      }
    }

    private static string ReplaceYo(string s)
    {
      if (String.IsNullOrEmpty(s))
        return String.Empty;
      s = s.Replace('Ё', 'Е');
      s = s.Replace('ё', 'е');
      return s;
    }

    #endregion

    #region Замена частей

    /// <summary>
    /// Возвращает новый объект Ф.И.О. с замененной фамилией
    /// </summary>
    /// <param name="newSurname">Новая фамилия</param>
    /// <returns>Копия объекта с заменой</returns>
    public RusFullName SetSurname(string newSurname)
    {
      return new RusFullName(newSurname, this.Name, this.Patronymic);
    }

    /// <summary>
    /// Возвращает новый объект Ф.И.О. с замененным именем
    /// </summary>
    /// <param name="newName">Новое имя</param>
    /// <returns>Копия объекта с заменой</returns>
    public RusFullName SetName(string newName)
    {
      return new RusFullName(this.Surname, newName, this.Patronymic);
    }

    /// <summary>
    /// Возвращает новый объект Ф.И.О. с замененным отчеством
    /// </summary>
    /// <param name="newPatronymic">Новое отчество</param>
    /// <returns>Копия объекта с заменой</returns>
    public RusFullName SetPatronymic(string newPatronymic)
    {
      return new RusFullName(this.Surname, this.Name, newPatronymic);
    }

    #endregion

    #region Склонение Ф.И.О.

    /// <summary>
    /// Получение 12 склонений
    /// </summary>
    /// <param name="sex">Пол человека. Если Undefined, то определяется автоматически исходя из отчества</param>
    /// <returns>Массив из 12 элементов</returns>
    public RusFullName[] GetCases(SexOfPerson sex)
    {
      RusFullName[] Forms;
      GetCases(sex, out Forms);
      return Forms;
    }

    /// <summary>
    /// Получение 12 склонений.
    /// </summary>
    /// <param name="sex">Пол человека. Если Undefined, то определяется автоматически исходя из отчества</param>
    /// <param name="forms">По ссылке возвращается массив из 12 элементов</param>
    /// <returns>В текущей реализации всегда возвращается true</returns>
    public bool GetCases(SexOfPerson sex, out RusFullName[] forms)
    {
      if (sex == SexOfPerson.Undefined)
        // Пытаемся определить пол
        sex = this.Sex;

      RusGender Gender;
      switch (sex)
      {
        case SexOfPerson.Male:
          Gender = RusGender.Masculine;
          break;
        case SexOfPerson.Female:
          Gender = RusGender.Feminine;
          break;
        default:
          Gender = RusGender.Undefined;
          break;
      }

      forms = new RusFullName[12];

      RusNounFormArray Surnames = new RusNounFormArray();
      RusNounFormArray Names = new RusNounFormArray();
      RusNounFormArray Patronymics = new RusNounFormArray();

      bool NoCasesSurname = false;
      if (String.IsNullOrEmpty(Surname))
        NoCasesSurname = true;
      else
      {
        string Surname1 = Surname.ToUpperInvariant();
        if (Surname1.EndsWith("О") || Surname1.EndsWith("ИХ") || Surname1.EndsWith("ЫХ"))
          // Фамилии на "О" не склоняются
          NoCasesSurname = true;

        // 20.09.2011
        // Женские фамилии, не имеющие суффиксов, не склоняются
        if (Gender == RusGender.Feminine)
        {
          if ("БВГДЕЖЗИЙКЛМНПРСТУФХЦШЫЬЭЮ".IndexOf(Surname1[Surname1.Length - 1]) >= 0)
            NoCasesSurname = true;
        }
      }
      if (NoCasesSurname)
        Surnames.Fill(Surname);
      else
        Surnames.GetCases(Surname, Gender, RusFormArrayGetCasesOptions.NoPlural | RusFormArrayGetCasesOptions.Which);

      Names.GetCases(Name, Gender, RusFormArrayGetCasesOptions.NoPlural | RusFormArrayGetCasesOptions.Name);
      Patronymics.GetCases(Patronymic, Gender, RusFormArrayGetCasesOptions.NoPlural);

      string[] SurnameItems = Surnames.Items;
      string[] NameItems = Names.Items;
      string[] PatronymicItems = Patronymics.Items;
      for (int i = 0; i < 12; i++)
        forms[i] = new RusFullName(SurnameItems[i], NameItems[i], PatronymicItems[i]);
      return true;
    }

    #endregion

    #region Сравнение

    /// <summary>
    /// Сравнивает с другим Ф.И.О.
    /// Регистр символов игнорируется.
    /// Считаются одинаковыми Ф.И.О., если в одном объекте имя и отчество заданы полностью, а в другом - только сокращение.
    /// Например, "Иванов Иван Иванович"=="Иванов И.И."
    /// </summary>
    /// <param name="obj">Второй сравниваемый объект</param>
    /// <returns>Результат сравнения</returns>
    public override bool Equals(object obj)
    {
      if (obj == null)
        return false;
      if (!(obj is RusFullName))
        return false;
      return this == (RusFullName)obj;
    }

    /// <summary>
    /// Сравнивает два Ф.И.О.
    /// Регистр символов игнорируется.
    /// Считаются одинаковыми Ф.И.О., если в одном объекте имя и отчество заданы полностью, а в другом - только сокращение.
    /// Например, "Иванов Иван Иванович"=="Иванов И.И."
    /// </summary>
    /// <param name="obj1">Первый сравниваемый объект</param>
    /// <param name="obj2">Второй сравниваемый объект</param>
    /// <returns>Результат сравнения</returns>
    public static bool operator ==(RusFullName obj1, RusFullName obj2)
    {
      if (!CompareParts(obj1.Surname, obj2.Surname, 1))
        return false;
      if (!CompareParts(obj1.Name, obj2.Name, 2))
        return false;
      return CompareParts(obj1.Patronymic, obj2.Patronymic, 3);
    }

    private static bool CompareParts(string s1, string s2, int nPart)
    {
      if (s1 == null)
        s1 = String.Empty;
      if (s2 == null)
        s2 = String.Empty;

      s1 = s1.ToUpperInvariant().Replace('Ё', 'Е');
      s2 = s2.ToUpperInvariant().Replace('Ё', 'Е');

      // Точное сравнение
      if (s1 == s2)
        return true;

      // Имя и отчество может быть одно задано, а другое - нет
      if (nPart >= 2)
      {
        if (s1.Length == 0 && s2.Length > 0)
          return true;
        if (s1.Length > 0 && s2.Length == 0)
          return true;

        if (s1.Length > 1 && s2.Length == 1)
          return s1[0] == s2[0];
        if (s1.Length == 1 && s2.Length > 1)
          return s1[0] == s2[0];
      }

      return false;
    }

    /// <summary>
    /// Сравнивает два Ф.И.О.
    /// Регистр символов игнорируется.
    /// Считаются одинаковыми Ф.И.О., если в одном объекте имя и отчество заданы полностью, а в другом - только сокращение.
    /// Например, "Иванов Иван Иванович"=="Иванов И.И."
    /// </summary>
    /// <param name="obj1">Первый сравниваемый объект</param>
    /// <param name="obj2">Второй сравниваемый объект</param>
    /// <returns>Результат сравнения</returns>
    public static bool operator !=(RusFullName obj1, RusFullName obj2)
    {
      return !(obj1 == obj2);
    }

    /// <summary>
    /// Возвращает хэш-код из фамилии.
    /// Требуется для работы колле6
    /// </summary>
    /// <returns>Хэш код</returns>
    public override int GetHashCode()
    {
      if (String.IsNullOrEmpty(Surname))
        return 0;
      else
      {
        string s = Surname.ToUpperInvariant().Replace('Ё', 'Е');
        return s.GetHashCode();
      }
    }

    #endregion

    #region Проверка корректности

    /// <summary>
    /// Выполнить проверку фамилии, имени и отчества
    /// </summary>
    /// <param name="options">Опции проверки</param>
    /// <param name="errorText">Сюда записывается сообщение об ошибке</param>
    /// <returns>true, если все компоненты корректны</returns>
    public bool Validate(RusFullNameValidateOptions options, out string errorText)
    {
      if (!ValidateSurname(Surname, options, out errorText))
        return false;
      if (!ValidateName(Name, options, out errorText))
        return false;
      if (!ValidatePatronymic(Patronymic, options, out errorText))
        return false;

      if ((options & RusFullNameValidateOptions.InitialsAllowed) == RusFullNameValidateOptions.InitialsAllowed &&
        (!String.IsNullOrEmpty(Patronymic)))
      {
        bool NameIsInitial = Name.Length == 1;
        bool PatronymicIsInitial = Patronymic.Length == 1;
        if (NameIsInitial != PatronymicIsInitial)
        {
          errorText = "Имя и отчество либо должны быть заданы полностью, либо оба инициалами";
          return false;
        }
      }

      return true;
    }

    /// <summary>
    /// Выполнить проверку фамилии
    /// </summary>
    /// <param name="surname">Проверяемое значение</param>
    /// <param name="options">Опции проверки</param>
    /// <param name="errorText">Сюда записывается сообщение об ошибке</param>
    /// <returns>true, если значение корректно</returns>
    public static bool ValidateSurname(string surname, RusFullNameValidateOptions options, out string errorText)
    {
      if (String.IsNullOrEmpty(surname))
      {
        errorText = "Фамилия должна быть задана";
        return false;
      }

      return ValidateChars(surname, options, out errorText, RusFullNamePart.Surname, false);
    }

    /// <summary>
    /// Выполнить проверку имени
    /// </summary>
    /// <param name="name">Проверяемое значение</param>
    /// <param name="options">Опции проверки</param>
    /// <param name="errorText">Сюда записывается сообщение об ошибке</param>
    /// <returns>true, если значение корректно</returns>
    public static bool ValidateName(string name, RusFullNameValidateOptions options, out string errorText)
    {
      if (String.IsNullOrEmpty(name))
      {
        errorText = "Имя должно быть задано";
        return false;
      }

      return ValidateChars(name, options, out errorText, RusFullNamePart.Name, false);
    }

    /// <summary>
    /// Выполнить проверку отчества.
    /// Пустое отчество считается корректным значением
    /// </summary>
    /// <param name="patronymic">Проверяемое значение</param>
    /// <param name="options">Опции проверки</param>
    /// <param name="errorText">Сюда записывается сообщение об ошибке</param>
    /// <returns>true, если значение корректно</returns>
    public static bool ValidatePatronymic(string patronymic, RusFullNameValidateOptions options, out string errorText)
    {
      return ValidateChars(patronymic, options, out errorText, RusFullNamePart.Patronymic, false);
    }

    private static bool ValidateChars(string text, RusFullNameValidateOptions options, out string errorText, RusFullNamePart part, bool isPatronymic)
    {
      errorText = null;
      if (String.IsNullOrEmpty(text))
        return true;

      int CharCount = 0;
      bool HasSpace = false;

      for (int i = 0; i < text.Length; i++)
      {
        if (text[i] >= 'А' && text[i] <= 'Я')
        {
          CharCount++;
          continue;
        }
        if (text[i] >= 'а' && text[i] <= 'я')
        {
          CharCount++;
          continue;
        }
        if (text[i] == ' ')
        {
          if (!isPatronymic)
          {
            errorText = GetErrorPrefix(part, i) + "Пробелы допускаются только в отчестве";
            return false;
          }

          if (i == 0 || i == text.Length - 1)
          {
            errorText = GetErrorPrefix(part, i) + "Пробелы не могут быть в начале или в конце";
            return false;
          }
          if (HasSpace)
          {
            errorText = GetErrorPrefix(part, i) + "Больше одного разделителя не допускается";
            return false;
          }

          HasSpace = true;
          continue;
        }
        if (text[i] == '-')
        {
          if (i == 0 || i == text.Length - 1)
          {
            errorText = GetErrorPrefix(part, i) + "Дефис не может быть в начале или в конце";
            return false;
          }
          if (HasSpace)
          {
            errorText = GetErrorPrefix(part, i) + "Больше одного разделителя не допускается";
            return false;
          }

          HasSpace = true;
          continue;
        }

        errorText = GetErrorPrefix(part, i) + "Недопустимый символ \"" + text[i] + "\"";
        return false;
      }

      if (CharCount == 0)
      {
        errorText = GetPartDisplayName(part) + ". Нет ни одного буквенного символа";
        return false;
      }
      if (HasSpace && CharCount < 3)
      {
        errorText = GetPartDisplayName(part) + ". Слишком мало буквенных символов при наличии разделителя";
        return false;
      }

      if (text.Length == 1 && part != RusFullNamePart.Surname)
      {
        if ((options & RusFullNameValidateOptions.InitialsAllowed) == RusFullNameValidateOptions.InitialsAllowed)
          return true;

        errorText = GetPartDisplayName(part) + ". Должно быть больше одного символа";
        return false;
      }

      return true;
    }

    private static string GetErrorPrefix(RusFullNamePart part, int i)
    {
      string PartName = GetPartDisplayName(part);

      return PartName + ", позиция " + (i + 1).ToString() + ". ";
    }

    private static string GetPartDisplayName(RusFullNamePart part)
    {
      switch (part)
      {
        case RusFullNamePart.Surname: return "Фамилия";
        case RusFullNamePart.Name: return "Имя";
        case RusFullNamePart.Patronymic: return "Отчество";
        default: throw new ArgumentOutOfRangeException("Part");
      }
    }

    #endregion
  }
}
