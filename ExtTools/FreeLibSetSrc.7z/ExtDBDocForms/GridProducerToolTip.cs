﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.Specialized;
using System.Data;
using AgeyevAV;
using AgeyevAV.ExtDB;

/*
 * The BSD License
 * 
 * Copyright (c) 2015, Ageyev A.V.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace AgeyevAV.ExtForms.Docs
{
  /// <summary>
  /// Реализация свойства GridProducer.ToolTips
  /// </summary>
  public class GridProducerToolTips : NameObjectCollectionBase
  {
    #region Свойства

    /// <summary>
    /// Доступ к подсказке по индексу
    /// </summary>
    /// <param name="index">Индекс подсказки в списке в диапазоне от 0 до (Count-1)</param>
    /// <returns>Объект подсказки</returns>
    public GridProducerToolTip this[int index]
    {
      get
      {
        return (GridProducerToolTip)(base.BaseGet(index));
      }
    }

    /// <summary>
    /// Доступ к подсказке по имени (свойство GridProducerToolTip.Name).
    /// Если подсказка не найдена, возвращается null.
    /// </summary>
    /// <param name="name">Имя подсказки</param>
    /// <returns>Объект подсказки</returns>
    public GridProducerToolTip this[string name]
    {
      get
      {
        return (GridProducerToolTip)(base.BaseGet(name));
      }
    }

    #endregion

    #region Методы добавления

    /// <summary>
    /// Добавляет объект всплывающей подказки
    /// </summary>
    /// <param name="item">Генератор всплывающей подказки</param>
    public void Add(GridProducerToolTip item)
    {
#if DEBUG
      if (item == null)
        throw new ArgumentNullException("item");
      if (base.BaseGet(item.Name) != null)
        throw new InvalidOperationException("Повторное добавление подсказки \"" + item.Name + "\"");
#endif

      base.BaseAdd(item.Name, item);
    }

    /// <summary>
    /// Добавить строку подсказки с содержимым одного поля
    /// </summary>
    /// <param name="columnName">Поле, значение которого выводится</param>
    /// <param name="prefixText">Текст, который будет выведен перед значением в виде "DisplayName : Значение".
    /// Если null, то будет выводиться имя поля. 
    /// Если пустая строка, то ничего выводится перед значением не будет</param>
    /// <returns>Объект выдачи подсказки</returns>
    public GridProducerTextColumnToolTip AddText(string columnName, string prefixText)
    {
      GridProducerTextColumnToolTip Item = new GridProducerTextColumnToolTip(columnName);
      if (prefixText != null)
      {
        if (prefixText.Length == 0)
          Item.PrefixText = "";
        else
        {
          Item.PrefixText = prefixText + ": ";
          Item.DisplayName = prefixText;
        }
      }
      Add(Item);
      return Item;
    }

    /// <summary>
    /// Добавить строку подсказки с содержимым одного поля типа даты
    /// </summary>
    /// <param name="columnName">Поле, значение которого выводится</param>
    /// <param name="prefixText">Текст, который будет выведен перед значением в виде "DisplayName : Значение".
    /// Если null, то будет выводиться имя поля. 
    /// Если пустая строка, то ничего выводится перед значением не будет</param>
    /// <returns>Объект выдачи подсказки</returns>
    public GridProducerDateColumnToolTip AddDate(string columnName, string prefixText)
    {
      GridProducerDateColumnToolTip Item = new GridProducerDateColumnToolTip(columnName);
      if (prefixText != null)
      {
        if (prefixText.Length == 0)
          Item.PrefixText = "";
        else
        {
          Item.PrefixText = prefixText + ": ";
          Item.DisplayName = prefixText;
        }
      }
      Add(Item);
      return Item;
    }

    /// <summary>
    /// Добавить строку подсказки с содержимым двух полей типа "дата" для задания диапазона
    /// </summary>
    /// <param name="firstColumnName">Имя поля начальной даты</param>
    /// <param name="lastColumnName">Имя поля конечной даты</param>
    /// <param name="prefixText">Текст, который будет выведен перед значением в виде "PrefixText : Диапазон".
    /// Если пустая строка, то ничего выводится перед значением не будет</param>
    /// <returns>Объект выдачи подсказки</returns>
    public GridProducerDateRangeColumnsToolTip AddDateRange(string firstColumnName, string lastColumnName, string prefixText)
    {
      GridProducerDateRangeColumnsToolTip Item = new GridProducerDateRangeColumnsToolTip(firstColumnName, lastColumnName);
      if (prefixText != null)
      {
        if (prefixText.Length == 0)
          Item.PrefixText = "";
        else
        {
          Item.PrefixText = prefixText + ": ";
          Item.DisplayName = prefixText;
        }
      }
      Add(Item);
      return Item;
    }

    /// <summary>
    /// Добавление подсказки, формируемой пользовательским обработчиком
    /// </summary>
    /// <param name="name">Имя подсказки (для сохранения конфигурации просмотра)</param>
    /// <param name="columnNames">Имена полей, значения которых используются для формирования подсказки.
    /// Список имен разделяется запятыми</param>
    /// <param name="handler">Обработчик, формирующий текст подсказки</param>
    /// <returns>Созданный объект подсказки</returns>
    public GridProducerUserToolTip AddUserItem(string name, string columnNames,
      GridProducerUserToolTipTextNeededEventHandler handler)
    {
      string[] aNames = columnNames.Split(',');
      GridProducerUserToolTip Item = new GridProducerUserToolTip(name, aNames);
      Item.CellToolTipTextNeeded += handler;
      Add(Item);
      return Item;
    }


    /*
    /// <summary>
    /// Добавить подсказку, содержащую текстовое представление документа или поддокумента.
    /// Используется ссылочное поле
    /// Подсказка будет иметь имя "RefColumnName_Text"
    /// </summary>
    /// <param name="RefColumnName">Имя ссылочного поля (может содержать точки)</param>
    /// <param name="DocTypeName">Имя типа документа или поддокумента, на которое ссылается поле</param>
    /// <param name="PrefixText">Текст, который будет выведен перед значением в виде "DisplayName : Значение".
    /// Если null, то будет выводиться название вида документа. 
    /// Если пустая строка, то ничего выводится перед значением не будет</param>
    /// <returns>Объект выдачи подсказки</returns>
    public GridProducerDocRefTextToolTip AddDocRefText(string RefColumnName, string DocTypeName, string PrefixText)
    {
      GridProducerDocRefTextToolTip Item = new GridProducerDocRefTextToolTip(RefColumnName, DocTypeName);
      if (PrefixText != null)
      {
        if (PrefixText.Length == 0)
          Item.PrefixText = "";
        else
        {
          Item.PrefixText = PrefixText + ": ";
          Item.DisplayName = PrefixText;
        }
      }
      Add(Item);
      return Item;
    }
      */

    /// <summary>
    /// Последняя добавленная подсказка.
    /// Вспомогательное свойство, которое можно использовать в процессе добавления подсказок
    /// </summary>
    public GridProducerToolTip LastAdded
    {
      get
      {
        if (Count == 0)
          return null;
        else
          return this[Count - 1];
      }
    }

    #endregion

    #region Прочие методы

    /// <summary>
    /// Возвращает имена подсказок через запятую
    /// </summary>
    /// <returns>Текстовое представление</returns>
    public override string ToString()
    {
      string s = "";
      for (int i = 0; i < Count; i++)
      {
        if (i > 0)
          s += ", ";
        s += this[i].Name;
      }
      return "{" + s + "}";
    }

    /// <summary>
    /// Поиск всплывающей подсказки по имени
    /// </summary>
    /// <param name="name">Имя подсказки (свойство GridProducerToolTip.Name)</param>
    /// <returns>Индекс подсказки или (-1)</returns>
    public int IndexOf(string name)
    {
      if (String.IsNullOrEmpty(name))
        return -1;

      for (int i = 0; i < Count; i++)
      {
        if (this[i].Name == name)
          return i;
      }
      return -1;
    }

    /// <summary>
    /// Поиск всплывающей подсказки
    /// </summary>
    /// <param name="item">Объект подсказки</param>
    /// <returns>Индекс подсказки или (-1)</returns>
    public int IndexOf(GridProducerToolTip item)
    {
      if (item == null)
        return -1;

      for (int i = 0; i < Count; i++)
      {
        if (this[i] == item)
          return i;
      }
      return -1;
    }

    #endregion
  }

  /// <summary>
  /// Описание одного возможного элемента ToolTip.
  /// Абстрактный базовый класс
  /// </summary>
  public abstract class GridProducerToolTip
  {
    #region Конструктор

    /// <summary>
    /// Создает подсказку
    /// </summary>
    /// <param name="name">Имя подсказки</param>
    public GridProducerToolTip(string name)
    {
#if DEBUG
      if (String.IsNullOrEmpty(name))
        throw new ArgumentNullException("name");
#endif
      _Name = name;
      _DisplayName = null;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Имя, которое используется для сохранения конфигурации
    /// </summary>
    public string Name { get { return _Name; } }
    private string _Name;

    /// <summary>
    /// Имя которое, используется в окне настройки конфигурации
    /// </summary>
    public string DisplayName
    {
      get
      {
        if (_DisplayName == null)
          return _Name;
        return _DisplayName;
      }
      set
      {
        _DisplayName = value;
      }
    }
    private string _DisplayName;

    #endregion

    #region Виртуальные методы и свойства

    /// <summary>
    /// Основной метод.
    /// Реализует получение текста подсказки.
    /// Для доступа к значениям полей документа или поддокумента следует использовать метод GetColumnValue()
    /// </summary>
    /// <returns>Текст всплывающей подсказки</returns>
    protected abstract string GetText();

    /// <summary>
    /// Имена полей, которые должны быть в наборе данных
    /// </summary>
    public abstract void GetColumnNames(DBxColumnList columns);

    /// <summary>
    /// Возвращает свойство Name.
    /// </summary>
    /// <returns>Текстовое представление</returns>
    public override string ToString()
    {
      return Name;
    }

    #endregion

    #region Вспомогательные методы

    /// <summary>
    /// Получить текст всплывающей подсказки.
    /// Вызывает абстрактный метод GetText()
    /// </summary>
    /// <param name="owner">Объект-владелец</param>
    /// <param name="row">Строка в табличном просмотре</param>
    /// <returns>Текст подсказки</returns>
    public string PerformGetText(GridProducer owner, DataRow row)
    {
      if (owner == null)
        throw new ArgumentNullException("owner");
      if (row == null)
        throw new ArgumentNullException("row");

      _Owner = owner;
      _Row = row;
      string res = GetText();
      _Row = null;
      return res;
    }

    private DataRow _Row;
    private GridProducer _Owner;

    /// <summary>
    /// Получить значение поля
    /// </summary>
    /// <param name="columnName"></param>
    /// <returns></returns>
    protected object GetColumnValue(string columnName)
    {
#if DEBUG
      if (_Row == null)
        throw new InvalidOperationException("Метод может вызываться только из GetText()");
#endif

      int pos = _Row.Table.Columns.IndexOf(columnName);
      if (pos >= 0)
        return _Row[pos];
      // Такого поля нет
      return _Owner.OnGetColumnValue(_Row, columnName);
    }

    #endregion
  }

  /// <summary>
  /// Реализация строки подсказки для вывода значения одного, обычно текстового, поля.
  /// Свойство Name задает имя столбца
  /// </summary>
  public class GridProducerTextColumnToolTip : GridProducerToolTip
  {
    #region Конструктор

    /// <summary>
    /// Создает подсказку.
    /// </summary>
    /// <param name="columnName">Имя столбца документа или поддокумента.
    /// Могут использоваться ссылочные поля с точками</param>
    public GridProducerTextColumnToolTip(string columnName)
      : base(columnName)
    {
      PrefixText = columnName + ": ";
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Имя столбца равно свойству Name.
    /// </summary>
    public string ColumnName { get { return base.Name; } }

    /// <summary>
    /// Текст, который будет идти перед значением поля
    /// </summary>
    public string PrefixText { get { return _PrefixText; } set { _PrefixText = value; } }
    private string _PrefixText;

    #endregion

    #region Переопределенные методы

    /// <summary>
    /// Получить значение поля
    /// </summary>
    /// <returns>Текст подсказки</returns>
    protected override string GetText()
    {
      string s = PrefixText + GetColumnValue(ColumnName);
      if (s == null)
        return String.Empty;
      return s.Trim();
    }

    /// <summary>
    /// Получить имена полей.
    /// Добавляет в список <paramref name="columns"/> имя ColumnName.
    /// </summary>
    /// <param name="columns">Список для заполнения</param>
    public override void GetColumnNames(DBxColumnList columns)
    {
      columns.Add(ColumnName);
    }

    #endregion
  }

  /// <summary>
  /// Подсказка для вывода поля типа "Дата"
  /// Заменяет у GridProducerTextColumnToolTip форматирование текста
  /// </summary>
  public class GridProducerDateColumnToolTip : GridProducerTextColumnToolTip
  {
    #region Конструктор

    /// <summary>
    /// Создает подсказку.
    /// </summary>
    /// <param name="columnName">Имя столбца документа или поддокумента.
    /// Могут использоваться ссылочные поля с точками</param>
    public GridProducerDateColumnToolTip(string columnName)
      : base(columnName)
    {
      // Конструктор нужен из-за аргумента
    }

    #endregion

    #region Переопределенные методы

    /// <summary>
    /// Получить значение поля
    /// </summary>
    /// <returns>Текст подсказки</returns>
    protected override string GetText()
    {
      Nullable<DateTime> dt = DataTools.GetNullableDateTime(GetColumnValue(ColumnName));
      string s = String.Empty;
      if (dt.HasValue)
        s = dt.Value.ToString("d");
      return PrefixText + s;
    }

    #endregion
  }

  /// <summary>
  /// Подсказка для вывода двух поля типа "Дата", задающих интервал дат.
  /// Для форматирования используется DateRangeFormatter.
  /// </summary>
  public class GridProducerDateRangeColumnsToolTip : GridProducerToolTip
  {
    #region Конструктор

    /// <summary>
    /// Создает подсказку.
    /// Свойство Name="FirstColumnName_LastColumnName".
    /// </summary>
    /// <param name="firstColumnName">Имя первого столбца документа или поддокумента.
    /// Могут использоваться ссылочные поля с точками</param>
    /// <param name="lastColumnName">Имя второго столбца документа или поддокумента.
    /// Могут использоваться ссылочные поля с точками</param>
    public GridProducerDateRangeColumnsToolTip(string firstColumnName, string lastColumnName)
      : base(firstColumnName + "_" + lastColumnName)
    {
      if (String.IsNullOrEmpty(firstColumnName))
        throw new ArgumentNullException("firstColumnName");
      if (String.IsNullOrEmpty(lastColumnName))
        throw new ArgumentNullException("lastColumnName");

      _FirstColumnName = firstColumnName;
      _LastColumnName = lastColumnName;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Имя первого столбца
    /// </summary>
    public string FirstColumnName { get { return _FirstColumnName; } }
    private string _FirstColumnName;

    /// <summary>
    /// Имя второго столбца
    /// </summary>
    public string LastColumnName { get { return _LastColumnName; } }
    private string _LastColumnName;

    /// <summary>
    /// Текст, выводимый в начале подсказки.
    /// Если используется, не забудьте добавить пробел в конце для правильного форматирования
    /// </summary>
    public string PrefixText { get { return _PrefixText; } set { _PrefixText = value; } }
    private string _PrefixText;

    #endregion

    #region Переопределенные методы

    /// <summary>
    /// Добавляет в список FirstColumnName и LastColumnName
    /// </summary>
    /// <param name="сolumns">Список для добавления имен полей</param>
    public override void GetColumnNames(DBxColumnList сolumns)
    {
      сolumns.Add(FirstColumnName);
      сolumns.Add(LastColumnName);
    }

    /// <summary>
    /// Получить значение поля, используя DateRangeFormatter.
    /// </summary>
    /// <returns>Текст подсказки</returns>
    protected override string GetText()
    {
      DateTime? dt1 = DataTools.GetNullableDateTime(GetColumnValue(FirstColumnName));
      DateTime? dt2 = DataTools.GetNullableDateTime(GetColumnValue(LastColumnName));
      return PrefixText + DateRangeFormatter.Default.ToString(dt1, dt2, true);
    }

    #endregion
  }

  // TODO:
#if XXX
  /// <summary>
  /// Реализация строки подсказки для вывода текстового представления документа,
  /// для которого есть ссылочное поле
  /// </summary>
  public class GridProducerDocRefTextToolTip : GridProducerToolTip
  {
  #region Конструктор

    public GridProducerDocRefTextToolTip(string RefColumnName,
      string DocTypeName)
      : base(RefColumnName + "_Text")
    {
#if DEBUG
      if (String.IsNullOrEmpty(RefColumnName))
        throw new ArgumentNullException("RefColumnName");
      if (String.IsNullOrEmpty(DocTypeName))
        throw new ArgumentNullException("DocTypeName");
#endif

      FRefColumnName = RefColumnName;
      if (!AccDepClientExec.DocTypes.FindTypeForTable(DocTypeName, out FDocType))
        throw new ArgumentException("Неизвестный вид документа или поддокумента: \"" + DocTypeName + "\"", "DocTypeName");

      PrefixText = ((DocTypeBase)FDocType).SingularTitle + ": ";
      DisplayName = RefColumnName;
    }

    #endregion

  #region Свойства

    /// <summary>
    /// Имя cсылочного столбца (задается в конструкторе)
    /// </summary>
    public string RefColumnName { get { return FRefColumnName; } }
    private string FRefColumnName;

    /// <summary>
    /// Объявление документа или поддокумента
    /// </summary>
    public IClientDocTypeBase DocType { get { return FDocType; } }
    private IClientDocTypeBase FDocType;

    /// <summary>
    /// Текст, который будет идти перед значением поля
    /// </summary>
    public string PrefixText;

    #endregion

  #region Переопределенные методы

    protected override string GetText()
    {
      Int32 Id = DataTools.GetInt(GetColumnValue(RefColumnName));
      return PrefixText + FDocType.GetTextValue(Id);
    }

    public override string[] ColumnNames
    {
      get { return new string[] { RefColumnName }; }
    }

    #endregion
  }
#endif


  /// <summary>
  /// Аргументы события GridProducerUserToolTip.TextNeeded.
  /// </summary>
  public class GridProducerUserToolTipTextNeededEventArgs : EventArgs
  {
    #region Конструктор

    /// <summary>
    /// Создается в GridProducerUserToolTip
    /// </summary>
    /// <param name="owner">Объект GridProducerUserToolTip</param>
    /// <param name="columnValues">Список значений полей</param>
    public GridProducerUserToolTipTextNeededEventArgs(GridProducerUserToolTip owner, object[] columnValues)
    {
      _Owner = owner;
      _Values = columnValues;
      ToolTipText = String.Empty;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Объект, вызвавший события
    /// </summary>
    public GridProducerUserToolTip Owner { get { return _Owner; } }
    private GridProducerUserToolTip _Owner;

    /// <summary>
    /// Имена исходных полей, заданных в GridProducerUserToolTip
    /// </summary>
    public string[] ColumnNames { get { return _Owner.SourceColumnNames; } }

    /// <summary>
    /// Массив значений полей, соответствующий списку ColumnNames
    /// </summary>
    public object[] Values { get { return _Values; } }
    private object[] _Values;

    /// <summary>
    /// Сюда должен быть записан текст подсказки
    /// </summary>
    public string ToolTipText { get { return _ToolTipText; } set { _ToolTipText = value; } }
    private string _ToolTipText;

    /// <summary>
    /// Доступ к свойству GridProducerUserToolTip.Tag
    /// </summary>
    public object Tag
    {
      get { return _Owner.Tag; }
      set { _Owner.Tag = value; }
    }

    #endregion

    #region Типизированный доступ к значениям

    /// <summary>
    /// Получить значение поля
    /// </summary>
    /// <param name="columnName">Имя поля. Должно быть в списке ColumnNames</param>
    /// <returns>Значение поля</returns>
    public object GetValue(string columnName)
    {
      int p = Array.IndexOf<string>(ColumnNames, columnName);
      if (p < 0)
        throw new ArgumentException("Обращение к неизвестному полю \"" + columnName + "\"", "ColumnName");
      return _Values[p];
    }

    /// <summary>
    /// Получить значение поля
    /// </summary>
    /// <param name="columnName">Имя поля. Должно быть в списке ColumnNames</param>
    /// <returns>Значение поля</returns>
    public string GetString(string columnName)
    {
      return DataTools.GetString(GetValue(columnName));
    }

    /// <summary>
    /// Получить значение поля
    /// </summary>
    /// <param name="columnName">Имя поля. Должно быть в списке ColumnNames</param>
    /// <returns>Значение поля</returns>
    public bool GetBool(string columnName)
    {
      return DataTools.GetBool(GetValue(columnName));
    }

    /// <summary>
    /// Получить значение поля
    /// </summary>
    /// <param name="columnName">Имя поля. Должно быть в списке ColumnNames</param>
    /// <returns>Значение поля</returns>
    public Nullable<DateTime> GetNullableDateTime(string columnName)
    {
      return DataTools.GetNullableDateTime(GetValue(columnName));
    }

    /// <summary>
    /// Получить значение поля
    /// </summary>
    /// <param name="columnName">Имя поля. Должно быть в списке ColumnNames</param>
    /// <returns>Значение поля</returns>
    public int GetInt(string columnName)
    {
      return DataTools.GetInt(GetValue(columnName));
    }

    /// <summary>
    /// Получить значение поля
    /// </summary>
    /// <param name="columnName">Имя поля. Должно быть в списке ColumnNames</param>
    /// <returns>Значение поля</returns>
    public float GetSingle(string columnName)
    {
      return DataTools.GetSingle(GetValue(columnName));
    }

    /// <summary>
    /// Получить значение поля
    /// </summary>
    /// <param name="columnName">Имя поля. Должно быть в списке ColumnNames</param>
    /// <returns>Значение поля</returns>
    public double GetDouble(string columnName)
    {
      return DataTools.GetDouble(GetValue(columnName));
    }

    /// <summary>
    /// Получить значение поля
    /// </summary>
    /// <param name="columnName">Имя поля. Должно быть в списке ColumnNames</param>
    /// <returns>Значение поля</returns>
    public decimal GetDecimal(string columnName)
    {
      return DataTools.GetDecimal(GetValue(columnName));
    }

    #endregion
  }

  /// <summary>
  /// Делегат события GridProducerUserToolTip.TextNeeded.
  /// </summary>
  /// <param name="sender">Объект GridProducerUserToolTip</param>
  /// <param name="args">Аргументы события</param>
  public delegate void GridProducerUserToolTipTextNeededEventHandler(object sender,
    GridProducerUserToolTipTextNeededEventArgs args);

  /// <summary>
  /// Всплывающая подсказка, использующая пользовательский обработчик для вывода текста из несколькиз полей
  /// </summary>
  public class GridProducerUserToolTip : GridProducerToolTip
  {
    #region Конструктор

    /// <summary>
    /// Создает объект подсказки
    /// </summary>
    /// <param name="name">Имя подсказки для сохранения в настроках просмотра</param>
    /// <param name="sourceColumnNames">Имена исходных столбцов, используемых для получения подсказки</param>
    public GridProducerUserToolTip(string name, string[] sourceColumnNames)
      : base(name)
    {
      _SourceColumnNames = sourceColumnNames;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Произвольные пользовательские данные
    /// </summary>
    public object Tag { get { return _Tag; } set { _Tag = value; } }
    private object _Tag;

    #endregion

    #region События

    /// <summary>
    /// Событие вызывается при получении текста подсказки.
    /// Обработчик должен быть установлен.
    /// </summary>
    public event GridProducerUserToolTipTextNeededEventHandler CellToolTipTextNeeded;

    #endregion

    #region Переопределенные методы и свойства

    /// <summary>
    /// Получение текста подсказки.
    /// Получает значения полей и вызывает обработчик события CellToolTipTextNeeded
    /// </summary>
    /// <returns></returns>
    protected override string GetText()
    {
      if (CellToolTipTextNeeded == null)
        return DisplayName + ": Не задан обработчик CellToolTipTextNeeded";

      object[] Values = new object[_SourceColumnNames.Length];
      for (int i = 0; i < _SourceColumnNames.Length; i++)
        Values[i] = GetColumnValue(_SourceColumnNames[i]);

      GridProducerUserToolTipTextNeededEventArgs Args = new GridProducerUserToolTipTextNeededEventArgs(this, Values);
      CellToolTipTextNeeded(this, Args);
      return Args.ToolTipText;
    }

    /// <summary>
    /// Добавляет все поля из SourceColumnNames
    /// </summary>
    /// <param name="columns">Список для заполнения</param>
    public override void GetColumnNames(DBxColumnList columns)
    {
      columns.AddRange(_SourceColumnNames);
    }

    /// <summary>
    /// Имена исходных столбцов, по которым строится текст подсказки
    /// </summary>
    public string[] SourceColumnNames { get { return _SourceColumnNames; } }
    private string[] _SourceColumnNames;

    #endregion
  }

  /// <summary>
  /// Объект для извлечения всплывающих подсказок для строки, 
  /// отдельно от табличного просмотра
  /// </summary>
  public class GridProducerToolTipExtractor
  {
    #region Конструкторы

    /// <summary>
    /// Создает объект
    /// </summary>
    /// <param name="producer">Генератор табличного просмотра</param>
    /// <param name="toolTips">Список подсказок, которые требуется извлекать</param>
    public GridProducerToolTipExtractor(GridProducer producer, IEnumerable<GridProducerToolTip> toolTips)
    {
#if DEBUG
      if (producer == null)
        throw new ArgumentNullException("producer");
      if (toolTips == null)
        throw new ArgumentNullException("toolTips");
#endif

      _Producer = producer;
      _ToolTips = toolTips;

      DBxColumnList lst = new DBxColumnList();

      foreach (GridProducerToolTip ToolTip in toolTips)
        ToolTip.GetColumnNames(lst);

      _ColumnNames = new DBxColumns(lst);
    }

    /// <summary>
    /// Создает объект
    /// </summary>
    /// <param name="producer">Генератор табличного просмотра</param>
    /// <param name="config">Настройка табличного просмотра</param>
    public GridProducerToolTipExtractor(GridProducer producer, EFPDataGridViewConfig config)
      : this(producer, GetToolTips(producer, config))
    {
    }

    private static IEnumerable<GridProducerToolTip> GetToolTips(GridProducer producer, EFPDataGridViewConfig config)
    {
      List<GridProducerToolTip> ToolTips = new List<GridProducerToolTip>();
      for (int i = 0; i < config.ToolTips.Count; i++)
      {
        GridProducerToolTip ToolTip = producer.ToolTips[config.ToolTips[i].ToolTipName];
        if (ToolTip != null)
          ToolTips.Add(ToolTip);
      }
      return ToolTips;
    }

    /// <summary>
    /// Вызывает GridProducer.LoadConfig() и создает объект
    /// </summary>
    /// <param name="producer">Генератор табличного просмотра</param>
    /// <param name="configSectionName">Имя секции конфигурации, используемое табличным просмотром</param>
    /// <param name="defaultConfigName">Имя фиксированной настройки, используемой табличным просмотром.
    /// Пустая строка (обычно), если используется настройка просмота GridProducer.DefaultConfig</param>
    /// <param name="cfgName">Имя сохраненной секции. В текущей реализации должно быть пустой строкой</param>
    public GridProducerToolTipExtractor(GridProducer producer, string configSectionName, string defaultConfigName, string cfgName)
      : this(producer, producer.LoadConfig(configSectionName, defaultConfigName, cfgName))
    {
    }

    /// <summary>
    /// Вызывает GridProducer.LoadConfig() и создает объект
    /// </summary>
    /// <param name="producer">Генератор табличного просмотра</param>
    /// <param name="configSectionName">Имя секции конфигурации, используемое табличным просмотром</param>
    /// <param name="defaultConfigName">Имя фиксированной настройки, используемой табличным просмотром.
    /// Пустая строка (обычно), если используется настройка просмота GridProducer.DefaultConfig</param>
    public GridProducerToolTipExtractor(GridProducer producer, string configSectionName, string defaultConfigName)
      : this(producer, producer.LoadConfig(configSectionName, defaultConfigName))
    {
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Объект-источник
    /// </summary>
    public GridProducer Producer { get { return _Producer; } }
    private GridProducer _Producer;

    /// <summary>
    /// Список используемых компонентов всплывающих подсказок
    /// Задается в конструкторе
    /// </summary>
    public IEnumerable<GridProducerToolTip> ToolTips { get { return _ToolTips; } }
    private IEnumerable<GridProducerToolTip> _ToolTips;

    /// <summary>
    /// Список полей, необходимых для получения подсказок
    /// Инициализируется в конструкторе
    /// </summary>
    public DBxColumns ColumnNames { get { return _ColumnNames; } }
    private DBxColumns _ColumnNames;

    /// <summary>
    /// Возвращает true, если список подсказок пустой
    /// </summary>
    public bool IsEmpty { get { return _ColumnNames == null; } }

    #endregion

    #region Получение подсказки

    /// <summary>
    /// Основной метод получения подсказки.
    /// Возвращает строку, содержащую тексты подсказок, разделенные символами CR+LF
    /// Исходные данные должны быть переданы в виде строки данных Row. Строка должна
    /// содержать все поля, необходимые для создания подсказки
    /// </summary>
    /// <param name="row">Строка исходных данных</param>
    /// <returns>Текст подсказки</returns>
    public string GetToolTipText(DataRow row)
    {
      if (row == null)
        throw new ArgumentNullException("row");

      StringBuilder sb = new StringBuilder();
      foreach (GridProducerToolTip ToolTip in ToolTips)
      {
        try
        {
          string s = ToolTip.PerformGetText(Producer, row);
          if (String.IsNullOrEmpty(s))
            continue;
          if (sb.Length > 0)
            sb.Append(Environment.NewLine);
          sb.Append(s);
        }
        catch
        {
        }
      }
      return sb.ToString();
    }

    #endregion
  }
}
