﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Drawing;
using AgeyevAV.ExtDB;
using AgeyevAV.DBF;
using AgeyevAV.ExtDB.Docs;
using AgeyevAV.TextMasks;
using AgeyevAV.ExtForms.NodeControls;

/*
 * The BSD License
 * 
 * Copyright (c) 2015, Ageyev A.V.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


namespace AgeyevAV.ExtForms.Docs
{
  /// <summary>
  /// Описание всех возможных полей и настроек по умолчанию для
  /// табличного просмотра. 
  /// </summary>
  public class GridProducer : IEFPConfigurableGridProducer
  {
    #region Константы

    /// <summary>
    /// Имя конфигурации по умолчанию для отображения в списках
    /// </summary>
    public const string DefaultConfigDisplayName = "< По умолчанию >";

    #endregion

    #region Конструктор

    /// <summary>
    /// Создает пустой объект
    /// </summary>
    public GridProducer()
    {
      _Columns = new GridProducerColumns();
      _ToolTips = new GridProducerToolTips();
      _Orders = new GridProducerOrders();

      _FixedColumns = new DBxColumnList();
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Полный список столбцов, которые могут быть отображены в табличном просмотре
    /// </summary>
    public GridProducerColumns Columns { get { return _Columns; } }
    private GridProducerColumns _Columns;

    /// <summary>
    /// Список строк всплывающих подсказок, которые могут быть отображены для строки табличного просмотра
    /// </summary>
    public GridProducerToolTips ToolTips { get { return _ToolTips; } }
    private GridProducerToolTips _ToolTips;

    /// <summary>
    /// Список вохможных порядков сортировки табличного просмотра
    /// </summary>
    public GridProducerOrders Orders { get { return _Orders; } }
    private GridProducerOrders _Orders;

    /// <summary>
    /// Количество записец в списке Orders
    /// </summary>
    public int OrderCount { get { return _Orders.Count; } }

    /// <summary>
    /// Кофнигурация табличного просмотра по умолчанию.
    /// Если конфигурация не была задана в явном виде, она создается автоматически при
    /// каждом обращении к свойству
    /// </summary>
    public EFPDataGridViewConfig DefaultConfig
    {
      get
      {
        if (_DefaultConfig == null)
          return MakeDefaultConfig();
        else
          return _DefaultConfig;
      }
      set
      {
        _DefaultConfig = value;
      }
    }

    private EFPDataGridViewConfig _DefaultConfig;

    /// <summary>
    /// Список имен "обязательных" полей, которые всегда добавляются в список
    /// Columns при вызове InitGrid (например, "RefId")
    /// По умолчанию - список пуст
    /// </summary>
    public DBxColumnList FixedColumns { get { return _FixedColumns; } }
    private DBxColumnList _FixedColumns;

    /// <summary>
    /// Именованные секции конфигурации
    /// </summary>
    private Dictionary<string, EFPDataGridViewConfig> _NamedConfigs;

    #endregion

    #region Инициализация табличного просмотра

    /// <summary>
    /// Инициализация табличного просмотра
    /// </summary>
    /// <param name="controlProvider">Обработчик табличного просмотра</param>
    /// <param name="reInit"></param>
    /// <param name="config">Конфигурация или null для использования конфигурации по умолчанию</param>
    /// <param name="usedColumns">Сюда добавляются имена полей, которые должны быть в наборе данных</param>
    public void InitGrid(EFPDBxGridView controlProvider, bool reInit, EFPDataGridViewConfig config, DBxColumnList usedColumns)
    {
      if (controlProvider == null)
        throw new ArgumentNullException("controlProvider");
      if (reInit)
      {
        if (controlProvider.GridProducer != this)
          throw new InvalidOperationException("Запрошена повторная инициализация, но свойство EFPDataGridView.GridProducer не установлено или установлено неверно");
      }
      if (usedColumns == null)
        throw new ArgumentNullException("UsedColumns");
      usedColumns.CheckNotReadOnly();

#if XXX // ????????????????
      if (Config == null && (!String.IsNullOrEmpty(ControlProvider.CurrentConfigName)))
      {
        try
        {
          Config = ControlProvider.ReadGridConfig(ControlProvider.CurrentConfigName);

          if (Config == null)
            EFPApp.MessageBox("Настройка просмотра \"" + ControlProvider.CurrentConfigName + "\" была удалена. Загружается настройка по умолчанию");
        }
        catch (Exception e)
        {
          EFPApp.MessageBox("Ошибка при загрузке настройки \"" + ControlProvider.CurrentConfigName + "\": " +
            e.Message + ". Будет использована настройка по умолчанию");
          Config = null;
        }
      }
#endif

      if (config == null)
      {
        if (String.IsNullOrEmpty(controlProvider.DefaultConfigName))
          config = DefaultConfig;
        else
        {
          config = GetNamedConfig(controlProvider.DefaultConfigName);
          if (config == null)
            throw new BugException("Не найдена именная конфигурация \"" + controlProvider.DefaultConfigName +
              "\". Неправильное значение свойства EFPAccDepGrid.DefaultConfigName");
        }
        // TODO: ????? ControlProvider.CurrentConfigName = String.Empty;
      }


      // предотвращаем Stack overflow
      if (config != controlProvider.CurrentConfig)
      {
        controlProvider.CurrentConfig = config;
        //ControlProvider.GridProducer = this;
      }

      usedColumns.Add(FixedColumns);
      int MaxTextRowHeight = 1;
      for (int i = 0; i < config.Columns.Count; i++)
      {
        string ColumnName = config.Columns[i].ColumnName;
        GridProducerColumn ColDef = Columns[ColumnName];
        if (ColDef == null)
          // Нет в с списке доступных столбцов
          continue;
        DataGridViewColumn Col = ColDef.CreateColumn();
        ColDef.ApplyConfig(Col, config.Columns[i], controlProvider);
        controlProvider.Control.Columns.Add(Col);
        // Запоминаем поля, которые нужны
        ColDef.GetColumnNames(usedColumns);

        EFPDataGridViewColumn Col2 = controlProvider.Columns[Col];
        Col2.ColumnProducer = ColDef;
        Col2.SizeGroup = ColDef.SizeGroup;
        Col2.CanIncSearch = ColDef.CanIncSearch;
        Col2.MaskProvider = ColDef.MaskProvider;
        Col2.DbfInfo = ColDef.DbfInfo;
        Col2.PrintHeaders = ColDef.PrintHeaders;
        Col2.ColorType = ColDef.ColorType;
        Col2.Grayed = ColDef.Grayed;

        MaxTextRowHeight = Math.Max(MaxTextRowHeight, ColDef.TextRowHeight);
      }

      if (config.FrozenColumns > 0 && config.FrozenColumns < config.Columns.Count)
        controlProvider.Control.Columns[config.FrozenColumns - 1].Frozen = true;

      controlProvider.TextRowHeight = MaxTextRowHeight;

      if (!String.IsNullOrEmpty(config.StartColumnName))
      {
        int StartColumnIndex = controlProvider.Columns.IndexOf(config.StartColumnName);
        //else
        //  // Активируем первый столбец с автоинкрементом
        //  16.05.2018
        //  Не надо. Активация нужного столбца перенесена в EFPDataGridView
        //  StartColumnIndex = ControlProvider.FirstIncSearchColumnIndex;

        controlProvider.CurrentColumnIndex = StartColumnIndex;
      }
      for (int i = 0; i < config.ToolTips.Count; i++)
      {
        GridProducerToolTip Item = ToolTips[config.ToolTips[i].ToolTipName];
        if (Item == null)
          continue;
        Item.GetColumnNames(usedColumns);
      }


      // Для отображения всплывающих подсказок и получения значений нужен отдельный 
      // объект, который будет хранить только выбранные части
      // подсказки и содержать обработчик
      if (!reInit)
      {
        GridProducerHandler tth = new GridProducerHandler(this, controlProvider);

        controlProvider.Control.CellValueNeeded += new DataGridViewCellValueEventHandler(tth.CellValueNeeded);
        controlProvider.Control.VirtualMode = true;
      }

      if (controlProvider.UseGridProducerOrders)
      {
        // Попытаемся сохранить старый порядок сортировки
        string OrgOrderDisplayName = String.Empty;
        if (reInit && controlProvider.CurrentOrder != null)
          OrgOrderDisplayName = controlProvider.CurrentOrder.DisplayName;

        if (controlProvider.OrderCount > 0)
          controlProvider.Orders.Clear();
        else
          controlProvider.DisableOrdering(); // запрет щелкать по заголовкам
        int NewOrderIndex = -1;
        if (Orders.Count > 0)
        {
          for (int i = 0; i < Orders.Count; i++)
          {
            // Добавляем только объекты сортировки, для которых существуют поля
            // в массиве Fields
            if (usedColumns.Contains(Orders[i].RequiredColumns)) // есть все необходимые поля ?
            {
              controlProvider.Orders.Add(Orders[i].DataOrder, Orders[i].DisplayName, Orders[i].SortInfo);
              if (Orders[i].DisplayName == OrgOrderDisplayName)
                NewOrderIndex = controlProvider.Orders.Count - 1;
            }
          }
          controlProvider.AutoSort = controlProvider.Orders.Count > 0;
          if (reInit)
          {
            if (NewOrderIndex >= 0)
              controlProvider.CurrentOrderIndex = NewOrderIndex;
            else
            {
              if (controlProvider.OrderCount > 0)
                controlProvider.CurrentOrderIndex = 0;
            }
          }
        }
        // 31.08.2017 условие убрано if (ReInit)
          controlProvider.CommandItems.RefreshOrderItems();
      } // ControlProvider.UseGridProducerOrders
      else
        controlProvider.DisableOrdering(); // 24.11.2015
    }

    /// <summary>
    /// Инициализация табличного просмотра
    /// </summary>
    /// <param name="controlProvider">Обработчик табличного просмотра</param>
    /// <param name="reInit">При первом показе табличного просмотра получает значение False.
    /// При повторных вызовах, когда табличный просмотр уже был инициализирован, получает значение true</param>
    public void InitGrid(EFPDataGridView controlProvider, bool reInit)
    {
      if (!(controlProvider is EFPDBxGridView))
        throw new ArgumentException("Ожидался EFPDataGridView", "controlProvider");
      DBxColumnList DummyColumns = new DBxColumnList();
      InitGrid((EFPDBxGridView)controlProvider, reInit, controlProvider.CurrentConfig, DummyColumns);
    }

    #endregion

    #region Инициализация древовидного просмотра

    /// <summary>
    /// Инициализация иерархического просмотра
    /// </summary>
    /// <param name="controlProvider">Обработчик просмотра</param>
    /// <param name="reInit"></param>
    /// <param name="config">Конфигурация или null для использования конфигурации по умолчанию</param>
    /// <param name="usedColumns">Сюда добавляются имена полей, которые должны быть в наборе данных</param>
    public void InitTree(EFPDBxTreeView controlProvider, bool reInit, EFPDataGridViewConfig config, DBxColumnList usedColumns)
    {
      if (controlProvider == null)
        throw new ArgumentNullException("controlProvider");
      if (reInit)
      {
        if (controlProvider.GridProducer != this)
          throw new InvalidOperationException("Запрошена повторная инициализация, но свойство EFPDataGridView.GridProducer не установлено или установлено неверно");
      }
      if (usedColumns == null)
        throw new ArgumentNullException("UsedColumns");
      usedColumns.CheckNotReadOnly();

      if (config == null && (!String.IsNullOrEmpty(controlProvider.CurrentConfigName)))
      {
        try
        {
          config = controlProvider.ReadGridConfig(controlProvider.CurrentConfigName);

          if (config == null)
            EFPApp.MessageBox("Настройка просмотра \"" + controlProvider.CurrentConfigName + "\" была удалена. Загружается настройка по умолчанию");
        }
        catch (Exception e)
        {
          EFPApp.MessageBox("Ошибка при загрузке настройки \"" + controlProvider.CurrentConfigName + "\": " +
            e.Message + ". Будет использована настройка по умолчанию");
          config = null;
        }
      }

      if (config == null)
      {
        if (String.IsNullOrEmpty(controlProvider.DefaultConfigName))
          config = this.DefaultConfig;
        else
        {
          config = this.GetNamedConfig(controlProvider.DefaultConfigName);
          if (config == null)
            throw new BugException("Не найдена именная конфигурация \"" + controlProvider.DefaultConfigName +
              "\". Неправильное значение свойства EFPAccDepGrid.DefaultConfigName");
        }
        controlProvider.CurrentConfigName = String.Empty;
      }


      // предотвращаем Stack overflow
      if (config != controlProvider.CurrentConfig)
      {
        controlProvider.CurrentConfig = config;
        controlProvider.GridProducer = this;
      }

      controlProvider.Control.UseColumns = true;

      usedColumns.Add(this.FixedColumns);

      int MaxTextRowHeight = 1;
      for (int i = 0; i < config.Columns.Count; i++)
      {
        string ColumnName = config.Columns[i].ColumnName;
        GridProducerColumn ColDef = this.Columns[ColumnName];
        if (ColDef == null)
          // Нет в с списке доступных столбцов
          continue;
        // Создаем объект TreeColumn
        TreeColumn tc = ColDef.CreateTreeColumn(config.Columns[i]);
        controlProvider.Control.Columns.Add(tc);

        // Создаем объект NodeControl
        BindableControl bc = ColDef.CreateNodeControl();
        ColDef.ApplyConfig(bc, config.Columns[i], controlProvider);
        bc.VirtualMode = true;
        bc.DataPropertyName = ColDef.ColumnName;
        bc.ParentColumn = controlProvider.Control.Columns[controlProvider.Control.Columns.Count - 1];
        controlProvider.Control.NodeControls.Add(bc);



        // Запоминаем поля, которые нужны
        ColDef.GetColumnNames(usedColumns);
        /*
        EFPDataGridViewColumn Col2 = ControlProvider.Columns[Col];
        Col2.ColumnProducer = ColDef;
        Col2.SizeGroup = ColDef.SizeGroup;
        Col2.CanIncSearch = ColDef.CanIncSearch;
        Col2.MaskProvider = ColDef.MaskProvider;
        Col2.DbfInfo = ColDef.DbfInfo;
        Col2.PrintHeaders = ColDef.PrintHeaders;
                                                                            */
        MaxTextRowHeight = Math.Max(MaxTextRowHeight, ColDef.TextRowHeight);
      }

      //if (Config.FrozenColumns > 0 && Config.FrozenColumns < Config.Columns.Count)
      //  ControlProvider.Control.Columns[Config.FrozenColumns - 1].Frozen = true;

      //ControlProvider.TextRowHeight = MaxTextRowHeight;
      /*
      int StartColumnIndex;
      if (String.IsNullOrEmpty(Config.StartColumnName))
        // Активируем первый столбец с автоинкрементом
        StartColumnIndex = ControlProvider.FirstIncSearchColumnIndex;
      else
        StartColumnIndex = ControlProvider.Columns.IndexOf(Config.StartColumnName);
      if (StartColumnIndex < 0)
        StartColumnIndex = 0;
      ControlProvider.CurrentColumnIndex = StartColumnIndex;
       */

      /*
      for (int i = 0; i < Config.ToolTips.Count; i++)
      {
        GridProducerToolTip Item = ToolTips[Config.ToolTips[i].ToolTipName];
        if (Item == null)
          continue;
        Item.GetColumnNames(UsedColumns);
      }
       */

      // Для отображения всплывающих подсказок и получения значений нужен отдельный 
      // объект, который будет хранить только выбранные части
      // подсказки и содержать обработчик
      if (!reInit)
      {              /*
        GridProducerHandler tth = new GridProducerHandler(this, ControlProvider);

        ControlProvider.Control.CellValueNeeded += new DataGridViewCellValueEventHandler(tth.CellValueNeeded);
        ControlProvider.Control.VirtualMode = true;*/
      }

      // Попытаемся сохранить старый порядок сортировки
      string OrgOrderDisplayName = String.Empty;
      if (reInit && controlProvider.CurrentOrder != null)
        OrgOrderDisplayName = controlProvider.CurrentOrder.DisplayName;

      if (controlProvider.OrderCount > 0)
        controlProvider.Orders.Clear();
      else
        controlProvider.DisableOrdering(); // запрет щелкать по заголовкам
#if XXX
      int NewOrderIndex = -1;
      if (Orders.Count > 0)
      {
        for (int i = 0; i < Orders.Count; i++)
        {
          // Добавляем только объекты сортировки, для которых существуют поля
          // в массиве Fields
          if (UsedColumns.Contains(Orders[i].RequiredColumns)) // есть все необходимые поля ?
          {
            ControlProvider.Orders.Add(Orders[i].ColumnNames, Orders[i].DisplayName, Orders[i].SortInfo);
            if (Orders[i].DisplayName == OrgOrderDisplayName)
              NewOrderIndex = ControlProvider.Orders.Count - 1;
          }
        }
        ControlProvider.AutoSort = ControlProvider.Orders.Count > 0;
        if (ReInit)
        {
          if (NewOrderIndex >= 0)
            ControlProvider.CurrentOrderIndex = NewOrderIndex;
          else
          {
            if (ControlProvider.OrderCount > 0)
              ControlProvider.CurrentOrderIndex = 0;
          }
        }
      }
      if (ReInit)
        ControlProvider.CommandItems.RefreshOrderItems();
#endif
    }

    #endregion

    #region Работа с настройками просмотра

    /// <summary>
    /// Создает новый объект для DefaultConfig и опционально заполняет его всеми
    /// имеющимися столбцами и ToolTip'ами
    /// </summary>
    /// <param name="addAll">Если true, то будут вызваны методы GridConfig.Columns.Add() и
    /// ToolTips.Add() для имеющихся на текуший момент значениями</param>
    public void NewDefaultConfig(bool addAll)
    {
      DefaultConfig = new EFPDataGridViewConfig();
      if (addAll)
        DefaultConfig = CreateDefaultConfig();
      else
        DefaultConfig = new EFPDataGridViewConfig();
    }


    /// <summary>
    /// Создает объект конфигурации и устанавливает в ней отметки для всех столбцов и
    /// всплывающих подсказок.
    /// </summary>
    /// <returns>Новая конфигурация</returns>
    public EFPDataGridViewConfig CreateDefaultConfig()
    {
      EFPDataGridViewConfig Config = new EFPDataGridViewConfig();
      for (int i = 0; i < Columns.Count; i++)
        Config.Columns.Add(Columns[i].ColumnName);
      for (int i = 0; i < ToolTips.Count; i++)
        Config.ToolTips.Add(ToolTips[i].Name);
      return Config;
    }

    /// <summary>
    /// Создать настройку с фиксированным именем
    /// </summary>
    /// <param name="fixedName">Имя настройки</param>
    /// <returns>Пустая конфигурация, которую нужно заполнить</returns>
    public EFPDataGridViewConfig NewNamedConfig(string fixedName)
    {
#if DEBUG
      if (String.IsNullOrEmpty(fixedName))
        throw new ArgumentNullException(fixedName);
#endif

      if (_NamedConfigs == null)
        _NamedConfigs = new Dictionary<string, EFPDataGridViewConfig>();
      EFPDataGridViewConfig Config = new EFPDataGridViewConfig();
      _NamedConfigs.Add(fixedName, Config);
      return Config;
    }

    /// <summary>
    /// Получить настройку с фиксированным именем.
    /// Если настройка не была создана, генерируется исключение
    /// </summary>
    /// <param name="fixedName">Имя настройки</param>
    /// <returns></returns>
    public EFPDataGridViewConfig GetNamedConfig(string fixedName)
    {
#if DEBUG
      if (String.IsNullOrEmpty(fixedName))
        throw new ArgumentNullException(fixedName);
#endif
      if (_NamedConfigs == null)
        return null;

      EFPDataGridViewConfig Config;
      if (_NamedConfigs.TryGetValue(fixedName, out Config))
        return Config;
      else
        throw new ArgumentException("Фиксированная настройка табличного просмотра с именем \"" + fixedName +
          "\" не была объявлена в генераторе табличного просмотра", "FixedName");
    }

    /// <summary>
    /// Возращает имена настроек, добавленных с помощью NewNamedConfig()
    /// </summary>
    /// <returns></returns>
    public string[] GetNamedConfigNames()
    {
      if (_NamedConfigs == null)
        return DataTools.EmptyStrings;
      else
      {
        string[] a = new string[_NamedConfigs.Count];
        _NamedConfigs.Keys.CopyTo(a, 0);
        return a;
      }
    }

    /// <summary>
    /// Загрузить сохраненную ранее конфигурацию с заданным именем. Если имя не задано,
    /// то возвращается DefaultConfig. Если имя неправильное, или настройка была удалена,
    /// то возврашается null
    /// </summary>
    /// <param name="configSectionName">Имя секции конфигурации, используемое табличным просмотром</param>
    /// <param name="defaulConfigName">Имя фиксированной настройки или пустая строка, если используется настройка по умолчанию</param>
    /// <param name="cfgName">Имя сохраненной секции</param>
    /// <returns></returns>
    public EFPDataGridViewConfig LoadConfig(string configSectionName, string defaulConfigName, string cfgName)
    {
      if (String.IsNullOrEmpty(cfgName))
      {
        if (String.IsNullOrEmpty(defaulConfigName))
          return DefaultConfig;
        else
          return GetNamedConfig(defaulConfigName);
      }
      else
      {
        throw new NotImplementedException();
        //TODO: return GridHandlerConfigs.GetConfig(ConfigSectionName, CfgName);
      }
    }

    /// <summary>
    /// Загрузить сохраненную ранее конфигурацию, определив имя текущей конфигурации. 
    /// Если имя не было сохранено или неправильное, или настройка была удалена,
    /// то возврашается DefaultConfig
    /// </summary>
    /// <param name="configSectionName">Имя секции конфигурации, используемое табличным просмотром</param>
    /// <param name="defaultConfigName">Имя фиксированной настройки или пустая строка, если используется настройка по умолчанию</param>
    /// <returns>Загруженная секция или DefaultConfig</returns>
    public EFPDataGridViewConfig LoadConfig(string configSectionName, string defaultConfigName)
    {
      string CfgName = GetCurrentConfigName(configSectionName);
      EFPDataGridViewConfig Config = LoadConfig(configSectionName, defaultConfigName, CfgName);
      if (Config == null)
        Config = DefaultConfig;
      return Config;
    }

    /// <summary>
    /// Определить имя текущей конфигурации, которая должна использоваться просмотром
    /// </summary>
    /// <param name="configSectionName"></param>
    /// <returns></returns>
    public static string GetCurrentConfigName(string configSectionName)
    {
      return String.Empty;
      // TODO:
      /*
      if (String.IsNullOrEmpty(ConfigSectionName))
        throw new ArgumentNullException("ConfigSectionName");
      ConfigSection Sect = AccDepClientExec.ConfigSections[ConfigSectionName, "Просмотр"];
      return Sect.GetString("Настройка");
       * */
    }

    /// <summary>
    /// Получить список полей, необходимых для заданной конфигурации
    /// </summary>
    /// <param name="config">Конфигурация. Если null, то возврашается FixedFields</param>
    /// <param name="usedColumns">Сюда добавляются имена полей</param>
    public void GetColumnNames(EFPDataGridViewConfig config, DBxColumnList usedColumns)
    {
      if (usedColumns == null)
        throw new ArgumentNullException();
      usedColumns.CheckNotReadOnly();

      usedColumns.Add(FixedColumns);
      if (config != null)
      {
        // Столбцы
        int i;
        for (i = 0; i < config.Columns.Count; i++)
        {
          string ColumnName = config.Columns[i].ColumnName;
          GridProducerColumn ColDef = Columns[ColumnName];
          if (ColDef == null)
            // Нет в с списке доступных столбцов
            continue;
          // Запоминаем поля, которые нужны
          ColDef.GetColumnNames(usedColumns);
        }

        // Всплывающие подсказки
        for (i = 0; i < config.ToolTips.Count; i++)
        {
          GridProducerToolTip Item = ToolTips[config.ToolTips[i].ToolTipName];
          if (Item == null)
            continue;
          Item.GetColumnNames(usedColumns);
        }
      }
    }

    /// <summary>
    /// Получить список полей, необходимых для табличного просмотра, при использовании
    /// конфигурации, запомненной пользователем
    /// </summary>
    /// <param name="configSectioName">Имя секции конфигурации для табличного просмотра</param>
    /// <param name="defaultConfigName">Имя фиксированной настройки или пустая строка, если используется настройка по умолчанию</param>
    /// <param name="usedColumns">Сюда добавляются имена полей</param>
    public void GetColumnNames(string configSectioName, string defaultConfigName, DBxColumnList usedColumns)
    {
      GetColumnNames(LoadConfig(configSectioName, defaultConfigName), usedColumns);
    }

    private EFPDataGridViewConfig MakeDefaultConfig()
    {
      EFPDataGridViewConfig res = new EFPDataGridViewConfig();
      int i;
      for (i = 0; i < Columns.Count; i++)
      {
        res.Columns.Add(new EFPDataGridViewConfigColumn(Columns[i].ColumnName));
        // Если определен только один столбец - делаем его с заполнением
        if (Columns.Count == 1)
          res.Columns[0].FillMode = true;
      }

      for (i = 0; i < ToolTips.Count; i++)
        res.ToolTips.Add(ToolTips[i].Name);

      res.SetReadOnly();
      return res;
    }

    #endregion

    #region Внутренняя реализация

    /// <summary>
    /// Класс для генерации всплывающих подсказок к строке 
    /// </summary>
    private class GridProducerHandler
    {
      public GridProducerHandler(GridProducer owner, EFPDataGridView controlProvider)
      {
        _Owner = owner;
        _ControlProvider = controlProvider;
      }

      private GridProducer _Owner;

      private EFPDataGridView _ControlProvider;


      public void CellValueNeeded(object sender, DataGridViewCellValueEventArgs args)
      {
        if (args.Value != null)
          return; // уже определено
        DataGridView control = (DataGridView)sender;
        DataGridViewColumn Col = control.Columns[args.ColumnIndex];

        DataRow SourceRow = EFPDataGridView.GetDataRow((DataGridView)sender, args.RowIndex);
        if (SourceRow == null)
          return;
        if (SourceRow.RowState == DataRowState.Deleted)
          return;

        GridProducerColumn ColDef = _ControlProvider.Columns[Col].ColumnProducer as GridProducerColumn;
        if (ColDef == null)
        {
          if (!String.IsNullOrEmpty(Col.DataPropertyName))
          {
            if (SourceRow.Table.Columns.Contains(Col.DataPropertyName))
              args.Value = SourceRow[Col.DataPropertyName];
          }
          return;
        }

        try
        {
          args.Value = ColDef.GetValue(control, args.RowIndex, SourceRow);
        }
        catch
        {
          args.Value = null;
        }
      }

    }

    #endregion

    #region Обработка подсказок

    internal string GetDefaultCellToolTipText(EFPDataGridViewColumn column, int rowIndex)
    {
      string s1;

      if (column.GridColumn is DataGridViewTextBoxColumn)
      {
        object v = column.ControlProvider.Control.Rows[rowIndex].Cells[column.GridColumn.Index].FormattedValue;
        if (v != null)
          s1 = v.ToString();
        else
          s1 = String.Empty;
      }
      else if (column.GridColumn is DataGridViewCheckBoxColumn)
      {
        object v = column.ControlProvider.Control.Rows[rowIndex].Cells[column.GridColumn.Index].Value;
        if (DataTools.GetBool(v))
          s1 = "Да";
        else
          s1 = "Нет";
      }
      else
        return String.Empty;

      s1 = column.GridColumn.ToolTipText + ": " + s1;
      return s1;
    }

    internal void AddRowToolTips(List<string> list, DataRow row, string columnName, EFPDataGridViewConfig config)
    {
      if (config == null)
        return;
      if (config.ToolTips.Count == 0)
        return;
      List<string> a2 = new List<string>();
      for (int i = 0; i < config.ToolTips.Count; i++)
      {
        GridProducerToolTip ToolTip = ToolTips[config.ToolTips[i].ToolTipName];
        if (ToolTip == null)
          continue;

        // 10.10.2007
        // Если в подсказки входит столбец, на который наведена мышь, то
        // исходный текст подсказки очищаем
        if (!String.IsNullOrEmpty(columnName))
        {
          DBxColumnList Columns = new DBxColumnList();
          ToolTip.GetColumnNames(Columns);
          if (Columns.Contains(columnName))
            list.Clear();
        }

        string s;
        try
        {
          s = ToolTip.PerformGetText(this, row);
        }
        catch (Exception e)
        {
          s = ToolTip.DisplayName + ": Ошибка! " + e.Message;
        }
        if (!String.IsNullOrEmpty(s))
          a2.Add(s);
      }
      if (a2.Count > 0)
      {
        list.Add("----------------------------------");
        list.AddRange(a2);
      }
    }

    #endregion

    #region Получение значений полей

    /// <summary>
    /// Присоединить объект к DBxCache.
    /// После этого, метод OnGetColumnValue() будет возвращать значение из кэша.
    /// Метод может вызываться только сразу после конструктора
    /// </summary>
    public void SetCache(DBxCache cache, string tableName)
    {
      if (cache == null)
        throw new ArgumentNullException("cache");
      if (String.IsNullOrEmpty(tableName))
        throw new ArgumentNullException("tableName");
      if (_Cache != null)
        throw new InvalidOperationException("Повторный вызов метода");

      _Cache = cache;
      _TableName = tableName;
    }

    /// <summary>
    /// Система кэширования таблиц.
    /// Устанавливается методом SetCache(), иначе содержит null.
    /// </summary>
    public DBxCache Cache { get { return _Cache; } }
    private DBxCache _Cache;

    /// <summary>
    /// Имя таблицы в системе кэширования таблиц.
    /// Устанавливается методом SetCache(), иначе содержит null.
    /// </summary>
    public string TableName { get { return _TableName; } }
    private string _TableName;

    /// <summary>
    /// Получение значения для отстутствующего в строке поля.
    /// Если метод не переопределен, то возвращает значение из кэша по заданному идентификатору
    /// (поле Id).
    /// Иначе возвращает null.
    /// </summary>
    /// <param name="row">Строка данных</param>
    /// <param name="columnName">Имя поля, которого нет в строке данных</param>
    /// <returns>Значение поля</returns>
    internal protected virtual object OnGetColumnValue(DataRow row, string columnName)
    {
      if (_Cache == null)
        return null;
      else
        return _Cache[_TableName].GetValue(DataTools.GetInt(row, "Id"), columnName);
    }

    #endregion

    #region Редактор

    /// <summary>
    /// Инициализация редактора настройки столбцов табличного просмотра.
    /// Метод должен добавить управляющие элементы в форму редактора и вернуть интерфейс управления.
    /// Загружать начальные значения в редактор не следует
    /// </summary>
    /// <param name="parentControl">Панель в окне настройки формы для размещения элементов редактора</param>
    /// <param name="baseProvider">Базовый провайдер редактора настроек</param>
    /// <param name="callerControlProvider">Провайдер настраиваемого табличного просмотра</param>
    /// <returns>Интерфейс объекта редактора</returns>
    public IEFPGridProducerEditor CreateEditor(Control parentControl, EFPBaseProvider baseProvider, IEFPGridControl callerControlProvider)
    {
      GridProducerEditor Form = new GridProducerEditor(this, callerControlProvider, baseProvider);
      parentControl.Controls.Add(Form.TheTabControl);
      return Form;
    }

    #endregion
  }

  /// <summary>
  /// Получение значения с использованием поля таблицы или объекта DBxCache
  /// </summary>
  public class TreeViewCachedValueAdapter
  {
    #region Конструктор

    /// <summary>
    /// Создает переходник
    /// </summary>
    /// <param name="nodeControl">Элемент в TreeViewAdv, к которому присоединяется обработчик события ValueNeeded</param>
    /// <param name="cache">Система кэширования данных</param>
    /// <param name="column">Генератор столбца табличного просмотра</param>
    public TreeViewCachedValueAdapter(BindableControl nodeControl, DBxCache cache, GridProducerColumn column)
    {
      if (String.IsNullOrEmpty(nodeControl.DataPropertyName))
        throw new ArgumentException("Свойство BaseTextControl.DataPropertyName не установлено");
      _UserColumn = column as GridProducerUserColumn;
      if (_UserColumn != null)
        nodeControl.ValueNeeded += new EventHandler<NodeControlValueEventArgs>(NodeControl_UserValueNeeded);
      else
        nodeControl.ValueNeeded += new EventHandler<NodeControlValueEventArgs>(NodeControl_ValueNeeded);
      _Cache = cache;
    }

    #endregion

    #region Свойство

    /// <summary>
    /// Система кэширования данных
    /// </summary>
    public DBxCache Cache { get { return _Cache; } }
    private DBxCache _Cache;

    private string _TableName;

    private string _ColumnName;

    private bool _UseCache;

    private GridProducerUserColumn _UserColumn;

    #endregion

    #region Получение значения

    private void NodeControl_ValueNeeded(object sender, NodeControlValueEventArgs args)
    {
      BindableControl NodeControl = (BindableControl)sender;
      DataRow Row = args.Node.Tag as DataRow;
      if (Row != null)
      {
        if (_ColumnName == null)
        {
          // Инициализация при первом вызове
          if (Row.Table.Columns.Contains(NodeControl.DataPropertyName))
          {
            _ColumnName = NodeControl.DataPropertyName;
            _UseCache = false;
          }
          else
          {
            int p = NodeControl.DataPropertyName.IndexOf('.');
            if (p < 0)
              throw new InvalidOperationException("Таблица \"" + Row.Table.TableName + "\" не содержит столбца \"" +
                NodeControl.DataPropertyName + "\"");
            _ColumnName = NodeControl.DataPropertyName.Substring(0, p);
            _TableName = Row.Table.TableName;
            _UseCache = true;
          }
        }

        if (Row.RowState == DataRowState.Deleted)
          args.Value = null;
        else
        {
          if (_UseCache)
          {
            Int32 RefId = DataTools.GetInt(Row, _ColumnName);
            args.Value = Cache[_TableName].GetRefValue(NodeControl.DataPropertyName, RefId, Row.Table.DataSet);
          }
          else
            args.Value = DataTools.GetString(Row, NodeControl.DataPropertyName);
        }
      }
      else
        args.Value = null;
    }

    private void NodeControl_UserValueNeeded(object sender, NodeControlValueEventArgs args)
    {
      BindableControl NodeControl = (BindableControl)sender;
      DataRow Row = args.Node.Tag as DataRow;
      if (Row != null)
      {
        if (Row.RowState == DataRowState.Deleted)
          args.Value = "Строка удалена";
        else
          args.Value = _UserColumn.GetValue(Row);
      }
      else
        args.Value = null;
    }

    #endregion

    #region Статический метод инициализации

    /// <summary>
    /// Инициализация столбцов иерархического просмотра.
    /// Находит все объекты BindableControl, созданные в <paramref name="control"/>,
    /// и создает для них экземпляры TreeViewCachedValueAdapter.
    /// </summary>
    /// <param name="control">Управляющий элемент иерархического просмотра</param>
    /// <param name="cache">Система кэширования данных</param>
    /// <param name="gridProducer">Хранилище описаний столбцов</param>
    public static void InitColumns(TreeViewAdv control, DBxCache cache, GridProducer gridProducer)
    {
      foreach (NodeControl nc in control.NodeControls)
      {
        BindableControl bc = nc as BindableControl;
        if (bc != null)
        {
          GridProducerColumn Column = gridProducer.Columns[bc.DataPropertyName];
          if (Column == null)
            continue; // неизвестно что
          new TreeViewCachedValueAdapter(bc, cache, Column);
        }
      }
    }

    #endregion
  }
}
