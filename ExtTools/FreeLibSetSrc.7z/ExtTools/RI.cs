﻿using System;
using System.Collections.Generic;
using System.Text;
using AgeyevAV.Config;
using AgeyevAV.Remoting;
using AgeyevAV.IO;
using AgeyevAV.TextMasks;
using System.Runtime.Serialization;
using AgeyevAV.DependedValues;

/*
 * The BSD License
 * 
 * Copyright (c) 2012-2015, Ageyev A.V.
 * 
 * All rights reserved.                                          
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Удаленный диалоговый интерфейс.
 * 
 * Обычное использование терминов "клиент" и "сервер" является неудобным, т.к. вводит в заблуждение.
 * Используются термины "вызывающая сторона" - та, где ожидаются результаты ввода данных и 
 * "вызываемая строна", которая взаимодействует с пользователем
 * 
 * Вызывающая сторона создает объект RIDialog и добавляет в него элементы, производные от RIItem,
 * например RILabel, RITextBox, ... Устанавливаются начальные значения свойств, например RITextBox.Text.
 * Объекты RIDialog и RIItem являются сериализуемыми. Объект RIDialog передается вызываемой стороне.
 * 
 * На вызываемой стороне выводится блок диалога. Для этого используются классы, реализованные в модуле ExtForms.dll
 * (если используется интерфейс Windows Forms). Для каждого RIItem имеется эквивалентный класс в ExtForms.
 * Эти классы отвечают за наполнение блока диалога реальным содержимым, получение и отправку реальных значений.
 * Класс RIItem содержит свойство HasChanges, которое возвращает true,
 * если есть несохраненные изменения. Класс реализует абстрактные методы ReadChanges() и WriteChanges(). 
 * Они получают в качестве аргумента объект CfgPart. Передаются только те свойства, которые изменились
 * с предыдущего вызова. Если свойство HasChanges возвращает false, метод WriteChanges() не вызывается и
 * "лишние" данные не передаются.
 * 
 * Когда пользователь нажимает "ОК" в блоке диалога, вызывается метод RIItem.GetValues() для всех элементов,
 * имеющих имя. Заполненный CfgPart передается вызывающей стороне. Там вызываются методы RIItem.WriteChanges(),
 * после чего на вызывающей стороне объект RIDialog становится синхронизированным с введенными значениями.
 * Пользовательский обработчик (событие RIDialog.Validating) может установить свойство RIItem.Error. 
 * Если есть ошибки, то вызывающая сторона собирает список ошибок и передает его вызываемой стороне. 
 * Для передачи ошибок используется те же методы ReadChanges() и WriteChanges(), что и для вводимых значений
 * В блоке диалога на экране выполняется подсветка соответствующих элементов и ожидается повторное нажатие
 * кнопки ОК.
 * В отличие от ExtForms, где EFPControl также поддерживает метод SetWarning(), для удаленного интерфейса
 * установка предупреждений не реализована. Предупреждения обычно используются для динамической подсветки
 * управляющих элементов. Удаленный интефрейс не поддерживает динамическую подсветку элементов, т.к. это
 * потребовало бы пересылки значений между сторонами, например, в процессе редактирования текста, что замедлило
 * бы работу
 * 
 * Идентификация элементов
 * Однократная передача диалога вызываемой стороне использует механизм сериализации. При этом RIDialog
 * восстанавливается в полном объеме без использования имен. При использовании WriteChanges() обязанность
 * по созданию секции CfgPart для элемента ложится на элемент-родитель. Он же отвечает за именование дочерних
 * элементов. Например, RIBand использует имена секций "C0", "C1", ..., соответствующие индексам дочерних
 * элементов
 * 
 * Пользовательский код может использовать свойство RIItem.Name и метод Find() для поиска управляющих элементов.
 * Также можно использовать обычные ссылки на элементы. Например
 * 
 * RIDialog dlg=new RIDialog("Тестовый диалог");
 * RIDateBox dt1=new RIDateBox();
 * dt1.Value=DateTime.Today; // исходное значение поля ввода
 * dlg.Controls.Add(new RILabelWithControl("Дата", dt1));
 * 
 * IRemoteInterface UI=...; // интерфейс обработки
 * if (UI.ShowDialog(dlg)!=RIDialogResult.Ok)
 *   return;
 * 
 * xxx=dt1.Value; // введенное пользователем значение
 * 
 * 
 * 
 * Запуска диалога на выполнение на сервере
 * -----------------------------
 * Основной задачей RI является показ диалога из процедуры ExecProc, выполняемой на сервере
 * Предполагается, что свойство ExecProc.Context["UIProcProxy"] возвращает ссылку на callback-процедуру
 * обработки интерфейса клиентом
 * Интерфейс IRemoteInterface объявляет методы MessageBox(), ShowDialog()
 */

namespace AgeyevAV.RI
{
  #region Перечисления для MessageBox

  /// <summary>
  /// Specifies constants defining which buttons to display on a System.Windows.Forms.MessageBox.
  /// </summary>
  [Serializable]
  public enum MessageBoxButtons
  {
    /// <summary>
    /// The message box contains an OK button.
    /// </summary>
    OK = 0,

    /// <summary>
    /// The message box contains OK and Cancel buttons.
    /// </summary>
    OKCancel = 1,

    /// <summary>
    /// The message box contains Abort, Retry, and Ignore buttons.
    /// </summary>
    AbortRetryIgnore = 2,

    /// <summary>
    /// The message box contains Yes, No, and Cancel buttons.
    /// </summary>
    YesNoCancel = 3,

    /// <summary>
    /// The message box contains Yes and No buttons.
    /// </summary>
    YesNo = 4,

    /// <summary>
    /// The message box contains Retry and Cancel buttons.
    /// </summary>
    RetryCancel = 5,
  }

  /// <summary>
  /// Specifies constants defining which information to display.
  /// </summary>
  [Serializable]
  public enum MessageBoxIcon
  {
    /// <summary>
    /// The message box contain no symbols.
    /// </summary>
    None = 0,

    /// <summary>
    /// The message box contains a symbol consisting of white X in a circle with a red background.
    /// </summary>
    Error = 16,

    /// <summary>
    /// The message box contains a symbol consisting of a white X in a circle with a red background.
    /// </summary>
    Hand = 16,

    /// <summary>
    /// The message box contains a symbol consisting of white X in a circle with a red background.
    /// </summary>
    Stop = 16,

    /// <summary>
    /// The message box contains a symbol consisting of a question mark in a circle.
    /// The question-mark message icon is no longer recommended because it does not
    /// clearly represent a specific type of message and because the phrasing of
    /// a message as a question could apply to any message type. In addition, users
    /// can confuse the message symbol question mark with Help information. Therefore,
    /// do not use this question mark message symbol in your message boxes. The system
    /// continues to support its inclusion only for backward compatibility.
    /// </summary>
    Question = 32,

    /// <summary>
    /// The message box contains a symbol consisting of an exclamation point in a
    /// triangle with a yellow background.
    /// </summary>
    Exclamation = 48,

    /// <summary>
    /// The message box contains a symbol consisting of an exclamation point in a
    /// triangle with a yellow background.
    /// </summary>
    Warning = 48,

    /// <summary>
    /// The message box contains a symbol consisting of a lowercase letter i in a circle.
    /// </summary>
    Information = 64,

    /// <summary>
    /// The message box contains a symbol consisting of a lowercase letter i in a circle.
    /// </summary>
    Asterisk = 64,
  }

  /// <summary>
  /// Specifies constants defining the default button on a System.Windows.Forms.MessageBox.
  /// </summary>
  [Serializable]
  public enum MessageBoxDefaultButton
  {
    /// <summary>
    /// The first button on the message box is the default button.
    /// </summary>
    Button1 = 0,

    /// <summary>
    /// The second button on the message box is the default button.
    /// </summary>
    Button2 = 256,

    /// <summary>
    /// The third button on the message box is the default button.
    /// </summary>
    Button3 = 512,
  }

  /// <summary>
  /// Результат вызова блока диалога
  /// </summary>
  [Serializable]
  public enum DialogResult
  {
    /// <summary>
    /// Nothing is returned from the dialog box. 
    /// This means that the modal dialog continues running.
    /// Не используется.
    /// </summary>
    None = 0,

    /// <summary>
    /// The dialog box return value is OK (usually sent from a button labeled OK).
    /// </summary>
    OK = 1,

    /// <summary>
    /// The dialog box return value is Cancel (usually sent from a button labeled Cancel).
    /// </summary>
    Cancel = 2,

    /// <summary>
    /// The dialog box return value is Abort (usually sent from a button labeled Abort).
    /// </summary>
    Abort = 3,

    /// <summary>
    /// The dialog box return value is Retry (usually sent from a button labeled Retry).
    /// </summary>
    Retry = 4,

    /// <summary>
    /// The dialog box return value is Ignore (usually sent from a button labeled Ignore).
    /// </summary>
    Ignore = 5,

    /// <summary>
    /// The dialog box return value is Yes (usually sent from a button labeled Yes).
    /// </summary>
    Yes = 6,

    /// <summary>
    /// The dialog box return value is No (usually sent from a button labeled No).
    /// </summary>
    No = 7,
  }

  #endregion

  #region Перечисления для управляющих элементов

  /// <summary>
  /// Specifies the state of a control, such as a check box, that can be checked,
  /// unchecked, or set to an indeterminate state. 
  /// </summary>
  [Serializable]
  public enum CheckState
  {
    /// <summary>
    /// The control is unchecked.
    /// </summary>
    Unchecked = 0,

    /// <summary>
    /// The control is checked.
    /// </summary>
    Checked = 1,

    /// <summary>
    /// The control is indeterminate. An indeterminate control generally has a shaded appearance.
    /// </summary>
    Indeterminate = 2,
  }

  #endregion

  #region Перечисление RIValueCfgType

  /// <summary>
  /// Тип секции конфигурации для сохранения значения
  /// </summary>
  [Serializable]
  public enum RIValueCfgType
  {
    /// <summary>
    /// Основная секция конфигурации, относящаяся к пользователю
    /// </summary>
    Default,

    /// <summary>
    /// Секция конфигурации, относящаяся к пользователю и компьютеру.
    /// В ней хранятся, например, имена файлов и каталогов.
    /// Если программа выполняется на другом компьютере, то эти данные недействительны.
    /// Под компьютером понимается обычно клиентский (вызываемый) компьютер
    /// </summary>
    MachineSpecific
  }

  #endregion

  #region Перечисление ValidateState

  /// <summary>
  /// Результат проверки ошибок
  /// </summary>
  [Serializable]
  public enum ValidateState
  {
    // Числовые значения совпадают с EFPValidateState в ExtForms.dll

    /// <summary>
    /// Ошибок не найдено
    /// </summary>
    Ok = 0,

    /// <summary>
    /// Предупреждение
    /// </summary>
    Warning = 1,

    /// <summary>
    /// Ошибка
    /// </summary>
    Error = 2
  }

  #endregion

  /// <summary>
  /// Базовый класс для передаваемых элементов пользовательского интерфейса
  /// </summary>
  [Serializable]
  public abstract class RIItem
  {
    #region Конструктор

    /// <summary>
    /// Конструктор базового класса
    /// </summary>
    public RIItem()
    {
      _Name = null;
      _ErrorMessage = null;
    }

    #endregion

    #region Имя

    /// <summary>
    /// Имя управляющего элемента для поиска.
    /// Использование свойства не является обязательным
    /// </summary>
    public string Name
    {
      get { return _Name; }
      set
      {
        CheckNotFixed();
        _Name = value;
      }
    }
    private string _Name;

    /*
    /// <summary>
    /// Проверяет наличие установленного значения для свойства Name.
    /// Если свойство не установлено, выбрасывает NullReferenceException
    /// </summary>
    protected void CheckHasName()
    {
      if (String.IsNullOrEmpty(Name))
        throw new NullReferenceException("Свойство Name не установлено для элемента");
    }
     */

    /// <summary>
    /// Поиск управляющего элемента по имени.
    /// Непереопределенный метод проверяет соответствие <paramref name="name"/> свойству Name текукущего элемента.
    /// Для контейнеров, переопределенный метод выполняет поиск среди дочерних элементов.
    /// Имена элементов являются чувствительными к регистру
    /// </summary>
    /// <param name="name">Искомое имя</param>
    /// <returns>Ссылка на найденный элемент или null.</returns>
    public virtual RIItem Find(string name)
    {
      if (String.IsNullOrEmpty(name))
        return null;
      if (name == _Name)
        return this;
      else
        return null;
    }

    /// <summary>
    /// Получение полного списка элементов.
    /// Непереопределенный метод просто добавляет текущий объект к списку.
    /// Для контейнеров, переопределенный метод добавляет также все дочерние элементы
    /// </summary>
    /// <param name="Items">Список для заполнения</param>
    public virtual void GetItems(ICollection<RIItem> Items)
    {
      Items.Add(this);
    }

    #endregion

    #region Результат проверки

    /// <summary>
    /// Установить состояние ошибки для элемента.
    /// Этот метод может вызываться из обработчика события Dialog.Validating.
    /// Очищать сообщение об ошибке в обработчике Validating (вызовом ClearErrors()) обычно нет необходимости.
    /// </summary>
    /// <param name="message">Текст сообщения об ошибке. Не может быть пустой строкой</param>
    public void SetError(string message)
    {
      if (String.IsNullOrEmpty(message))
        throw new ArgumentNullException("Message");
      _ErrorMessage = message;
    }

    /// <summary>
    /// Очищает список ошибок.
    /// Для контейнера также выполняет очистку для всех дочерних элементов.
    /// Этот метод не используется в прикладном коде.
    /// </summary>
    public virtual void ClearErrors()
    {
      _ErrorMessage = null;
    }

    /// <summary>
    /// Текущее сообщение об ошибке.
    /// Возвращает пустую строку, если нет ошибки.
    /// </summary>
    public string ErrorMessage
    {
      get
      {
        if (_ErrorMessage == null)
          return String.Empty;
        else
          return _ErrorMessage;
      }
    }
    /// <summary>
    /// Храним null вместо "", чтобы сэкономить на сериализации
    /// </summary>
    private string _ErrorMessage;

    private string OldErrorMessage
    {
      get
      {
        if (_OldErrorMessage == null)
          return String.Empty;
        else
          return _OldErrorMessage;
      }
    }
    private string _OldErrorMessage;

    /// <summary>
    /// Рекурсивный поиск элемента с ошибкой.
    /// Возвращает первый элемент, у которого установлено свойство RIItem.ErrorMessage.
    /// Возвращает null, если ошибок нет
    /// </summary>
    /// <returns>Найденный элемент или null</returns>
    public RIItem FindError()
    {
      List<RIItem> Items = new List<RIItem>();
      GetItems(Items);
      for (int i = 0; i < Items.Count; i++)
      {
        if (!String.IsNullOrEmpty(Items[i].ErrorMessage))
          return Items[i];
      }
      return null;
    }

    #endregion

    #region Чтение и запись значений

    #region Передача изменений между сервером и клиентом при сериализации

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public virtual bool HasChanges { get { return ErrorMessage != OldErrorMessage; } }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public virtual void WriteChanges(CfgPart part)
    {
      //if (ErrorMessage != OldErrorMessage)
      //{
      part.SetString("Error", ErrorMessage);
      _OldErrorMessage = _ErrorMessage;
      //}
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public virtual void ReadChanges(CfgPart part)
    {
      _ErrorMessage = part.GetString("Error");
      if (_ErrorMessage == String.Empty)
        _ErrorMessage = null;
      _OldErrorMessage = _ErrorMessage;
    }

    #endregion

    #region Сохранение значений между сеансами работы

    /// <summary>
    /// Если класс поддерживает сохранение значений между вызовами, он должен вернуть true для той секции конфигурации (или нескольких секций), 
    /// которая используется для хранения значения.
    /// Метод должен вернуть false, если свойство Name не установлено.
    /// Метод переопределяется для составных элементов, например RIBand.
    /// Вместо этого метода обычно следует переопределить OnSupportsCfgType.
    /// </summary>
    /// <param name="cfgType">Запрашиваемый тип секции конфигурации</param>
    /// <returns>true, если секция используется</returns>
    public virtual bool SupportsCfgType(RIValueCfgType cfgType)
    {
      if (String.IsNullOrEmpty(Name))
        return false;
      else
        return OnSupportsCfgType(cfgType);
    }

    /// <summary>
    /// Должно переопределяться для управляющих элементов и стандартных блоков диалога, которые поддерживают
    /// сохранение введенного значения между вызовами.
    /// Обычно, переопределенный метод должен вернуть true, если <paramref name="сfgType"/>=Default.
    /// Метод не вызывается, если свойство Name не устрановлено
    /// </summary>
    /// <param name="сfgType">Запрашиваемый тип секции конфигурации</param>
    /// <returns>true, если секция используется</returns>
    protected virtual bool OnSupportsCfgType(RIValueCfgType сfgType)
    {
      return false;
    }

    /// <summary>
    /// Записать значения в секцию конфигурации для сохранения между сеансами работы.
    /// В отличие от WriteChanges(), отдельная секция для каждого элемента не создается, т.к. это было бы не экономно.
    /// Метод вызыает SupportsCfgType() и, если true, вызывает OnWriteValues(), который и должен быть
    /// переопределен для большинства элементов.
    /// Метод переопределяется для составных элементов, типа RIItem
    /// </summary>
    /// <param name="part">Записываемая секция конфигурации</param>
    /// <param name="cfgType">Тип секции конфигурации. Должен проверяться перед записью</param>
    public virtual void WriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (SupportsCfgType(cfgType))
        OnWriteValues(part, cfgType);
    }

    /// <summary>
    /// Записать значения в секцию конфигурации для сохранения между сеансами работы.
    /// В отличие от WriteChanges(), отдельная секция для каждого элемента не создается, т.к. это было бы не экономно.
    /// В качестве имени записываемого значения должно использоваться свойство Name. Если требуется
    /// записать несколько значений, следует использовать имя Name+"."+Суффикс.
    /// Метод вызывается, только если SupportsCfgType() возвращает true для данной секции.
    /// Поэтому, обычно нет необходимости проверять свойство Name и аргумент CfgType.
    /// </summary>
    /// <param name="part">Записываемая секция конфигурации</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected virtual void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      throw new NotImplementedException("Метод OnWriteValues() должен быть переопределен для класса " + GetType().ToString());
    }

    /// <summary>
    /// Прочитать значения из секции конфигурации, сохраненные между сеансами работы
    /// В отличие от ReadChanges(), отдельная секция для каждого элемента не создается, т.к. это было бы не экономно.
    /// Метод вызыает SupportsCfgType() и, если true, вызывает OnWriteValues(), который и должен быть
    /// переопределен для большинства элементов.
    /// Метод переопределяется для составных элементов, типа RIItem
    /// </summary>
    /// <param name="part">Считываемая секция конфигурации</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    public virtual void ReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (SupportsCfgType(cfgType))
        OnReadValues(part, cfgType);
    }

    /// <summary>
    /// Прочитать значения из секцию конфигурации для сохранения между сеансами работы.
    /// В отличие от ReadChanges(), отдельная секция для каждого элемента не создается, т.к. это было бы не экономно.
    /// В качестве имени записываемого значения должно использоваться свойство Name. Если требуется
    /// записать несколько значений, следует использовать имя Name+"."+Суффикс.
    /// Метод вызывается, только если SupportsCfgType() возвращает true для данной секции.
    /// Поэтому, обычно нет необходимости проверять свойство Name и аргумент CfgType.
    /// </summary>
    /// <param name="part">Считываемая секция конфигурации</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected virtual void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      throw new NotImplementedException("Метод OnReadValues() должен быть переопределен для класса " + GetType().ToString());
    }

    internal void ReadWriteValues(CfgPart part, RIValueCfgType cfgType, bool IsWrite)
    {
      if (IsWrite)
        WriteValues(part, cfgType);
      else
        ReadValues(part, cfgType);
    }

    #endregion

    #endregion

    #region Фиксация изменений

    /// <summary>
    /// Свойство возвращает true, если диалог уже был передан клиенту.
    /// Когда свойство установлено, разрешается только изменение вводимых значений (например, свойства TextBox.Text),
    /// но не управляющих свойств (TextBox.CanBeEmpty). Также запрещается добавление дочерних элементов
    /// </summary>
    public bool IsFixed { get { return _IsFixed; } }

    [NonSerialized] // после передачи вызываемой стороне, свойство будет установлено заново
    private bool _IsFixed;

    /// <summary>
    /// Установить свойство IsFixed у текущего элемента и всех дочерних элементов.
    /// Метод может вызываться многократно
    /// </summary>
    public void SetFixed()
    {
      if (!_IsFixed)
        OnSetFixed();
    }

    /// <summary>
    /// Устанавливает свойство IsFixed в true.
    /// Переопределяется составнымт элементами, такими, как RIBand, для установки свойства дочерних элементов
    /// </summary>
    protected virtual void OnSetFixed()
    {
      _IsFixed = true;
    }

    /// <summary>
    /// Если свойство IsFixed=true, генерируется исключение InvalidOperationException
    /// </summary>
    public void CheckNotFixed()
    {
      if (_IsFixed)
        throw new InvalidOperationException("Элемент защищен от изменения управляющих свойств и добавления дочерних элементов");
    }

    #endregion

    #region Вспомогательные методы

    /// <summary>
    /// Проверяет, что массив не null, его длина больше нуля, и все строки имеют ненулевую длину
    /// </summary>
    /// <param name="items">Проверяемый массив</param>
    /// <param name="zeroLengthAllowed">Если true, то допускается массив нулевой длины</param>
    internal static void CheckNotEmptyStringArray(string[] items, bool zeroLengthAllowed)
    {
      if (items == null)
        throw new ArgumentNullException("items");
      if (!zeroLengthAllowed)
      {
        if (items.Length == 0)
          throw new ArgumentException("Items.Length=0", "items");
      }

      for (int i = 0; i < items.Length; i++)
      {
        if (String.IsNullOrEmpty(items[i]))
          throw new ArgumentNullException("Items[" + i.ToString() + "]");
      }
    }


    #endregion
  }

  /// <summary>
  /// Базовый класс для управляющих элементов, которые могут располагаться на полосе RIBand
  /// </summary>
  [Serializable]
  public abstract class Control : RIItem
  {
    #region Конструктор

    /// <summary>
    /// Конструктор базового класса
    /// </summary>
    public Control()
    {
    }

    #endregion

    #region Свойство Enabled


    /// <summary>
    /// Доступность элемента для ввода пользователем.
    /// По умолчанию - true.
    /// Нет смысла устанавливать в false это свойство, так как элемент становится бесполезным.
    /// Вместо этого можно использовать свойство EnabledEx для организации условных блокировок элементов.
    /// Свойство, однако, может опрашиваться в обработчике события Dialog.Validating, чтобы выполнять
    /// проверку корректности введенного эначения только когда элемент доступен для ввода.
    /// </summary>
    public bool Enabled
    {
      // Нет смысла делать свойство Enabled как отдельное поле, т.к. оно нужно редко

      get
      {
        if (FEnabledEx == null)
          return true; // обычный вариант
        else
          return FEnabledEx.Value;
      }
      set
      {
        if (value && (FEnabledEx == null))
          return;

        EnabledEx.Value = value;
      }
    }

    /// <summary>
    /// Управляемое значение для Enabled.
    /// Используется для организации условной блокировки элементов.
    /// Например, элемент может быть доступен, только если включен флажок CheckBox.
    /// </summary>
    public DepValue<bool> EnabledEx
    {
      get
      {
        InitEnabledEx();
        return FEnabledEx;
      }
      set
      {
        InitEnabledEx();
        FEnabledEx.Source = value;
      }
    }
    private DepInput<bool> FEnabledEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства EnabledEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasEnabledExProperty { get { return FEnabledEx != null; } }


    private void InitEnabledEx()
    {
      if (FEnabledEx == null)
      {
        FEnabledEx = new DepInput<bool>();
        FEnabledEx.OwnerInfo = new DepOwnerInfo(this, "EnabledEx");
        FEnabledEx.Value = true;
        FEnabledEx.ValueChanged += new EventHandler(FEnabledEx_ValueChanged);
      }
    }

    private void FEnabledEx_ValueChanged(object Sender, EventArgs Args)
    {
    }

    #endregion
  }

  /// <summary>
  /// Метка для другого управляющего элемента.
  /// Свойство "Text" является неизменяемым
  /// Не содержит значений, которые можно было бы передавать
  /// </summary>
  [Serializable]
  public class Label : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает метку.
    /// </summary>
    /// <param name="text">Текст метки. Может содержать символ "амперсанд" для выделения "горячей клавиши".
    /// Не может быть пустой строкой</param>
    public Label(string text)
    {
      if (String.IsNullOrEmpty(text))
        throw new ArgumentNullException("text");
      _Text = text;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Текст метки. Может содержать символ "амперсанд" для выделения "горячей клавиши"
    /// </summary>
    public string Text { get { return _Text; } }
    private string _Text;

    #endregion
  }


  /// <summary>
  /// Поле ввода однострочного текста
  /// </summary>
  [Serializable]
  public class TextBox : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает поле ввода
    /// </summary>
    public TextBox()
    {
      _MaxLength = Int16.MaxValue;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Введенный текст
    /// </summary>
    public string Text
    {
      get
      {
        if (_Text == null)
          return String.Empty;
        else
          return _Text;
      }
      set
      {
        if (String.IsNullOrEmpty(value))
          _Text = null;
        else
          _Text = value;
        if (_TextEx != null)
          _TextEx.Value = _Text;
      }
    }
    private string _Text; // храним null вместо пустой строки

    private string _OldText;


    /// <summary>
    /// Управляемое значение для Text.
    /// </summary>
    public DepValue<string> TextEx
    {
      get
      {
        InitTextEx();
        return _TextEx;
      }
      set
      {
        InitTextEx();
        _TextEx.Source = value;
      }
    }
    private DepInput<string> _TextEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства TextEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasTextExProperty { get { return _TextEx != null; } }

    private void InitTextEx()
    {
      if (_TextEx == null)
      {
        _TextEx = new DepInput<string>();
        _TextEx.OwnerInfo = new DepOwnerInfo(this, "TextEx");
        _TextEx.Value = Text;
        _TextEx.ValueChanged += new EventHandler(TextEx_ValueChanged);
      }
    }

    private void TextEx_ValueChanged(object Sender, EventArgs Args)
    {
      Text = _TextEx.Value;
    }


    /// <summary>
    /// Может ли поле быть пустым
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне
    /// Значение по умолчанию: false (поле является обязательным)
    /// </summary>
    public bool CanBeEmpty
    {
      get { return _CanBeEmpty; }
      set
      {
        CheckNotFixed();
        _CanBeEmpty = value;
      }
    }
    private bool _CanBeEmpty;

    /// <summary>
    /// Максимальная длина текста. По умолчанию: 32767 (Int16.MaxValue) символов
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне
    /// </summary>
    public int MaxLength
    {
      get { return _MaxLength; }
      set
      {
        CheckNotFixed();
        _MaxLength = value;
      }
    }
    private int _MaxLength;

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return Text != _OldText;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetString("Text", Text);
      _OldText = Text;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Text = part.GetString("Text");
      _OldText = Text;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetString(Name, Text);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
        Text = part.GetString(Name);
    }

    #endregion
  }

  /// <summary>
  /// Поле ввода целого числа
  /// </summary>
  [Serializable]
  public class IntEditBox : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает поле ввода
    /// </summary>
    public IntEditBox()
    {
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Текушее значение
    /// </summary>
    public int Value
    {
      get
      {
        return _Value;
      }
      set
      {
        _Value = value;
        if (_ValueEx != null)
          _ValueEx.Value = value;
      }
    }
    private int _Value;

    private int _OldValue;

    /// <summary>
    /// Управляемое значение для Value.
    /// </summary>
    public DepValue<int> ValueEx
    {
      get
      {
        InitValueEx();
        return _ValueEx;
      }
      set
      {
        InitValueEx();
        _ValueEx.Source = value;
      }
    }
    private DepInput<int> _ValueEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства ValueEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasValueExProperty { get { return _ValueEx != null; } }

    private void InitValueEx()
    {
      if (_ValueEx == null)
      {
        _ValueEx = new DepInput<int>();
        _ValueEx.OwnerInfo = new DepOwnerInfo(this, "ValueEx");
        _ValueEx.Value = Value;
        _ValueEx.ValueChanged += new EventHandler(ValueEx_ValueChanged);
      }
    }

    private void ValueEx_ValueChanged(object Sender, EventArgs Args)
    {
      Value = _ValueEx.Value;
    }

    /// <summary>
    /// Минимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public int? Minimum
    {
      get { return _Minimum; }
      set
      {
        CheckNotFixed();
        _Minimum = value;
      }
    }
    private int? _Minimum;

    /// <summary>
    /// Максимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public int? Maximum
    {
      get { return _Maximum; }
      set
      {
        CheckNotFixed();
        _Maximum = value;
      }
    }
    private int? _Maximum;

    /// <summary>
    /// Если свойство установлено в true, то значение можно выбирать с помощью стрелочек.
    /// По умолчанию - false - стрелочки не используются.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public bool ShowUpDown
    {
      get { return _ShowUpDown; }
      set
      {
        CheckNotFixed();
        _ShowUpDown = value;
      }
    }
    private bool _ShowUpDown;

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _Value != _OldValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetInt("Value", _Value);
      _OldValue = _Value;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      _Value = part.GetInt("Value");
      _OldValue = Value;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetInt(Name, Value);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      Value = part.GetIntDef(Name, Value);
    }

    #endregion
  }

  /// <summary>
  /// Поле ввода числа одинарной точности
  /// </summary>
  [Serializable]
  public class SingleEditBox : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает поле ввода
    /// </summary>
    public SingleEditBox()
    {
      _DecimalPlaces = -1;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Текушее значение
    /// </summary>
    public float Value
    {
      get
      {
        return _Value;
      }
      set
      {
        _Value = value;
        if (_ValueEx != null)
          _ValueEx.Value = value;
      }
    }
    private float _Value;

    private float _OldValue;


    /// <summary>
    /// Управляемое значение для Value.
    /// </summary>
    public DepValue<float> ValueEx
    {
      get
      {
        InitValueEx();
        return _ValueEx;
      }
      set
      {
        InitValueEx();
        _ValueEx.Source = value;
      }
    }
    private DepInput<float> _ValueEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства ValueEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasValueExProperty { get { return _ValueEx != null; } }

    private void InitValueEx()
    {
      if (_ValueEx == null)
      {
        _ValueEx = new DepInput<float>();
        _ValueEx.OwnerInfo = new DepOwnerInfo(this, "ValueEx");
        _ValueEx.Value = Value;
        _ValueEx.ValueChanged += new EventHandler(ValueEx_ValueChanged);
      }
    }

    private void ValueEx_ValueChanged(object Sender, EventArgs Args)
    {
      Value = _ValueEx.Value;
    }
    /// <summary>
    /// Количество знаков после запятой. По умолчанию: (-1) - разрешается использование любого числа знаков
    /// Если поле предназначено для ввода целых чисел, следует установить равным 0.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public int DecimalPlaces { get { return _DecimalPlaces; } set { _DecimalPlaces = value; } }
    private int _DecimalPlaces;

    /// <summary>
    /// Минимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public float? Minimum
    {
      get { return _Minimum; }
      set
      {
        CheckNotFixed();
        _Minimum = value;
      }
    }
    private float? _Minimum;

    /// <summary>
    /// Максимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public float? Maximum
    {
      get { return _Maximum; }
      set
      {
        CheckNotFixed();
        _Maximum = value;
      }
    }
    private float? _Maximum;

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _Value != _OldValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetSingle("Value", _Value);
      _OldValue = _Value;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      _Value = part.GetSingle("Value");
      _OldValue = Value;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetSingle(Name, Value);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      Value = part.GetSingleDef(Name, Value);
    }

    #endregion
  }

  /// <summary>
  /// Поле ввода числа двойной точности
  /// </summary>
  [Serializable]
  public class DoubleEditBox : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает поле ввода
    /// </summary>
    public DoubleEditBox()
    {
      _DecimalPlaces = -1;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Текушее значение
    /// </summary>
    public double Value
    {
      get
      {
        return _Value;
      }
      set
      {
        _Value = value;
        if (_ValueEx != null)
          _ValueEx.Value = value;
      }
    }
    private double _Value;

    private double _OldValue;

    /// <summary>
    /// Управляемое значение для Value.
    /// </summary>
    public DepValue<double> ValueEx
    {
      get
      {
        InitValueEx();
        return _ValueEx;
      }
      set
      {
        InitValueEx();
        _ValueEx.Source = value;
      }
    }
    private DepInput<Double> _ValueEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства ValueEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasValueExProperty { get { return _ValueEx != null; } }

    private void InitValueEx()
    {
      if (_ValueEx == null)
      {
        _ValueEx = new DepInput<double>();
        _ValueEx.OwnerInfo = new DepOwnerInfo(this, "ValueEx");
        _ValueEx.Value = Value;
        _ValueEx.ValueChanged += new EventHandler(ValueEx_ValueChanged);
      }
    }

    private void ValueEx_ValueChanged(object sender, EventArgs args)
    {
      Value = _ValueEx.Value;
    }

    /// <summary>
    /// Количество знаков после запятой. По умолчанию: (-1) - разрешается использование любого числа знаков
    /// Если поле предназначено для ввода целых чисел, следует установить равным 0.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public int DecimalPlaces { get { return _DecimalPlaces; } set { _DecimalPlaces = value; } }
    private int _DecimalPlaces;

    /// <summary>
    /// Минимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public double? Minimum
    {
      get { return _Minimum; }
      set
      {
        CheckNotFixed();
        _Minimum = value;
      }
    }
    private double? _Minimum;

    /// <summary>
    /// Максимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public double? Maximum
    {
      get { return _Maximum; }
      set
      {
        CheckNotFixed();
        _Maximum = value;
      }
    }
    private double? _Maximum;

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _Value != _OldValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetDouble("Value", _Value);
      _OldValue = _Value;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      _Value = part.GetDouble("Value");
      _OldValue = Value;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetDouble(Name, Value);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      Value = part.GetDoubleDef(Name, Value);
    }

    #endregion
  }

  /// <summary>
  /// Поле ввода числа типа decimal
  /// </summary>
  [Serializable]
  public class DecimalEditBox : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает поле ввода
    /// </summary>
    public DecimalEditBox()
    {
      _DecimalPlaces = -1;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Текушее значение
    /// </summary>
    public decimal Value
    {
      get
      {
        return _Value;
      }
      set
      {
        _Value = value;
        if (_ValueEx != null)
          _ValueEx.Value = value;
      }
    }
    private decimal _Value; // данные всегда хранятся в формате Decimal

    private decimal _OldValue;

    /// <summary>
    /// Управляемое значение для Value.
    /// </summary>
    public DepValue<decimal> ValueEx
    {
      get
      {
        InitValueEx();
        return _ValueEx;
      }
      set
      {
        InitValueEx();
        _ValueEx.Source = value;
      }
    }
    private DepInput<decimal> _ValueEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства ValueEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasValueExProperty { get { return _ValueEx != null; } }

    private void InitValueEx()
    {
      if (_ValueEx == null)
      {
        _ValueEx = new DepInput<decimal>();
        _ValueEx.OwnerInfo = new DepOwnerInfo(this, "ValueEx");
        _ValueEx.Value = Value;
        _ValueEx.ValueChanged += new EventHandler(ValueEx_ValueChanged);
      }
    }

    private void ValueEx_ValueChanged(object sender, EventArgs args)
    {
      Value = _ValueEx.Value;
    }

    /// <summary>
    /// Количество знаков после запятой. По умолчанию: (-1) - разрешается использование любого числа знаков
    /// Если поле предназначено для ввода целых чисел, следует установить равным 0.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public int DecimalPlaces { get { return _DecimalPlaces; } set { _DecimalPlaces = value; } }
    private int _DecimalPlaces;

    /// <summary>
    /// Минимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public decimal? Minimum
    {
      get { return _Minimum; }
      set
      {
        CheckNotFixed();
        _Minimum = value;
      }
    }
    private decimal? _Minimum;

    /// <summary>
    /// Максимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public decimal? Maximum
    {
      get { return _Maximum; }
      set
      {
        CheckNotFixed();
        _Maximum = value;
      }
    }
    private decimal? _Maximum;

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _Value != _OldValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetDecimal("Value", _Value);
      _OldValue = _Value;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      _Value = part.GetDecimal("Value");
      _OldValue = Value;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetDecimal(Name, Value);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      Value = part.GetDecimalDef(Name, Value);
    }

    #endregion
  }

  /// <summary>
  /// Переключатель CheckBox.
  /// Поддерживаются переключатели на два и на три состояния (свойство ThreeState).
  /// </summary>
  [Serializable]
  public class CheckBox : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает переключатель
    /// </summary>
    /// <param name="text">Текст кнопки. Должен быть задан</param>
    public CheckBox(string text)
    {
      if (String.IsNullOrEmpty(text))
        throw new ArgumentNullException("Text");
      _Text = text;
      _CheckState = CheckState.Unchecked;
      _OldCheckState = CheckState.Unchecked;
    }

    #endregion

    #region Свойства

    #region Text

    /// <summary>
    /// Текст переключателя.
    /// Может содержать амперсанд для подчеркивания буквы.
    /// Задается в конструкторе и не может быть изменено.
    /// </summary>
    public string Text { get { return _Text; } }
    private string _Text;

    #endregion

    #region ThreeState

    /// <summary>
    /// Разрешено ли использовать третье состояние
    /// По умолчанию - false - (два состояния).
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public bool ThreeState
    {
      get { return _ThreeState; }
      set
      {
        CheckNotFixed();
        _ThreeState = value;
      }
    }
    private bool _ThreeState;

    #endregion

    #region CheckState

    /// <summary>
    /// Если есть расширенное свойство CheckedEx и устанавливается значение CheckState=Indeterminate,
    /// то оно исчезнет и заменится на Checked. Чтобы этого не произошло, предотвращаем вложенный вызов
    /// </summary>
    [NonSerialized]
    private bool InsideSetCheckState;

    /// <summary>
    /// Текущее состояние кнопки.
    /// Обычно свойство используется для кнопок, у которых установлено ThreeState=true.
    /// Для обычных кнопок на два положения удобнее использовать свойство Checked.
    /// </summary>
    public CheckState CheckState
    {
      get { return _CheckState; }
      set
      {
        if (InsideSetCheckState)
          return;
        InsideSetCheckState = true;
        try
        {
          _CheckState = value;
          if (_CheckStateEx != null)
            _CheckStateEx.Value = CheckState;
          if (_CheckedEx != null)
            _CheckedEx.Value = Checked;
        }
        finally
        {
          InsideSetCheckState = false;
        }
      }
    }
    private CheckState _CheckState;

    private CheckState _OldCheckState;

    /// <summary>
    /// Управляемое значение для CheckState.
    /// </summary>
    public DepValue<CheckState> CheckStateEx
    {
      get
      {
        InitCheckStateEx();
        return _CheckStateEx;
      }
      set
      {
        InitCheckStateEx();
        _CheckStateEx.Source = value;
      }
    }
    private DepInput<CheckState> _CheckStateEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства CheckStateEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasCheckStateExProperty { get { return _CheckStateEx != null; } }

    private void InitCheckStateEx()
    {
      if (_CheckStateEx == null)
      {
        _CheckStateEx = new DepInput<CheckState>();
        _CheckStateEx.OwnerInfo = new DepOwnerInfo(this, "CheckStateEx");
        _CheckStateEx.Value = CheckState;
        _CheckStateEx.ValueChanged += new EventHandler(CheckStateEx_ValueChanged);
      }
    }

    private void CheckStateEx_ValueChanged(object sender, EventArgs args)
    {
      CheckState = _CheckStateEx.Value;
    }

    #endregion

    #region Checked

    /// <summary>
    /// Состояние кнопки.
    /// Используется для обычных кнопок на два положения.
    /// Если ThreeState=true, используйте свойство CheckState.
    /// Если ThreeState=true, то свойство возращает true для CheckState=Checked и Indeterminate и false для Unchecked.
    /// Установка свойства в true задает CheckState=Checked, а false - CheckState=Unchecked.
    /// </summary>
    public bool Checked
    {
      get
      {
        return CheckState != CheckState.Unchecked;
      }
      set
      {
        CheckState = value ? CheckState.Checked : CheckState.Unchecked;
      }
    }

    /// <summary>
    /// Управляемое значение для Checked.
    /// </summary>
    public DepValue<bool> CheckedEx
    {
      get
      {
        InitCheckedEx();
        return _CheckedEx;
      }
      set
      {
        InitCheckedEx();
        _CheckedEx.Source = value;
      }
    }
    private DepInput<bool> _CheckedEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства CheckedEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasCheckedExProperty { get { return _CheckedEx != null; } }

    private void InitCheckedEx()
    {
      if (_CheckedEx == null)
      {
        _CheckedEx = new DepInput<bool>();
        _CheckedEx.OwnerInfo = new DepOwnerInfo(this, "CheckedEx");
        _CheckedEx.Value = Checked;
        _CheckedEx.ValueChanged += new EventHandler(CheckedEx_ValueChanged);
      }
    }

    private void CheckedEx_ValueChanged(object sender, EventArgs args)
    {
      Checked = _CheckedEx.Value;
    }

    #endregion

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return CheckState != _OldCheckState;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetInt("CheckState", (int)CheckState);
      _OldCheckState = CheckState;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      CheckState = (CheckState)part.GetInt("CheckState");
      _OldCheckState = CheckState;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetInt(Name, (int)CheckState); // 0,1 или 2
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (ThreeState)
        CheckState = (CheckState)part.GetIntDef(Name, (int)CheckState);
      else
        Checked = part.GetBoolDef(Name, Checked);
    }

    #endregion
  }

  /// <summary>
  /// Группа радиокнопок
  /// </summary>
  [Serializable]
  public class RadioGroup : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает группу кнопок.
    /// </summary>
    /// <param name="items">Список надписей для кнопок. Массив не может быть пустым</param>
    public RadioGroup(string[] items)
    {
      CheckNotEmptyStringArray(items, false);

      _Items = items;
    }

    #endregion

    #region Свойства

    #region Items

    /// <summary>
    /// Названия радиокнопок.
    /// Названия могут содержать амперсанд, чтобы выделить букву.
    /// Задаются в конструкторе и не могут быть изменены в дальнейшем
    /// </summary>
    public string[] Items { get { return _Items; } }
    private string[] _Items;

    #endregion

    #region SelectedIndex

    /// <summary>
    /// Текущее выбранное значение (индекс в списке Items)
    /// </summary>
    public int SelectedIndex
    {
      get { return _SelectedIndex; }
      set
      {
        _SelectedIndex = value;
        if (_SelectedIndexEx != null)
          _SelectedIndexEx.Value = SelectedIndex;
        if (_SelectedCodeEx != null)
          _SelectedCodeEx.Value = SelectedCode;
      }
    }
    private int _SelectedIndex;

    private int _OldSelectedIndex;

    /// <summary>
    /// Управляемое значение для SelectedIndex.
    /// </summary>
    public DepValue<int> SelectedIndexEx
    {
      get
      {
        InitSelectedIndexEx();
        return _SelectedIndexEx;
      }
      set
      {
        InitSelectedIndexEx();
        _SelectedIndexEx.Source = value;
      }
    }
    private DepInput<int> _SelectedIndexEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства SelectedIndexEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasSelectedIndexExProperty { get { return _SelectedIndexEx != null; } }

    private void InitSelectedIndexEx()
    {
      if (_SelectedIndexEx == null)
      {
        _SelectedIndexEx = new DepInput<int>();
        _SelectedIndexEx.OwnerInfo = new DepOwnerInfo(this, "SelectedIndexEx");
        _SelectedIndexEx.Value = SelectedIndex;
        _SelectedIndexEx.ValueChanged += new EventHandler(SelectedIndexEx_ValueChanged);
      }
    }

    private void SelectedIndexEx_ValueChanged(object sender, EventArgs args)
    {
      SelectedIndex = _SelectedIndexEx.Value;
    }

    #endregion

    #region Codes

    /// <summary>
    /// Коды для элементов.
    /// Если свойство установлено, то для сохранения значения между сеансами работы используется код, а не индекс.
    /// По умолчанию свойство содержит значение null и свойство SelectedCode нельзя использовать.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// Длина массива должна совпадать с Items.
    /// </summary>
    public string[] Codes
    {
      get { return _Codes; }
      set
      {
        CheckNotFixed();
        if (value != null)
        {
          if (value.Length != _Items.Length)
            throw new ArgumentException("Неправильная длина массива кодов");
          _Codes = value;
        }
      }
    }
    private string[] _Codes;

    #endregion

    #region SelectedCode

    /// <summary>
    /// Текущая выбранная позиция как код.
    /// Должно быть установлено свойство Codes, иначе свойство возвращает пустую строку.
    /// </summary>
    public string SelectedCode
    {
      get
      {
        if (Codes == null)
          return String.Empty;
        else
        {
          if (SelectedIndex < 0)
            return String.Empty; // нет свойства UnselectedCode
          else
            return Codes[SelectedIndex];
        }
      }
      set
      {
        if (Codes == null)
          throw new InvalidOperationException("Свойство Codes не установено");
        SelectedIndex = Array.IndexOf<string>(Codes, value);
      }
    }

    /// <summary>
    /// Управляемое значение для SelectedCode.
    /// </summary>
    public DepValue<string> SelectedCodeEx
    {
      get
      {
        InitSelectedCodeEx();
        return _SelectedCodeEx;
      }
      set
      {
        InitSelectedCodeEx();
        _SelectedCodeEx.Source = value;
      }
    }
    private DepInput<string> _SelectedCodeEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства SelectedCodeEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasSelectedCodeExProperty { get { return _SelectedCodeEx != null; } }

    private void InitSelectedCodeEx()
    {
      if (_SelectedCodeEx == null)
      {
        _SelectedCodeEx = new DepInput<string>();
        _SelectedCodeEx.OwnerInfo = new DepOwnerInfo(this, "SelectedCodeEx");
        _SelectedCodeEx.Value = SelectedCode;
        _SelectedCodeEx.ValueChanged += new EventHandler(FSelectedCodeEx_ValueChanged);
      }
    }

    private void FSelectedCodeEx_ValueChanged(object Sender, EventArgs Args)
    {
      SelectedCode = _SelectedCodeEx.Value;
    }

    #endregion

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return SelectedIndex != _OldSelectedIndex;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetInt("SelectedIndex", SelectedIndex);
      _OldSelectedIndex = SelectedIndex;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      SelectedIndex = part.GetInt("SelectedIndex");
      _OldSelectedIndex = SelectedIndex;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (Codes == null)
        part.SetInt(Name, SelectedIndex);
      else
        part.SetString(Name, SelectedCode);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
      {
        if (Codes == null)
          SelectedIndex = part.GetInt(Name);
        else
          SelectedCode = part.GetString(Name);
      }
    }

    #endregion
  }

  /// <summary>
  /// Поле ввода даты
  /// </summary>
  [Serializable]
  public class DateBox : Control
  {
    #region Свойства

    /// <summary>
    /// Введенное значение
    /// </summary>
    public DateTime? Value
    {
      get { return _Value; }
      set
      {
        _Value = value;
        if (_ValueEx != null)
          _ValueEx.Value = value;
      }
    }
    private DateTime? _Value;

    private DateTime? _OldValue;

    /// <summary>
    /// Управляемое значение для Value.
    /// </summary>
    public DepValue<DateTime?> ValueEx
    {
      get
      {
        InitValueEx();
        return _ValueEx;
      }
      set
      {
        InitValueEx();
        _ValueEx.Source = value;
      }
    }
    private DepInput<DateTime?> _ValueEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства ValueEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasValueExProperty { get { return _ValueEx != null; } }

    private void InitValueEx()
    {
      if (_ValueEx == null)
      {
        _ValueEx = new DepInput<DateTime?>();
        _ValueEx.OwnerInfo = new DepOwnerInfo(this, "ValueEx");
        _ValueEx.Value = Value;
        _ValueEx.ValueChanged += new EventHandler(ValueEx_ValueChanged);
      }
    }

    private void ValueEx_ValueChanged(object sender, EventArgs args)
    {
      Value = _ValueEx.Value;
    }

    /// <summary>
    /// Может ли поле быть пустым.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public bool CanBeEmpty
    {
      get { return _CanBeEmpty; }
      set
      {
        CheckNotFixed();
        _CanBeEmpty = value;
      }
    }
    private bool _CanBeEmpty;

    /// <summary>
    /// Минимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство можно устанавливать только до вывода диалога на экран.
    /// </summary>
    public DateTime? Minimum
    {
      get { return _Minimum; }
      set
      {
        CheckNotFixed();
        _Minimum = value;
      }
    }
    private DateTime? _Minimum;

    /// <summary>
    /// Максимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено
    /// </summary>
    public DateTime? Maximum
    {
      get { return _Maximum; }
      set
      {
        CheckNotFixed();
        _Maximum = value;
      }
    }
    private DateTime? _Maximum;

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return Value != _OldValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableDate("Value", Value);
      _OldValue = Value;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Value = part.GetNullableDate("Value");
      _OldValue = Value;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (Value.HasValue)
        part.SetDate(Name, Value.Value);
      else
        part.SetString(Name, String.Empty);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
        Value = part.GetNullableDate(Name);
    }

    #endregion
  }

  /// <summary>
  /// Поле ввода интервала дат
  /// </summary>
  [Serializable]
  public class DateRangeBox : Control
  {
    #region Свойства

    #region Редактируемое значение

    /// <summary>
    /// Начальная дата диапазона
    /// </summary>
    public DateTime? FirstDate
    {
      get { return _FirstDate; }
      set { _FirstDate = value; }
    }
    private DateTime? _FirstDate;

    private DateTime? _OldFirstDate;

    /// <summary>
    /// Конечная дата диапазона
    /// </summary>
    public DateTime? LastDate
    {
      get { return _LastDate; }
      set { _LastDate = value; }
    }
    private DateTime? _LastDate;

    private DateTime? _OldLastDate;

    /// <summary>
    /// Вспомогательное свойство для доступа к интервалу дат.
    /// Если начальная и/или конечная дата не установлена, свойство возвращает DateRange.Empty.
    /// Установка значения свойства в DateRange.Empty очищает обе даты
    /// </summary>
    public DateRange DateRange
    {
      get
      {
        if (FirstDate.HasValue && LastDate.HasValue)
          return new DateRange(FirstDate.Value, LastDate.Value);
        else
          return DateRange.Empty;
      }
      set
      {
        if (value.IsEmpty)
        {
          FirstDate = null;
          LastDate = null;
        }
        else
        {
          FirstDate = value.FirstDate;
          LastDate = value.LastDate;
        }
      }
    }

    #endregion

    #region CanBeEmpty

    /// <summary>
    /// Могут ли поля быть пустыми.
    /// По умолчанию - false.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public bool CanBeEmpty
    {
      get { return _CanBeEmpty; }
      set
      {
        CheckNotFixed();
        _CanBeEmpty = value;
      }
    }
    private bool _CanBeEmpty;

    #endregion

    #region Диапазон значений

    #region Отдельно для начальной даты

    /// <summary>
    /// Минимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public DateTime? MinimumFirstDate
    {
      get { return _MinimumFirstDate; }
      set
      {
        CheckNotFixed();
        _MinimumFirstDate = value;
      }
    }
    private DateTime? _MinimumFirstDate;

    /// <summary>
    /// Максимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public DateTime? MaximumFirstDate
    {
      get { return _MaximumFirstDate; }
      set
      {
        CheckNotFixed();
        _MaximumFirstDate = value;
      }
    }
    private DateTime? _MaximumFirstDate;

    #endregion

    #region Отдельно для конечной даты

    /// <summary>
    /// Минимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public DateTime? MinimumLastDate
    {
      get { return _MinimumLastDate; }
      set
      {
        CheckNotFixed();
        _MinimumLastDate = value;
      }
    }
    private DateTime? _MinimumLastDate;

    /// <summary>
    /// Максимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public DateTime? MaximumLastDate
    {
      get { return _MaximumLastDate; }
      set
      {
        CheckNotFixed();
        _MaximumLastDate = value;
      }
    }
    private DateTime? _MaximumLastDate;

    #endregion

    #region Для диапазона в-целом

    /// <summary>
    /// Минимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Установка этого свойства задает ограничение и для начальной и для конечной даты диапазона (свойства MinimumFirstDate и MinumumLastDate).
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public DateTime? Minimum
    {
      get
      {
        if (MinimumFirstDate.HasValue && MinimumLastDate.HasValue && MinimumFirstDate == MinimumLastDate)
          return MinimumFirstDate;
        else
          return null;
      }
      set
      {
        MinimumFirstDate = value;
        MinimumLastDate = value;
      }
    }

    /// <summary>
    /// Максимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Установка этого свойства задает ограничение и для начально и для конечной даты диапазона (свойства MaximumFirstDate и MaximumLastDate).
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public DateTime? Maximum
    {
      get
      {
        if (MaximumFirstDate.HasValue && MaximumLastDate.HasValue && MaximumFirstDate == MaximumLastDate)
          return MinimumFirstDate;
        else
          return null;
      }
      set
      {
        MaximumFirstDate = value;
        MaximumLastDate = value;
      }
    }

    #endregion

    #endregion

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return FirstDate != _OldFirstDate || LastDate != _OldLastDate;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableDate("FirstDate", FirstDate);
      part.SetNullableDate("LastDate", LastDate);
      _OldFirstDate = FirstDate;
      _OldLastDate = LastDate;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      FirstDate = part.GetNullableDate("FirstDate");
      LastDate = part.GetNullableDate("LastDate");
      _OldFirstDate = FirstDate;
      _OldLastDate = LastDate;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (FirstDate.HasValue)
        part.SetDate(Name + "-First", FirstDate.Value);
      else
        part.SetString(Name + "-First", String.Empty);

      if (LastDate.HasValue)
        part.SetDate(Name + "-Last", LastDate.Value);
      else
        part.SetString(Name + "-Last", String.Empty);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name + "-First"))
        FirstDate = part.GetNullableDate(Name + "-First");
      if (part.HasValue(Name + "-Last"))
        LastDate = part.GetNullableDate(Name + "-Last");
    }

    #endregion
  }

  /// <summary>
  /// Поле ввода одиночной даты или интервала дат.
  /// Полуоткрытые интервалы недопускаются
  /// </summary>
  [Serializable]
  public class DateOrRangeBox : Control
  {
    #region Свойства

    #region Вводимое значение

    /// <summary>
    /// Интервал дат.
    /// Пустой интервал задается как DateRange.Empty
    /// </summary>
    public DateRange DateRange
    {
      get { return _DateRange; }
      set { _DateRange = value; }
    }
    private DateRange _DateRange;

    private DateRange _OldDateRange;

    #endregion

    #region CanBeEmpty

    /// <summary>
    /// Допускается ли пустой интервал дат.
    /// По умолчанию - false.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public bool CanBeEmpty
    {
      get { return _CanBeEmpty; }
      set
      {
        CheckNotFixed();
        _CanBeEmpty = value;
      }
    }
    private bool _CanBeEmpty;

    #endregion

    #region Диапазон значений

    /// <summary>
    /// Минимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public DateTime? Minimum
    {
      get { return _Minimum; }
      set
      {
        CheckNotFixed();
        _Minimum = value;
      }
    }
    private DateTime? _Minimum;

    /// <summary>
    /// Максимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public DateTime? Maximum
    {
      get { return _Maximum; }
      set
      {
        CheckNotFixed();
        _Maximum = value;
      }
    }
    private DateTime? _Maximum;

    #endregion

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return DateRange != _OldDateRange;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      if (DateRange.IsEmpty)
      {
        part.Remove("FirstDate");
        part.Remove("LastDate");
      }
      else
      {
        part.SetNullableDate("FirstDate", DateRange.FirstDate);
        part.SetNullableDate("LastDate", DateRange.LastDate);
      }
      _OldDateRange = DateRange;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      DateTime? FirstDate = part.GetNullableDate("FirstDate");
      DateTime? LastDate = part.GetNullableDate("LastDate");
      if (FirstDate.HasValue && LastDate.HasValue)
        DateRange = new DateRange(FirstDate.Value, LastDate.Value);
      else
        DateRange = DateRange.Empty;
      _OldDateRange = DateRange;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (DateRange.IsEmpty)
      {
        part.SetString(Name + "-First", String.Empty);
        part.SetString(Name + "-Last", String.Empty);
      }
      else
      {
        part.SetDate(Name + "-First", DateRange.FirstDate);
        part.SetDate(Name + "-Last", DateRange.LastDate);
      }
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      DateTime? FirstDate = part.GetNullableDate(Name + "-First");
      DateTime? LastDate = part.GetNullableDate(Name + "-Last");

      if (FirstDate.HasValue && LastDate.HasValue)
        DateRange = new DateRange(FirstDate.Value, LastDate.Value);
      else
        DateRange = DateRange.Empty;
    }

    #endregion
  }

  /// <summary>
  /// Поле выбора месяца и года
  /// </summary>
  [Serializable]
  public class YearMonthBox : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает поле.
    /// </summary>
    public YearMonthBox()
    {
      _Year = DateTime.Today.Year;
      _Month = DateTime.Today.Month;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Текущее значение - выбранный год
    /// </summary>
    public int Year
    {
      get { return _Year; }
      set { _Year = value; }
    }
    private int _Year;

    private int _OldYear;

    /// <summary>
    /// Текущее значение - выбранный месяц (1-12)
    /// </summary>
    public int Month
    {
      get { return _Month; }
      set { _Month = value; }
    }
    private int _Month;

    private int _OldMonth;

    /// <summary>
    /// Текущее значение - год и месяц всесте
    /// </summary>
    public YearMonth YM
    {
      get { return new YearMonth(Year, Month); }
      set
      {
        if (value.IsEmpty)
          throw new ArgumentNullException();
        Year = value.Year;
        Month = value.Month;
      }
    }

    /// <summary>
    /// Минимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено (YearMonth.Empty).
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public YearMonth Minimum
    {
      get { return _Minimum; }
      set
      {
        CheckNotFixed();
        _Minimum = value;
      }
    }
    private YearMonth _Minimum;

    /// <summary>
    /// Максимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено (YearMonth.Empty).
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public YearMonth Maximum
    {
      get { return _Maximum; }
      set
      {
        CheckNotFixed();
        _Maximum = value;
      }
    }
    private YearMonth _Maximum;


    /// <summary>
    /// Вспомогательное свойство для чтения/записи значений как интервала дат.
    /// При установке свойства интервал дат должен относиться к одному месяцу.
    /// </summary>
    /// <remarks>В основном, для совместимости с YearMonthRangeBox</remarks>
    public DateRange DateRange
    {
      get
      {
        return YM.DateRange;
      }
      set
      {
        if (value.IsEmpty)
          throw new ArgumentNullException("DateRange", "Задан пустой интервал дат");
        if (value.FirstDate.Year != value.LastDate.Year || value.FirstDate.Month != value.LastDate.Month)
          throw new ArgumentException("Интервал дат должен относиться к одному месяцу");

        Year = value.FirstDate.Year;
        Month = value.FirstDate.Month;
      }
    }

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return Year != _OldYear || Month != _OldMonth;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="Part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="Part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart Part)
    {
      base.WriteChanges(Part);
      Part.SetInt("Year", Year);
      Part.SetInt("Month", Month);
      _OldYear = Year;
      _OldMonth = Month;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="Part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart Part)
    {
      base.ReadChanges(Part);
      Year = Part.GetInt("Year");
      Month = Part.GetInt("Month");
      _OldYear = Year;
      _OldMonth = Month;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="CfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType CfgType)
    {
      return CfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="Part">Секция конфигурации для записи</param>
    /// <param name="CfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart Part, RIValueCfgType CfgType)
    {
      Part.SetInt(Name + "-Year", Year);
      Part.SetInt(Name + "-Month", Month);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="Part">Секция конфигурации для чтения значений</param>
    /// <param name="CfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart Part, RIValueCfgType CfgType)
    {
      if (Part.HasValue(Name + "-Year"))
      {
        Year = Part.GetInt(Name + "-Year");
        Month = Part.GetInt(Name + "-Month");
      }
    }

    #endregion
  }

  /// <summary>
  /// Поле выбора диапазона месяцев и года.
  /// Может задаваться только один год.
  /// При размещении на полосе элементов рекомендуется занимать целую полосу, задавая метку на предыдущей полосе
  /// </summary>
  [Serializable]
  public class YearMonthRangeBox : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает поле
    /// </summary>
    public YearMonthRangeBox()
    {
      Year = DateTime.Today.Year;
      FirstMonth = DateTime.Today.Month;
      LastMonth = FirstMonth;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Выбранный год
    /// </summary>
    public int Year
    {
      get { return _Year; }
      set { _Year = value; }
    }
    private int _Year;

    private int _OldYear;

    /// <summary>
    /// Выбранный первый месяц (1 .. 12)
    /// </summary>
    public int FirstMonth
    {
      get { return _FirstMonth; }
      set { _FirstMonth = value; }
    }
    private int _FirstMonth;

    private int _OldFirstMonth;

    /// <summary>
    /// Выбранный последний месяц (1 .. 12)
    /// </summary>
    public int LastMonth
    {
      get { return _LastMonth; }
      set { _LastMonth = value; }
    }
    private int _LastMonth;

    private int _OldLastMonth;

    /// <summary>
    /// Первый месяц и год в виде структуры YearMonth
    /// </summary>
    public YearMonth FirstYM
    {
      get { return new YearMonth(Year, FirstMonth); }
      set
      {
        if (value.IsEmpty)
          throw new ArgumentNullException();
        Year = value.Year;
        FirstMonth = value.Month;
      }
    }

    /// <summary>
    /// Последний месяц и год в виде структуры YearMonth
    /// </summary>
    public YearMonth LastYM
    {
      get { return new YearMonth(Year, LastMonth); }
      set
      {
        if (value.IsEmpty)
          throw new ArgumentNullException();
        Year = value.Year;
        LastMonth = value.Month;
      }
    }

    /// <summary>
    /// Вспомогательное свойство для чтения/записи значений как интервала дат.
    /// При установке свойства интервал дат должен относиться к одному году
    /// </summary>
    public DateRange DateRange
    {
      get
      {
        return new DateRange(FirstYM.DateRange.FirstDate, LastYM.DateRange.LastDate);
      }
      set
      {
        if (value.IsEmpty)
          throw new ArgumentNullException("DateRange", "Задан пустой интервал дат");
        if (value.FirstDate.Year != value.LastDate.Year)
          throw new ArgumentException("Интервал дат должен относиться к одному году");

        Year = value.FirstDate.Year;
        FirstMonth = value.FirstDate.Month;
        LastMonth = value.LastDate.Month;
      }
    }

    /// <summary>
    /// Свойства FirstYM и LastYM вместе
    /// </summary>
    public YearMonthRange YMRange
    {
      get
      {
        return new YearMonthRange(Year, FirstMonth, LastMonth);
      }
      set
      {
        if (value.IsEmpty)
          throw new ArgumentNullException();
        if (value.LastYM.Year != value.FirstYM.Year)
          throw new ArgumentException("Период должен относиться к одному году");
        this.Year = value.FirstYM.Year;
        this.FirstMonth = value.FirstYM.Month;
        this.LastMonth = value.LastYM.Month;
      }
    }

    /// <summary>
    /// Минимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено (YearMonth.Empty).
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public YearMonth Minimum
    {
      get { return _Minimum; }
      set
      {
        CheckNotFixed();
        _Minimum = value;
      }
    }
    private YearMonth _Minimum;

    /// <summary>
    /// Максимальное значение, которое можно ввести.
    /// По умолчанию ограничение не установлено (YearMonth.Empty).
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public YearMonth Maximum
    {
      get { return _Maximum; }
      set
      {
        CheckNotFixed();
        _Maximum = value;
      }
    }
    private YearMonth _Maximum;

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _Year != _OldYear || _FirstMonth != _OldFirstMonth || _LastMonth != _OldLastMonth;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetInt("Year", Year);
      part.SetInt("FirstMonth", FirstMonth);
      part.SetInt("LastMonth", LastMonth);
      _OldYear = _Year;
      _OldFirstMonth = FirstMonth;
      _OldLastMonth = LastMonth;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Year = part.GetInt("Year");
      FirstMonth = part.GetInt("FirstMonth");
      LastMonth = part.GetInt("LastMonth");
      _OldYear = Year;
      _OldFirstMonth = FirstMonth;
      _OldLastMonth = LastMonth;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetInt(Name + "-Year", Year);
      part.SetInt(Name + "-FirstMonth", FirstMonth);
      part.SetInt(Name + "-LastMonth", LastMonth);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name + "-Year"))
      {
        Year = part.GetInt(Name + "-Year");
        FirstMonth = part.GetInt(Name + "-FirstMonth");
        LastMonth = part.GetInt(Name + "-LastMonth");
      }
    }

    #endregion
  }


  /// <summary>
  /// Комбоблок выбора значения из выпадающего списка.
  /// Текущее значение определяется свойством SelectedIndex.
  /// Список для выбора является фиксированным и задается в конструкторе.
  /// Вариант "отсутствие выбора" не поддерживается.
  /// </summary>
  [Serializable]
  public class ListComboBox : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает комбоблок
    /// </summary>
    /// <param name="items">Список элементов, из которых можно выбирать</param>
    public ListComboBox(string[] items)
    {
      if (items == null)
        throw new ArgumentNullException("Items");
      _Items = items;
    }

    #endregion

    #region Свойства

    #region Items

    /// <summary>
    /// Массив строк для выпадающего списка.
    /// Задается в конструкторе.
    /// </summary>
    public string[] Items { get { return _Items; } }
    private string[] _Items;

    #endregion

    #region SelectedIndex

    /// <summary>
    /// Текушее значение (индекс в массиве Items).
    /// По умолчанию - 0 - выбран первый элемент списка
    /// </summary>
    public int SelectedIndex
    {
      get { return _SelectedIndex; }
      set
      {
        _SelectedIndex = value;
        if (_SelectedIndexEx != null)
          _SelectedIndexEx.Value = SelectedIndex;
        if (_SelectedCodeEx != null)
          _SelectedCodeEx.Value = SelectedCode;
      }
    }
    private int _SelectedIndex;

    private int _OldSelectedIndex;

    /// <summary>
    /// Управляемое значение для SelectedIndex.
    /// </summary>
    public DepValue<int> SelectedIndexEx
    {
      get
      {
        InitSelectedIndexEx();
        return _SelectedIndexEx;
      }
      set
      {
        InitSelectedIndexEx();
        _SelectedIndexEx.Source = value;
      }
    }
    private DepInput<int> _SelectedIndexEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства SelectedIndexEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasSelectedIndexExProperty { get { return _SelectedIndexEx != null; } }

    private void InitSelectedIndexEx()
    {
      if (_SelectedIndexEx == null)
      {
        _SelectedIndexEx = new DepInput<int>();
        _SelectedIndexEx.OwnerInfo = new DepOwnerInfo(this, "SelectedIndexEx");
        _SelectedIndexEx.Value = SelectedIndex;
        _SelectedIndexEx.ValueChanged += new EventHandler(SelectedIndexEx_ValueChanged);
      }
    }

    private void SelectedIndexEx_ValueChanged(object sender, EventArgs args)
    {
      SelectedIndex = _SelectedIndexEx.Value;
    }

    #endregion

    #region Codes

    /// <summary>
    /// Коды для элементов.
    /// Если свойство установлено, то для сохранения значения между сеансами работы используется код, а не индекс.
    /// По умолчанию свойство содержит значение null (коды не используются).
    /// При установке свойства длина массива должна совпадать с длиной массива Items.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public string[] Codes
    {
      get { return _Codes; }
      set
      {
        CheckNotFixed();
        if (value != null)
        {
          if (value.Length != _Items.Length)
            throw new ArgumentException("Неправильная длина массива кодов");
          _Codes = value;
        }
      }
    }
    private string[] _Codes;

    #endregion

    #region SelectedCode

    /// <summary>
    /// Текущая выбранная позиция как код.
    /// Должно быть установлено свойство Codes, иначе возвращается пустая строка.
    /// </summary>
    public string SelectedCode
    {
      get
      {
        if (Codes == null)
          return String.Empty;
        else
          return Codes[SelectedIndex];
      }
      set
      {
        if (Codes == null)
          throw new InvalidOperationException("Свойство Codes не установено");
        SelectedIndex = Array.IndexOf<string>(Codes, value);
      }
    }

    /// <summary>
    /// Управляемое значение для SelectedCode.
    /// </summary>
    public DepValue<string> SelectedCodeEx
    {
      get
      {
        InitSelectedCodeEx();
        return _SelectedCodeEx;
      }
      set
      {
        InitSelectedCodeEx();
        _SelectedCodeEx.Source = value;
      }
    }
    private DepInput<string> _SelectedCodeEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства SelectedCodeEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasSelectedCodeExProperty { get { return _SelectedCodeEx != null; } }

    private void InitSelectedCodeEx()
    {
      if (_SelectedCodeEx == null)
      {
        _SelectedCodeEx = new DepInput<string>();
        _SelectedCodeEx.OwnerInfo = new DepOwnerInfo(this, "SelectedCodeEx");
        _SelectedCodeEx.Value = SelectedCode;
        _SelectedCodeEx.ValueChanged += new EventHandler(SelectedCodeEx_ValueChanged);
      }
    }

    private void SelectedCodeEx_ValueChanged(object sender, EventArgs args)
    {
      SelectedCode = _SelectedCodeEx.Value;
    }

    #endregion

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _SelectedIndex != _OldSelectedIndex;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetInt("SelectedIndex", _SelectedIndex);
      _OldSelectedIndex = _SelectedIndex;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      _SelectedIndex = part.GetInt("SelectedIndex");
      _OldSelectedIndex = SelectedIndex;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (Codes == null)
        part.SetInt(Name, SelectedIndex);
      else
        part.SetString(Name, SelectedCode);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
      {
        if (Codes == null)
          SelectedIndex = part.GetInt(Name);
        else
          SelectedCode = part.GetString(Name);
      }
    }

    #endregion
  }

  /// <summary>
  /// Комбоблок ввода текста с возможностью выбора из выпадающего списка.
  /// Пользователь может как выбрать текст из списка, так и ввести его вручную.
  /// Текущее значение определяется свойством Text.
  /// Список для выбора является фиксированным и задается в конструкторе.
  /// </summary>
  [Serializable]
  public class TextComboBox : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает комбоблок
    /// </summary>
    /// <param name="items">Список вариантов, из которых можно выбирать готовые значения</param>
    public TextComboBox(string[] items)
    {
      if (items == null)
        throw new ArgumentNullException("items");
      _Items = items;
      _MaxLength = Int16.MaxValue;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Массив строк для выпадающего списка.
    /// Задается в конструкторе.
    /// </summary>
    public string[] Items { get { return _Items; } }
    private string[] _Items;

    /// <summary>
    /// Текущее введенное значение.
    /// По умолчанию - пустая строка
    /// </summary>
    public string Text
    {
      get
      {
        if (_Text == null)
          return String.Empty;
        else
          return _Text;
      }
      set
      {
        if (String.IsNullOrEmpty(value))
          _Text = null;
        else
          _Text = value;
      }
    }
    private string _Text; // храним null вместо пустой строки

    private string _OldText;

    /// <summary>
    /// Управляемое значение для Text.
    /// </summary>
    public DepValue<string> TextEx
    {
      get
      {
        InitTextEx();
        return _TextEx;
      }
      set
      {
        InitTextEx();
        _TextEx.Source = value;
      }
    }
    private DepInput<string> _TextEx;

    /// <summary>
    /// Возвращает true, если обработчик свойства TextEx инициализирован.
    /// Это свойство не предназначено для использования в пользовательском коде
    /// </summary>
    public bool HasTextExProperty { get { return _TextEx != null; } }

    private void InitTextEx()
    {
      if (_TextEx == null)
      {
        _TextEx = new DepInput<string>();
        _TextEx.OwnerInfo = new DepOwnerInfo(this, "TextEx");
        _TextEx.Value = Text;
        _TextEx.ValueChanged += new EventHandler(TextEx_ValueChanged);
      }
    }

    private void TextEx_ValueChanged(object Sender, EventArgs Args)
    {
      Text = _TextEx.Value;
    }

    /// <summary>
    /// Может ли поле быть пустым
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// Значение по умолчанию: false (поле является обязательным).
    /// </summary>
    public bool CanBeEmpty
    {
      get { return _CanBeEmpty; }
      set
      {
        CheckNotFixed();
        _CanBeEmpty = value;
      }
    }
    private bool _CanBeEmpty;

    /// <summary>
    /// Максимальная длина текста. По умолчанию: 32767 символов (Int16.MaxValue).
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public int MaxLength
    {
      get { return _MaxLength; }
      set
      {
        CheckNotFixed();
        _MaxLength = value;
      }
    }
    private int _MaxLength;

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return Text != _OldText;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetString("Text", Text);
      _OldText = Text;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Text = part.GetString("Text");
      _OldText = Text;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetString(Name, Text);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
        Text = part.GetString(Name);
    }

    #endregion
  }

  /// <summary>
  /// Комбоблок для выбора одного или нескольких кодов, разделенных запятыми.
  /// </summary>
  [Serializable]
  public class CsvCodesComboBox : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает комбоблок с заданным списком доступных кодов
    /// </summary>
    /// <param name="codes">Массив кодов, из которых можно выбирать</param>
    public CsvCodesComboBox(string[] codes)
    {
      if (codes == null)
        throw new ArgumentNullException("сodes");
      _Codes = codes;
      _SelectedCodes = DataTools.EmptyStrings;
      _OldSelectedCodes = _SelectedCodes;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Список доступных кодов. Задается в конструкторе
    /// </summary>
    public string[] Codes { get { return _Codes; } }
    private string[] _Codes;

    /// <summary>
    /// Описания, соответствующие кодам AvailableCodes.
    /// По умолчанию null - нет описаний.
    /// </summary>
    public string[] Names
    {
      get { return _Names; }
      set
      {
        CheckNotFixed();
        if (value != null)
        {
          if (value.Length != _Codes.Length)
            throw new ArgumentException("Неправильная длина массива: " + value.Length.ToString() + ". Ожидалось: " + _Codes.Length.ToString());
          _Names = value;
        }
      }
    }
    private string[] _Names;


    /// <summary>
    /// Может ли поле быть пустым
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// Значение по умолчанию: false (поле является обязательным).
    /// </summary>
    public bool CanBeEmpty
    {
      get { return _CanBeEmpty; }
      set
      {
        CheckNotFixed();
        _CanBeEmpty = value;
      }
    }
    private bool _CanBeEmpty;

    /// <summary>
    /// Основное свойство - выбранные коды.
    /// По умолчанию - пустой массив кодов
    /// </summary>
    public string[] SelectedCodes
    {
      get { return _SelectedCodes; }
      set
      {
        if (value == null)
          value = DataTools.EmptyStrings;
        _SelectedCodes = value;
      }
    }
    private string[] _SelectedCodes;
    private string[] _OldSelectedCodes;

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return !Object.ReferenceEquals(_SelectedCodes, _OldSelectedCodes);
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetString("SelectedCodes", String.Join(",", _SelectedCodes));
      _OldSelectedCodes = _SelectedCodes;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      string s = part.GetString("SelectedCodes");
      if (s.Length == 0)
        _SelectedCodes = DataTools.EmptyStrings;
      else
        _SelectedCodes = s.Split(',');
      _OldSelectedCodes = _SelectedCodes;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetString(Name, String.Join(",", _SelectedCodes));
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      string s = part.GetString(Name);
      if (s.Length == 0)
        _SelectedCodes = DataTools.EmptyStrings;
      else
        _SelectedCodes = s.Split(',');
    }

    #endregion
  }

  /// <summary>
  /// Поле с информационным текстом.
  /// Кроме текста, может содержать значок, как MessageBox.
  /// Пользователь не может взаимодействовать с элементом.
  /// Не связано с другими управляющими элементами, как Label.
  /// </summary>
  [Serializable]
  public class InfoLabel : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает окно с текстом
    /// </summary>
    /// <param name="Text">Текст сообщения. Не может быть пустой строкой</param>
    public InfoLabel(string Text)
    {
      if (String.IsNullOrEmpty(Text))
        throw new ArgumentNullException("Text");
      _Text = Text;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Текст сообщения.
    /// Символ "амперсанд" отображается как есть, а не используется для подчеркивания буквы.
    /// Задается в конструкторе.
    /// </summary>
    public string Text { get { return _Text; } }
    private string _Text;

    /// <summary>
    /// Значок слева от текста.
    /// По умолчанию - None - значок не отображается.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public MessageBoxIcon Icon
    {
      get { return _Icon; }
      set
      {
        CheckNotFixed();
        _Icon = value;
      }
    }
    private MessageBoxIcon _Icon;

    #endregion
  }

  /// <summary>
  /// Поле ввода имени каталога с кнопкой "Обзор"
  /// </summary>
  [Serializable]
  public class FolderBrowserTextBox : Control
  {
    #region Свойства

    /// <summary>
    /// Выбранный каталог (вход и выход)
    /// </summary>
    public AbsPath Path { get { return _Path; } set { _Path = value; } }
    private AbsPath _Path;

    private AbsPath _OldPath;


    /// <summary>
    /// Может ли поле быть пустым.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне
    /// Значение по умолчанию: false (поле является обязательным)
    /// </summary>
    public bool CanBeEmpty
    {
      get { return _CanBeEmpty; }
      set
      {
        CheckNotFixed();
        _CanBeEmpty = value;
      }
    }
    private bool _CanBeEmpty;

    /// <summary>
    /// Пояснительный текст, который выводится в диалоге выбора каталога при нажатии кнопки "Обзор".
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// По умолчанию текст не задан.
    /// </summary>
    public string Description { get { return _Description; } set { _Description = value; } }
    private string _Description;

    /// <summary>
    /// Должна ли в диалоге выбора отображаться кнопка "Создать папку".
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// По умолчанию - false (когда выбирается папка для выбора существующих файлов).
    /// </summary>
    public bool ShowNewFolderButton
    {
      get { return _ShowNewFolderButton; }
      set
      {
        CheckNotFixed();
        _ShowNewFolderButton = value;
      }
    }
    private bool _ShowNewFolderButton;

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _OldPath != Path;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);

      part.SetString("Path", Path.Path);
      _OldPath = Path;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Path = new AbsPath(part.GetString("Path"));
      _OldPath = Path;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.MachineSpecific;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetString(Name, Path.SlashedPath);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
        Path = new AbsPath(part.GetString(Name));
    }

    #endregion
  }

  /// <summary>
  /// Базовый класс для OpenFileBox и SaveFileBox
  /// </summary>
  [Serializable]
  public abstract class FileTextBox : Control
  {
    #region Свойства

    /// <summary>
    /// Выбранный файл.
    /// Выбрать можно только один файл, множественный выбор не поддерживается.
    /// </summary>
    public AbsPath Path { get { return _Path; } set { _Path = value; } }
    private AbsPath _Path;

    private AbsPath _OldPath;


    /// <summary>
    /// Может ли поле быть пустым
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне
    /// Значение по умолчанию: false (поле является обязательным).
    /// </summary>
    public bool CanBeEmpty
    {
      get { return _CanBeEmpty; }
      set
      {
        CheckNotFixed();
        _CanBeEmpty = value;
      }
    }
    private bool _CanBeEmpty;

    /// <summary>
    /// Фильтры (разделитель "|"). Например: "Текстовые файлы|*.txt|Все файлы|*.*".
    /// Если свойство не установлено, то предлагается выбирать из полного списка файлов.
    /// Свойство носит рекомендательный характер. Пользователь может ввести путь к файлу вручную без использования диалога выбора.
    /// Свойство может устанавливаться только до передачи диалога вызываемой стороне.
    /// </summary>
    public string Filter
    {
      get { return _Filter; }
      set
      {
        CheckNotFixed();
        _Filter = value;
      }
    }
    private string _Filter;

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _OldPath != Path;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);

      part.SetString("Path", Path.Path);
      _OldPath = Path;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Path = new AbsPath(part.GetString("Path"));
      _OldPath = Path;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.MachineSpecific;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetString(Name, Path.Path);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
        Path = new AbsPath(part.GetString(Name));
    }

    #endregion
  }

  /// <summary>
  /// Поле ввода имени файла с кнопкой "Обзор", показывающей диалог открытия файла
  /// </summary>
  [Serializable]
  public class OpenFileTextBox : FileTextBox
  {
  }

  /// <summary>
  /// Поле ввода имени файла с кнопкой "Обзор", показывающей диалог сохранения файла
  /// </summary>
  [Serializable]
  public class SaveFileTextBox : FileTextBox
  {
  }


  /// <summary>
  /// Метка (Label) и управляющий элемент (любой Control), располагающиеся рядом на полосе RIBand
  /// </summary>
  [Serializable]
  public class ControlWithLabel : Control
  {
    #region Конструктор

    /// <summary>
    /// Создает элемент
    /// </summary>
    /// <param name="labelText">Текст метки. Должен быть задан. Может содержать амперсанд для подчеркивания символа</param>
    /// <param name="mainControl">Управляюший элемент. Должен быть задан</param>
    public ControlWithLabel(string labelText, Control mainControl)
    {
      _Label = new Label(labelText);
      if (mainControl == null)
        throw new ArgumentNullException("mainControl");
      _MainControl = mainControl;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Метка. Создается в конструкторе.
    /// </summary>
    public Label Label { get { return _Label; } }
    private Label _Label;

    /// <summary>
    /// Основной элемент.
    /// Задается в конструкторе.
    /// </summary>
    public Control MainControl { get { return _MainControl; } }
    private Control _MainControl;

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges { get { return _MainControl.HasChanges; } }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      // Не создаем отдельную секцию

      _MainControl.WriteChanges(part);
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      _MainControl.ReadChanges(part);
    }

    /// <summary>
    /// Вызывает соответствующий метод MainControl
    /// </summary>
    /// <param name="cfgType">Запрашиваемый тип секции конфигурации</param>
    /// <returns>true, если секция используется</returns>
    public override bool SupportsCfgType(RIValueCfgType cfgType)
    {
      return _MainControl.SupportsCfgType(cfgType);
    }

    /// <summary>
    /// Вызывает соответствующий метод MainControl
    /// </summary>
    /// <param name="part">Записываемая секция конфигурации</param>
    /// <param name="cfgType">Тип секции конфигурации. Должен проверяться перед записью</param>
    public override void WriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      _MainControl.WriteValues(part, cfgType);
    }

    /// <summary>
    /// Вызывает соответствующий метод MainControl
    /// </summary>
    /// <param name="part">Считываемая секция конфигурации</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    public override void ReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      _MainControl.ReadValues(part, cfgType);
    }

    #endregion

    #region Другие методы

    /// <summary>
    /// Рекурсивный поиск элемента по имени в MainControl. Также проверяет, не соответствует ли имя Label.Name.
    /// </summary>
    /// <param name="name">Имя элемента</param>
    /// <returns>Найденный элемент или null</returns>
    public override RIItem Find(string name)
    {
      if (String.IsNullOrEmpty(name))
        return null;

      RIItem res = base.Find(name);
      if (res == null && _Label != null)
        res = _Label.Find(name);
      if (res == null)
        res = _MainControl.Find(name);

      return res;
    }

    /// <summary>
    /// Рекурсивное создание списка из всех элементов.
    /// </summary>
    /// <param name="items">Заполняемый список</param>
    public override void GetItems(ICollection<RIItem> items)
    {
      base.GetItems(items);
      if (_Label != null)
        _Label.GetItems(items);
      _MainControl.GetItems(items);
    }

    /// <summary>
    /// Рекурсивная очистка списка сообщений.
    /// Метод не используется в прикладном коде.
    /// </summary>
    public override void ClearErrors()
    {
      base.ClearErrors();
      _Label.ClearErrors();
      _MainControl.ClearErrors();
    }

    /// <summary>
    /// Рекурсивный вызов SetFixed()
    /// </summary>
    protected override void OnSetFixed()
    {
      base.OnSetFixed();
      if (_Label != null)
        _Label.SetFixed();
      _MainControl.SetFixed();
    }

    #endregion
  }

  /// <summary>
  /// Полоса управляющих элементов RIControl.
  /// Каждый элемент располагается на отдельной "строке". Высота, занимаемая "строкой" определяется автоматически.
  /// Интерфейс ICollection реализован только частично. Можно добавлять элементы, но не удалять их.
  /// </summary>
  [Serializable]
  public class Band : RIItem, ICollection<Control>
  {
    #region Конструктор

    /// <summary>
    /// Создает пустую полосу
    /// </summary>
    public Band()
    {
      _Items = new List<Control>();
    }

    #endregion

    #region Список управляющих элементов

    private List<Control> _Items;

    /// <summary>
    /// Доступ к дочерим элементам по индексу
    /// </summary>
    /// <param name="index">Индекс в диапазоне от 0 до (Count-1)</param>
    /// <returns>Элемент</returns>
    public Control this[int index]
    {
      get { return _Items[index]; }
    }

    #endregion

    #region ICollection<RIControl> Members

    /// <summary>
    /// Добавление управляющего элемента на полосу
    /// </summary>
    /// <param name="item">Управляющий элемент или объект ControlWithLabel</param>
    public void Add(Control item)
    {
      CheckNotFixed();
      if (item == null)
        throw new ArgumentNullException("item");
      _Items.Add(item);
    }

    /// <summary>
    /// Добавление управляющего элемента с меткой на полосу.
    /// Создает и добавляет элемент ControlWithLabel.
    /// </summary>
    /// <param name="labelText">Текст метки. Должен быть задан. Может содержать амперсанд для выделения буквы</param>
    /// <param name="control">Основной управляющий элемент. Должен быть задан.</param>
    public void Add(string labelText, Control control)
    {
      Add(new ControlWithLabel(labelText, control));
    }

    void ICollection<Control>.Clear()
    {
      CheckNotFixed();
      throw new NotSupportedException();
    }

    bool ICollection<Control>.Contains(Control item)
    {
      return _Items.Contains(item);
    }

    void ICollection<Control>.CopyTo(Control[] array, int arrayIndex)
    {
      _Items.CopyTo(array, arrayIndex);
    }

    /// <summary>
    /// Возвращает количество дочерних элементов на полосе. 
    /// Вложенные элементы не учитываются.
    /// </summary>
    public int Count { get { return _Items.Count; } }

    bool ICollection<Control>.IsReadOnly { get { return false; } }

    bool ICollection<Control>.Remove(Control item)
    {
      CheckNotFixed();
      throw new NotSupportedException();
    }

    #endregion

    #region IEnumerable<RIControl> Members

    /// <summary>
    /// Создает нерекурсивный перечислитель по дочерним элементам.
    /// 
    /// Тип возвращаемого значения может измениться в будущем, 
    /// гарантируется только реализация интерфейса перечислителя.
    /// Поэтому в прикладном коде метод должен использоваться исключительно для использования в операторе foreach.
    /// </summary>
    /// <returns></returns>
    public List<Control>.Enumerator GetEnumerator()
    {
      return _Items.GetEnumerator();
    }

    IEnumerator<Control> IEnumerable<Control>.GetEnumerator()
    {
      return _Items.GetEnumerator();
    }

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
    {
      return _Items.GetEnumerator();
    }

    #endregion

    #region Переопределенные методы

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        for (int i = 0; i < _Items.Count; i++)
        {
          if (_Items[i].HasChanges)
            return true;
        }
        return false;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      for (int i = 0; i < _Items.Count; i++)
      {
        if (_Items[i].HasChanges)
        {
          CfgPart Part2 = part.GetChild("C" + i.ToString(), true);
          _Items[i].WriteChanges(Part2);
        }
      }
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      for (int i = 0; i < _Items.Count; i++)
      {
        CfgPart Part2 = part.GetChild("C" + i.ToString(), false);
        if (Part2 != null)
          _Items[i].ReadChanges(Part2);
      }
    }

    /// <summary>
    /// Рекурсивный вызов SupportsCfgType() для дочерних элементов.
    /// Возвращает true, если хотя бы один элемент вернул true.
    /// </summary>
    /// <param name="cfgType">Тип секции</param>
    /// <returns>True, если используется запись в такую секцию</returns>
    public override bool SupportsCfgType(RIValueCfgType cfgType)
    {
      for (int i = 0; i < _Items.Count; i++)
      {
        if (_Items[i].SupportsCfgType(cfgType))
          return true;
      }
      return false;
    }


    /// <summary>
    /// Рекурсивная запись значений
    /// </summary>
    /// <param name="part">Секция для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    public override void WriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      for (int i = 0; i < _Items.Count; i++)
      {
        try
        {
          _Items[i].WriteValues(part, cfgType);
        }
        catch { }
      }
    }

    /// <summary>
    /// Рекурсивное чтение значений
    /// </summary>
    /// <param name="part">Секция для чтения</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    public override void ReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      for (int i = 0; i < _Items.Count; i++)
      {
        try
        {
          _Items[i].ReadValues(part, cfgType);
        }
        catch { }
      }
    }

    #endregion

    #region Другие переопределенные методы

    /// <summary>
    /// Рекурсивный поиск элемента по имени
    /// </summary>
    /// <param name="name">Имя</param>
    /// <returns>Найденный элемент или null</returns>
    public override RIItem Find(string name)
    {
      RIItem res = base.Find(name);
      if (res != null)
        return res;

      for (int i = 0; i < _Items.Count; i++)
      {
        res = _Items[i].Find(name);
        if (res != null)
          return res;
      }

      return null;
    }

    /// <summary>
    /// Рекурсивное построение списка элементов
    /// </summary>
    /// <param name="items">Список для заполнения</param>
    public override void GetItems(ICollection<RIItem> items)
    {
      base.GetItems(items);
      for (int i = 0; i < _Items.Count; i++)
        _Items[i].GetItems(items);
    }

    /// <summary>
    /// Рекурсивная очистка списка ошибок.
    /// Не используется в пользовательском коде.
    /// </summary>
    public override void ClearErrors()
    {
      base.ClearErrors();
      for (int i = 0; i < _Items.Count; i++)
        _Items[i].ClearErrors();
    }

    /// <summary>
    /// Рекурсивный вызов метода
    /// </summary>
    protected override void OnSetFixed()
    {
      base.OnSetFixed();
      for (int i = 0; i < _Items.Count; i++)
        _Items[i].SetFixed();
    }

    #endregion
  }

  /// <summary>
  /// Сериализуемый блок диалога.
  /// Содержит одну "полосу" управляющих элеметов и панель кнопок внизу
  /// </summary>
  [Serializable]
  public class Dialog : RIItem
  {
    #region Конструктор

    /// <summary>
    /// Создает блок диалога
    /// </summary>
    /// <param name="text">Заголовок окна</param>
    public Dialog(string text)
    {
      _Text = text;

      _Controls = new Band();
    }

    #endregion

    #region Заголовок

    /// <summary>
    /// Заголовок блока диалога.
    /// Задается в конструкторе.
    /// </summary>
    public string Text { get { return _Text; } }
    private string _Text;

    #endregion

    #region Полоса элементов

    /// <summary>
    /// Полоса управляющих элементов
    /// </summary>
    public Band Controls { get { return _Controls; } }
    private Band _Controls;

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _Controls.HasChanges;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      _Controls.WriteChanges(part);
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      _Controls.ReadChanges(part);
    }

    /// <summary>
    /// Вызывает Controls.SupportsCfgType()
    /// </summary>
    /// <param name="cfgType">Тип секции</param>
    /// <returns>True, если используется запись в такую секцию</returns>
    public override bool SupportsCfgType(RIValueCfgType cfgType)
    {
      return _Controls.SupportsCfgType(cfgType);
    }


    /// <summary>
    /// Вызывает Controls.WriteValues()
    /// </summary>
    /// <param name="part">Секция для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    public override void WriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      _Controls.WriteValues(part, cfgType);
    }


    /// <summary>
    /// Вызывает Controls.ReadValues()
    /// </summary>
    /// <param name="part">Секция для чтения</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    public override void ReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      _Controls.ReadValues(part, cfgType);
    }

    #endregion

    #region Другие переопределенные методы

    /// <summary>
    /// Рекурсивный поиск управляющего элемента по имени.
    /// Имена элементов являются чувствительными к регистру.
    /// </summary>
    /// <param name="name">Искомое имя</param>
    /// <returns>Ссылка на найденный элемент или null.</returns>
    public override RIItem Find(string name)
    {
      RIItem res = base.Find(name);
      if (res == null)
        res = _Controls.Find(name);

      return res;
    }

    /// <summary>
    /// Создание списка всех элементов блока диалога
    /// </summary>
    /// <param name="items">Заполняемый список</param>
    public override void GetItems(ICollection<RIItem> items)
    {
      base.GetItems(items);
      _Controls.GetItems(items);
    }

    /// <summary>
    /// Рекурсивный вызов.
    /// </summary>
    protected override void OnSetFixed()
    {
      base.OnSetFixed();
      _Controls.SetFixed();
    }

    #endregion

    #region Проверка значений

    /// <summary>
    /// Очистка списка ошибок.
    /// Вызывается из метода Validate().
    /// Не используется в прикладном коде.
    /// </summary>
    public override void ClearErrors()
    {
      base.ClearErrors();
      _Controls.ClearErrors();
    }

    /// <summary>
    /// Выполнить проверку значений в диалоге.
    /// Возвращает false, если хотя бы для одного элемента выставлен признак ошибки.
    /// Не используется в прикладном коде.
    /// </summary>
    /// <returns>Успех проверки</returns>
    public bool Validate()
    {
      ClearErrors();
      if (_Validating != null)
        _Validating(this, EventArgs.Empty);
      RIItem ErrorItem = FindError();
      return ErrorItem == null;
    }

    /// <summary>
    /// Событие вызывается на вызывающей стороне для проверки корректности введенных значений
    /// </summary>
    public event EventHandler Validating
    {
      add { _Validating += value; }
      remove { _Validating -= value; }
    }
    [NonSerialized]
    private EventHandler _Validating;

    #endregion
  }

  #region Стандартные блоки диалога

  /// <summary>
  /// Базовый класс для стандартных блоков диалогв
  /// </summary>
  [Serializable]
  public abstract class StandardDialog : RIItem
  {
    #region Свойства

    /// <summary>
    /// Заголовок окна.
    /// Значение по умолчанию зависить от конкруетного диалога.
    /// </summary>
    public string Title { get { return _Title; } set { _Title = value; } }
    private string _Title;

    #endregion
  }

  #region Файлы и папки

  /// <summary>
  /// Диалог выбора каталога
  /// </summary>
  [Serializable]
  public class FolderBrowserDialog : StandardDialog
  {
    #region Свойства

    /// <summary>
    /// Выбранный каталог (вход и выход)
    /// </summary>
    public AbsPath Path { get { return _Path; } set { _Path = value; } }
    private AbsPath _Path;

    private AbsPath _OldPath;

    /// <summary>
    /// Текст описания внизу блока диалога.
    /// Дублирует свойство Title, т.к. заголовок не может быть задан для этого блока диалога
    /// </summary>
    public string Description { get { return base.Title; } set { base.Title = value; } }

    /// <summary>
    /// Должна ли отображаться кнопка "Создать папку"
    /// </summary>
    public bool ShowNewFolderButton
    {
      get { return _ShowNewFolderButton; }
      set
      {
        CheckNotFixed();
        _ShowNewFolderButton = value;
      }
    }
    private bool _ShowNewFolderButton;

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _OldPath != Path;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);

      part.SetString("Path", Path.Path);
      _OldPath = Path;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Path = new AbsPath(part.GetString("Path"));
      _OldPath = Path;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.MachineSpecific;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetString(Name, Path.SlashedPath);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
        Path = new AbsPath(part.GetString(Name));
    }

    #endregion
  }

  /// <summary>
  /// Базовый класс для OpenFileDialog и SaveFileDialog
  /// </summary>
  [Serializable]
  public abstract class FileDialog : StandardDialog
  {
    #region Свойства

    /// <summary>
    /// Выбранный файл
    /// </summary>
    public AbsPath Path { get { return _Path; } set { _Path = value; } }
    private AbsPath _Path;

    private AbsPath _OldPath;

    /// <summary>
    /// Расширение по умолчанию
    /// </summary>
    public string DefaultExt
    {
      get { return _DefaultExt; }
      set
      {
        CheckNotFixed();
        _DefaultExt = value;
      }
    }
    private string _DefaultExt;

    /// <summary>
    /// Фильтры (разделитель "|"). Например: "Текстовые файлы|*.txt|Все файлы|*.*".
    /// </summary>
    public string Filter
    {
      get { return _Filter; }
      set
      {
        CheckNotFixed();
        _Filter = value;
      }
    }
    private string _Filter;

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _OldPath != Path;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);

      part.SetString("Path", Path.Path);
      _OldPath = Path;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Path = new AbsPath(part.GetString("Path"));
      _OldPath = Path;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.MachineSpecific;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetString(Name, Path.Path);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
        Path = new AbsPath(part.GetString(Name));
    }

    #endregion
  }

  /// <summary>
  /// Диалог выбора файла для открытия
  /// </summary>
  [Serializable]
  public class OpenFileDialog : FileDialog
  {
  }

  /// <summary>
  /// Диалог выбора файла для записи
  /// </summary>
  [Serializable]
  public class SaveFileDialog : FileDialog
  {
  }

  #endregion

  #region Ввод значений

  /// <summary>
  /// Базовый класс для диалогов ввода единственного значения, например TextInputDialog
  /// </summary>
  [Serializable]
  public abstract class BaseInputDialog : StandardDialog
  {
    #region Свойства

    /// <summary>
    /// Текст подсказки.
    /// Значение по умолчанию зависит от конкретного диалога.
    /// </summary>
    public string Prompt
    {
      get { return _Prompt; }
      set
      {
        CheckNotFixed();
        _Prompt = value;
      }
    }
    private string _Prompt;

    /// <summary>
    /// Можно ли вводить пустое значение.
    /// По умолчанию - false
    /// </summary>
    public bool CanBeEmpty
    {
      get { return _CanBeEmpty; }
      set
      {
        CheckNotFixed();
        _CanBeEmpty = value;
      }
    }
    private bool _CanBeEmpty;

    #endregion
  }

  /// <summary>
  /// Диалог ввода строки текста.
  /// Есть возможность ввода пароля.
  /// </summary>
  [Serializable]
  public class TextInputDialog : BaseInputDialog
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public TextInputDialog()
    {
      Title = "Ввод текста";
      Prompt = "Значение";
      Value = String.Empty;
      MaxLength = 0;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Вход и выход: редактируемое значение.
    /// По умолчанию - пустая строка.
    /// </summary>
    public string Value { get { return _Value; } set { _Value = value; } }
    private string _Value;
    private string _OldValue;

    /// <summary>
    /// Максимальная длина текста.
    /// По умолчанию: 0 - длина текста ограничена 32767 символами (Int16.MaxValue)
    /// </summary>
    public int MaxLength
    {
      get { return _MaxLength; }
      set
      {
        CheckNotFixed();
        _MaxLength = value;
      }
    }
    private int _MaxLength;


    /// <summary>
    /// Если установлено в true, то поле предназначено для ввода пароля. Вводимые символы не отображаются.
    /// По умолчанию - false - обычный ввод строки.
    /// </summary>
    public bool IsPassword { get { return _IsPassword; } set { _IsPassword = value; } }
    private bool _IsPassword;

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _OldValue != Value;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetString("Value", Value);
      _OldValue = Value;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Value = part.GetString("Value");
      _OldValue = Value;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetString(Name, Value);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
        Value = part.GetString(Name);
    }

    #endregion
  }

  /// <summary>
  /// Диалог ввода произвольной строки текста с возможностью выбора из списка возможных значений.
  /// </summary>
  [Serializable]
  public class ComboTextInputDialog : BaseInputDialog
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public ComboTextInputDialog()
    {
      Title = "Ввод текста";
      Prompt = "Значение";
      Value = String.Empty;
      MaxLength = 0;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Вход и выход: редактируемое значение.
    /// В отличие от TextBox, в блоке диалога свойство имеет имя "Value", а не "Text".
    /// По умолчанию - пустая строка.
    /// </summary>
    public string Value { get { return _Value; } set { _Value = value; } }
    private string _Value;
    private string _OldValue;

    /// <summary>
    /// Максимальная длина текста.
    /// По умолчанию: 0 - длина текста ограничена 32767 символами (Int16.MaxValue)
    /// </summary>
    public int MaxLength
    {
      get { return _MaxLength; }
      set
      {
        CheckNotFixed();
        _MaxLength = value;
      }
    }
    private int _MaxLength;

    /// <summary>
    /// Список строк, из которых можно выбрать значение.
    /// По умолчанию - null - список для выбора не задан.
    /// </summary>
    public string[] Items
    {
      get { return _Items; }
      set
      {
        CheckNotFixed();
        _Items = value;
      }
    }
    private string[] _Items;

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _OldValue != Value;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetString("Value", Value);
      _OldValue = Value;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Value = part.GetString("Value");
      _OldValue = Value;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetString(Name, Value);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
        Value = part.GetString(Name);
    }

    #endregion
  }

  /// <summary>
  /// Диалог ввода целого числа
  /// </summary>
  [Serializable]
  public class IntInputDialog : BaseInputDialog
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public IntInputDialog()
    {
      Title = "Ввод числа";
      Prompt = "Значение";
      NullableValue = null;
      MinValue = Int32.MinValue;
      MaxValue = Int32.MaxValue;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Вход и выход: редактируемое значение.
    /// Используйте это свойство, если CanBeEmpty=false.
    /// Пустое значение трактуется как 0.
    /// </summary>
    public int Value
    {
      get { return NullableValue ?? 0; }
      set { NullableValue = value; }
    }

    /// <summary>
    /// Ввод и вывод: Редактируемое значение
    /// </summary>
    public int? NullableValue { get { return _NullableValue; } set { _NullableValue = value; } }
    private int? _NullableValue;
    private int? _OldNullableValue;

    /// <summary>
    /// Минимальное значение. По умолчанию: Int32.MinValue
    /// </summary>
    public int MinValue
    {
      get { return _MinValue; }
      set
      {
        CheckNotFixed();
        _MinValue = value;
      }
    }
    private int _MinValue;

    /// <summary>
    /// Максимальное значение. По умолчанию: Int32.MaxValue
    /// </summary>
    public int MaxValue
    {
      get { return _MaxValue; }
      set
      {
        CheckNotFixed();
        _MaxValue = value;
      }
    }
    private int _MaxValue;

    /// <summary>
    /// Если свойство установлено в true, то значение можно выбирать с помощью стрелочек.
    /// По умолчанию - false - стрелочки не используются
    /// </summary>
    public bool ShowUpDown
    {
      get { return _ShowUpDown; }
      set
      {
        CheckNotFixed();
        _ShowUpDown = value;
      }
    }
    private bool _ShowUpDown;

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _OldNullableValue != NullableValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableInt("Value", NullableValue);
      _OldNullableValue = NullableValue;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      NullableValue = part.GetNullableInt("Value");
      _OldNullableValue = NullableValue;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetNullableInt(Name, NullableValue);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      NullableValue = part.GetNullableInt(Name);
    }

    #endregion
  }

  /// <summary>
  /// Базовый класс для SingleInputBox, DoubleInputBox и DecimalInputBox
  /// </summary>
  /// <typeparam name="T">Тип значения</typeparam>
  [Serializable]
  public abstract class BaseFloatInputDialog<T> : BaseInputDialog
    where T : struct
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public BaseFloatInputDialog()
    {
      Title = "Ввод числа";
      Prompt = "Значение";
      NullableValue = null;
      DecimalPlaces = -1;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Вход и выход: редактируемое значение.
    /// Используйте это свойство, если CanBeEmpty=false.
    /// Пустое значение трактуется как 0.
    /// </summary>
    public T Value
    {
      get { return NullableValue ?? default(T); }
      set { NullableValue = value; }
    }


    /// <summary>
    /// Вход и выход: редактируемое значение.
    /// </summary>
    public T? NullableValue { get { return _NullableValue; } set { _NullableValue = value; } }
    private T? _NullableValue;

    /// <summary>
    /// Используется при чтении/записи изменений
    /// </summary>
    protected T? OldNullableValue;


    /// <summary>
    /// Число десятичных знаков после запятой. По умолчанию: (-1) - число дейсятичных знаков не установлено
    /// </summary>
    public int DecimalPlaces
    {
      get { return _DecimalPlaces; }
      set
      {
        CheckNotFixed();
        _DecimalPlaces = value;
      }
    }
    private int _DecimalPlaces;

    /// <summary>
    /// Альтернативная установка свойства DecimalPlaces
    /// </summary>
    public string Format
    {
      get
      {
        return DataTools.DecimalPlacesToNumberFormat(DecimalPlaces);
      }
      set
      {
        DecimalPlaces = DataTools.DecimalPlacesFromNumberFormat(value);
      }
    }

    /// <summary>
    /// Минимальное значение. По умолчанию - минимально возможное значение для своего типа
    /// </summary>
    public T MinValue
    {
      get { return _MinValue; }
      set
      {
        CheckNotFixed();
        _MinValue = value;
      }
    }
    private T _MinValue;

    /// <summary>
    /// Максимальное значение. По умолчанию - максимально возможно значение для своего типа
    /// </summary>
    public T MaxValue
    {
      get { return _MaxValue; }
      set
      {
        CheckNotFixed();
        _MaxValue = value;
      }
    }
    private T _MaxValue;

    #endregion

    #region Методы

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="сfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType сfgType)
    {
      return сfgType == RIValueCfgType.Default;
    }

    #endregion
  }

  /// <summary>
  /// Диалог ввода числа одинарной точности
  /// </summary>
  [Serializable]
  public class SingleInputDialog : BaseFloatInputDialog<float>
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public SingleInputDialog()
    {
      MinValue = Single.MinValue;
      MaxValue = Single.MaxValue;
    }

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return OldNullableValue != NullableValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableSingle("Value", NullableValue);
      OldNullableValue = NullableValue;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      NullableValue = part.GetNullableSingle("Value");
      OldNullableValue = NullableValue;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetNullableSingle(Name, NullableValue);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      NullableValue = part.GetNullableSingle(Name);
    }

    #endregion
  }

  /// <summary>
  /// Диалог ввода числа двойной точности
  /// </summary>
  [Serializable]
  public class DoubleInputDialog : BaseFloatInputDialog<double>
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public DoubleInputDialog()
    {
      MinValue = Double.MinValue;
      MaxValue = Double.MaxValue;
    }

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return OldNullableValue != NullableValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableDouble("Value", NullableValue);
      OldNullableValue = NullableValue;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      NullableValue = part.GetNullableDouble("Value");
      OldNullableValue = NullableValue;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetNullableDouble(Name, NullableValue);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      NullableValue = part.GetNullableDouble(Name);
    }

    #endregion
  }

  /// <summary>
  /// Диалог ввода числа типа Decimal
  /// </summary>
  [Serializable]
  public class DecimalInputDialog : BaseFloatInputDialog<decimal>
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public DecimalInputDialog()
    {
      MinValue = Decimal.MinValue;
      MaxValue = Decimal.MaxValue;
    }

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return OldNullableValue != NullableValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableDecimal("Value", NullableValue);
      OldNullableValue = NullableValue;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      NullableValue = part.GetNullableDecimal("Value");
      OldNullableValue = NullableValue;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetNullableDecimal(Name, NullableValue);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      NullableValue = part.GetNullableDecimal(Name);
    }

    #endregion
  }

  /// <summary>
  /// Диалог ввода текста с возможностью выбора из списка возможных значений
  /// </summary>
  [Serializable]
  public class DateInputDialog : BaseInputDialog
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public DateInputDialog()
    {
      Title = "Ввод текста";
      Prompt = "Значение";
      Value = null;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Вход и выход: редактируемое значение
    /// </summary>
    public DateTime? Value { get { return _Value; } set { _Value = value; } }
    private DateTime? _Value;
    private DateTime? _OldValue;


    /// <summary>
    /// Минимальное значение. По умолчанию ограничение не задано
    /// </summary>
    public DateTime? MinValue
    {
      get { return _MinValue; }
      set
      {
        CheckNotFixed();
        _MinValue = value;
      }
    }
    private DateTime? _MinValue;

    /// <summary>
    /// Максимальное значение. По умолчанию ограничение не задано
    /// </summary>
    public DateTime? MaxValue
    {
      get { return _MaxValue; }
      set
      {
        CheckNotFixed();
        _MaxValue = value;
      }
    }
    private DateTime? _MaxValue;

    /// <summary>
    /// Если свойство установлено в true, то в диалоге будет не поле ввода даты, а календарик.
    /// Установка свойства несовместима с CanBeEmpty=true
    /// </summary>
    public bool UseCalendar
    {
      get { return _UseCalendar; }
      set
      {
        CheckNotFixed();
        _UseCalendar = value;
      }
    }
    private bool _UseCalendar;

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _OldValue != Value;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableDate("Value", Value);
      _OldValue = Value;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Value = part.GetNullableDate("Value");
      _OldValue = Value;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (Value.HasValue)
        part.SetDate(Name, Value.Value);
      else
        part.SetString(Name, String.Empty);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
        Value = part.GetNullableDate(Name);
    }

    #endregion
  }

  /// <summary>
  /// Диалог ввода многострочного текста.
  /// </summary>
  [Serializable]
  public class MultiLineTextInputDialog : StandardDialog
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public MultiLineTextInputDialog()
    {
      Title = "Ввод текста";
      _Lines = DataTools.EmptyStrings;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Вход и выход: редактируемое значение.
    /// Разделителем строк является Environment.NewLine.
    /// При передаче между компьютерами с разными операционными системами разделитель заменяется.
    /// </summary>
    public string Value
    {
      get
      {
        if (_Lines.Length == 0)
          return String.Empty;
        else
          return String.Join(Environment.NewLine, _Lines);
      }
      set
      {
        if (String.IsNullOrEmpty(value))
          _Lines = DataTools.EmptyStrings;
        else
          _Lines = value.Split(DataTools.NewLineSeparators, StringSplitOptions.None);
      }
    }

    /// <summary>
    /// Многострочный текст.
    /// Дублирует свойство Value как массив строк.
    /// </summary>
    public string[] Lines
    {
      get { return _Lines; }
      set
      {
        if (value == null)
          _Lines = DataTools.EmptyStrings;
        else if (value.Length == 0)
          _Lines = DataTools.EmptyStrings;
        else
          _Lines = value;
      }
    }
    private string[] _Lines;
    private string[] _OldLines;


    /// <summary>
    /// Можно ли вводить пустое значение.
    /// По умолчанию - false
    /// </summary>
    public bool CanBeEmpty
    {
      get { return _CanBeEmpty; }
      set
      {
        CheckNotFixed();
        _CanBeEmpty = value;
      }
    }
    private bool _CanBeEmpty;

    /// <summary>
    /// Если true, то форма будет предназначена только для просмотра текста, а не для редактирования.
    /// По умолчанию - false - текст можно редактировать
    /// </summary>
    public bool ReadOnly
    {
      get { return _ReadOnly; }
      set
      {
        CheckNotFixed();
        _ReadOnly = value;
      }
    }
    private bool _ReadOnly;

    /// <summary>
    /// Если true, то форма будет выведена на весь экран
    /// По умолчанию - false - форма имеет размер по умолчанию
    /// </summary>
    public bool Maximized
    {
      get { return _Maximized; }
      set
      {
        CheckNotFixed();
        _Maximized = value;
      }
    }
    private bool _Maximized;

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return !DataTools.AreArraysEqual<string>(_OldLines, Lines);
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetString("Value", Value);
      _OldLines = Lines;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      Value = part.GetString("Value");
      _OldLines = Lines;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetString(Name, Value);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
        Value = part.GetString(Name);
    }

    #endregion
  }

  #endregion

  #region Ввод диапазонов

  /// <summary>
  /// Диалог ввода диапазона целых чисел
  /// </summary>
  [Serializable]
  public class IntRangeDialog : BaseInputDialog
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public IntRangeDialog()
    {
      Title = "Ввод диапазона чисел";
      Prompt = "Диапазон";
      NullableFirstValue = null;
      NullableLastValue = null;
      CanBeEmpty = false;
      MinValue = Int32.MinValue;
      MaxValue = Int32.MaxValue;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Вход и выход - первое редактируемое значение с поддержкой null
    /// </summary>
    public int? NullableFirstValue { get { return _NullableFirstValue; } set { _NullableFirstValue = value; } }
    private int? _NullableFirstValue;
    private int? _OldNullableFirstValue;

    /// <summary>
    /// Вход и выход - второе редактируемое значение с поддержкой null
    /// </summary>
    public int? NullableLastValue { get { return _NullableLastValue; } set { _NullableLastValue = value; } }
    private int? _NullableLastValue;
    private int? _OldNullableLastValue;

    /// <summary>
    /// Вход и выход: первое редактируемое значение без поддержки null
    /// </summary>
    public int FirstValue
    {
      get { return NullableFirstValue ?? 0; }
      set { NullableFirstValue = value; }
    }

    /// <summary>
    /// Вход и выход: второе редактируемое значение без поддержки null
    /// </summary>
    public int LastValue
    {
      get { return NullableLastValue ?? 0; }
      set { NullableLastValue = value; }
    }

    /// <summary>
    /// Минимальное значение. По умолчанию: Int32.MinValue
    /// </summary>
    public int MinValue
    {
      get { return _MinValue; }
      set
      {
        CheckNotFixed();
        _MinValue = value;
      }
    }
    private int _MinValue;

    /// <summary>
    /// Максимальное значение. По умолчанию: Int32.MaxValue
    /// </summary>
    public int MaxValue
    {
      get { return _MaxValue; }
      set
      {
        CheckNotFixed();
        _MaxValue = value;
      }
    }
    private int _MaxValue;

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _OldNullableFirstValue != NullableFirstValue || _OldNullableLastValue != NullableLastValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableInt("FirstValue", NullableFirstValue);
      part.SetNullableInt("LastValue", NullableLastValue);
      _OldNullableFirstValue = NullableFirstValue;
      _OldNullableLastValue = NullableLastValue;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      NullableFirstValue = part.GetNullableInt("FirstValue");
      NullableLastValue = part.GetNullableInt("LastValue");
      _OldNullableFirstValue = NullableFirstValue;
      _OldNullableLastValue = NullableLastValue;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetNullableInt(Name + "-FirstValue", NullableFirstValue);
      part.SetNullableInt(Name + "-LastValue", NullableLastValue);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      NullableFirstValue = part.GetNullableInt(Name + "-FirstValue");
      NullableLastValue = part.GetNullableInt(Name + "-LastValue");
    }

    #endregion
  }

  /// <summary>
  /// Базовый класс для SingleRangeBox, DoubleRangeBox и DecimalRangeBox
  /// </summary>
  /// <typeparam name="T">Тип значения</typeparam>
  [Serializable]
  public abstract class BaseFloatRangeDialog<T> : BaseInputDialog
    where T : struct
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public BaseFloatRangeDialog()
    {
      Title = "Ввод диапазона чисел";
      Prompt = "Диапазон";
      NullableFirstValue = null;
      NullableLastValue = null;
      CanBeEmpty = false;
      _DecimalPlaces = -1;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Вход и выход: первое редактируемое значение с поддержкой null
    /// </summary>
    public T? NullableFirstValue { get { return _NullableFirstValue; } set { _NullableFirstValue = value; } }
    private T? _NullableFirstValue;

    /// <summary>
    /// Используется при чтении и записи значений
    /// </summary>
    protected T? OldNullableFirstValue;

    /// <summary>
    /// Вход и выход: второе редактируемое значение с поддержкой null
    /// </summary>
    public T? NullableLastValue { get { return _NullableLastValue; } set { _NullableLastValue = value; } }
    private T? _NullableLastValue;

    /// <summary>
    /// Используется при чтении и записи значений
    /// </summary>
    protected T? OldNullableLastValue;

    /// <summary>
    /// Вход и выход: первое редактируемое значение без поддержки null
    /// </summary>
    public T FirstValue
    {
      get { return NullableFirstValue ?? default(T); }
      set { NullableFirstValue = value; }
    }

    /// <summary>
    /// Вход и выход: второе редактируемое значение без поддержки null
    /// </summary>
    public T LastValue
    {
      get { return NullableLastValue ?? default(T); }
      set { NullableLastValue = value; }
    }


    /// <summary>
    /// Число десятичных знаков после запятой. По умолчанию: (-1) - число десятичных знаков не установлено
    /// </summary>
    public int DecimalPlaces
    {
      get { return _DecimalPlaces; }
      set
      {
        CheckNotFixed();
        _DecimalPlaces = value;
      }
    }
    private int _DecimalPlaces;

    /// <summary>
    /// Альтернативная установка свойства DecimalPlaces
    /// </summary>
    public string Format
    {
      get
      {
        if (DecimalPlaces < 0)
          return String.Empty;
        else if (DecimalPlaces == 0)
          return "0";
        else
          return "0." + new string('0', DecimalPlaces);
      }
      set
      {
        if (String.IsNullOrEmpty(value))
        {
          DecimalPlaces = -1;
          return;
        }

        int p = value.IndexOf('.');
        if (p < 0)
        {
          DecimalPlaces = 0;
          return;
        }

        DecimalPlaces = value.Length - p - 1;
      }
    }

    /// <summary>
    /// Минимальное значение. По умолчанию - минимально возможное значение для своего типа
    /// </summary>
    public T MinValue
    {
      get { return _MinValue; }
      set
      {
        CheckNotFixed();
        _MinValue = value;
      }
    }
    private T _MinValue;

    /// <summary>
    /// Максимальное значение. По умолчанию - максимально возможно значение для своего типа
    /// </summary>
    public T MaxValue
    {
      get { return _MaxValue; }
      set
      {
        CheckNotFixed();
        _MaxValue = value;
      }
    }
    private T _MaxValue;

    #endregion

    #region Методы

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    #endregion
  }

  /// <summary>
  /// Диалог ввода числа одинарной точности
  /// </summary>
  [Serializable]
  public class SingleRangeDialog : BaseFloatRangeDialog<float>
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public SingleRangeDialog()
    {
      MinValue = Single.MinValue;
      MaxValue = Single.MaxValue;
    }

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return OldNullableFirstValue != NullableFirstValue || OldNullableLastValue != NullableLastValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableSingle("FirstValue", NullableFirstValue);
      part.SetNullableSingle("LastValue", NullableLastValue);
      OldNullableFirstValue = NullableFirstValue;
      OldNullableLastValue = NullableLastValue;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      NullableFirstValue = part.GetNullableSingle("FirstValue");
      NullableLastValue = part.GetNullableSingle("LastValue");
      OldNullableFirstValue = NullableFirstValue;
      OldNullableLastValue = NullableLastValue;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetNullableSingle(Name + "-FirstValue", NullableFirstValue);
      part.SetNullableSingle(Name + "-LastValue", NullableLastValue);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      NullableFirstValue = part.GetNullableSingle(Name + "-FirstValue");
      NullableLastValue = part.GetNullableSingle(Name + "-LastValue");
    }

    #endregion
  }

  /// <summary>
  /// Диалог ввода числа двойной точности
  /// </summary>
  [Serializable]
  public class DoubleRangeDialog : BaseFloatRangeDialog<double>
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public DoubleRangeDialog()
    {
      MinValue = Double.MinValue;
      MaxValue = Double.MaxValue;
    }

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return OldNullableFirstValue != NullableFirstValue || OldNullableLastValue != NullableLastValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableDouble("FirstValue", NullableFirstValue);
      part.SetNullableDouble("LastValue", NullableLastValue);
      OldNullableFirstValue = NullableFirstValue;
      OldNullableLastValue = NullableLastValue;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      NullableFirstValue = part.GetNullableDouble("FirstValue");
      NullableLastValue = part.GetNullableDouble("LastValue");
      OldNullableFirstValue = NullableFirstValue;
      OldNullableLastValue = NullableLastValue;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetNullableDouble(Name + "-FirstValue", NullableFirstValue);
      part.SetNullableDouble(Name + "-LastValue", NullableLastValue);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      NullableFirstValue = part.GetNullableDouble(Name + "-FirstValue");
      NullableLastValue = part.GetNullableDouble(Name + "-LastValue");
    }

    #endregion
  }

  /// <summary>
  /// Диалог ввода числа decimal
  /// </summary>
  [Serializable]
  public class DecimalRangeDialog : BaseFloatRangeDialog<decimal>
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public DecimalRangeDialog()
    {
      MinValue = Decimal.MinValue;
      MaxValue = Decimal.MaxValue;
    }

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return OldNullableFirstValue != NullableFirstValue || OldNullableLastValue != NullableLastValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableDecimal("FirstValue", NullableFirstValue);
      part.SetNullableDecimal("LastValue", NullableLastValue);
      OldNullableFirstValue = NullableFirstValue;
      OldNullableLastValue = NullableLastValue;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      NullableFirstValue = part.GetNullableDecimal("FirstValue");
      NullableLastValue = part.GetNullableDecimal("LastValue");
      OldNullableFirstValue = NullableFirstValue;
      OldNullableLastValue = NullableLastValue;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetNullableDecimal(Name + "-FirstValue", NullableFirstValue);
      part.SetNullableDecimal(Name + "-LastValue", NullableLastValue);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      NullableFirstValue = part.GetNullableDecimal(Name + "-FirstValue");
      NullableLastValue = part.GetNullableDecimal(Name + "-LastValue");
    }

    #endregion
  }

  /// <summary>
  /// Диалог ввода диапазона дат
  /// </summary>
  [Serializable]
  public class DateRangeDialog : BaseInputDialog
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    public DateRangeDialog()
    {
      Title = "Ввод диапазона дат";
      Prompt = "Диапазон";
      FirstValue = null;
      LastValue = null;
      CanBeEmpty = false;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Вход и выход - первое редактируемое значение с поддержкой null
    /// </summary>
    public DateTime? FirstValue { get { return _FirstValue; } set { _FirstValue = value; } }
    private DateTime? _FirstValue;
    private DateTime? _OldFirstValue;

    /// <summary>
    /// Вход и выход - второе редактируемое значение с поддержкой null
    /// </summary>
    public DateTime? LastValue { get { return _LastValue; } set { _LastValue = value; } }
    private DateTime? _LastValue;
    private DateTime? _OldLastValue;

    /// <summary>
    /// Минимальное значение. По умолчанию: null
    /// </summary>
    public DateTime? MinValue
    {
      get { return _MinValue; }
      set
      {
        CheckNotFixed();
        _MinValue = value;
      }
    }
    private DateTime? _MinValue;

    /// <summary>
    /// Максимальное значение. По умолчанию: null
    /// </summary>
    public DateTime? MaxValue
    {
      get { return _MaxValue; }
      set
      {
        CheckNotFixed();
        _MaxValue = value;
      }
    }
    private DateTime? _MaxValue;

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _OldFirstValue != FirstValue || _OldLastValue != LastValue;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetNullableDate("FirstValue", FirstValue);
      part.SetNullableDate("LastValue", LastValue);
      _OldFirstValue = FirstValue;
      _OldLastValue = LastValue;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      FirstValue = part.GetNullableDate("FirstValue");
      LastValue = part.GetNullableDate("LastValue");
      _OldFirstValue = FirstValue;
      _OldLastValue = LastValue;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      part.SetNullableDate(Name + "-FirstValue", FirstValue);
      part.SetNullableDate(Name + "-LastValue", LastValue);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      FirstValue = part.GetNullableDate(Name + "-FirstValue");
      LastValue = part.GetNullableDate(Name + "-LastValue");
    }

    #endregion
  }

  #endregion

  #region Выбор из списка

  #region Перечисление ListSelectDialogClipboardMode

  /// <summary>
  /// Режимы использования буфера обмена в диалоге ListSelectDialog
  /// </summary>
  [Serializable]
  public enum ListSelectDialogClipboardMode
  {
    /// <summary>
    /// Буфер обмена не используется
    /// </summary>
    None = 0,

    /// <summary>
    /// Если MultiSelect=true, в буфер обмена копируются отмеченные флажками элементы, разделенные запятыми, в виде одной строки текста.
    /// Дополнительные пробелы не добавляются. В режиме MultiSelect=false копируется текущий элемент.
    /// Дополнительный столбец SubItems не копируется, даже если он есть.
    /// Режим можно использовать, только если в списке ListSelectDialog.Items гарантированно нет запятых.
    /// </summary>
    CommaCodes = 1,
  }

  #endregion

  /// <summary>
  /// Диалог выбора одного или нескольких значений из списка.
  /// Список должен со
  /// </summary>
  [Serializable]
  public class ListSelectDialog : StandardDialog
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог для выбора одного элемента из списка
    /// </summary>
    /// <param name="items">Список элементов для выбора. Не может быть пустым.</param>
    public ListSelectDialog(string[] items)
      : this(items, false)
    {
    }

    /// <summary>
    /// Создает диалог для выбора одного или нескольких элементов из списка.
    /// </summary>
    /// <param name="items">Список элементов для выбора. Не может быть пустым.</param>
    /// <param name="multiSelect">True, если разрешается выбор нескольких элементов</param>
    public ListSelectDialog(string[] items, bool multiSelect)
    {
      CheckNotEmptyStringArray(items, true);
      _Items = items;

      if (items.Length == 0)
      {
        // 25.10.2019
        _SelectedIndex = -1;
        _OldSelectedIndex = -1;
      }
      else
      {
        _SelectedIndex = 0;
        _OldSelectedIndex = 0;
      }

      if (multiSelect)
      {
        _Selections = new bool[items.Length];
        _OldSelections = new bool[items.Length];
      }
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Список для выбора. Задается в конструкторе
    /// Строки могут содержать символ "амперсанд" для подчеркивания буквы.
    /// </summary>
    public string[] Items { get { return _Items; } }
    private string[] _Items;

    /// <summary>
    /// True, если разрешено выбирать несколько позиций. Задается в конструкторе.
    /// </summary>
    public bool MultiSelect { get { return _Selections != null; } }

    /// <summary>
    /// Вход и выход: Текущее выбранное значение.
    /// По умолчанию свойство имеет значение 0 или (-1), если Items.Length=0.
    /// </summary>
    public int SelectedIndex
    {
      get { return _SelectedIndex; }
      set
      {
        if (value < (-1) || value > Items.Length)
          throw new ArgumentOutOfRangeException();
        _SelectedIndex = value;
      }
    }
    private int _SelectedIndex;
    private int _OldSelectedIndex;


    /// <summary>
    /// Флажки выбора в режиме MultiSelect.
    /// Если MultiSelect=false, то свойство возвращает null.
    /// </summary>
    public bool[] Selections
    {
      get { return _Selections; }
      set
      {
        if (!MultiSelect)
          throw new InvalidOperationException("Список не предназначен для множественного выбора");
        if (value == null)
          throw new ArgumentNullException();
        value.CopyTo(_Selections, 0);
      }
    }
    private bool[] _Selections;
    private bool[] _OldSelections;


    /// <summary>
    /// Можно ли не выбирать ни одной позиции.
    /// По умолчанию - false - выбор является обязательным.
    /// </summary>
    public bool CanBeEmpty
    {
      get { return _CanBeEmpty; }
      set
      {
        CheckNotFixed();
        _CanBeEmpty = value;
      }
    }
    private bool _CanBeEmpty;

    /// <summary>
    /// Заголовок над списком
    /// </summary>
    public string ListTitle
    {
      get { return _ListTitle; }
      set
      {
        CheckNotFixed();
        _ListTitle = value;
      }
    }
    private string _ListTitle;

    /// <summary>
    /// В режиме MultiSelect возвращает true, если в Selected установлены все флажки
    /// </summary>
    public bool AreAllSelected
    {
      get
      {
        if (_Selections == null)
          return false;
        for (int i = 0; i < _Selections.Length; i++)
        {
          if (!_Selections[i])
            return false;
        }
        return true;
      }
    }

    /// <summary>
    /// В режиме MultiSelect возвращает true, если в Selected сброшены все флажки
    /// </summary>
    public bool AreAllUnselected
    {
      get
      {
        if (_Selections == null)
          return false;
        for (int i = 0; i < _Selections.Length; i++)
        {
          if (_Selections[i])
            return false;
        }
        return true;
      }
    }

    /// <summary>
    /// Индексы выбранных строк.
    /// Если MultiSelect=false значение содержит один или ноль элементов.
    /// Если в режиме MultiSelect=false устанавливается значение с количеством элементов в массиве, большим 1, 
    /// то используется первый элемент переданного массива, а остальные элементы отбрасываются. Если массив пустой, то устанавливается SelectedIndex=-1.
    /// </summary>
    public int[] SelectedIndices
    {
      get
      {
        if (MultiSelect)
        {
          List<int> lst = new List<int>();
          for (int i = 0; i < _Selections.Length; i++)
          {
            if (_Selections[i])
              lst.Add(i);
          }
          return lst.ToArray();
        }
        else
        {
          if (SelectedIndex >= 0)
            return new int[1] { SelectedIndex };
          else
            return DataTools.EmptyInts;
        }
      }
      set
      {
        if (MultiSelect)
        {
          DataTools.FillArray<bool>(_Selections, false);
          if (value != null)
          {
            for (int i = 0; i < value.Length; i++)
            {
              if (value[i] < 0 || value[i] >= _Selections.Length)
                throw new ArgumentOutOfRangeException();
              _Selections[value[i]] = true;
            }
          }
        }
        else
        {
          if (value == null)
            SelectedIndex = -1;
          else if (value.Length == 0)
            SelectedIndex = -1;
          else /*if (value.Length == 1) ограничение убрано 25.10.2019 */
          {
            if (value[0] < 0 || value[0] >= _Items.Length)
              throw new ArgumentOutOfRangeException();
            SelectedIndex = value[0];
          }
        }
      }
    }

    /// <summary>
    /// Коды выбраны строк.
    /// Если MultiSelect=false значение содержит один или ноль элементов.
    /// Свойство действительно только при установленном свойстве Codes.
    /// Если коды не используются, свойство возвращает null.
    /// Если в режиме MultiSelect=false устанавливается значение с количеством элементов в массиве, большим 1, 
    /// то используется первый элемент переданного массива, а остальные элементы отбрасываются. Если массив пустой, то устанавливается SelectedIndex=-1.
    /// </summary>
    public string[] SelectedCodes
    {
      get
      {
        if (Codes == null)
          return null;

        if (MultiSelect)
        {
          List<string> lst = new List<string>();
          for (int i = 0; i < _Selections.Length; i++)
          {
            if (_Selections[i])
              lst.Add(Codes[i]);
          }
          return lst.ToArray();
        }
        else
        {
          if (SelectedIndex >= 0)
            return new string[1] { Codes[SelectedIndex] };
          else
            return DataTools.EmptyStrings;
        }
      }
      set
      {
        if (Codes == null)
          throw new InvalidOperationException("Свойство Codes не установено");

        if (MultiSelect)
        {

          DataTools.FillArray<bool>(_Selections, false);
          if (value != null)
          {
            ArrayIndexer<string> ai = new ArrayIndexer<string>(value);

            for (int i = 0; i < Codes.Length; i++)
            {
              if (ai.Contains(Codes[i]))
                _Selections[i] = true;
            }
          }
        }
        else
        {
          if (value == null)
            SelectedIndex = -1;
          else if (value.Length == 0)
            SelectedIndex = -1;
          else
            SelectedCode = value[0];
        }
      }
    }

    /// <summary>
    /// Список строк для второго столбца.
    /// Если свойство равно null (по умолчанию), то второго столбца нет
    /// </summary>
    public string[] SubItems
    {
      get
      {
        return _SubItems;
      }
      set
      {
        CheckNotFixed();
        if (value != null)
        {
          if (value.Length != _Items.Length)
            throw new ArgumentException("Неправильная длина массива");
        }
        _SubItems = value;
      }
    }
    private string[] _SubItems;

    /// <summary>
    /// Коды для элементов.
    /// Если свойство установлено, то для сохранения значения между сеансами работы используется код, а не индекс.
    /// По умолчанию свойство содержит значение null
    /// </summary>
    public string[] Codes
    {
      get { return _Codes; }
      set
      {
        CheckNotFixed();
        if (value != null)
        {
          if (value.Length != _Items.Length)
            throw new ArgumentException("Неправильная длина массива кодов");
          _Codes = value;
        }
      }
    }
    private string[] _Codes;

    /// <summary>
    /// Текущая выбранная позиция как код.
    /// Должно быть установлен свойство Codes.
    /// </summary>
    public string SelectedCode
    {
      get
      {
        if (Codes == null)
          return String.Empty;
        else
          return Codes[SelectedIndex];
      }
      set
      {
        if (Codes == null)
          throw new InvalidOperationException("Свойство Codes не установено");
        SelectedIndex = Array.IndexOf<string>(Codes, value);
      }
    }

    /// <summary>
    /// Можно ли использовать команды копирования и вставки из буфера обмена.
    /// По умолчанию - None - копирование недоступно.
    /// </summary>
    public ListSelectDialogClipboardMode ClipboardMode 
    { 
      get { return _ClipboardMode; } 
      set 
      {
        CheckNotFixed();
        _ClipboardMode = value; 
      } 
    }
    private ListSelectDialogClipboardMode _ClipboardMode;

    #endregion

    #region Методы

    /// <summary>
    /// Задать выбранные элементы с помощью списка строк.
    /// Для строк Items, которые будут найдены в переданном аргументе, будет 
    /// установлена отметка. Для остальных строк отметка будет снята
    /// </summary>
    /// <param name="selectedItems">Значения, которые нужно выбрать</param>
    public void SetSelectedItems(string[] selectedItems)
    {
      if (!MultiSelect)
        throw new InvalidOperationException("Свойство MultiSelect не установлено");

      Array.Clear(_Selections, 0, _Selections.Length);

      if (selectedItems != null)
      {
        for (int i = 0; i < selectedItems.Length; i++)
        {
          int p = Array.IndexOf<String>(_Items, selectedItems[i]);
          if (p >= 0)
            Selections[p] = true;
        }
      }
    }

    /// <summary>
    /// Получить список отмеченных строк из массива Items
    /// </summary>
    /// <returns></returns>
    public string[] GetSelectedItems()
    {
      if (!MultiSelect)
      {
        if (SelectedIndex >= 0)
          return new string[1] { Items[SelectedIndex] };
        return DataTools.EmptyStrings;
      }

      // Придется делать 2 прохода
      int i;
      int n = 0;
      for (i = 0; i < Selections.Length; i++)
      {
        if (Selections[i])
          n++;
      }
      string[] a = new string[n];
      n = 0;
      for (i = 0; i < Selections.Length; i++)
      {
        if (Selections[i])
        {
          a[n] = Items[i];
          n++;
        }
      }
      return a;
    }

    /// <summary>
    /// Установить отметки для всех позиций
    /// </summary>
    public void SelectAll()
    {
      if (!MultiSelect)
        throw new InvalidOperationException("Свойство MultiSelect не установлено");

      for (int i = 0; i < Selections.Length; i++)
        Selections[i] = true;
    }

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        if (_OldSelectedIndex != SelectedIndex)
          return true;
        if (MultiSelect)
        {
          for (int i = 0; i < _Selections.Length; i++)
          {
            if (_Selections[i] != _OldSelections[i])
              return true;
          }
        }

        return false;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetInt("SelectedIndex", SelectedIndex);
      _OldSelectedIndex = SelectedIndex;
      if (MultiSelect)
      {
        int[] a1 = SelectedIndices;
        string[] a2 = new string[a1.Length];
        for (int i = 0; i < a1.Length; i++)
          a2[i] = a1[i].ToString();
        part.SetString("Selections", String.Join(",", a2));
      }
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      SelectedIndex = part.GetInt("SelectedIndex");
      _OldSelectedIndex = SelectedIndex;
      if (MultiSelect)
      {
        string s = part.GetString("Selections");
        string[] a1;
        if (String.IsNullOrEmpty(s))
          a1 = DataTools.EmptyStrings;
        else
          a1 = s.Split(',');
        int[] a2 = new int[a1.Length];
        for (int i = 0; i < a1.Length; i++)
          a2[i] = int.Parse(a1[i]);
        SelectedIndices = a2;

        Array.Copy(_Selections, _OldSelections, _Selections.Length);
      }
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (MultiSelect)
      {
        // добавлено 25.10.2019

        // Записываем коды или индексы в одну строку через запятую
        // При чтении будем учитывать совместимость для MultiSelect=true и false.

        if (Codes == null)
          part.SetIntCommaString(Name, SelectedIndices);
        else
          part.SetString(Name, String.Join(",", SelectedCodes));
      }
      else
      {
        if (Codes == null)
          part.SetInt(Name, SelectedIndex);
        else
          part.SetString(Name, SelectedCode);
      }
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
      {
        // Можно в любом режиме использовать свойства SelectedIndices и SelectedCodes, так как работают и при MultiSelect=false.

        if (Codes == null)
          SelectedIndices = part.GetIntCommaString(Name);
        else
          SelectedCodes = part.GetString(Name).Split(',');

        if (MultiSelect)
        {
          // Устанавливаем текущую позицию на первый выбранный элемент
          _SelectedIndex = -1;
          for (int i = 0; i < _Selections.Length; i++)
          {
            if (_Selections[i])
            {
              _SelectedIndex = i;
              break;
            }
          }
          if (_SelectedIndex < 0 && _Items.Length > 0)
            _SelectedIndex = 0;
        }
      }
    }

    #endregion
  }

  /// <summary>
  /// Диалог выбора значения с помощью группы радиокнопок
  /// </summary>
  [Serializable]
  public class RadioSelectDialog : StandardDialog
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог
    /// </summary>
    /// <param name="items">Список надписей для радиокнопок. Список не может быть пустым.</param>
    public RadioSelectDialog(string[] items)
    {
      CheckNotEmptyStringArray(items, false);
      _Items = items;
      _SelectedIndex = 0;
      _OldSelectedIndex = 0;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Список для выбора. Задается в конструкторе
    /// Строки могут содержать символ "амперсанд" для подчеркивания буквы
    /// </summary>
    public string[] Items { get { return _Items; } }
    private string[] _Items;


    /// <summary>
    /// Вход и выход: Текущее выбранное значение.
    /// По умолчанию свойство имеет значение 0
    /// </summary>
    public int SelectedIndex
    {
      get { return _SelectedIndex; }
      set
      {
        if (value < 0 || value > Items.Length)
          throw new ArgumentOutOfRangeException();
        _SelectedIndex = value;
      }
    }
    private int _SelectedIndex;
    private int _OldSelectedIndex;


    /// <summary>
    /// Заголовок над кнопками
    /// </summary>
    public string GroupTitle
    {
      get { return _GroupTitle; }
      set
      {
        CheckNotFixed();
        _GroupTitle = value;
      }
    }
    private string _GroupTitle;

    /// <summary>
    /// Коды для элементов.
    /// Если свойство установлено, то для сохранения значения между сеансами работы используется код, а не индекс.
    /// По умолчанию свойство содержит значение null.
    /// </summary>
    public string[] Codes
    {
      get { return _Codes; }
      set
      {
        CheckNotFixed();
        if (value != null)
        {
          if (value.Length != _Items.Length)
            throw new ArgumentException("Неправильная длина массива кодов");
          _Codes = value;
        }
      }
    }
    private string[] _Codes;

    /// <summary>
    /// Текущая выбранная позиция как код.
    /// Должно быть установлен свойство Codes
    /// </summary>
    public string SelectedCode
    {
      get
      {
        if (Codes == null)
          return String.Empty;
        else
          return Codes[SelectedIndex];
      }
      set
      {
        if (Codes == null)
          throw new InvalidOperationException("Свойство Codes не установено");
        SelectedIndex = Array.IndexOf<string>(Codes, value);
      }
    }

    #endregion

    #region Чтение и запись значений

    /// <summary>
    /// Свойство возвращает true, если для элемента есть непереданные на другую сторону изменения в значениях свойств,
    /// которые могут меняться при показе блока диалога.
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Свойство не используется в пользовательском коде.
    /// </summary>
    public override bool HasChanges
    {
      get
      {
        if (base.HasChanges)
          return true;
        return _OldSelectedIndex != SelectedIndex;
      }
    }

    /// <summary>
    /// Записать изменения. Метод вызывается родительским объектом, только если свойство HasChanges вернуло true. 
    /// На родительском объекте лежит обязанность по созданию раздела конфигурации <paramref name="part"/>
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для записи значений</param>
    public override void WriteChanges(CfgPart part)
    {
      base.WriteChanges(part);
      part.SetInt("SelectedIndex", SelectedIndex);
      _OldSelectedIndex = SelectedIndex;
    }

    /// <summary>
    /// Прочитать изменения, переданные "с другой стороны".
    /// Однократно задаваемые свойства, которые не могут меняться при работе диалога, не учитываются.
    /// Метод не используется в пользовательском коде.
    /// </summary>
    /// <param name="part">Секция для чтения значений</param>
    public override void ReadChanges(CfgPart part)
    {
      base.ReadChanges(part);
      SelectedIndex = part.GetInt("SelectedIndex");
      _OldSelectedIndex = SelectedIndex;
    }

    /// <summary>
    /// Возвращает true, если элемент поддерживает сохранение своих значений между сеансами работы
    /// в секции конфигурации заданного типа.
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, определяющий место ее хранения</param>
    /// <returns>true, если элемент может хранить данные</returns>
    protected override bool OnSupportsCfgType(RIValueCfgType cfgType)
    {
      return cfgType == RIValueCfgType.Default;
    }

    /// <summary>
    /// Записывает значения, сохраняемые между сеансами работы, в заданную секцию конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для записи</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnWriteValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (Codes == null)
        part.SetInt(Name, SelectedIndex);
      else
        part.SetString(Name, SelectedCode);
    }

    /// <summary>
    /// Считывает значения, сохраняемые между сеансами работы, из заданной секции конфигурации.
    /// Метод вызывается, только если OnSupportsCfgType() вернул true для заданного типа секции.
    /// </summary>
    /// <param name="part">Секция конфигурации для чтения значений</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    protected override void OnReadValues(CfgPart part, RIValueCfgType cfgType)
    {
      if (part.HasValue(Name))
      {
        if (Codes == null)
          SelectedIndex = part.GetInt(Name);
        else
          SelectedCode = part.GetString(Name);
      }
    }

    #endregion
  }

  #endregion

  #endregion

  /// <summary>
  /// Интерфейс, реализующий чтение/запись секций конфигурации.
  /// Для работы с интерфейсом используется статический метод RIExecProcCaller.PerformReadWriteValues()
  /// </summary>
  public interface IRIValueSaver
  {
    /// <summary>
    /// Метод должен возвращать true для <paramref name="cfgType"/>=Default.
    /// Для значения MachineSpecific метод должен вернуть true, если данные хранятся на сервере (что обычно бывает. Иначе - зачем удаленный интерфейс)
    /// Если метод вернет false, значит машинно-специфические данные будут храниться в основной секции данных
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации</param>
    /// <returns>true, если данные должны храниться отдельно</returns>
    bool SupportsCfgType(RIValueCfgType cfgType);

    /// <summary>
    /// Этот метод вызывается перед чтением или записью значений.
    /// Если метод вернет null, данные не будут читаться или записываться.
    /// Если метод секцию, обязательно будет вызван EndReadWrite()
    /// </summary>
    /// <param name="cfgType">Тип секции конфигурации, которая требуется</param>
    /// <param name="isWrite">true-запись значений, false - чтение значений</param>
    /// <returns>Секция для чтения или записи значений, или null</returns>
    CfgPart BeginReadWrite(RIValueCfgType cfgType, bool isWrite);

    /// <summary>
    /// Этот метод вызывается после чтения или записи значений.
    /// Вызов является парным для BeginReadWrite
    /// </summary>
    /// <param name="cfg">Секция, полученная от BeginReadWrite(). Не может быть null</param>
    /// <param name="cfgType">Тип секции конфигурации</param>
    /// <param name="isWrite">true-запись значений, false - чтение значений</param>
    void EndReadWrite(CfgPart cfg, RIValueCfgType cfgType, bool isWrite);
  }

  /// <summary>
  /// Интерфейс обработки удаленного пользовательского интерфейса
  /// </summary>
  public interface IRemoteInterface
  {
    #region Методы показа диалогов

    /// <summary>
    /// Вывести блок диалога, созданный в пользовательском коде и дождаться его завершения.
    /// После завершения следует проверить результат на равенство Ok
    /// </summary>
    /// <param name="dialog">Созданный блок диалога</param>
    /// <returns>Результат завершения (Ok или Cancel)</returns>
    DialogResult ShowDialog(Dialog dialog);

    /// <summary>
    /// Показать стандартный блок диалога
    /// После завершения следует проверить результат на равенство Ok
    /// </summary>
    /// <param name="dialog">Блок диалога</param>
    /// <returns>Результат завершения (Ok или Cancel)</returns>
    DialogResult ShowDialog(StandardDialog dialog);

    /// <summary>
    /// Вывести информационное сообщение без заголовка
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    void MessageBox(string text);

    /// <summary>
    /// Вывести информационное сообщение
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    /// <param name="caption">Текст заголовка</param>
    void MessageBox(string text, string caption);

    /// <summary>
    /// Вывести сообщение с заданным набором кнопок
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    /// <param name="caption">Текст заголовка</param>
    /// <param name="buttons">Какой набор кнопок использовать</param>
    /// <returns>Результат завершения блока диалога</returns>
    DialogResult MessageBox(string text, string caption, MessageBoxButtons buttons);

    /// <summary>
    /// Вывести сообщение с заданным набором кнопок и значком
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    /// <param name="caption">Текст заголовка</param>
    /// <param name="buttons">Какой набор кнопок использовать</param>
    /// <param name="icon">Значок</param>
    /// <returns>Результат завершения блока диалога</returns>
    DialogResult MessageBox(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon);

    /// <summary>
    /// Вывести сообщение с заданным набором кнопок и значком.
    /// Можно указать, какая кнопка будет активна по умолчанию
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    /// <param name="caption">Текст заголовка</param>
    /// <param name="buttons">Какой набор кнопок использовать</param>
    /// <param name="icon">Значок</param>
    /// <param name="defaultButton">Номер кнопки, выбранной по умолчанию</param>
    /// <returns>Результат завершения блока диалога</returns>
    DialogResult MessageBox(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton);

    /// <summary>
    /// Вывести сообщение об ошибке
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    void ErrorMessageBox(string text);

    /// <summary>
    /// Вывести сообщение об ошибке
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    /// <param name="caption">Текст заголовка</param>
    void ErrorMessageBox(string text, string caption);

    /// <summary>
    /// Вывести сообщение об ошибке
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    void WarningMessageBox(string text);

    /// <summary>
    /// Вывести сообщение об ошибке
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    /// <param name="caption">Текст заголовка</param>
    void WarningMessageBox(string text, string caption);

    #endregion
  }

  /// <summary>
  /// Переходник для процедуры, используемый на вызывающей стороне
  /// </summary>
  public class RIExecProcCaller : MarshalByRefObject, IRemoteInterface
  {
    #region Конструктор

    /// <summary>
    /// Создать переходник без поддержки сохранения значений между вызовами
    /// </summary>
    /// <param name="execProc">Выполняемая процедура</param>
    public RIExecProcCaller(IExecProc execProc)
      : this(execProc, null)
    {
    }

    /// <summary>
    /// Создать переходник с возможностью поддержки сохранения значений между вызовами
    /// </summary>
    /// <param name="execProc">Выполняемая процедура</param>
    /// <param name="saver">Поставщик секций конфигурации для сохранения значений. Может быть null</param>
    public RIExecProcCaller(IExecProc execProc, IRIValueSaver saver)
    {
      if (execProc == null)
        throw new ArgumentNullException("execProc");
      _ExecProc = execProc;
      _Saver = saver;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Ссылка на процедуру, выполняющую вызов. 
    /// </summary>
    public IExecProc ExecProc { get { return _ExecProc; } }
    private IExecProc _ExecProc;

    /// <summary>
    /// Интерфейс, используемый для чтения / записи значений между вызовами.
    /// Задается в конструкторе. Может быть null
    /// </summary>
    public IRIValueSaver Saver { get { return _Saver; } }
    private IRIValueSaver _Saver;

    #endregion

    #region IRemoteInterface Members

    /// <summary>
    /// Показывает пользовательский блок диалога.
    /// Проверяйте, что результат выполнения равен DialogResult=Ok после вызова метода.
    /// </summary>
    /// <param name="dialog">Диалог</param>
    /// <returns>Результат выполнения блока диалога</returns>
    public DialogResult ShowDialog(Dialog dialog)
    {
      if (dialog == null)
        throw new ArgumentNullException("dialog");

      dialog.SetFixed(); // блокируем добавление элементов
      PerformReadWriteValues(Saver, dialog, false); // прочитали предыдущие значения
      TempCfg Cfg = new TempCfg();
      dialog.WriteChanges(Cfg);

      while (true)
      {
        NamedValues DispArgs = new NamedValues();
        DispArgs["Action"] = "ShowDialog";
        DispArgs["Dialog"] = dialog;
        NamedValues DispRes = _ExecProc.Execute(DispArgs);
        Cfg = new TempCfg();
        Cfg.AsXmlText = DispRes.GetString("Changes");
        dialog.ReadChanges(Cfg);

        DialogResult DlgRes = (DialogResult)(DispRes["DialogResult"]);
        if (DlgRes == DialogResult.OK || DlgRes == DialogResult.Yes)
        {
          if (!dialog.Validate())
            continue;
          PerformReadWriteValues(Saver, dialog, true);
        }

        return DlgRes;
      }
    }

    /// <summary>
    /// Показ одного из стандартный блоков диалога.
    /// Проверяйте, что результат выполнения равен DialogResult=Ok после вызова метода.
    /// </summary>
    /// <param name="dialog">Диалог</param>
    /// <returns>Результат выполнения блока диалога</returns>
    public DialogResult ShowDialog(StandardDialog dialog)
    {
      if (dialog == null)
        throw new ArgumentNullException("dialog");

      dialog.SetFixed(); // блокируем внесение изменений
      PerformReadWriteValues(Saver, dialog, false);
      TempCfg Cfg = new TempCfg();
      dialog.WriteChanges(Cfg);

      while (true)
      {
        NamedValues DispArgs = new NamedValues();
        DispArgs["Action"] = "ShowStandardDialog";
        DispArgs["Dialog"] = dialog;
        NamedValues DispRes = _ExecProc.Execute(DispArgs);
        Cfg = new TempCfg();
        Cfg.AsXmlText = DispRes.GetString("Changes");
        dialog.ReadChanges(Cfg);

        DialogResult DlgRes = (DialogResult)(DispRes["DialogResult"]);
        if (DlgRes == DialogResult.OK || DlgRes == DialogResult.Yes)
        {
          // пока нет
          //if (!Dialog.Validate())
          //  continue;
          PerformReadWriteValues(Saver, dialog, true);
        }
        return DlgRes;
      }
    }

    /// <summary>
    /// Вывод окна с сообщением, без заголовка, и кнопкой ОК.
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    public void MessageBox(string text)
    {
      MessageBox(text, String.Empty, MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
    }

    /// <summary>
    /// Вывод окна с сообщением.
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    /// <param name="caption">Заголовок блока диалога</param>
    public void MessageBox(string text, string caption)
    {
      MessageBox(text, caption, MessageBoxButtons.OK, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
    }

    /// <summary>
    /// Вывод окна с сообщением.
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    /// <param name="caption">Заголовок блока диалога</param>
    /// <param name="buttons">Кнопки для выбора</param>
    /// <returns>Результат выполнения диалога</returns>
    public DialogResult MessageBox(string text, string caption, MessageBoxButtons buttons)
    {
      return MessageBox(text, caption, buttons, MessageBoxIcon.None, MessageBoxDefaultButton.Button1);
    }

    /// <summary>
    /// Вывод окна с сообщением.
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    /// <param name="caption">Заголовок блока диалога</param>
    /// <param name="buttons">Кнопки для выбора</param>
    /// <param name="icon">Значок</param>
    /// <returns>Результат выполнения диалога</returns>
    public DialogResult MessageBox(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
    {
      return MessageBox(text, caption, buttons, icon, MessageBoxDefaultButton.Button1);
    }

    /// <summary>
    /// Вывод окна с сообщением.
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    /// <param name="caption">Заголовок блока диалога</param>
    /// <param name="buttons">Кнопки для выбора</param>
    /// <param name="icon">Значок</param>
    /// <param name="defaultButton">Какая кнопка из <paramref name="buttons"/> должна быть активирована по умолчанию</param>
    /// <returns>Результат выполнения диалога</returns>
    public DialogResult MessageBox(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton)
    {
      NamedValues Args = new NamedValues();
      Args["Action"] = "MessageBox";

      //Args["Text"] = text;
      // 27.08.2019
      if (String.IsNullOrEmpty(text))
        Args["Lines"] = DataTools.EmptyStrings;
      else
        Args["Lines"] = text.Split(DataTools.NewLineSeparators, StringSplitOptions.None);

      Args["Caption"] = caption;
      Args["Buttons"] = buttons;
      Args["Icon"] = icon;
      Args["DefaultButton"] = defaultButton;

      NamedValues Res = _ExecProc.Execute(Args);
      return (DialogResult)(Res["DialogResult"]);
    }

    /// <summary>
    /// Вывод сообщения об ошибке
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    public void ErrorMessageBox(string text)
    {
      MessageBox(text, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    /// <summary>
    /// Вывод сообщения об ошибке
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    /// <param name="caption">Заголовок блока диалога</param>
    public void ErrorMessageBox(string text, string caption)
    {
      MessageBox(text, caption, MessageBoxButtons.OK, MessageBoxIcon.Error);
    }

    /// <summary>
    /// Вывод предупреждающего сообщения
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    public void WarningMessageBox(string text)
    {
      MessageBox(text, "Предупреждение", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }

    /// <summary>
    /// Вывод предупреждающего сообщения.
    /// <param name="caption">Заголовок блока диалога</param>
    /// </summary>
    /// <param name="text">Текст сообщения</param>
    public void WarningMessageBox(string text, string caption)
    {
      MessageBox(text, caption, MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }

    #endregion

    #region Чтение / запись значений

    /// <summary>
    /// Работа с интерфейсом IRIValueSaver
    /// Выполняет чтение или запись значений, если есть сохраняемые данные и Saver поддерживает секции конфигурации.
    /// Перехватывает все исключения
    /// </summary>
    /// <param name="saver">Объект, реализующий IRIValueSaver. Может быть null</param>
    /// <param name="item">Объект Dialog или StandardDialog</param>
    /// <param name="isWrite">true-запись значений, false - чтение</param>
    /// <returns>true, нсли чтение или запись выполнена</returns>
    public static bool PerformReadWriteValues(IRIValueSaver saver, RIItem item, bool isWrite)
    {
      if (saver == null)
        return false;
      if (item == null)
        return false;

      try
      {
        if (!saver.SupportsCfgType(RIValueCfgType.Default))
          return false; // Обработчик отказался сохранять данные

        bool NeedsDefaultCfg = item.SupportsCfgType(RIValueCfgType.Default);
        bool NeedsMachineSpecificCfg = item.SupportsCfgType(RIValueCfgType.MachineSpecific);

        if (NeedsDefaultCfg)
        {
          if (NeedsMachineSpecificCfg)
          {
            // Требуется обе секции
            if (saver.SupportsCfgType(RIValueCfgType.MachineSpecific))
            {
              // Обрабатываем секции отдельно

              if (!DoReadWriteValues(saver, item, isWrite, RIValueCfgType.Default, RIValueCfgType.Default))
                return false;
              if (!DoReadWriteValues(saver, item, isWrite, RIValueCfgType.MachineSpecific, RIValueCfgType.MachineSpecific))
                return false;
              return true;
            }
            else
            {
              // Обрабатываем обе секции вместе
              CfgPart cfg = saver.BeginReadWrite(RIValueCfgType.Default, isWrite);
              if (cfg == null)
                return false;
              try
              {
                try
                {
                  item.ReadWriteValues(cfg, RIValueCfgType.Default, isWrite);
                  item.ReadWriteValues(cfg, RIValueCfgType.MachineSpecific, isWrite);
                }
                finally
                {
                  saver.EndReadWrite(cfg, RIValueCfgType.Default, isWrite);
                }
              }
              catch
              {
                return false;
              }
              return true;
            }
          }
          else
          {
            // Требуется только основная секция
            return DoReadWriteValues(saver, item, isWrite, RIValueCfgType.Default, RIValueCfgType.Default);
          }
        }
        else
        {
          if (NeedsMachineSpecificCfg)
          {
            // Требуется только секция машинных данных
            if (saver.SupportsCfgType(RIValueCfgType.MachineSpecific))
              return DoReadWriteValues(saver, item, isWrite, RIValueCfgType.MachineSpecific, RIValueCfgType.MachineSpecific);
            else
              return DoReadWriteValues(saver, item, isWrite, RIValueCfgType.Default, RIValueCfgType.MachineSpecific);
          }
          else
            // Ничего не нужно
            return false;
        }
      }
      catch
      {
        return false;
      }
    }

    private static bool DoReadWriteValues(IRIValueSaver saver, RIItem item, bool isWrite, RIValueCfgType saverCfgType, RIValueCfgType itemCfgType)
    {
      CfgPart cfg = saver.BeginReadWrite(saverCfgType, isWrite);
      if (cfg == null)
        return false;
      try
      {
        try
        {
          item.ReadWriteValues(cfg, itemCfgType, isWrite);
        }
        finally
        {
          saver.EndReadWrite(cfg, saverCfgType, isWrite);
        }
        return true;
      }
      catch
      {
        return false;
      }
    }

    #endregion
  }

  /// <summary>
  /// Заглушка реализации IRemoteInterface.
  /// Может либо выбрасывать исключения при всех вызовах, либо "нажимать кнопку Отмена" для всех вызовов
  /// </summary>
  public class RemoteInterfaceStub : IRemoteInterface
  {
    #region Конструктор

    /// <summary>
    /// Создает заглушку.
    /// </summary>
    /// <param name="throwExceptions">Если true, то будут выбрасываться исключения, если false - будет отправляться результат "Отмена"</param>
    public RemoteInterfaceStub(bool throwExceptions)
    {
      _ThrowExceptions = throwExceptions;
    }

    /// <summary>
    /// Создает заглушку, выбрасывающую исключения с заданным сообщением
    /// </summary>
    /// <param name="exceptionMessage">Сообщение об ошибке</param>
    public RemoteInterfaceStub(string exceptionMessage)
    {
      _ThrowExceptions = true;
      _ExceptionMessage = exceptionMessage;
    }


    #endregion

    #region Свойства

    /// <summary>
    /// Если true, то будут выбрасываться исключения, если false - будет отправляться результат "Отмена"
    /// </summary>
    public bool ThrowExceptions { get { return _ThrowExceptions; } }
    private bool _ThrowExceptions;

    /// <summary>
    /// Текст сообщения в исключении.
    /// Если свойство не установлено, будет использовано сообщение по умолчанию.
    /// </summary>
    public string ExceptionMessage { get { return _ExceptionMessage; } set { _ExceptionMessage = value; } }
    private string _ExceptionMessage;

    #endregion

    #region IRemoteInterface Members

    private void DoThrowException()
    {
      if (ThrowExceptions)
      {
        if (String.IsNullOrEmpty(ExceptionMessage))
          throw new RemoteInterfaceNotsopportedException();
        else
          throw new RemoteInterfaceNotsopportedException(ExceptionMessage);
      }
    }

    DialogResult IRemoteInterface.ShowDialog(Dialog dialog)
    {
      DoThrowException();
      return DialogResult.Cancel;
    }

    DialogResult IRemoteInterface.ShowDialog(StandardDialog dialog)
    {
      DoThrowException();
      return DialogResult.Cancel;
    }

    void IRemoteInterface.MessageBox(string text)
    {
      DoThrowException();
    }

    void IRemoteInterface.MessageBox(string text, string caption)
    {
      DoThrowException();
    }

    DialogResult IRemoteInterface.MessageBox(string text, string caption, MessageBoxButtons buttons)
    {
      DoThrowException();
      return DialogResult.Cancel;
    }

    DialogResult IRemoteInterface.MessageBox(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon)
    {
      DoThrowException();
      return DialogResult.Cancel;
    }

    DialogResult IRemoteInterface.MessageBox(string text, string caption, MessageBoxButtons buttons, MessageBoxIcon icon, MessageBoxDefaultButton defaultButton)
    {
      DoThrowException();
      return DialogResult.Cancel;
    }

    void IRemoteInterface.ErrorMessageBox(string text)
    {
      DoThrowException();
    }

    void IRemoteInterface.ErrorMessageBox(string text, string caption)
    {
      DoThrowException();
    }

    void IRemoteInterface.WarningMessageBox(string text)
    {
      DoThrowException();
    }

    void IRemoteInterface.WarningMessageBox(string text, string caption)
    {
      DoThrowException();
    }

    #endregion
  }

  /// <summary>
  /// Исключение, выбрасываемое, если удаленный интерфейс не поддерживается
  /// </summary>
  [Serializable]
  public class RemoteInterfaceNotsopportedException : NotSupportedException
  {
    #region Конструкторы

    /// <summary>
    /// Создает новый объект исключения
    /// </summary>
    /// <param name="message">Сообщение</param>
    public RemoteInterfaceNotsopportedException(string message)
      : base(message)
    {
    }

    /// <summary>
    /// Создает новый объект исключения с заданным вложенным исключением
    /// </summary>
    /// <param name="message">Сообщение</param>
    /// <param name="innerException">Вложенное исключение</param>
    public RemoteInterfaceNotsopportedException(string message, Exception innerException)
      : base(message, innerException)
    {
    }

    /// <summary>
    /// Создает новый объект исключения со стандартным сообщением
    /// </summary>
    public RemoteInterfaceNotsopportedException()
      : base("Вызов интерфейса пользователя невозможен")
    {
    }

    /// <summary>
    /// Эта версия конструктора нужна для правильной десериализации
    /// </summary>
    protected RemoteInterfaceNotsopportedException(SerializationInfo info, StreamingContext context)
      : base(info, context)
    {
    }

    #endregion
  }

  /// <summary>
  /// Выполняемая процедура, используемая на вызываемой стороне.
  /// Объекты этого класса не должны использоваться в прикладном коде.
  /// Процедура является "многоразовой" (AutoDispose=false) и позволяет получать для нее ExecProcProxy многократно
  /// </summary>
  public class RIExecProc : ExecProc
  {
    #region Конструкторы

    /// <summary>
    /// Создает процедуру со ссылкой на интерфейс
    /// </summary>
    /// <param name="ui">Интерфейс удаленного доступа</param>
    public RIExecProc(IRemoteInterface ui)
    {
      if (ui == null)
        throw new ArgumentNullException("ui");

      base.AutoDispose = false;

      NamedValues ctx = new NamedValues();
      ctx.Add("UI", ui);
      base.SetContext(ctx);
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Доступ к удаленному интерфейсу
    /// </summary>
    public IRemoteInterface UI
    {
      get
      {
        return base.Context["UI"] as IRemoteInterface;
      }
    }

    /// <summary>
    /// Если установлено, то выполняется callback-вызов для проверки диалога
    /// </summary>
    public IExecProcCallBack CallBackProc { get { return _CallBackProc; } set { _CallBackProc = value; } }
    private IExecProcCallBack _CallBackProc;

    #endregion

    #region Переопределенные методы

    /// <summary>
    /// Выполнение процедуры
    /// </summary>
    /// <param name="args">Аргументы</param>
    /// <returns>Результат выполнения</returns>
    protected override NamedValues OnExecute(NamedValues args)
    {
      if (UI == null)
        throw new NullReferenceException("Не установлено контекстное свойство \"UI\"");
      NamedValues Res = ExecuteInterfaceCall(args, UI);
      if (Res == null)
        throw new InvalidOperationException("Неизвестное действие Action=\"" + args.GetString("Action") + "\"");
      return Res;
    }

    /// <summary>
    /// Этот метод можно использовать, если команды интерфейса передаются не через выделенную процедуру.
    /// Обрабатывается строковый аргумент "Action" для определения необходимого действия.
    /// Если действие не может быть обработано, метод возврашает null. Это значение следует обрабатывать,
    /// генерируя исключение
    /// </summary>
    /// <param name="args"></param>
    /// <param name="ui"></param>
    /// <returns></returns>
    private NamedValues ExecuteInterfaceCall(NamedValues args, IRemoteInterface ui)
    {
      NamedValues Res;
      switch (args.GetString("Action"))
      {
        case "ShowDialog":
          Dialog dlg1 = args["Dialog"] as Dialog;
          if (dlg1 == null)
            throw new NullReferenceException("Не задан аргумент \"Dialog\"");
          dlg1.SetFixed();

          Res = new NamedValues();
          Res["DialogResult"] = ui.ShowDialog(dlg1);
          TempCfg Cfg1 = new TempCfg();
          dlg1.WriteChanges(Cfg1);
          Res["Changes"] = Cfg1.AsXmlText;
          return Res;
        case "ShowStandardDialog":
          StandardDialog dlg2 = args["Dialog"] as StandardDialog;
          if (dlg2 == null)
            throw new NullReferenceException("Не задан аргумент \"Dialog\"");
          dlg2.SetFixed();

          Res = new NamedValues();
          Res["DialogResult"] = ui.ShowDialog(dlg2);
          TempCfg Cfg2 = new TempCfg();
          dlg2.WriteChanges(Cfg2);
          Res["Changes"] = Cfg2.AsXmlText;
          return Res;
        case "MessageBox":
          Res = new NamedValues();

          string[] a = (string[])args["Lines"]; // 27.08.2019
          string text;
          if (a.Length == 0)
            text = String.Empty;
          else
            text = String.Join(Environment.NewLine, a);
          Res["DialogResult"] = ui.MessageBox(/*args.GetString("Text")*/ text,
            args.GetString("Caption"),
            (MessageBoxButtons)(args["Buttons"]),
            (MessageBoxIcon)(args["Icon"]),
            (MessageBoxDefaultButton)(args["DefaultButton"]));
          return Res;
        default:
          return null; // не наше сообщение
      }
    }

    #endregion
  }

  /// <summary>
  /// Вспомогательные функции для удаленного пользовательского интерфейса
  /// </summary>
  public static class RITools
  {
    #region GetMessageBoxIcon

    /// <summary>
    /// Возвращает значок Error, Warning или Information для сообщения с заданным уровнем серьезности.
    /// Полученный значок может использоваться при вызове метода MessageBox().
    /// </summary>
    /// <param name="kind">Уровень серьезности</param>
    /// <returns>Идентификатор значка для MessageBox()</returns>
    public static MessageBoxIcon GetMessageBoxIcon(ErrorMessageKind kind)
    {
      switch (kind)
      {
        case ErrorMessageKind.Info: return MessageBoxIcon.Information;
        case ErrorMessageKind.Warning: return MessageBoxIcon.Warning;
        default: return MessageBoxIcon.Error;
      }
    }

    /// <summary>
    /// Возвращает значок Error, Warning или Information для сообщения с заданным уровнем серьезности.
    /// Для значения <paramref name="kind"/>=null возвращается None.
    /// Полученный значок может использоваться при вызове метода MessageBox().
    /// </summary>
    /// <param name="kind">Уровень серьезности</param>
    /// <returns>Идентификатор значка для MessageBox()</returns>
    public static MessageBoxIcon GetMessageBoxIcon(ErrorMessageKind? kind)
    {
      if (kind.HasValue)
        return GetMessageBoxIcon(kind.Value);
      else
        return MessageBoxIcon.None;
    }

    /// <summary>
    /// Возвращает значок Error, Warning или Information для списка сообщений.
    /// Если <paramref name="errors"/>=null или список не содержит сообщений, возвращается None.
    /// Полученный значок может использоваться при вызове метода MessageBox().
    /// </summary>
    /// <param name="errors">Список сообщений</param>
    /// <returns>Идентификатор значка для MessageBox()</returns>
    public static MessageBoxIcon GetMessageBoxIcon(ErrorMessageList errors)
    {
      return GetMessageBoxIcon(errors, false);
    }

    /// <summary>
    /// Возвращает значок Error, Warning или Information для списка сообщений.
    /// Если <paramref name="errors"/>=null или список не содержит сообщений, то возвращается None или Information,
    /// в зависимости от параметра <paramref name="informationIfEmpty"/>.
    /// Полученный значок может использоваться при вызове метода MessageBox().
    /// </summary>
    /// <param name="errors">Список сообщений</param>
    /// <param name="informationIfEmpty">Определяет значок, когда список <paramref name="errors"/>пустой.
    /// Если true, то возвращается Information, если false - то None</param>
    /// <returns>Идентификатор значка для MessageBox()</returns>
    public static MessageBoxIcon GetMessageBoxIcon(ErrorMessageList errors, bool informationIfEmpty)
    {
      if (errors == null)
        errors = ErrorMessageList.Empty;
      if (errors.Count == 0)
        return informationIfEmpty ? MessageBoxIcon.Information : MessageBoxIcon.None;
      else
        return GetMessageBoxIcon(errors.Severity);
    }

    #endregion
  }
}
