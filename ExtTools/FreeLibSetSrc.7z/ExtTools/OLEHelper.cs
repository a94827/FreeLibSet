﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Diagnostics;
using System.IO;
using AgeyevAV.IO;
using System.Globalization;

/*
 * The BSD License
 * 
 * Copyright (c) 2012-2015, Ageyev A.V.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace AgeyevAV.OLE
{
  /// <summary>
  /// Вспомогательный класс для работы с серверами OLE, например,
  /// Microsoft Excel.
  /// Реализует позднее связывание объектов
  /// </summary>
  public class OLEHelper : DisposableObject
  {
    #region Конструктор и Disposing

    /// <summary>
    /// Создает OLEHelper
    /// </summary>
    public OLEHelper()
    {
      Args1 = new object[1];
      Args2 = new object[2];
      Args3 = new object[3];
      Args4 = new object[4];
    }

    /// <summary>
    /// Освобождает ресурсы, вызывая Marshal.ReleaseComObject()
    /// </summary>
    /// <param name="disposing">true, если вызов из Dispose()</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing)
      {
        // Разрушение ресурсов
        if (_MainObj != null)
        {
          Marshal.ReleaseComObject(_MainObj);
          _MainObj = null;
        }
      }
      base.Dispose(disposing);
    }

    #endregion

    #region Основной объект (обычно - приложение)

    /// <summary>
    /// Основной объект (например, "Word.Application"). 
    /// Инициализируется вызовом CreateMainObj() или GetActivemainObj()
    /// </summary>
    public object MainObj { get { return _MainObj; } }
    private object _MainObj;

    /// <summary>
    /// Создание нового экземпляра объекта
    /// </summary>
    /// <param name="progId">Идентификатор приложения COM, например, "Word.Application". Используется при вызове метода Type.GetTypeFromProgID()</param>
    public void CreateMainObj(string progId)
    {
      CheckNotDisposed();
      if (_MainObj != null)
        throw new InvalidOperationException("Повторное создание объекта");

      Type MainObjType = Type.GetTypeFromProgID(progId);
      if (MainObjType == null)
        throw new ArgumentException("Неизвестный тип объекта ProgId=\"" + progId + "\"", "progId");
      _MainObj = Activator.CreateInstance(MainObjType);
    }

    /// <summary>
    /// Получение активного объекта и сохранение ссылки на него в MainObj
    /// </summary>
    /// <param name="progId">Идентификатор приложения COM, например, "Word.Application". Используется при вызове метода Marshal.GetActiveObject()</param>
    public void GetActiveMainObj(string progId)
    {
      CheckNotDisposed();
      if (_MainObj != null)
        throw new InvalidOperationException("Повторная активация объекта");

      _MainObj = Marshal.GetActiveObject(progId);
    }

    #endregion

    #region Текущая культура

    /// <summary>
    /// Культура, используемая при вызове свойств и методов.
    /// По умолчанию - null
    /// </summary>
    public CultureInfo CultureInfo
    {
      get { return _CultureInfo; }
      set { _CultureInfo = value; }
    }
    private CultureInfo _CultureInfo;

    /// <summary>
    /// Идентификатор локали.
    /// Возвращает CultureInfo.LCID.
    /// Для приложений Microsoft Office свойство должно быть установлено в 0x0409
    /// </summary>
    public int LCID
    {
      get
      {
        if (_CultureInfo == null)
          return CultureInfo.CurrentCulture.LCID;
        else
          return _CultureInfo.LCID;
      }
      set
      {
        _CultureInfo = CultureInfo.GetCultureInfo(value);
        if (_CultureInfo == null)
          throw new ArgumentException("Неизвестный LCID=" + value.ToString());
      }
    }

    #endregion

    #region Установка свойств

    /// <summary>
    /// Получить свойство <paramref name="name"/> объекта <paramref name="obj"/>
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя свойства</param>
    /// <returns>Значение свойства</returns>
    public object GetProp(object obj, string name)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      return obj.GetType().InvokeMember(name, BindingFlags.GetProperty, null, obj, null, CultureInfo);
    }

    /// <summary>
    /// Установить свойство <paramref name="name"/> объекта <paramref name="obj"/>
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя свойства</param>
    /// <param name="value">Значение свойства</param>
    public void SetProp(object obj, string name, object value)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      Args1[0] = value;
      obj.GetType().InvokeMember(name, BindingFlags.SetProperty, null, obj, Args1, CultureInfo);
    }

    /// <summary>
    /// Получить значение индексированного свойства <paramref name="name"/> объекта <paramref name="obj"/>
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя свойства</param>
    /// <param name="index">Индекс</param>
    /// <returns>Значение свойства</returns>
    public object GetIndexProp(object obj, string name, object index)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      Args1[0] = index;
      return obj.GetType().InvokeMember(name, BindingFlags.GetProperty, null, obj, Args1, CultureInfo);
    }

    /// <summary>
    /// Получить значение индексированного свойства <paramref name="name"/> объекта <paramref name="obj"/>
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя свойства</param>
    /// <param name="index1">Первый индекс</param>
    /// <param name="index2">Второй индекс</param>
    /// <returns>Значение свойства</returns>
    public object GetIndexProp(object obj, string name, object index1, object index2)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      Args2[0] = index1;
      Args2[1] = index2;
      return obj.GetType().InvokeMember(name, BindingFlags.GetProperty, null, obj, Args2, CultureInfo);
    }

    #endregion

    #region Вызов методов

    /// <summary>
    /// Вызвать метод с именем <paramref name="name"/> для объекта <paramref name="obj"/> без аргумента
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя метода</param>
    /// <returns>Значение, возвращаемое метода</returns>
    public object Call(object obj, string name)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      return obj.GetType().InvokeMember(name, BindingFlags.InvokeMethod, null, obj, null, CultureInfo);
    }

    /// <summary>
    /// Вызвать метод с именем <paramref name="name"/> для объекта <paramref name="obj"/> с одним аргументом
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя метода</param>
    /// <param name="arg1">Аргумент</param>
    /// <returns>Значение, возвращаемое метода</returns>
    public object Call(object obj, string name, object arg1)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      Args1[0] = arg1;
      return obj.GetType().InvokeMember(name, BindingFlags.InvokeMethod, null, obj, Args1, CultureInfo);
    }

    /// <summary>
    /// Вызвать метод с именем <paramref name="name"/> для объекта <paramref name="obj"/> с двумя аргументами
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя метода</param>
    /// <param name="arg1">Первый аргумент</param>
    /// <param name="arg2">Второй аргумент</param>
    /// <returns>Значение, возвращаемое метода</returns>
    public object Call(object obj, string name, object arg1, object arg2)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      Args2[0] = arg1;
      Args2[1] = arg2;
      return obj.GetType().InvokeMember(name, BindingFlags.InvokeMethod, null, obj, Args2, CultureInfo);
    }

    /// <summary>
    /// Вызвать метод с именем <paramref name="name"/> для объекта <paramref name="obj"/> с тремя аргументами
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя метода</param>
    /// <param name="arg1">Первый аргумент</param>
    /// <param name="arg2">Второй аргумент</param>
    /// <param name="arg3">Третий аргумент</param>
    /// <returns>Значение, возвращаемое метода</returns>
    public object Call(object obj, string name, object arg1, object arg2, object arg3)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      Args3[0] = arg1;
      Args3[1] = arg2;
      Args3[2] = arg3;
      return obj.GetType().InvokeMember(name, BindingFlags.InvokeMethod, null, obj, Args3, CultureInfo);
    }

    /// <summary>
    /// Вызвать метод с именем <paramref name="name"/> для объекта <paramref name="obj"/> с тремя аргументами
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя метода</param>
    /// <param name="arg1">Первый аргумент</param>
    /// <param name="arg2">Второй аргумент</param>
    /// <param name="arg3">Третий аргумент</param>
    /// <param name="arg4">Четвертый аргумент</param>
    /// <returns>Значение, возвращаемое метода</returns>
    public object Call(object obj, string name, object arg1, object arg2, object arg3, object arg4)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      Args4[0] = arg1;
      Args4[1] = arg2;
      Args4[2] = arg3;
      Args4[3] = arg4;
      return obj.GetType().InvokeMember(name, BindingFlags.InvokeMethod, null, obj, Args4, CultureInfo);
    }

    /// <summary>
    /// Вызвать метод с именем <paramref name="name"/> для объекта <paramref name="obj"/> с произвольным количеством аргументов
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя метода</param>
    /// <param name="args">Аргументы</param>
    /// <returns>Значение, возвращаемое метода</returns>
    public object CallWithArgs(object obj, string name, object[] args)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      return obj.GetType().InvokeMember(name, BindingFlags.InvokeMethod, null, obj, args, CultureInfo);
    }
    #endregion

    #region Установка свойств для LCID 0409

    private static System.Globalization.CultureInfo CultureInfo0409 =
      System.Globalization.CultureInfo.GetCultureInfo(0x0409);

    /// <summary>
    /// Чтение свойства в международном формате (например, NumberFormat в Excel)
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя свойства</param>
    /// <returns>Значение свойства</returns>
    public object GetProp0409(object obj, string name)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      return obj.GetType().InvokeMember(name, BindingFlags.GetProperty, null, obj, null, null, CultureInfo0409, null);
    }

    /// <summary>
    /// Установка свойства в международном формате (например, NumberFormat в Excel)
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="name">Имя свойства</param>
    /// <param name="value">Значение свойства</param>
    public void SetProp0409(object obj, string name, object value)
    {
#if DEBUG
      CheckNotDisposed();
#endif

      Args1[0] = value;
      obj.GetType().InvokeMember(name, BindingFlags.SetProperty, null, obj, Args1, null, CultureInfo0409, null);
    }

    #endregion

    #region Внутренняя реализация

    private object[] Args1;
    private object[] Args2;
    private object[] Args3;
    private object[] Args4;

    #endregion

    #region Статические методы

    /*
     * Какое безобразие!
     * Неужели нет готовых функций?
     */

    /// <summary>
    /// Получить идентификатор класс для идентификатора ProgID
    /// (я не нашел, где есть такая стандартная функция)
    /// </summary>
    /// <param name="progID">Идентификатор программы, например, "Excel.Application"</param>
    /// <param name="clsID">Сюда записывается GUID</param>
    /// <returns>true, если идентификатор получен</returns>
    public static bool GetClsIDForProgID(string progID, out Guid clsID)
    {
      clsID = new Guid();
      if (String.IsNullOrEmpty(progID))
        return false;
      try
      {
        string KeyName = "HKEY_CLASSES_ROOT\\" + progID + "\\CLSID";
        string s = (string)(Microsoft.Win32.Registry.GetValue(KeyName, String.Empty, String.Empty));
        if (String.IsNullOrEmpty(s))
          return false;
        clsID = new Guid(s);
      }
      catch
      {
        return false;
      }
      return true;
    }

    /// <summary>
    /// Получить путь к серверу (узел LocalServer32)
    /// </summary>
    /// <param name="clsID">GUID, поиск которого осуществляется в HKEY_CLASSES_ROOT/CLSID</param>
    /// <returns>Путь из реестра. Убираются ключи, например "/Automation", если они заданы в реестре</returns>
    public static AbsPath GetLocalServer32Path(Guid clsID)
    {
      string s;
      try
      {
        string KeyName = "HKEY_CLASSES_ROOT\\CLSID\\" + clsID.ToString("B") + "\\LocalServer32";
        s = (string)(Microsoft.Win32.Registry.GetValue(KeyName, String.Empty, String.Empty));
        if (String.IsNullOrEmpty(s))
        {
          // 11.01.2013
          // Для 64-битной версии Windows и 32-разрядной версии Office
          KeyName = "HKEY_CLASSES_ROOT\\Wow6432Node\\CLSID\\" + clsID.ToString("B") + "\\LocalServer32";
          s = (string)(Microsoft.Win32.Registry.GetValue(KeyName, String.Empty, String.Empty));
          if (String.IsNullOrEmpty(s))
            return AbsPath.Empty;
        }
      }
      catch
      {
        return AbsPath.Empty;
      }

      int p = s.IndexOf('/'); // Может быть ключ "/Automation"
      if (p >= 0)
        s = s.Substring(0, p).Trim();
      return new AbsPath(s);
    }

    /// <summary>
    /// Возвращает путь к серверу OLE.
    /// Если сервер не зарегистрирован, возвращает пустой путь AbsPath.Empty.
    /// </summary>
    /// <param name="progID">Идентификатор ProgId, например, "Word.Application"</param>
    /// <returns>Путь к серверу</returns>
    public static AbsPath GetLocalServer32Path(string progID)
    {
      Guid ClsID;
      if (!GetClsIDForProgID(progID, out ClsID))
        return AbsPath.Empty;
      return GetLocalServer32Path(ClsID);
    }

    /// <summary>
    /// Возвращает версию сервера OLE. Версия извлекается из ресурсов EXE/DLL-файла
    /// Если сервер не зарегистрирован, возвращает null.
    /// </summary>
    /// <param name="progID">Идентификатор ProgId, например, "Word.Application"</param>
    /// <returns>Версия</returns>
    public static Version GetLocalServer32Version(string progID)
    {
      AbsPath Path = GetLocalServer32Path(progID);
      return FileTools.GetFileVersion(Path.Path);
    }

    #endregion
  }

  /// <summary>
  /// Ссылка на интерфейс + ссылка на Helper
  /// </summary>
  public struct ObjBase
  {
    #region Конструктор

    /// <summary>
    /// Инициализация структуры
    /// </summary>
    /// <param name="obj">Объект</param>
    /// <param name="helper">OLEHelper</param>
    public ObjBase(Object obj, OLEHelper helper)
    {
#if DEBUG
      if (obj == null)
        throw new ArgumentNullException("obj");
      Type t = obj.GetType();
      if (!t.IsCOMObject)
        throw new ArgumentException("Не COM-объект", "obj");
      if (helper == null)
        throw new ArgumentNullException("helper");
#endif
      _Obj = obj;
      _Helper = helper;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Объект OLE
    /// </summary>
    public object Obj { get { return _Obj; } }
    private object _Obj;

    /// <summary>
    /// OLEHelper
    /// </summary>
    public OLEHelper Helper { get { return _Helper; } }
    private OLEHelper _Helper;

    /// <summary>
    /// Возвращает true, если структура не была инициализирована
    /// </summary>
    public bool IsEmpty { get { return _Obj == null; } }

    #endregion
  }
}
