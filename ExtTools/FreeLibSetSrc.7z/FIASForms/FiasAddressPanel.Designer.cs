namespace AgeyevAV.ExtForms.FIAS
{
#pragma warning disable 1591

  partial class FiasAddressPanel
  {
    /// <summary> 
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Component Designer generated code

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.MainTLP = new System.Windows.Forms.TableLayoutPanel();
      this.lblHouse = new System.Windows.Forms.Label();
      this.lblStreet = new System.Windows.Forms.Label();
      this.lblPS = new System.Windows.Forms.Label();
      this.lblVillage = new System.Windows.Forms.Label();
      this.lblCity = new System.Windows.Forms.Label();
      this.lblDistrict = new System.Windows.Forms.Label();
      this.btnHouseSel = new System.Windows.Forms.Button();
      this.btnStreetSel = new System.Windows.Forms.Button();
      this.btnPSSel = new System.Windows.Forms.Button();
      this.btnVillageSel = new System.Windows.Forms.Button();
      this.btnCitySel = new System.Windows.Forms.Button();
      this.btnDistrictSel = new System.Windows.Forms.Button();
      this.btnRegionSel = new System.Windows.Forms.Button();
      this.btnFlatSel = new System.Windows.Forms.Button();
      this.edRegionAOType = new System.Windows.Forms.TextBox();
      this.edRegionName = new System.Windows.Forms.TextBox();
      this.edDistrictName = new System.Windows.Forms.TextBox();
      this.edDistrictAOType = new System.Windows.Forms.TextBox();
      this.edCityAOType = new System.Windows.Forms.TextBox();
      this.edCityName = new System.Windows.Forms.TextBox();
      this.edVillageAOType = new System.Windows.Forms.TextBox();
      this.edVillageName = new System.Windows.Forms.TextBox();
      this.edPlanStrAOType = new System.Windows.Forms.TextBox();
      this.edPlanStrName = new System.Windows.Forms.TextBox();
      this.edStreetName = new System.Windows.Forms.TextBox();
      this.edStreetAOType = new System.Windows.Forms.TextBox();
      this.edHouseAOType = new System.Windows.Forms.TextBox();
      this.edHouseName = new System.Windows.Forms.TextBox();
      this.edBuildingName = new System.Windows.Forms.TextBox();
      this.edBuildingAOType = new System.Windows.Forms.TextBox();
      this.edStrAOType = new System.Windows.Forms.TextBox();
      this.edStrName = new System.Windows.Forms.TextBox();
      this.edFlatAOType = new System.Windows.Forms.TextBox();
      this.edFlatName = new System.Windows.Forms.TextBox();
      this.edRoomAOType = new System.Windows.Forms.TextBox();
      this.edRoomName = new System.Windows.Forms.TextBox();
      this.btnRegionClear = new System.Windows.Forms.Button();
      this.btnDistrictClear = new System.Windows.Forms.Button();
      this.btnCityClear = new System.Windows.Forms.Button();
      this.btnVillageClear = new System.Windows.Forms.Button();
      this.btnPSClear = new System.Windows.Forms.Button();
      this.btnStreetClear = new System.Windows.Forms.Button();
      this.btnHouseClear = new System.Windows.Forms.Button();
      this.btnFlatClear = new System.Windows.Forms.Button();
      this.btnErrors = new System.Windows.Forms.Button();
      this.btnMore = new System.Windows.Forms.Button();
      this.edTextView = new System.Windows.Forms.TextBox();
      this.lblRegion = new System.Windows.Forms.Label();
      this.lblFlat = new System.Windows.Forms.Label();
      this.cbManualPostalCode = new System.Windows.Forms.CheckBox();
      this.edPostalCode = new System.Windows.Forms.MaskedTextBox();
      this.button7 = new System.Windows.Forms.Button();
      this.button8 = new System.Windows.Forms.Button();
      this.button9 = new System.Windows.Forms.Button();
      this.MainTLP.SuspendLayout();
      this.SuspendLayout();
      // 
      // MainTLP
      // 
      this.MainTLP.AutoSize = true;
      this.MainTLP.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
      this.MainTLP.ColumnCount = 5;
      this.MainTLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 32F));
      this.MainTLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 60F));
      this.MainTLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40F));
      this.MainTLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 43F));
      this.MainTLP.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 45F));
      this.MainTLP.Controls.Add(this.lblHouse, 0, 6);
      this.MainTLP.Controls.Add(this.lblStreet, 0, 5);
      this.MainTLP.Controls.Add(this.lblPS, 0, 4);
      this.MainTLP.Controls.Add(this.lblVillage, 0, 3);
      this.MainTLP.Controls.Add(this.lblCity, 0, 2);
      this.MainTLP.Controls.Add(this.lblDistrict, 0, 1);
      this.MainTLP.Controls.Add(this.btnHouseSel, 3, 6);
      this.MainTLP.Controls.Add(this.btnStreetSel, 3, 5);
      this.MainTLP.Controls.Add(this.btnPSSel, 3, 4);
      this.MainTLP.Controls.Add(this.btnVillageSel, 3, 3);
      this.MainTLP.Controls.Add(this.btnCitySel, 3, 2);
      this.MainTLP.Controls.Add(this.btnDistrictSel, 3, 1);
      this.MainTLP.Controls.Add(this.btnRegionSel, 3, 0);
      this.MainTLP.Controls.Add(this.btnFlatSel, 3, 9);
      this.MainTLP.Controls.Add(this.edRegionAOType, 2, 0);
      this.MainTLP.Controls.Add(this.edRegionName, 1, 0);
      this.MainTLP.Controls.Add(this.edDistrictName, 1, 1);
      this.MainTLP.Controls.Add(this.edDistrictAOType, 2, 1);
      this.MainTLP.Controls.Add(this.edCityAOType, 2, 2);
      this.MainTLP.Controls.Add(this.edCityName, 1, 2);
      this.MainTLP.Controls.Add(this.edVillageAOType, 2, 3);
      this.MainTLP.Controls.Add(this.edVillageName, 1, 3);
      this.MainTLP.Controls.Add(this.edPlanStrAOType, 2, 4);
      this.MainTLP.Controls.Add(this.edPlanStrName, 1, 4);
      this.MainTLP.Controls.Add(this.edStreetName, 1, 5);
      this.MainTLP.Controls.Add(this.edStreetAOType, 2, 5);
      this.MainTLP.Controls.Add(this.edHouseAOType, 2, 6);
      this.MainTLP.Controls.Add(this.edHouseName, 1, 6);
      this.MainTLP.Controls.Add(this.edBuildingName, 1, 7);
      this.MainTLP.Controls.Add(this.edBuildingAOType, 2, 7);
      this.MainTLP.Controls.Add(this.edStrAOType, 2, 8);
      this.MainTLP.Controls.Add(this.edStrName, 1, 8);
      this.MainTLP.Controls.Add(this.edFlatAOType, 2, 9);
      this.MainTLP.Controls.Add(this.edFlatName, 1, 9);
      this.MainTLP.Controls.Add(this.edRoomAOType, 2, 10);
      this.MainTLP.Controls.Add(this.edRoomName, 1, 10);
      this.MainTLP.Controls.Add(this.btnRegionClear, 4, 0);
      this.MainTLP.Controls.Add(this.btnDistrictClear, 4, 1);
      this.MainTLP.Controls.Add(this.btnCityClear, 4, 2);
      this.MainTLP.Controls.Add(this.btnVillageClear, 4, 3);
      this.MainTLP.Controls.Add(this.btnPSClear, 4, 4);
      this.MainTLP.Controls.Add(this.btnStreetClear, 4, 5);
      this.MainTLP.Controls.Add(this.btnHouseClear, 4, 6);
      this.MainTLP.Controls.Add(this.btnFlatClear, 4, 9);
      this.MainTLP.Controls.Add(this.btnErrors, 3, 12);
      this.MainTLP.Controls.Add(this.btnMore, 4, 12);
      this.MainTLP.Controls.Add(this.edTextView, 1, 12);
      this.MainTLP.Controls.Add(this.lblRegion, 0, 0);
      this.MainTLP.Controls.Add(this.lblFlat, 0, 9);
      this.MainTLP.Controls.Add(this.cbManualPostalCode, 1, 11);
      this.MainTLP.Controls.Add(this.edPostalCode, 2, 11);
      this.MainTLP.Dock = System.Windows.Forms.DockStyle.Top;
      this.MainTLP.Location = new System.Drawing.Point(0, 0);
      this.MainTLP.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.MainTLP.Name = "MainTLP";
      this.MainTLP.RowCount = 13;
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 28F));
      this.MainTLP.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 52F));
      this.MainTLP.Size = new System.Drawing.Size(667, 443);
      this.MainTLP.TabIndex = 0;
      // 
      // lblHouse
      // 
      this.lblHouse.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.lblHouse.Location = new System.Drawing.Point(4, 198);
      this.lblHouse.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblHouse.Name = "lblHouse";
      this.lblHouse.Size = new System.Drawing.Size(24, 33);
      this.lblHouse.TabIndex = 30;
      this.lblHouse.Text = "&7";
      this.lblHouse.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblStreet
      // 
      this.lblStreet.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.lblStreet.Location = new System.Drawing.Point(4, 165);
      this.lblStreet.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblStreet.Name = "lblStreet";
      this.lblStreet.Size = new System.Drawing.Size(24, 33);
      this.lblStreet.TabIndex = 25;
      this.lblStreet.Text = "&6";
      this.lblStreet.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblPS
      // 
      this.lblPS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.lblPS.Location = new System.Drawing.Point(4, 132);
      this.lblPS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblPS.Name = "lblPS";
      this.lblPS.Size = new System.Drawing.Size(24, 33);
      this.lblPS.TabIndex = 20;
      this.lblPS.Text = "&5";
      this.lblPS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblVillage
      // 
      this.lblVillage.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.lblVillage.Location = new System.Drawing.Point(4, 99);
      this.lblVillage.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblVillage.Name = "lblVillage";
      this.lblVillage.Size = new System.Drawing.Size(24, 33);
      this.lblVillage.TabIndex = 15;
      this.lblVillage.Text = "&4";
      this.lblVillage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblCity
      // 
      this.lblCity.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.lblCity.Location = new System.Drawing.Point(4, 66);
      this.lblCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblCity.Name = "lblCity";
      this.lblCity.Size = new System.Drawing.Size(24, 33);
      this.lblCity.TabIndex = 10;
      this.lblCity.Text = "&3";
      this.lblCity.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblDistrict
      // 
      this.lblDistrict.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.lblDistrict.Location = new System.Drawing.Point(4, 33);
      this.lblDistrict.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblDistrict.Name = "lblDistrict";
      this.lblDistrict.Size = new System.Drawing.Size(24, 33);
      this.lblDistrict.TabIndex = 5;
      this.lblDistrict.Text = "&2";
      this.lblDistrict.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // btnHouseSel
      // 
      this.btnHouseSel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnHouseSel.Location = new System.Drawing.Point(582, 202);
      this.btnHouseSel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnHouseSel.Name = "btnHouseSel";
      this.btnHouseSel.Size = new System.Drawing.Size(35, 25);
      this.btnHouseSel.TabIndex = 33;
      this.btnHouseSel.UseVisualStyleBackColor = true;
      // 
      // btnStreetSel
      // 
      this.btnStreetSel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnStreetSel.Location = new System.Drawing.Point(582, 169);
      this.btnStreetSel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnStreetSel.Name = "btnStreetSel";
      this.btnStreetSel.Size = new System.Drawing.Size(35, 25);
      this.btnStreetSel.TabIndex = 28;
      this.btnStreetSel.UseVisualStyleBackColor = true;
      // 
      // btnPSSel
      // 
      this.btnPSSel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnPSSel.Location = new System.Drawing.Point(582, 136);
      this.btnPSSel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnPSSel.Name = "btnPSSel";
      this.btnPSSel.Size = new System.Drawing.Size(35, 25);
      this.btnPSSel.TabIndex = 23;
      this.btnPSSel.UseVisualStyleBackColor = true;
      // 
      // btnVillageSel
      // 
      this.btnVillageSel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnVillageSel.Location = new System.Drawing.Point(582, 103);
      this.btnVillageSel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnVillageSel.Name = "btnVillageSel";
      this.btnVillageSel.Size = new System.Drawing.Size(35, 25);
      this.btnVillageSel.TabIndex = 18;
      this.btnVillageSel.UseVisualStyleBackColor = true;
      // 
      // btnCitySel
      // 
      this.btnCitySel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnCitySel.Location = new System.Drawing.Point(582, 70);
      this.btnCitySel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnCitySel.Name = "btnCitySel";
      this.btnCitySel.Size = new System.Drawing.Size(35, 25);
      this.btnCitySel.TabIndex = 13;
      this.btnCitySel.UseVisualStyleBackColor = true;
      // 
      // btnDistrictSel
      // 
      this.btnDistrictSel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnDistrictSel.Location = new System.Drawing.Point(582, 37);
      this.btnDistrictSel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnDistrictSel.Name = "btnDistrictSel";
      this.btnDistrictSel.Size = new System.Drawing.Size(35, 25);
      this.btnDistrictSel.TabIndex = 8;
      this.btnDistrictSel.UseVisualStyleBackColor = true;
      // 
      // btnRegionSel
      // 
      this.btnRegionSel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnRegionSel.Location = new System.Drawing.Point(582, 4);
      this.btnRegionSel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnRegionSel.Name = "btnRegionSel";
      this.btnRegionSel.Size = new System.Drawing.Size(35, 25);
      this.btnRegionSel.TabIndex = 3;
      this.btnRegionSel.UseVisualStyleBackColor = true;
      // 
      // btnFlatSel
      // 
      this.btnFlatSel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnFlatSel.Location = new System.Drawing.Point(582, 301);
      this.btnFlatSel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnFlatSel.Name = "btnFlatSel";
      this.btnFlatSel.Size = new System.Drawing.Size(35, 25);
      this.btnFlatSel.TabIndex = 42;
      this.btnFlatSel.UseVisualStyleBackColor = true;
      // 
      // edRegionAOType
      // 
      this.edRegionAOType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edRegionAOType.Location = new System.Drawing.Point(364, 4);
      this.edRegionAOType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edRegionAOType.Name = "edRegionAOType";
      this.edRegionAOType.Size = new System.Drawing.Size(210, 22);
      this.edRegionAOType.TabIndex = 2;
      this.edRegionAOType.Text = "? ������";
      // 
      // edRegionName
      // 
      this.edRegionName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edRegionName.Location = new System.Drawing.Point(36, 4);
      this.edRegionName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edRegionName.Name = "edRegionName";
      this.edRegionName.Size = new System.Drawing.Size(320, 22);
      this.edRegionName.TabIndex = 1;
      // 
      // edDistrictName
      // 
      this.edDistrictName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edDistrictName.Location = new System.Drawing.Point(36, 37);
      this.edDistrictName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edDistrictName.Name = "edDistrictName";
      this.edDistrictName.Size = new System.Drawing.Size(320, 22);
      this.edDistrictName.TabIndex = 6;
      // 
      // edDistrictAOType
      // 
      this.edDistrictAOType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edDistrictAOType.Location = new System.Drawing.Point(364, 37);
      this.edDistrictAOType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edDistrictAOType.Name = "edDistrictAOType";
      this.edDistrictAOType.Size = new System.Drawing.Size(210, 22);
      this.edDistrictAOType.TabIndex = 7;
      this.edDistrictAOType.Text = "? �����";
      // 
      // edCityAOType
      // 
      this.edCityAOType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edCityAOType.Location = new System.Drawing.Point(364, 70);
      this.edCityAOType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edCityAOType.Name = "edCityAOType";
      this.edCityAOType.Size = new System.Drawing.Size(210, 22);
      this.edCityAOType.TabIndex = 12;
      this.edCityAOType.Text = "? �����";
      // 
      // edCityName
      // 
      this.edCityName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edCityName.Location = new System.Drawing.Point(36, 70);
      this.edCityName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edCityName.Name = "edCityName";
      this.edCityName.Size = new System.Drawing.Size(320, 22);
      this.edCityName.TabIndex = 11;
      // 
      // edVillageAOType
      // 
      this.edVillageAOType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edVillageAOType.Location = new System.Drawing.Point(364, 103);
      this.edVillageAOType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edVillageAOType.Name = "edVillageAOType";
      this.edVillageAOType.Size = new System.Drawing.Size(210, 22);
      this.edVillageAOType.TabIndex = 17;
      this.edVillageAOType.Text = "? ���. �����";
      // 
      // edVillageName
      // 
      this.edVillageName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edVillageName.Location = new System.Drawing.Point(36, 103);
      this.edVillageName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edVillageName.Name = "edVillageName";
      this.edVillageName.Size = new System.Drawing.Size(320, 22);
      this.edVillageName.TabIndex = 16;
      // 
      // edPlanStrAOType
      // 
      this.edPlanStrAOType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edPlanStrAOType.Location = new System.Drawing.Point(364, 136);
      this.edPlanStrAOType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edPlanStrAOType.Name = "edPlanStrAOType";
      this.edPlanStrAOType.Size = new System.Drawing.Size(210, 22);
      this.edPlanStrAOType.TabIndex = 22;
      this.edPlanStrAOType.Text = "? ��-� ��";
      // 
      // edPlanStrName
      // 
      this.edPlanStrName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edPlanStrName.Location = new System.Drawing.Point(36, 136);
      this.edPlanStrName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edPlanStrName.Name = "edPlanStrName";
      this.edPlanStrName.Size = new System.Drawing.Size(320, 22);
      this.edPlanStrName.TabIndex = 21;
      // 
      // edStreetName
      // 
      this.edStreetName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edStreetName.Location = new System.Drawing.Point(36, 169);
      this.edStreetName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edStreetName.Name = "edStreetName";
      this.edStreetName.Size = new System.Drawing.Size(320, 22);
      this.edStreetName.TabIndex = 26;
      // 
      // edStreetAOType
      // 
      this.edStreetAOType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edStreetAOType.Location = new System.Drawing.Point(364, 169);
      this.edStreetAOType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edStreetAOType.Name = "edStreetAOType";
      this.edStreetAOType.Size = new System.Drawing.Size(210, 22);
      this.edStreetAOType.TabIndex = 27;
      this.edStreetAOType.Text = "? �����";
      // 
      // edHouseAOType
      // 
      this.edHouseAOType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edHouseAOType.Location = new System.Drawing.Point(364, 202);
      this.edHouseAOType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edHouseAOType.Name = "edHouseAOType";
      this.edHouseAOType.Size = new System.Drawing.Size(210, 22);
      this.edHouseAOType.TabIndex = 32;
      this.edHouseAOType.Text = "? ���";
      // 
      // edHouseName
      // 
      this.edHouseName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edHouseName.Location = new System.Drawing.Point(36, 202);
      this.edHouseName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edHouseName.Name = "edHouseName";
      this.edHouseName.Size = new System.Drawing.Size(320, 22);
      this.edHouseName.TabIndex = 31;
      // 
      // edBuildingName
      // 
      this.edBuildingName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edBuildingName.Location = new System.Drawing.Point(36, 235);
      this.edBuildingName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edBuildingName.Name = "edBuildingName";
      this.edBuildingName.Size = new System.Drawing.Size(320, 22);
      this.edBuildingName.TabIndex = 35;
      // 
      // edBuildingAOType
      // 
      this.edBuildingAOType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edBuildingAOType.Location = new System.Drawing.Point(364, 235);
      this.edBuildingAOType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edBuildingAOType.Name = "edBuildingAOType";
      this.edBuildingAOType.Size = new System.Drawing.Size(210, 22);
      this.edBuildingAOType.TabIndex = 36;
      this.edBuildingAOType.Text = "? ������";
      // 
      // edStrAOType
      // 
      this.edStrAOType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edStrAOType.Location = new System.Drawing.Point(364, 268);
      this.edStrAOType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edStrAOType.Name = "edStrAOType";
      this.edStrAOType.Size = new System.Drawing.Size(210, 22);
      this.edStrAOType.TabIndex = 38;
      this.edStrAOType.Text = "? ��������";
      // 
      // edStrName
      // 
      this.edStrName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edStrName.Location = new System.Drawing.Point(36, 268);
      this.edStrName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edStrName.Name = "edStrName";
      this.edStrName.Size = new System.Drawing.Size(320, 22);
      this.edStrName.TabIndex = 37;
      // 
      // edFlatAOType
      // 
      this.edFlatAOType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edFlatAOType.Location = new System.Drawing.Point(364, 301);
      this.edFlatAOType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edFlatAOType.Name = "edFlatAOType";
      this.edFlatAOType.Size = new System.Drawing.Size(210, 22);
      this.edFlatAOType.TabIndex = 41;
      this.edFlatAOType.Text = "? ��������";
      // 
      // edFlatName
      // 
      this.edFlatName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edFlatName.Location = new System.Drawing.Point(36, 301);
      this.edFlatName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edFlatName.Name = "edFlatName";
      this.edFlatName.Size = new System.Drawing.Size(320, 22);
      this.edFlatName.TabIndex = 40;
      // 
      // edRoomAOType
      // 
      this.edRoomAOType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edRoomAOType.Location = new System.Drawing.Point(364, 334);
      this.edRoomAOType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edRoomAOType.Name = "edRoomAOType";
      this.edRoomAOType.Size = new System.Drawing.Size(210, 22);
      this.edRoomAOType.TabIndex = 45;
      this.edRoomAOType.Text = "? �������";
      // 
      // edRoomName
      // 
      this.edRoomName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edRoomName.Location = new System.Drawing.Point(36, 334);
      this.edRoomName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edRoomName.Name = "edRoomName";
      this.edRoomName.Size = new System.Drawing.Size(320, 22);
      this.edRoomName.TabIndex = 44;
      // 
      // btnRegionClear
      // 
      this.btnRegionClear.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnRegionClear.Location = new System.Drawing.Point(625, 4);
      this.btnRegionClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnRegionClear.Name = "btnRegionClear";
      this.btnRegionClear.Size = new System.Drawing.Size(38, 25);
      this.btnRegionClear.TabIndex = 4;
      this.btnRegionClear.UseVisualStyleBackColor = true;
      // 
      // btnDistrictClear
      // 
      this.btnDistrictClear.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnDistrictClear.Location = new System.Drawing.Point(625, 37);
      this.btnDistrictClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnDistrictClear.Name = "btnDistrictClear";
      this.btnDistrictClear.Size = new System.Drawing.Size(38, 25);
      this.btnDistrictClear.TabIndex = 9;
      this.btnDistrictClear.UseVisualStyleBackColor = true;
      // 
      // btnCityClear
      // 
      this.btnCityClear.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnCityClear.Location = new System.Drawing.Point(625, 70);
      this.btnCityClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnCityClear.Name = "btnCityClear";
      this.btnCityClear.Size = new System.Drawing.Size(38, 25);
      this.btnCityClear.TabIndex = 14;
      this.btnCityClear.UseVisualStyleBackColor = true;
      // 
      // btnVillageClear
      // 
      this.btnVillageClear.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnVillageClear.Location = new System.Drawing.Point(625, 103);
      this.btnVillageClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnVillageClear.Name = "btnVillageClear";
      this.btnVillageClear.Size = new System.Drawing.Size(38, 25);
      this.btnVillageClear.TabIndex = 19;
      this.btnVillageClear.UseVisualStyleBackColor = true;
      // 
      // btnPSClear
      // 
      this.btnPSClear.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnPSClear.Location = new System.Drawing.Point(625, 136);
      this.btnPSClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnPSClear.Name = "btnPSClear";
      this.btnPSClear.Size = new System.Drawing.Size(38, 25);
      this.btnPSClear.TabIndex = 24;
      this.btnPSClear.UseVisualStyleBackColor = true;
      // 
      // btnStreetClear
      // 
      this.btnStreetClear.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnStreetClear.Location = new System.Drawing.Point(625, 169);
      this.btnStreetClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnStreetClear.Name = "btnStreetClear";
      this.btnStreetClear.Size = new System.Drawing.Size(38, 25);
      this.btnStreetClear.TabIndex = 29;
      this.btnStreetClear.UseVisualStyleBackColor = true;
      // 
      // btnHouseClear
      // 
      this.btnHouseClear.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnHouseClear.Location = new System.Drawing.Point(625, 202);
      this.btnHouseClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnHouseClear.Name = "btnHouseClear";
      this.btnHouseClear.Size = new System.Drawing.Size(38, 25);
      this.btnHouseClear.TabIndex = 34;
      this.btnHouseClear.UseVisualStyleBackColor = true;
      // 
      // btnFlatClear
      // 
      this.btnFlatClear.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnFlatClear.Location = new System.Drawing.Point(625, 301);
      this.btnFlatClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnFlatClear.Name = "btnFlatClear";
      this.btnFlatClear.Size = new System.Drawing.Size(38, 25);
      this.btnFlatClear.TabIndex = 43;
      this.btnFlatClear.UseVisualStyleBackColor = true;
      // 
      // btnErrors
      // 
      this.btnErrors.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnErrors.Location = new System.Drawing.Point(582, 395);
      this.btnErrors.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnErrors.Name = "btnErrors";
      this.btnErrors.Size = new System.Drawing.Size(35, 28);
      this.btnErrors.TabIndex = 49;
      this.btnErrors.UseVisualStyleBackColor = true;
      // 
      // btnMore
      // 
      this.btnMore.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.btnMore.Location = new System.Drawing.Point(625, 395);
      this.btnMore.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.btnMore.Name = "btnMore";
      this.btnMore.Size = new System.Drawing.Size(38, 28);
      this.btnMore.TabIndex = 50;
      this.btnMore.UseVisualStyleBackColor = true;
      // 
      // edTextView
      // 
      this.edTextView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.MainTLP.SetColumnSpan(this.edTextView, 2);
      this.edTextView.Location = new System.Drawing.Point(36, 395);
      this.edTextView.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edTextView.Multiline = true;
      this.edTextView.Name = "edTextView";
      this.edTextView.ReadOnly = true;
      this.edTextView.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.edTextView.Size = new System.Drawing.Size(538, 44);
      this.edTextView.TabIndex = 48;
      this.edTextView.Text = "������ 1\r\n������ 2";
      // 
      // lblRegion
      // 
      this.lblRegion.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.lblRegion.Location = new System.Drawing.Point(4, 0);
      this.lblRegion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblRegion.Name = "lblRegion";
      this.lblRegion.Size = new System.Drawing.Size(24, 33);
      this.lblRegion.TabIndex = 0;
      this.lblRegion.Text = "&1";
      this.lblRegion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // lblFlat
      // 
      this.lblFlat.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.lblFlat.Location = new System.Drawing.Point(4, 297);
      this.lblFlat.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
      this.lblFlat.Name = "lblFlat";
      this.lblFlat.Size = new System.Drawing.Size(24, 33);
      this.lblFlat.TabIndex = 39;
      this.lblFlat.Text = "&8";
      this.lblFlat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // cbManualPostalCode
      // 
      this.cbManualPostalCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cbManualPostalCode.AutoSize = true;
      this.cbManualPostalCode.Location = new System.Drawing.Point(213, 367);
      this.cbManualPostalCode.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.cbManualPostalCode.Name = "cbManualPostalCode";
      this.cbManualPostalCode.Size = new System.Drawing.Size(143, 20);
      this.cbManualPostalCode.TabIndex = 46;
      this.cbManualPostalCode.Text = "�������� ������";
      this.cbManualPostalCode.UseVisualStyleBackColor = true;
      // 
      // edPostalCode
      // 
      this.edPostalCode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.edPostalCode.Location = new System.Drawing.Point(364, 367);
      this.edPostalCode.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.edPostalCode.Mask = "000000";
      this.edPostalCode.Name = "edPostalCode";
      this.edPostalCode.Size = new System.Drawing.Size(210, 22);
      this.edPostalCode.TabIndex = 47;
      // 
      // button7
      // 
      this.button7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.button7.Location = new System.Drawing.Point(126, 123);
      this.button7.Name = "button7";
      this.button7.Size = new System.Drawing.Size(32, 14);
      this.button7.TabIndex = 23;
      this.button7.UseVisualStyleBackColor = true;
      // 
      // button8
      // 
      this.button8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.button8.Location = new System.Drawing.Point(126, 103);
      this.button8.Name = "button8";
      this.button8.Size = new System.Drawing.Size(32, 14);
      this.button8.TabIndex = 20;
      this.button8.UseVisualStyleBackColor = true;
      // 
      // button9
      // 
      this.button9.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.button9.Location = new System.Drawing.Point(174, 119);
      this.button9.Name = "button9";
      this.button9.Size = new System.Drawing.Size(32, 23);
      this.button9.TabIndex = 17;
      this.button9.UseVisualStyleBackColor = true;
      // 
      // FiasAddressPanel
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.Controls.Add(this.MainTLP);
      this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
      this.Name = "FiasAddressPanel";
      this.Size = new System.Drawing.Size(667, 446);
      this.MainTLP.ResumeLayout(false);
      this.MainTLP.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    internal System.Windows.Forms.TableLayoutPanel MainTLP;
    internal System.Windows.Forms.TextBox edPlanStrAOType;
    internal System.Windows.Forms.TextBox edPlanStrName;
    internal System.Windows.Forms.Button btnPSSel;
    internal System.Windows.Forms.TextBox edVillageAOType;
    internal System.Windows.Forms.TextBox edVillageName;
    internal System.Windows.Forms.Button btnVillageSel;
    internal System.Windows.Forms.TextBox edCityAOType;
    internal System.Windows.Forms.TextBox edCityName;
    internal System.Windows.Forms.Button btnCitySel;
    internal System.Windows.Forms.TextBox edDistrictAOType;
    internal System.Windows.Forms.TextBox edDistrictName;
    internal System.Windows.Forms.Button btnDistrictSel;
    internal System.Windows.Forms.TextBox edRegionName;
    internal System.Windows.Forms.TextBox edRegionAOType;
    internal System.Windows.Forms.Button btnRegionSel;
    internal System.Windows.Forms.TextBox edHouseAOType;
    internal System.Windows.Forms.TextBox edHouseName;
    internal System.Windows.Forms.Button btnHouseSel;
    internal System.Windows.Forms.TextBox edStreetAOType;
    internal System.Windows.Forms.TextBox edStreetName;
    internal System.Windows.Forms.Button btnStreetSel;
    internal System.Windows.Forms.TextBox edStrAOType;
    internal System.Windows.Forms.TextBox edBuildingName;
    internal System.Windows.Forms.TextBox edBuildingAOType;
    internal System.Windows.Forms.TextBox edStrName;
    internal System.Windows.Forms.Button btnFlatSel;
    internal System.Windows.Forms.TextBox edFlatName;
    internal System.Windows.Forms.TextBox edFlatAOType;
    internal System.Windows.Forms.TextBox edRoomAOType;
    internal System.Windows.Forms.TextBox edRoomName;
    internal System.Windows.Forms.Button btnRegionClear;
    internal System.Windows.Forms.Button btnDistrictClear;
    internal System.Windows.Forms.Button btnCityClear;
    internal System.Windows.Forms.Button btnVillageClear;
    internal System.Windows.Forms.Button btnPSClear;
    internal System.Windows.Forms.Button btnStreetClear;
    internal System.Windows.Forms.Button button7;
    internal System.Windows.Forms.Button button8;
    internal System.Windows.Forms.Button button9;
    internal System.Windows.Forms.Button btnHouseClear;
    internal System.Windows.Forms.Button btnFlatClear;
    internal System.Windows.Forms.Button btnErrors;
    internal System.Windows.Forms.Button btnMore;
    internal System.Windows.Forms.TextBox edTextView;
    private System.Windows.Forms.Label lblHouse;
    private System.Windows.Forms.Label lblStreet;
    private System.Windows.Forms.Label lblPS;
    private System.Windows.Forms.Label lblVillage;
    private System.Windows.Forms.Label lblCity;
    private System.Windows.Forms.Label lblDistrict;
    private System.Windows.Forms.Label lblRegion;
    private System.Windows.Forms.Label lblFlat;
    internal System.Windows.Forms.CheckBox cbManualPostalCode;
    internal System.Windows.Forms.MaskedTextBox edPostalCode;

  }
}
