﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Xml.Serialization;
using System.Runtime.Serialization;
using AgeyevAV;
using AgeyevAV.Config;

/*
 * The BSD License
 * 
 * Copyright (c) 2015, Ageyev A.V.
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace AgeyevAV.ExtDB.Docs
{
  /// <summary>
  /// Выборка документов. В одной выборке могут присутствовать документы разных
  /// видов. Документ не может входить в выборку дважды.
  /// Класс не является потокобезопасным.
  /// </summary>
  [Serializable]
  public sealed class DBxDocSelection: ICloneable
  {
    #region Конструкторы

    /// <summary>
    /// Создать пустую выборку документов
    /// </summary>
    /// <param name="DBIdentity">Идентификатор базы данных (см. описание свойства)</param>
    public DBxDocSelection(string DBIdentity)
    {
      if (String.IsNullOrEmpty(DBIdentity))
        throw new ArgumentNullException("DBIdentity");

      FData = new DataSet();
      FData.RemotingFormat = SerializationFormat.Binary;
      FDBIdentity = DBIdentity;
    }

    /// <summary>
    /// Создает выборку из одного документа
    /// </summary>
    /// <param name="DBIdentity">Идентификатор базы данных (см. описание свойства)</param>
    /// <param name="TableName">Имя таблицы документа DBxDocType.Name</param>
    /// <param name="Id">Идентификатор документа</param>
    public DBxDocSelection(string DBIdentity, string TableName, Int32 Id)
      : this(DBIdentity)
    {
      Add(TableName, Id);
    }

    /// <summary>
    /// Создает выборку из нескольких документа
    /// </summary>
    /// <param name="DBIdentity">Идентификатор базы данных (см. описание свойства)</param>
    /// <param name="TableName">Имя таблицы документа DBxDocType.Name</param>
    /// <param name="Ids">Идентификаторы документов</param>
    public DBxDocSelection(string DBIdentity, string TableName, Int32[] Ids)
      : this(DBIdentity)
    {
      Add(TableName, Ids);
    }

    /// <summary>
    /// Создает копию выборки документов
    /// </summary>
    /// <param name="Source">Исходная выборка документов</param>
    public DBxDocSelection(DBxDocSelection Source)
      :this(Source.DBIdentity)
    {
      Add(Source);
    }

    /// <summary>
    /// Создает выборку документов, куда помещает идентификаторы только одного вида документов из исходной выборки
    /// </summary>
    /// <param name="Source">Исходная выборка документов</param>
    /// <param name="TableName">Имя таблицы</param>
    public DBxDocSelection(DBxDocSelection Source, string TableName)
      : this(Source.DBIdentity)
    {
      Add(TableName, Source[TableName]);
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Идентификатор базы данных (задается в конструкторе)
    /// Используется при работе с буфером обмена, чтобы не допустить вставку данных из программы,
    /// работающей с другой базой данных
    /// </summary>
    public string DBIdentity { get { return FDBIdentity; } }
    private string FDBIdentity;

    /// <summary>
    /// Основные данные. В каждой таблице имеется единственное поле Id
    /// </summary>
    private DataSet FData;

    /// <summary>
    /// Список имен таблиц, входящих в выборку
    /// </summary>
    public string[] TableNames
    {
      get
      {
        if (FTableNames == null)
        {
          FTableNames = new string[FData.Tables.Count];
          for (int i = 0; i < FTableNames.Length; i++)
            FTableNames[i] = FData.Tables[i].TableName;
        }
        return FTableNames;
      }
    }
    [NonSerialized]
    [XmlIgnore]
    private string[] FTableNames;

    /// <summary>
    /// Получить массив идентификаторов заданной таблицы, входящих в выборку
    /// Если нет идентификаторов для таблицы TableName, то возвращается пустой
    /// массив
    /// </summary>
    /// <param name="TableName"></param>
    /// <returns></returns>
    public Int32[] this[string TableName]
    {
      get
      {
        int p = FData.Tables.IndexOf(TableName);
        if (p < 0)
          return DataTools.EmptyIds;
        else
          return DataTools.GetIds(FData.Tables[p]);
      }
    }

    /// <summary>
    /// Получить число документов заданного вида
    /// </summary>
    /// <param name="TableName"></param>
    /// <returns></returns>
    public int GetCount(string TableName)
    {
      int p = FData.Tables.IndexOf(TableName);
      if (p < 0)
        return 0;
      else
        return FData.Tables[p].Rows.Count;
    }

    /// <summary>
    /// Общее число ссылок в выборке
    /// </summary>
    public int TotalCount
    {
      get
      {
        int cnt = 0;
        foreach (DataTable Table in FData.Tables)
          cnt += Table.Rows.Count;
        return cnt;
      }
    }

    /// <summary>
    /// Возращает true, если выборка не содердит ни одного документа
    /// </summary>
    public bool IsEmpty
    {
      get { return TotalCount == 0; }
    }

    #endregion

    #region Добавление / удаление документов

    ///// <summary>
    ///// Внутренний метод доступа к таблице с идентификаторами
    ///// </summary>
    ///// <param name="TableName"></param>
    ///// <returns></returns>
    //public DataTable GetTable(string TableName)
    //{
    //  return ReadyTable(TableName, true);
    //}

    private DataTable ReadyTable(string TableName, bool Create)
    {
#if DEBUG
      if (String.IsNullOrEmpty(TableName))
        throw new ArgumentNullException(TableName);
#endif
      int p = FData.Tables.IndexOf(TableName);
      if (p >= 0)
        return FData.Tables[p];
      if (!Create)
        return null;

      FTableNames = null; // список имен таблиц больше недействителен

      // Добавляем таблицу
      DataTable Table = FData.Tables.Add(TableName);
      Table.Columns.Add("Id", typeof(Int32));
      DataTools.SetPrimaryKey(Table, "Id");
      return Table;
    }

    /// <summary>
    /// Добавить документ в выборку
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Id">Идентификатор документа</param>
    /// <returns>1, если документ был добавлен, 0, если нет (уже есть в выборке или <paramref name="Id"/>=0</returns>
    public int Add(string TableName, Int32 Id)
    {
      if (Id == 0)
        return 0;
      DataTable Table = ReadyTable(TableName, true);
      DataRow DummyRow;
      return DataTools.FindOrAddPrimaryKeyRow(Table, Id, out DummyRow) ? 1 : 0;
    }

    /// <summary>
    /// Добавить несколько документов в выборку
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Ids">Идентификаторы документов для добавления</param>
    /// <returns>Количество добавленных документов</returns>
    public int Add(string TableName, Int32[] Ids)
    {
      if (Ids == null)
        return 0;
      if (Ids.Length == 0)
        return 0;
      DataTable Table = ReadyTable(TableName, true);
      int cnt = 0;
      for (int i = 0; i < Ids.Length; i++)
      {
        if (Ids[i] == 0)
          continue;
        DataRow DummyRow;
        if (DataTools.FindOrAddPrimaryKeyRow(Table, Ids[i], out DummyRow))
          cnt++;
      }
      return cnt;
    }

    /// <summary>
    /// Добавить несколько документов в выборку
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Ids">Идентификаторы документов для добавления</param>
    /// <returns>Количество добавленных документов</returns>
    public int Add(string TableName, IdList Ids)
    {
      if (Object.ReferenceEquals(Ids, null))
        return 0;
      if (Ids.Count == 0)
        return 0;
      DataTable Table = ReadyTable(TableName, true);
      int cnt = 0;
      foreach (Int32 Id in Ids)
      {
        DataRow DummyRow;
        if (DataTools.FindOrAddPrimaryKeyRow(Table, Id, out DummyRow))
          cnt++;
      }
      return cnt;
    }

    /// <summary>
    /// Добавить документы из другой выборки
    /// </summary>
    /// <param name="Src">Исходная выборка</param>
    /// <returns>Количество добавленных документов</returns>
    public int Add(DBxDocSelection Src)
    {
      if (Src == null)
        return 0;

      int cnt = 0;
      foreach (DataTable SrcTable in Src.FData.Tables)
      {
        DataTable ResTable = ReadyTable(SrcTable.TableName, true);
        foreach (DataRow SrcRow in SrcTable.Rows)
        {
          // Можно не проверять удаленные строки
          Int32 Id = (Int32)(SrcRow["Id"]);
          DataRow DummyRow;
          if (DataTools.FindOrAddPrimaryKeyRow(ResTable, Id, out DummyRow))
            cnt++;
        }
      }
      return cnt;
    }

    /// <summary>
    /// Добавить документы в выборку
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Table">Таблица, содержащая столбец "Id" с идентификаторами добавляемых документов</param>
    /// <returns>Количество добавленных документов</returns>
    public int Add(string TableName, DataTable Table)
    {
      if (String.IsNullOrEmpty(TableName))
        throw new ArgumentNullException("TableName");
      if (Table == null)
        return 0;
      if (Table.Rows.Count == 0)
        return 0;
      DataTable ResTable = ReadyTable(TableName, true);
      int cnt = 0;
      foreach (DataRow SrcRow in Table.Rows)
      {
        if (SrcRow.RowState == DataRowState.Deleted)
          continue; // 27.09.2017

        Int32 Id = (Int32)(SrcRow["Id"]);
        DataRow DummyRow;
        if (DataTools.FindOrAddPrimaryKeyRow(ResTable, Id, out DummyRow))
          cnt++;
      }

      return cnt;
    }

    /// <summary>
    /// Добавить документы в выборку.
    /// Свойство <paramref name="Table"/>.TableName определяет вид документов.
    /// </summary>
    /// <param name="Table">Таблица, содержащая столбец "Id" с идентификаторами добавляемых документов</param>
    /// <returns>Количество добавленных документов</returns>
    public int Add(DataTable Table)
    {
      if (Table == null)
        return 0;
      return Add(Table.TableName, Table);
    }

    /// <summary>
    /// Удалить документ из выборки
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Id">Идентификатор удаляемого документа</param>
    /// <returns>1, если документ был удален, 0, если такого документа нет в выборке</returns>
    public int Remove(string TableName, Int32 Id)
    {
      if (Id == 0)
        return 0;
      DataTable Table = ReadyTable(TableName, false);
      if (Table == null)
        return 0;
      DataRow Row = Table.Rows.Find(Id);
      if (Row != null)
      {
        Table.Rows.Remove(Row);
        return 1;
      }
      else
        return 0;
    }

    /// <summary>
    /// Удалить документы из выборки
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Ids">Идентификаторы удаляемых документов</param>
    /// <returns>Количество удаленных документов</returns>
    public int Remove(string TableName, Int32[] Ids)
    {
      if (Ids == null)
        return 0;
      if (Ids.Length == 0)
        return 0;
      DataTable Table = ReadyTable(TableName, false);
      if (Table == null)
        return 0;

      int cnt = 0;
      for (int i = 0; i < Ids.Length; i++)
      {
        DataRow Row = Table.Rows.Find(Ids[i]);
        if (Row != null)
        {
          Table.Rows.Remove(Row);
          cnt++;
        }
      }

      return cnt;
    }

    /// <summary>
    /// Удалить документы из выборки
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Ids">Идентификаторы удаляемых документов</param>
    /// <returns>Количество удаленных документов</returns>
    public int Remove(string TableName, IdList Ids)
    {
      if (Ids == null)
        return 0;
      if (Ids.Count == 0)
        return 0;
      DataTable Table = ReadyTable(TableName, false);
      if (Table == null)
        return 0;

      int cnt = 0;
      foreach (Int32 Id in Ids)
      {
        DataRow Row = Table.Rows.Find(Id);
        if (Row != null)
        {
          Table.Rows.Remove(Row);
          cnt++;
        }
      }

      return cnt;
    }

    /// <summary>
    /// Удалить документы из выборки
    /// </summary>
    /// <param name="Src">Выборка, содержащая документы, которые надо удалить из текущей выборки</param>
    /// <returns>Количество удаленных документов</returns>
    public int Remove(DBxDocSelection Src)
    {
      if (Src == null)
        return 0;

      int cnt = 0;
      foreach (DataTable SrcTable in Src.FData.Tables)
      {
        DataTable ResTable = ReadyTable(SrcTable.TableName, false);
        if (ResTable == null)
          continue;
        foreach (DataRow SrcRow in SrcTable.Rows)
        {
          Int32 Id = (Int32)(SrcRow["Id"]);
          DataRow Row = ResTable.Rows.Find(Id);
          if (Row != null)
          {
            ResTable.Rows.Remove(Row);
            cnt++;
          }
        }
      }

      return cnt;
    }

    /// <summary>
    /// Удалить все ссылки заданного вида
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <returns>Количество удаленных документов</returns>
    public int Remove(string TableName)
    {
      DataTable Table = ReadyTable(TableName, false);
      if (Table == null)
        return 0;
      int cnt = Table.Rows.Count;
      FData.Tables.Remove(Table);
      FTableNames = null;
      return cnt;
    }

    /// <summary>
    /// Удалить документы из выборки
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Table">Таблица, в которой есть столбец "Id", содержащий идентификаторы удаляемых документов</param>
    /// <returns>Количество удаленных документов</returns>
    public int Remove(string TableName, DataTable Table)
    {
      if (String.IsNullOrEmpty(TableName))
        throw new ArgumentNullException("TableName");
      if (Table == null)
        return 0;
      if (Table.Rows.Count == 0)
        return 0;
      DataTable ResTable = ReadyTable(TableName, false);
      if (ResTable == null)
        return 0;

      int cnt = 0;
      foreach (DataRow SrcRow in Table.Rows)
      {
        if (SrcRow.RowState == DataRowState.Deleted)
          continue; // 27.09.2017
        Int32 Id = (Int32)(SrcRow["Id"]);
        DataRow Row = ResTable.Rows.Find(Id);
        if (Row != null)
        {
          ResTable.Rows.Remove(Row);
          cnt++;
        }
      }
      return cnt;
    }

    /// <summary>
    /// Удалить документы из выборки.
    /// Свойство <paramref name="Table"/>.TableName задает вид удаляемых документов.
    /// </summary>
    /// <param name="Table">Таблица, в которой есть столбец "Id", содержащий идентификаторы удаляемых документов</param>
    /// <returns>Количество удаленных документов</returns>
    public int Remove(DataTable Table)
    {
      if (Table == null)
        return 0;
      return Remove(Table.TableName, Table);
    }

    /// <summary>
    /// Удаляет из текущей выборки все ссылки, которых нет в выборке <paramref name="Src"/>
    /// Если <paramref name="Src"/> - пустая выборка, то будут удалены все документы
    /// Таким образом, текущая выборка становится пересечением текущей выборки и <paramref name="Src"/>
    /// </summary>
    /// <param name="Src">Выборка для сравнения (не изменяется)</param>
    /// <returns>Число удаленных ссылок</returns>
    public int RemoveNeg(DBxDocSelection Src)
    {
      int cnt = 0;
      if (Src == null)
      {
        cnt = TotalCount;
        Clear();
        return cnt;
      }
      if (Src.IsEmpty)
      {
        cnt = TotalCount;
        Clear();
        return cnt;
      }

      for (int i = FData.Tables.Count - 1; i >= 0; i--)
      {
        DataTable ResTable = FData.Tables[i];
        DataTable SrcTable = Src.ReadyTable(ResTable.TableName, false);
        if (SrcTable == null)
        {
          cnt += ResTable.Rows.Count;
          FData.Tables.RemoveAt(i);
          FTableNames = null;
          continue;
        }

        for (int j = ResTable.Rows.Count - 1; j >= 0; j--)
        {
          DataRow ResRow = ResTable.Rows[j];
          Int32 Id = (Int32)(ResRow["Id"]);
          if (SrcTable.Rows.Find(Id) == null)
          {
            ResTable.Rows.RemoveAt(j);
            cnt++;
          }
        }
      }

      return cnt;
    }

    /// <summary>
    /// Очистка всей выборки
    /// </summary>
    public void Clear()
    {
      FData.Tables.Clear();
      FTableNames = null;
    }

    #endregion

    #region Поиск

    /// <summary>
    /// Получить первый идентификатор заданного документа или 0, если выборка не
    /// содержит таких документов
    /// </summary>
    /// <param name="TableName"></param>
    /// <returns></returns>
    public Int32 GetSingleId(string TableName)
    {
      int p = FData.Tables.IndexOf(TableName);
      if (p < 0)
        return 0;
      else
      {
        if (FData.Tables[p].Rows.Count == 0)
          return 0;
        else
          return DataTools.GetInt(FData.Tables[p].Rows[0], "Id");
      }
    }

    /// <summary>
    /// Возвращает true, если в выборке есть заданный документ
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Id">Идентификатор документа для поиска</param>
    /// <returns>true, если идентификатор есть в выборке</returns>
    public bool Contains(string TableName, Int32 Id)
    {
      int p = FData.Tables.IndexOf(TableName);
      if (p < 0)
        return false;
      else
        return FData.Tables[p].Rows.Find(Id) != null;
    }

    /// <summary>
    /// Возвращает true, если в выборке есть хотя бы один документ из списка
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Ids">Идентификаторы документов для поиска</param>
    /// <returns>true, если документ найден</returns>
    public bool ContainsAny(string TableName, Int32[] Ids)
    {
      if (Ids == null)
        return true;
      if (Ids.Length == 0)
        return true;

      int p = FData.Tables.IndexOf(TableName);
      if (p < 0)
        return false;
      else
      {
        for (int i = 0; i < Ids.Length; i++)
        {
          if (FData.Tables[p].Rows.Find(Ids[i]) != null)
            return true;
        }
        return false;
      }
    }

    /// <summary>
    /// Возвращает true, если в выборке есть хотя бы один документ из списка
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Ids">Идентификаторы документов для поиска</param>
    /// <returns>true, если документ найден</returns>
    public bool ContainsAny(string TableName, IdList Ids)
    {
      if (Ids == null)
        return true;
      if (Ids.Count == 0)
        return true;

      int p = FData.Tables.IndexOf(TableName);
      if (p < 0)
        return false;
      else
      {
        foreach (Int32 Id in Ids)
        {
          if (FData.Tables[p].Rows.Find(Id) != null)
            return true;
        }
        return false;
      }
    }

    /// <summary>
    /// Возвращает true, если в выборке есть хотя бы один документ из списка
    /// </summary>
    /// <param name="Src">Выборка документов, которые надо найти</param>
    /// <returns>true, если документ найден</returns>
    public bool ContainsAny(DBxDocSelection Src)
    {
      if (Src == null)
        return true;
      if (Src.IsEmpty)
        return true;

      foreach (DataTable SrcTable in Src.FData.Tables)
      {
        DataTable ResTable = ReadyTable(SrcTable.TableName, false);
        if (ResTable == null)
          continue;
        foreach (DataRow SrcRow in SrcTable.Rows)
        {
          // Можно не проверять удаленные строки
          Int32 Id = (Int32)(SrcRow["Id"]);
          if (ResTable.Rows.Find(Id) != null)
            return true;
        }
      }
      return false;
    }

    /// <summary>
    /// Возвращает true, если в выборке есть все документы из списка
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Ids">Идентификаторы документов для поиска</param>
    /// <returns>true, если документы найдены</returns>
    public bool ContainsAll(string TableName, Int32[] Ids)
    {
      if (Ids == null)
        return true;
      if (Ids.Length == 0)
        return true;

      int p = FData.Tables.IndexOf(TableName);
      if (p < 0)
        return false;
      else
      {
        for (int i = 0; i < Ids.Length; i++)
        {
          if (FData.Tables[p].Rows.Find(Ids[i]) == null)
            return false;
        }
        return true;
      }
    }

    /// <summary>
    /// Возвращает true, если в выборке есть все документы из списка
    /// </summary>
    /// <param name="TableName">Имя таблицы документов</param>
    /// <param name="Ids">Идентификаторы документов для поиска</param>
    /// <returns>true, если документы найдены</returns>
    public bool ContainsAll(string TableName, IdList Ids)
    {
      if (Ids == null)
        return true;
      if (Ids.Count == 0)
        return true;

      int p = FData.Tables.IndexOf(TableName);
      if (p < 0)
        return false;
      else
      {
        foreach (Int32 Id in Ids)
        {
          if (FData.Tables[p].Rows.Find(Id) == null)
            return false;
        }
        return true;
      }
    }

    /// <summary>
    /// Возвращает true, если в выборке есть все документы из списка
    /// </summary>
    /// <param name="Src">Выборка документов, которые надо найти</param>
    /// <returns>true, если документы найдены</returns>
    public bool ContainsAll(DBxDocSelection Src)
    {
      if (Src == null)
        return true;
      if (Src.IsEmpty)
        return true;

      foreach (DataTable SrcTable in Src.FData.Tables)
      {
        if (SrcTable.Rows.Count == 0)
          continue;

        DataTable ResTable = ReadyTable(SrcTable.TableName, false);
        if (ResTable == null)
          return false;

        foreach (DataRow SrcRow in SrcTable.Rows)
        {
          // Можно не проверять удаленные строки
          Int32 Id = (Int32)(SrcRow["Id"]);
          if (ResTable.Rows.Find(Id) == null)
            return false;
        }
      }
      return true;
    }

    #endregion

    #region Сериализация

    [OnSerializing()]
    internal void OnSerializingMethod(StreamingContext context)
    {
      // Перед сериализацией сохраняем все изменения
      FData.AcceptChanges();
    }

    #endregion

    #region Чтение и запись

    /// <summary>
    /// Запись в секцию конфигурацию
    /// В переданном узле создается полдузел "Tables" с вложенными подузлами, соответствующими
    /// именам таблиц в списке TableNames. Для каждого подузла создается строковый параметр "Ids".
    /// В строку записываются идентификаторы документов, разделенные запятыми.
    /// </summary>
    /// <param name="Sect">Секция конфигурации</param>
    public void WriteConfig(CfgPart Sect)
    {
      if (IsEmpty)
        Sect.Remove("Tables");
      else
      {
        CfgPart Part2 = Sect.GetChild("Tables", true);
        Part2.Clear();
        for (int i = 0; i < TableNames.Length; i++)
        {
          Int32[] Ids = this[TableNames[i]];
          if (Ids.Length == 0)
            continue;
          CfgPart Part3 = Part2.GetChild(TableNames[i], true);
          string s = DataTools.CommaStringFromIds(Ids, false);
          Part3.SetString("Ids", s);
        }
      }
    }

    /// <summary>
    /// Чтение выборки, которая была записана вызовом WriteConfig()
    /// </summary>
    /// <param name="Sect">Секция конфигурации</param>
    public void ReadConfig(CfgPart Sect)
    {
      Clear();
      CfgPart Part2 = Sect.GetChild("Tables", false);
      if (Part2 == null)
        return;
      string[] TableNames = Part2.GetChildNames();
      for (int i = 0; i < TableNames.Length; i++)
      {
        CfgPart Part3 = Part2.GetChild(TableNames[i], false);
        if (Part3 == null)
          continue; // ошибка
        string s = Part3.GetString("Ids");
        Int32[] Ids = DataTools.CommaStringToIds(s);
        Add(TableNames[i], Ids);
      }
    }

    #endregion

    // TODO: Нет доступа к сохраненным документам выборки

#if XXXX

    #region Нормализация

    /// <summary>
    /// Возвращает true, если выборка содержит ссылки на другие выборки и
    /// нуждается в нормализации
    /// </summary>
    public bool NormalizeNeeded
    {
      get { return GetCount("Выборки") > 0; }
    }

    /// <summary>
    /// Нормализация выборки.
    /// Заменяет ссылки на другие выборки их содержимым
    /// Возвращает true, если нормализация выполнена
    /// </summary>
    /// <param name="BufTables">Доступ к буферизации таблиц</param>
    /// <returns>true, если нормализация выполнена</returns>
    public bool Normalize(BufTables BufTables)
    {
      Int32[] Ids = this["Выборки"];
      if (Ids.Length == 0)
        return false;
      List<Int32> ReadyIds = new List<Int32>();
      for (int i = 0; i < Ids.Length; i++)
        NormalizeOneDocSel(Ids[i], ReadyIds, BufTables);
      Remove("Выборки");
      return true;
    }

    /// <summary>
    /// Рекурсивная процедура нормализации одной выборки
    /// </summary>
    /// <param name="DocSelId">Идентификатор текущей выборки</param>
    /// <param name="ReadyIds">Список уже обработанных выборок</param>
    /// <param name="BufTables">Доступ к данным</param>
    private void NormalizeOneDocSel(Int32 DocSelId, List<Int32> ReadyIds, BufTables BufTables)
    {
      if (ReadyIds.Contains(DocSelId))
        return; // уже обработана

      // Предотвращаем повторную обработку
      ReadyIds.Add(DocSelId);

      // Загружаем идентификаторы выборки
      string XmlText = DataTools.GetString(BufTables.GetValue("Выборки", DocSelId, "Данные"));
      ConfigSection Sect = new ConfigSection();
      Sect.AsXmlText = XmlText;
      DBxDocSelection DocSel2 = new DBxDocSelection(DBIdentity);
      DocSel2.ReadConfig(Sect);

      // Добавляем ссылки из другой выборки
      for (int i = 0; i < DocSel2.TableNames.Length; i++)
      {
        Int32[] Ids2 = DocSel2[DocSel2.TableNames[i]];
        if (DocSel2.TableNames[i] == "Выборки")
        {
          // Рекурсивный вызов
          for (int j = 0; j < Ids2.Length; j++)
            NormalizeOneDocSel(Ids2[j], ReadyIds, BufTables);
        }
        else
          // Обычное добавление
          Add(DocSel2.TableNames[i], Ids2);
      }
    }

    #endregion

#endif

    #region Текстовое представление

    /// <summary>
    /// Для отладки.
    /// Для вывода содержимого выборки пользователю используйте перегрузку метода с аргументом DBxDocTextHandlers.
    /// </summary>
    /// <returns>текстовое представление</returns>
    public override string ToString()
    {
      StringBuilder sb = new StringBuilder();
      //sb.Append("TotalCount=");
      //sb.Append(TotalCount);
      for (int i = 0; i < FData.Tables.Count; i++)
      {
        if (i > 0)
          sb.Append(", ");
        else
          sb.Append(": ");

        sb.Append(FData.Tables[i].TableName);
        sb.Append(" (");
        sb.Append(FData.Tables[i].Rows.Count);
        sb.Append(")");
      }
      return sb.ToString();
    }

    /// <summary>
    /// Улучшенный метод получения текстового представления для выборки документов
    /// </summary>
    /// <param name="TextHandlers">Обработчики текстового представления документов</param>
    /// <returns>Текстовое представление</returns>
    public string ToString(DBxDocTextHandlers TextHandlers)
    {
      if (IsEmpty)
        return "Нет документов";
      if (TotalCount == 1)
      {
        DBxDocType DocType = TextHandlers.DocTypes[FData.Tables[0].TableName];
        string sDTN = DocType.SingularTitle;
        Int32 DocId = this[DocType.Name][0];
        return sDTN + " " + TextHandlers.GetTextValue(DocType.Name, DocId);
      }

      StringBuilder sb = new StringBuilder();
      //sb.Append("TotalCount=");
      //sb.Append(TotalCount);
      for (int i = 0; i < FData.Tables.Count; i++)
      {
        if (i > 0)
          sb.Append(", ");
        else
          sb.Append(": ");

        DBxDocType DocType = TextHandlers.DocTypes[FData.Tables[i].TableName];
        int n = FData.Tables[i].Rows.Count;
        if (n == 1)
          sb.Append(DocType.SingularTitle);
        else
          sb.Append(DocType.PluralTitle);

        sb.Append(" (");
        sb.Append(n);
        sb.Append(")");
      }
      return sb.ToString();
    }

    #endregion

    #region ICloneable Members

    /// <summary>
    /// Создает копию выборки
    /// </summary>
    /// <returns></returns>
    public DBxDocSelection Clone()
    {
      return new DBxDocSelection(this);
    }

    object ICloneable.Clone()
    {
      return new DBxDocSelection(this);
    }

    #endregion
  }
}
