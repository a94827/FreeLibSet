﻿// Part of FreeLibSet.
// See copyright notices in "license" file in the FreeLibSet root directory.

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ExtDBDocForms")]
[assembly: AssemblyDescription("Windows Forms user interface for working with documents, supplied in ExtDBDocs.dll")]
[assembly: Guid("c75454f8-9c5c-4b09-98d7-966d6ae08a0b")]
