﻿// Part of FreeLibSet.
// See copyright notices in "license" file in the FreeLibSet root directory.

using System;
using System.Windows.Forms;
using FreeLibSet.Forms;
using System.Data;
using System.Drawing;
using System.Collections.Generic;
using FreeLibSet.DependedValues;
using FreeLibSet.Data.Docs;
using FreeLibSet.Data;
using FreeLibSet.Core;
using FreeLibSet.UICore;
using FreeLibSet.Forms.Data;

// Блоки диалога для выбора документов и поддокументов

namespace FreeLibSet.Forms.Docs
{
  /// <summary>
  /// Режимы выбора документов и поддокументов в диалогах <see cref="DocSelectDialog"/> и <see cref="SubDocSelectDialog"/>.
  /// </summary>
  public enum DocSelectionMode
  {
    /// <summary>
    /// Разрешается выбор только одного документа или поддокумента.
    /// Этот режим задан по умолчанию.
    /// </summary>
    Single,

    /// <summary>
    /// Выбор нескольких документов или поддокументов выделением нескольких строк мышью или клавиши Shift/Control+стрелочки.
    /// Этот режим удобен, только если есть простая возможность выводить диалог выбора несколько раз подряд.
    /// </summary>
    MultiSelect,

    /// <summary>
    /// Выбор с помощью флажков.
    /// </summary>
    MultiCheckBoxes,

    /// <summary>
    /// Показывается список с выбранными документами. В него можно добавлять документы из полного списка.
    /// </summary>
    MultiList
  }

  /// <summary>
  /// Диалог выбора одного или нескольких документов заданного вида
  /// </summary>
  public sealed class DocSelectDialog
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог со значениями по умолчанию
    /// </summary>
    /// <param name="docTypeUI">Интерфейс для вида документа. Ссылка должна быть задана</param>
    public DocSelectDialog(DocTypeUI docTypeUI)
    {
      if (docTypeUI == null)
        throw new ArgumentNullException("docTypeUI");
      _DocTypeUI = docTypeUI;
      _SelectionMode = DocSelectionMode.Single;
      _DocIds = IdArray<Int32>.Empty;
      _CanBeEmpty = false;
      _DialogPosition = new EFPDialogPosition();

      //_DefaultGridConfigName = String.Empty;
      //_DefaultTreeConfigName = String.Empty;
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Интерфейс для доступа к документам.
    /// Задается в конструкторе.
    /// Не может быть null.
    /// </summary>
    public DocTypeUI DocTypeUI { get { return _DocTypeUI; } }
    private readonly DocTypeUI _DocTypeUI;

    /// <summary>
    /// Режим выбора документа:
    /// <list type="bullet">
    /// <item><description><see cref="DocSelectionMode.Single"/></description></item>
    /// <item><description><see cref="DocSelectionMode.MultiSelect"/></description></item>
    /// <item><description><see cref="DocSelectionMode.MultiCheckBoxes"/></description></item>
    /// <item><description><see cref="DocSelectionMode.MultiList"/></description></item>
    /// </list>
    /// По умолчанию - <see cref="DocSelectionMode.Single"/>
    /// </summary>
    public DocSelectionMode SelectionMode
    {
      get { return _SelectionMode; }
      set
      {
        switch (value)
        {
          case DocSelectionMode.Single:
          case DocSelectionMode.MultiSelect:
          case DocSelectionMode.MultiCheckBoxes:
          case DocSelectionMode.MultiList:
            _SelectionMode = value;
            break;
          default:
            throw new ArgumentException();
        }
      }
    }
    private DocSelectionMode _SelectionMode;

    /// <summary>
    /// Альтернативное значение для свойства <see cref="SelectionMode"/>.
    /// Содержит true, если разрешен выбор нескольких документов.
    /// </summary>
    public bool MultiSelect
    {
      get { return _SelectionMode != DocSelectionMode.Single; }
      set { _SelectionMode = value ? DocSelectionMode.MultiSelect : DocSelectionMode.Single; }
    }

    /// <summary>
    /// Вход-выход. Идентификатор выбранного документа при <see cref="MultiSelect"/>=false
    /// </summary>
    public Int32 DocId
    {
      get { return _DocIds.SingleId; }
      set { _DocIds = IdArray<Int32>.FromId(value); }
    }

    /// <summary>
    /// Вход-выход. Идентификаторы выбранных документов при <see cref="MultiSelect"/>=true.
    /// </summary>
    public IIdSet<Int32> DocIds
    {
      get { return _DocIds; }
      set
      {
        if (value == null)
          _DocIds = IdArray<Int32>.Empty;
        else
          _DocIds = value;
      }
    }
    private IIdSet<Int32> _DocIds;

    /// <summary>
    /// Заголовок блока диалога.
    /// По умолчанию: "Выбор документа XXX" или "Выбор документов XXX" (при <see cref="MultiSelect"/>=true)
    /// </summary>
    public string Title
    {
      get
      {
        if (_Title == null)
        {
          if (MultiSelect)
            return String.Format(Res.DocSelectDialog_Title_MultiSelect, DocTypeUI.DocType.PluralTitle);
          else
            return String.Format(Res.DocSelectDialog_Title_SingleSelect, DocTypeUI.DocType.SingularTitle);
        }
        else
          return _Title;
      }
      set { _Title = value; }
    }
    private string _Title;

    /// <summary>
    /// Определяет наличие в диалоге кнопки "Нет", чтобы можно было установить <see cref="DocId"/>=0.
    /// По умолчанию - false;
    /// </summary>
    public bool CanBeEmpty { get { return _CanBeEmpty; } set { _CanBeEmpty = value; } }
    private bool _CanBeEmpty;

    /// <summary>
    /// Набор фиксированных фильтров табличного просмотра.
    /// Значение null (по умолчанию) приводит к использованию текущего набора
    /// установленных пользователем фильтров.
    /// Действует только при <see cref="FixedDocIds"/>=null.
    /// </summary>
    public EFPDBxGridFilters Filters
    {
      get { return _Filters; }
      set
      {
        if (value != null)
          value.SqlFilterRequired = true;
        _Filters = value;
      }
    }
    private EFPDBxGridFilters _Filters;

    /// <summary>
    /// Массив фиксированных идентификаторов для выбора.
    /// Если null (по умолчанию), то выбор осуществляется с помощью формы <see cref="DocTableViewForm"/>, включая табличку фильтров.
    /// Если свойство установлено, то выбор осуществляется с помощью упрощенной формы.
    /// </summary>
    public IIdSet<Int32> FixedDocIds
    {
      get { return _FixedDocIds; }
      set { _FixedDocIds = value; }
    }
    private IIdSet<Int32> _FixedDocIds;

    /// <summary>
    /// Внешний объект, определяющий начальные значения при создании документа внутри этого диалога.
    /// Если задан, то должен определять все значения, чтобы документ прошел условия фильтров, если заданы фильтры в свойстве <see cref="Filters"/>,
    /// т.к. сами фильтры не используются для установки значений.
    /// По умолчанию - null.
    /// Действует только при <see cref="FixedDocIds"/>=null.
    /// </summary>
    public DocumentViewHandler EditorCaller { get { return _EditorCaller; } set { _EditorCaller = value; } }
    private DocumentViewHandler _EditorCaller;

    /// <summary>
    /// Позиция вывода блока диалога.
    /// Может либо меняться существующий объект, либо быть передана ссылка на новый объект <see cref="EFPDialogPosition"/>.
    /// Используется в комбоблоках.
    /// </summary>
    public EFPDialogPosition DialogPosition
    {
      get { return _DialogPosition; }
      set
      {
        if (value == null)
          _DialogPosition = new EFPDialogPosition();
        else
          _DialogPosition = value;
      }
    }
    private EFPDialogPosition _DialogPosition;

    // Пока не уверен, что надо
    /*
    /// <summary>
    /// Имя фиксированной настройки табличного про
    /// </summary>
    public string DefaultGridConfigName { get { return _DefaultGridConfigName; } set { _DefaultGridConfigName = value; } }
    private string _DefaultGridConfigName;

    public string DefaultTreeConfigName { get { return _DefaultTreeConfigName; } set { _DefaultTreeConfigName = value; } }
    private string _DefaultTreeConfigName;

    public object UserInitData { get { return _UserInitData; } set { _UserInitData = value; } }
    private object _UserInitData;
     * */

    #endregion

    #region Вывод блока диалога

    #region Основной метод ShowDialog()

    /// <summary>
    /// Выводит блок диалога.
    /// Возвращает <see cref="DialogResult.OK"/>, если пользователь сделал выбор, в том числе нажал кнопку "Нет".
    /// </summary>
    /// <returns>Результат выполнения</returns>
    public DialogResult ShowDialog()
    {
      if (FixedDocIds == null)
      {
        if (SelectionMode == DocSelectionMode.MultiList)
          return ShowDialogMultiList();
        else if (CanBeUsedGroupDialog())
          return ShowDialogForGroups();
        else
          return ShowDialogNormal();
      }
      else
        return ShowDialogFixedIds();
    }

    #endregion

    #region Обычный диалог с DocTableViewForm

    private DialogResult ShowDialogNormal()
    {
      DialogResult res = DialogResult.Cancel;

      using (DocTableViewForm form = new DocTableViewForm(DocTypeUI, GetDocTableViewMode(SelectionMode)))
      {
        form.Text = Title;
        form.CanBeEmpty = CanBeEmpty;
        try
        {
          if (MultiSelect)
            form.SelectedDocIds = DocIds;
          else
            form.CurrentDocId = DocId;
        }
        catch (Exception e)
        {
          EFPApp.ShowException(e, Res.DocSelectDialog_ErrTitle_InitSelection);
        }
        form.ExternalFilters = Filters;
        form.ExternalEditorCaller = EditorCaller;
        /*
        if (Form.ViewProvider.DocGridView != null)
        {
          Form.ViewProvider.DocGridView.DefaultConfigName = DefaultGridConfigName;
          Form.ViewProvider.DocGridView.UserInitData = UserInitData;
        }
        if (Form.ViewProvider.DocTreeView != null)
        {
          Form.ViewProvider.DocTreeView.DefaultConfigName = DefaultTreeConfigName;
          Form.ViewProvider.DocTreeView.UserInitData = UserInitData;
        }
          */
        switch (EFPApp.ShowDialog(form, false, DialogPosition))
        {
          case DialogResult.OK:
            if (MultiSelect)
              DocIds = form.SelectedDocIds;
            else
              DocId = form.CurrentDocId;
            res = DialogResult.OK;
            break;
          case DialogResult.No:
            DocId = 0;
            res = DialogResult.OK;
            break;
        }
      }
      return res;
    }

    internal static DocTableViewMode GetDocTableViewMode(DocSelectionMode selectionMode)
    {
      switch (selectionMode)
      {
        case DocSelectionMode.Single: return DocTableViewMode.SelectSingle;
        case DocSelectionMode.MultiSelect:
        case DocSelectionMode.MultiList: return DocTableViewMode.SelectMulti;
        case DocSelectionMode.MultiCheckBoxes: return DocTableViewMode.SelectMultiWithFlags;
        default:
          throw new ArgumentException();
      }
    }

    #endregion

    #region Диалог с текстовым представлением документов EFPDocSelTextGridView

    private DialogResult ShowDialogMultiList()
    {
      DialogResult res = DialogResult.Cancel;
      using (OKCancelGridForm form = new OKCancelGridForm())
      {
        form.Text = Title;
        form.FormProvider.ConfigSectionName = DocTypeUI.DocType.Name + "_MultiList";

        EFPDocSelTextGridView gh = new EFPDocSelTextGridView(form.ControlWithToolBar, DocTypeUI);
        if (Filters != null)
          gh.Filters = Filters;
        gh.CommandItems.CanEditFilters = false; // 09.07.2019
        gh.ExternalEditorCaller = EditorCaller;
        gh.Ids = IdTools.AsIdArray<Int32>(DocIds);

        gh.CanBeEmpty = CanBeEmpty;
        gh.OrderMode = EFPDocSelGridViewOrderMode.Manual;

        if (EFPApp.ShowDialog(form, false, DialogPosition) == DialogResult.OK)
        {
          DocIds = gh.Ids;
          res = DialogResult.OK;
        }
      }

      return res;
    }

    #endregion

    #region Диалог выбора из фиксированного списка

    private DialogResult ShowDialogFixedIds()
    {
      DialogResult res = DialogResult.Cancel;
      using (OKCancelGridForm form = new OKCancelGridForm())
      {
        form.Text = Title;
        form.FormProvider.ConfigSectionName = DocTypeUI.DocType.Name + "_FixedIds";
        form.NoButtonProvider.Visible = CanBeEmpty;

        EFPDocGridView gh = new EFPDocGridView(form.ControlWithToolBar, DocTypeUI);
        gh.FixedDocIds = FixedDocIds;
        gh.Validating += new UIValidatingEventHandler(SelectSingleDoc_ValidateNotEmpty);
        gh.Control.MultiSelect = MultiSelect;
        gh.CommandItems.EnterAsOk = true;

        try
        {
          if (MultiSelect)
            gh.SelectedIds = DocIds;
          else
            gh.CurrentId = DocId;
        }
        catch (Exception e)
        {
          EFPApp.ShowException(e, Res.DocSelectDialog_ErrTitle_InitSelection);
        }

        switch (EFPApp.ShowDialog(form, false, DialogPosition))
        {
          case DialogResult.OK:
            if (MultiSelect)
              DocIds = gh.SelectedIds;
            else
              DocId = gh.CurrentId;
            res = DialogResult.OK;
            break;
          case DialogResult.No:
            DocId = 0;
            res = DialogResult.OK;
            break;
        }
      }
      return res;
    }

    private void SelectSingleDoc_ValidateNotEmpty(object sender, UIValidatingEventArgs args)
    {
      EFPDocGridView gh = (EFPDocGridView)sender;
      if (MultiSelect)
      {
        if (gh.SelectedRowCount == 0)
          args.SetError(Res.DocSelectDialog_Err_IsEmptyMultiSelect);
      }
      else
      {
        if (gh.CurrentId == 0)
          args.SetError(Res.DocSelectDialog_Err_IsEmptySingleSelect);
      }
    }

    #endregion

    #region Диалог выбора группы

    /// <summary>
    /// Возвращает true, если можно использовать диалог выбора группы
    /// </summary>
    /// <returns></returns>
    private bool CanBeUsedGroupDialog()
    {
      if (!(_DocTypeUI is GroupDocTypeUI))
        return false;
      if (SelectionMode != DocSelectionMode.MultiSelect)
        return false;
      if (DocIds.Count > 0)
        return false; // ?? может быть, можно выбрать группу
      if (_Filters != null)
      {
        if (_Filters.Count != 0)
          return false;
      }

      return true;
    }

    private DialogResult ShowDialogForGroups()
    {
      GroupDocTypeUI docTypeUI2 = (GroupDocTypeUI)_DocTypeUI;

      if (!GroupGridFilterForm.PerformEdit(docTypeUI2, Title, docTypeUI2.ImageKey, ref docTypeUI2.LastGroupId, ref docTypeUI2.LastIncludeNestedGroups, CanBeEmpty, DialogPosition))
        return DialogResult.Cancel;
      IdCollection<Int32> groupIds = docTypeUI2.GetAuxFilterGroupIdList(docTypeUI2.LastGroupId, docTypeUI2.LastIncludeNestedGroups);
      if (groupIds != null)
        DocIds = groupIds;
      else
        DocIds = IdArray<Int32>.Empty;

      return DialogResult.OK;
    }

    #endregion

    #endregion
  }
  /// <summary>
  /// Диалог выбора одного или нескольких поддокументов заданного вида
  /// </summary>
  public sealed class SubDocSelectDialog
  {
    #region Конструктор

    /// <summary>
    /// Создает диалог со значениями по умолчанию
    /// </summary>
    /// <param name="subDocTypeUI">Интерфейс для вида поддокумента. Ссылка должна быть задана</param>
    /// <param name="subDocs">Список поддокументов, из которых можно выбирать. Ссылка должна быть задана</param>
    public SubDocSelectDialog(SubDocTypeUI subDocTypeUI, DBxMultiSubDocs subDocs)
    {
      if (subDocTypeUI == null)
        throw new ArgumentNullException("subDocTypeUI");
      if (subDocs == null)
        throw new ArgumentNullException("subDocs");
      //if (!Object.ReferenceEquals(subDocTypeUI.SubDocType, subDocs.SubDocType))
      //  throw new ArgumentException("SubDocTypeUI и SubDocs относятся к разным объектам SubDocType", "subDocs");

      _SubDocTypeUI = subDocTypeUI;
      _SubDocs = subDocs;
      _SelectionMode = DocSelectionMode.Single;
      _SubDocIds = IdArray<Int32>.Empty;
      _CanBeEmpty = false;
      _DialogPosition = new EFPDialogPosition();
    }

    #endregion

    #region Свойства

    /// <summary>
    /// Интерфейс для доступа к документам.
    /// Задается в конструкторе.
    /// Не может быть null.
    /// </summary>
    public SubDocTypeUI SubDocTypeUI { get { return _SubDocTypeUI; } }
    private readonly SubDocTypeUI _SubDocTypeUI;

    /// <summary>
    /// Список поддокументов, из которых можно выбирать.
    /// Задается в конструкторе.
    /// Не может быть null
    /// </summary>
    public DBxMultiSubDocs SubDocs { get { return _SubDocs; } }
    private readonly DBxMultiSubDocs _SubDocs;

    /// <summary>
    /// Режим выбора документа Single, MultiSelect или MultiCheckBoxes.
    /// <list type="bullet">
    /// <item><description><see cref="DocSelectionMode.Single"/></description></item>
    /// <item><description><see cref="DocSelectionMode.MultiSelect"/></description></item>
    /// <item><description><see cref="DocSelectionMode.MultiCheckBoxes"/></description></item>
    /// <item><description></description></item>
    /// </list>
    /// По умолчанию - <see cref="DocSelectionMode.Single"/>.
    /// Режим <see cref="DocSelectionMode.MultiList"/> не поддерживается.
    /// </summary>
    public DocSelectionMode SelectionMode
    {
      get { return _SelectionMode; }
      set
      {
        switch (value)
        {
          case DocSelectionMode.Single:
          case DocSelectionMode.MultiSelect:
          case DocSelectionMode.MultiCheckBoxes:
            _SelectionMode = value;
            break;
          default:
            throw new ArgumentException();
        }
      }
    }
    private DocSelectionMode _SelectionMode;

    /// <summary>
    /// Альтернативное значение для свойства <see cref="SelectionMode"/>.
    /// Содержит true, если разрешен выбор нескольких документов.
    /// </summary>
    public bool MultiSelect
    {
      get { return _SelectionMode != DocSelectionMode.Single; }
      set { _SelectionMode = value ? DocSelectionMode.MultiSelect : DocSelectionMode.Single; }
    }

    /// <summary>
    /// Вход-выход. Идентификатор выбранного поддокумента при <see cref="MultiSelect"/>=false.
    /// </summary>
    public Int32 SubDocId
    {
      get { return _SubDocIds.SingleId; }
      set { _SubDocIds = IdArray<Int32>.FromId(value); }
    }

    /// <summary>
    /// Вход-выход. Идентификаторы выбранных документов при <see cref="MultiSelect"/>=true.
    /// </summary>
    public IIdSet<Int32> SubDocIds
    {
      get { return _SubDocIds; }
      set
      {
        if (value == null)
          _SubDocIds = IdArray<Int32>.Empty;
        else
          _SubDocIds = value;
      }
    }
    private IIdSet<Int32> _SubDocIds;

    /// <summary>
    /// Заголовок блока диалога.
    /// По умолчанию: "Выбор поддокумента XXX" или "Выбор поддокументов XXX" (при <see cref="MultiSelect"/>=true).
    /// </summary>
    public string Title
    {
      get
      {
        if (_Title == null)
        {
          if (MultiSelect)
            return String.Format(Res.SubDocSelectDialog_Title_MultiSelect, SubDocTypeUI.SubDocType.PluralTitle);
          else
            return String.Format(Res.SubDocSelectDialog_Title_SingleSelect, SubDocTypeUI.SubDocType.SingularTitle);
        }
        else
          return _Title;
      }
      set { _Title = value; }
    }
    private string _Title;

    /// <summary>
    /// Определяет наличие в диалоге кнопки "Нет", чтобы можно было установить <see cref="SubDocId"/>=0.
    /// По умолчанию - false;
    /// </summary>
    public bool CanBeEmpty { get { return _CanBeEmpty; } set { _CanBeEmpty = value; } }
    private bool _CanBeEmpty;

    ///// <summary>
    ///// Набор фиксированных фильтров табличного просмотра.
    ///// Значение null (по умолчанию) приводит к использованию текущего набора
    ///// установленных пользователем фильтров.
    ///// Действует только при FixedDocIds=null.
    ///// </summary>
    //public GridFilters Filters { get { return _Filters; } set { _Filters = value; } }
    //private GridFilters _Filters;

    ///// <summary>
    ///// Массив фиксированных идентификаторов для выбора.
    ///// Если null (по умолчанию), то выбор осуществляется с помощью формы DocTableViewForm, включая табличку фильтров.
    ///// Если свойство установлено, то выбор осуществляется с помощью упрощенной формы
    ///// </summary>
    //public IdList FixedDocIds
    //{
    //  get { return _FixedDocIds; }
    //  set { _FixedDocIds = value; }
    //}
    //private IdList _FixedDocIds;

    /// <summary>
    /// Позиция вывода блока диалога.
    /// Может либо меняться существующий объект, либо быть передана ссылка на новый объект <see cref="EFPDialogPosition"/>.
    /// Используется в комбоблоках
    /// </summary>
    public EFPDialogPosition DialogPosition
    {
      get { return _DialogPosition; }
      set
      {
        if (value == null)
          _DialogPosition = new EFPDialogPosition();
        else
          _DialogPosition = value;
      }
    }
    private EFPDialogPosition _DialogPosition;

    #endregion

    #region Вывод блока диалога

    /// <summary>
    /// Выводит блок диалога.
    /// Возвращает <see cref="DialogResult.OK"/>, если пользователь сделал выбор, в том числе нажал кнопку "Нет".
    /// </summary>
    /// <returns>Результат выполнения</returns>
    public DialogResult ShowDialog()
    {
      DialogResult res = DialogResult.Cancel;
      using (SubDocTableViewForm form = new SubDocTableViewForm(SubDocTypeUI, DocSelectDialog.GetDocTableViewMode(SelectionMode), SubDocs))
      {
        form.Text = Title;
        form.CanBeEmpty = CanBeEmpty;
        try
        {
          if (MultiSelect)
            form.SelectedSubDocIds = SubDocIds;
          else
            form.CurrentSubDocId = SubDocId;
        }
        catch (Exception e)
        {
          EFPApp.ShowException(e, Res.SubDocSelectDialog_ErrTitle_InitSelection);
        }
        //Form.ExternalFilters = Filters;

        switch (EFPApp.ShowDialog(form, false, DialogPosition))
        {
          case DialogResult.OK:
            if (MultiSelect)
              SubDocIds = form.SelectedSubDocIds;
            else
              SubDocId = form.CurrentSubDocId;
            res = DialogResult.OK;
            break;
          case DialogResult.No:
            SubDocId = 0;
            res = DialogResult.OK;
            break;
        }
      }
      return res;
    }

    #endregion
  }
}
