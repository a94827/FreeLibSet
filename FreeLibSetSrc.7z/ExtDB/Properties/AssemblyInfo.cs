﻿// Part of FreeLibSet.
// See copyright notices in "license" file in the FreeLibSet root directory.

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ExtDB")]
[assembly: AssemblyDescription("Database specified classes. Uses ExtTools")]
[assembly: Guid("62a83186-d410-4c44-a420-d3e656f00188")]
