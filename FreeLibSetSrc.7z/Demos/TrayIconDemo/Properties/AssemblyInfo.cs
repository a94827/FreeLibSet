﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("TrayIconDemo")]
[assembly: AssemblyDescription("EFPAppTrayIcon usage demo")]
// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("e51be11a-9f69-4639-baba-0a04442c737e")]
