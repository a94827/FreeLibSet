﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("ExeFileInfoDemo")]
[assembly: AssemblyDescription("PE executable format explore demo")]
// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("aee63c76-84fc-4802-96aa-ee8297e1a94d")]
