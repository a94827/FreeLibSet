﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("EFPAppRemoteExitDemo")]
[assembly: AssemblyDescription("Closing client application by server demo. Two-in-one CS app")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("34ce7334-5a34-441a-9848-034b80c0395d")]

