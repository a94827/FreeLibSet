﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("EFPCommandItemsDemo")]
[assembly: AssemblyDescription("WinForms UI demo")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("c89a1538-4f0f-491d-9326-dbaa3ae77887")]

