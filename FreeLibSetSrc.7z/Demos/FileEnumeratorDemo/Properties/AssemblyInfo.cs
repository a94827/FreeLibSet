﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("FileEnumeratorDemo")]
[assembly: AssemblyDescription("AbsPathEnumerable & RelPathEnumerable demo")]
// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("195aed51-8dfb-4dac-9806-902980498993")]

