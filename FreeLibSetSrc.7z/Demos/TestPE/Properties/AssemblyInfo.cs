﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("TestPE")]
[assembly: AssemblyDescription("FileTools.Is64bitPE() function demo")]
// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("6b1df034-6966-45ea-9858-e329a873d9bf")]
