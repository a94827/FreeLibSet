﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("BRReportDemo")]
[assembly: AssemblyDescription("Print, preview, export and send-to demo for EFPDataGridView and EFPDataGridView")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("8c28b77e-630b-4c7a-b21a-3f4c381d6a8a")]
