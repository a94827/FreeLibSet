﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("RefEditDemo")]
[assembly: AssemblyDescription("Sample regedit (actually viewer) app")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("8fc2517a-275c-4866-8de9-dec173fb851a")]
