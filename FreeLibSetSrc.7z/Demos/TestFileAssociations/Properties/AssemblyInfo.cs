﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("TestFileAssociations")]
[assembly: AssemblyDescription("ExtTools FileAssociations class demo. Shows system file associations for a given file extension")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("21655bf3-ccb7-4b3b-b1a8-73a2b8cd71af")]
