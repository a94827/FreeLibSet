﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("EnvironmentInfo")]
[assembly: AssemblyDescription("EnvironmentTools demo")]
// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("b78c0b55-e822-4e19-a483-565aed8d0e85")]
