﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ExtForms")]
[assembly: AssemblyDescription("Windows Forms user interface extension. Uses ExtTools")]
[assembly: Guid("9f449ae4-292a-40af-a612-4e1748b2ab12")]
