﻿// Part of FreeLibSet.
// See copyright notices in "license" file in the FreeLibSet root directory.

using System;
using System.Data;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Diagnostics;
using System.ComponentModel;
using System.Collections;
using FreeLibSet.Data;
using FreeLibSet.Collections;
using FreeLibSet.Calendar;
using System.Globalization;

namespace FreeLibSet.Core
{
  /// <summary>
  /// Шаблонный класс, предназначенный для избегания боксинга структур.
  /// Содержит статическую ссылку на boxed-структуру, содержащую нулевое (дефолтное) значение.
  /// </summary>
  /// <typeparam name="T">Тип структуры</typeparam>
  public static class ZeroValue<T>
    where T : new()
  {
    /// <summary>
    /// boxed-объект с экземпляром структуры
    /// </summary>
    public static object Object = (object)(new T());
  }

  /// <summary>
  /// Вспомогательные функции при работе с данными
  /// </summary>
  public static partial class DataTools
  {
    #region Преобразование типов

    #region GetXXX()

    #region GetInt32()

    /// <summary>
    /// Возвращает значение поля как число.
    /// Если поле содержит <see cref="DBNull"/>, возвращается 0.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static int GetInt32(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        // Убрано 29.06.2020
        //if (row.IsNull(columnName))
        //  return 0;
        //else
        if (row.RowState == DataRowState.Deleted)
          return GetInt32(row[columnName, DataRowVersion.Original]);
        else
          return GetInt32(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(int));
      }
#endif
    }

#if DEBUG

    /// <summary>
    /// Перевыброс исключения при ошибке преобразования значения поля строки в методах GetXXX(<paramref name="row"/> , <paramref name="columnName"/>)
    /// </summary>
    /// <param name="e">Исходное исключение</param>
    /// <param name="row">Строка данных</param>
    /// <param name="columnName">Имя поля данных</param>
    /// <param name="resType"></param>
    private static Exception RecreateDataRowConvertException(Exception e, DataRow row, string columnName, Type resType)
    {
      if (row == null)
        return new ArgumentNullException("row");
      if (String.IsNullOrEmpty(columnName))
        return ExceptionFactory.ArgStringIsNullOrEmpty("columnName");

      if (row.Table == null)
        e.Data["Row.Table"] = "null";
      else
      {
        e.Data["Row.Table.TableName"] = row.Table.TableName;
        //if (!Row.Table.Columns.Contains(ColumnName))
        //  throw new ArgumentException("Таблица \"" + Row.Table.TableName + "\" не содержит столбца \"" + ColumnName + "\"", e);

        e.Data["ColumnName"] = columnName;
        e.Data["Row.RowState"] = row.RowState.ToString();

        if (row.Table.Columns.Contains(columnName))
        {
          try
          {
            object x;
            if (row.RowState == DataRowState.Deleted)
              x = row[columnName, DataRowVersion.Original];
            else
              x = row[columnName];
            if (x == null)
              e.Data["Row[" + columnName + "]"] = "null";
            else
            {
              e.Data["Row[\"" + columnName + "\"]"] = x.ToString();
              e.Data["Row[\"" + columnName + "\"].GetType()"] = x.GetType().ToString();
            }
          }
          catch { }
        }
      }

      e.Data["ResultType"] = resType.ToString();

      return e;
    }

#endif

    /// <summary>
    /// Тоже, что и <see cref="Convert.ToInt32(object)"/>, но <see cref="DBNull"/> и пустая строка преобразуются в 0, а не выбрасывают исключение.
    /// Тип <see cref="Boolean"/> преобразуется в значение 0 или 1.
    /// Строковый тип преобразуется с использованием <see cref="StdConvert.ToInt32(string)"/> и не зависит от <see cref="CultureInfo.CurrentCulture"/>.
    /// Остальные типы преобразуются с помощью <see cref="Convert.ToInt32(object)"/>.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Значение типа <see cref="Int32"/></returns>
    public static int GetInt32(object value)
    {
      if (value is DBNull)
        return 0;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return 0;
        else
          return StdConvert.ToInt32(s);
      }

      if (value is Boolean)
        if ((bool)value)
          return 1;
        else
          return 0;

      // 26.06.2025
      if (value is Single)
      {
        float v2 = (float)value;
        double v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt32(v3);
      }
      if (value is Double)
      {
        double v2 = (double)value;
        double v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt32(v3);
      }
      if (value is Decimal)
      {
        decimal v2 = (decimal)value;
        decimal v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt32(v3);
      }

      return Convert.ToInt32(value); // преобразуется, в том числе, значение null
    }

    /// <summary>
    /// Получение числового значения из <see cref="PropertyCollection"/>.
    /// Если коллекция не содержит свойства с именем <paramref name="propName"/>, то значение <paramref name="value"/> не изменяется.
    /// </summary>
    /// <param name="collection">Коллекция свойств</param>
    /// <param name="propName">Имя свойства</param>
    /// <param name="value">Значение</param>
    /// <returns>True, если значение прочитано, false, если оставлено без изменений</returns>
    public static bool GetInt32(PropertyCollection collection, string propName, ref int value)
    {
      object x = collection[propName];
      if (x == null)
        return false;
      value = GetInt32(x);
      return true;
    }

    /// <summary>
    /// Получение числового значения из <see cref="PropertyCollection"/>.
    /// Если коллекция не содержит свойства с именем <paramref name="propName"/>, то возвращается 0.
    /// </summary>
    /// <param name="collection">Коллекция свойств</param>
    /// <param name="propName">Имя свойства</param>
    /// <returns>Значение свойства</returns>
    public static int GetInt32(PropertyCollection collection, string propName)
    {
      return GetInt32(collection[propName]);
    }

    /// <summary>
    /// Преобразование значения в число или null.
    /// Для значений null, <see cref="DBNull"/> и пустой строки возвращается null. 
    /// Для других значений выполняется попытка преобразования
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Число или null</returns>
    public static int? GetNullableInt32(object value)
    {
      if (Object.ReferenceEquals(value, null))
        return null;
      if (value is DBNull)
        return null;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return null;
        else
          return StdConvert.ToInt32(s);
      }

      if (value is Boolean)
        if ((bool)value)
          return 1;
        else
          return 0;

      // 26.06.2025
      if (value is Single)
      {
        float v2 = (float)value;
        double v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt32(v3);
      }
      if (value is Double)
      {
        double v2 = (double)value;
        double v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt32(v3);
      }
      if (value is Decimal)
      {
        decimal v2 = (decimal)value;
        decimal v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt32(v3);
      }

      return Convert.ToInt32(value);
    }

    /// <summary>
    /// Возвращает значение поля как число.
    /// Если поле содержит <see cref="DBNull"/>, возвращается null.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static int? GetNullableInt32(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        if (row.RowState == DataRowState.Deleted)
          return GetNullableInt32(row[columnName, DataRowVersion.Original]);
        else
          return GetNullableInt32(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(int));
      }
#endif
    }

    #endregion

    #region GetInt64()

    /// <summary>
    /// Возвращает значение поля как число.
    /// Если поле содержит <see cref="DBNull"/>, возвращается 0.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static long GetInt64(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        // Убрано 29.06.2020
        //if (row.IsNull(columnName))
        //  return 0;
        //else
        if (row.RowState == DataRowState.Deleted)
          return GetInt64(row[columnName, DataRowVersion.Original]);
        else
          return GetInt64(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(long));
      }
#endif
    }


    /// <summary>
    /// Тоже, что и <see cref="Convert.ToInt64(object)"/>, но <see cref="DBNull"/> и пустая строка преобразуются в 0, а не выбрасывают исключение.
    /// Тип <see cref="Boolean"/> преобразуется в значение 0 или 1.
    /// Строковый тип преобразуется с использованием <see cref="StdConvert.ToInt64(string)"/> и не зависит от <see cref="CultureInfo.CurrentCulture"/>.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Значение типа <see cref="Int64"/></returns>
    public static long GetInt64(object value)
    {
      if (value is DBNull)
        return 0L;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return 0L;
        else
          return StdConvert.ToInt64(s);
      }

      if (value is Boolean)
        if ((bool)value)
          return 1L;
        else
          return 0L;

      // 26.06.2025
      if (value is Single)
      {
        float v2 = (float)value;
        double v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt64(v3);
      }
      if (value is Double)
      {
        double v2 = (double)value;
        double v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt64(v3);
      }
      if (value is Decimal)
      {
        decimal v2 = (decimal)value;
        decimal v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt64(v3);
      }

      return Convert.ToInt64(value); // преобразуется, в том числе, значение null
    }

    /// <summary>
    /// Получение числового значения из <see cref="PropertyCollection"/>.
    /// Если коллекция не содержит свойства с именем <paramref name="propName"/>, то значение <paramref name="value"/> не изменяется.
    /// </summary>
    /// <param name="collection">Коллекция свойств</param>
    /// <param name="propName">Имя свойства</param>
    /// <param name="value">Значение</param>
    /// <returns>True, если значение прочитано, false, если оставлено без изменений</returns>
    public static bool GetInt64(PropertyCollection collection, string propName, ref long value)
    {
      object x = collection[propName];
      if (x == null)
        return false;
      value = GetInt64(x);
      return true;
    }

    /// <summary>
    /// Получение числового значения из <see cref="PropertyCollection"/>.
    /// Если коллекция не содержит свойства с именем <paramref name="propName"/>, то возвращается 0.
    /// </summary>
    /// <param name="collection">Коллекция свойств</param>
    /// <param name="propName">Имя свойства</param>
    /// <returns>Значениес свойства</returns>
    public static long GetInt64(PropertyCollection collection, string propName)
    {
      return GetInt64(collection[propName]);
    }

    /// <summary>
    /// Преобразование значения в число или null.
    /// Для значений null, <see cref="DBNull"/> и пустой строки возвращается null. 
    /// Для других значений выполняется попытка преобразования.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Число или null</returns>
    public static long? GetNullableInt64(object value)
    {
      if (Object.ReferenceEquals(value, null))
        return null;
      if (value is DBNull)
        return null;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return null;
        else
          return StdConvert.ToInt64(s);
      }

      if (value is Boolean)
        if ((bool)value)
          return 1L;
        else
          return 0L;

      // 26.06.2025
      if (value is Single)
      {
        float v2 = (float)value;
        double v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt64(v3);
      }
      if (value is Double)
      {
        double v2 = (double)value;
        double v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt64(v3);
      }
      if (value is Decimal)
      {
        decimal v2 = (decimal)value;
        decimal v3 = (Math.Round(v2, 0, MidpointRounding.AwayFromZero));
        return Convert.ToInt64(v3);
      }

      return Convert.ToInt64(value);
    }

    /// <summary>
    /// Возвращает значение поля как число.
    /// Если поле содержит <see cref="DBNull"/>, возвращается null.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static long? GetNullableInt64(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        if (row.RowState == DataRowState.Deleted)
          return GetNullableInt64(row[columnName, DataRowVersion.Original]);
        else
          return GetNullableInt64(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(int));
      }
#endif
    }


    #endregion

    #region GetSingle()

    /// <summary>
    /// Возвращает значение поля как число.
    /// Если поле содержит <see cref="DBNull"/>, возвращается 0.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static float GetSingle(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        // Убрано 29.06.2020
        //if (row.IsNull(columnName))
        //  return 0f;
        //else
        if (row.RowState == DataRowState.Deleted)
          return GetSingle(row[columnName, DataRowVersion.Original]);
        else
          return GetSingle(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(float));
      }
#endif
    }


    /// <summary>
    /// Тоже, что и <see cref="Convert.ToSingle(object)"/>, но пустая строка и <see cref="DBNull"/> преобразуются в 0, а не выбрасывают исключение.
    /// Тип <see cref="Boolean"/> преобразуется в значение 0 или 1.
    /// Строковый тип преобразуется с использованием <see cref="StdConvert.ToSingle(string)"/> и не зависит от <see cref="CultureInfo.CurrentCulture"/>.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Значение типа <see cref="Single"/></returns>
    public static float GetSingle(object value)
    {
      if (value is Boolean)
        if ((bool)value)
          return 1f;
        else
          return 0f;

      if (value is DBNull)
        return 0f;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return 0f;
        else
          return StdConvert.ToSingle(s);
      }

      return Convert.ToSingle(value); // преобразуется, в том числе, значение null
    }

    /// <summary>
    /// Преобразование значения в число или null.
    /// Для значений null, <see cref="DBNull"/> и пустой строки возвращается null. 
    /// Для других значений выполняется попытка преобразования.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Число или null</returns>
    public static float? GetNullableSingle(object value)
    {
      if (Object.ReferenceEquals(value, null))
        return null;
      if (value is DBNull)
        return null;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return null;
        else
          return StdConvert.ToSingle(s);
      }

      if (value is Boolean)
        if ((bool)value)
          return 1f;
        else
          return 0f;

      return Convert.ToSingle(value);
    }

    /// <summary>
    /// Возвращает значение поля как число.
    /// Если поле содержит <see cref="DBNull"/>, возвращается null.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static float? GetNullableSingle(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        if (row.RowState == DataRowState.Deleted)
          return GetNullableSingle(row[columnName, DataRowVersion.Original]);
        else
          return GetNullableSingle(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(int));
      }
#endif
    }


    #endregion

    #region GetDouble()

    /// <summary>
    /// Возвращает значение поля как число.
    /// Если поле содержит <see cref="DBNull"/>, возвращается 0.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static double GetDouble(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        // Убрано 29.06.2020
        //if (row.IsNull(columnName))
        //  return 0.0;
        //else
        if (row.RowState == DataRowState.Deleted)
          return GetDouble(row[columnName, DataRowVersion.Original]);
        else
          return GetDouble(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(double));
      }
#endif
    }


    /// <summary>
    /// Тоже, что и <see cref="Convert.ToDouble(object)"/>, но пустая строка и <see cref="DBNull"/> преобразуются в 0, а не выбрасывают исключение.
    /// Тип <see cref="Boolean"/> преобразуется в значение 0 или 1.
    /// Строковый тип преобразуется с использованием <see cref="StdConvert.ToDouble(string)"/> и не зависит от <see cref="CultureInfo.CurrentCulture"/>.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Значение типа <see cref="Double"/></returns>
    public static double GetDouble(object value)
    {
      if (value is Boolean)
        if ((bool)value)
          return 1.0;
        else
          return 0.0;

      if (value is DBNull)
        return 0.0;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return 0.0;
        else
          return StdConvert.ToDouble(s);
      }

      return Convert.ToDouble(value); // преобразуется, в том числе, значение null
    }

    /// <summary>
    /// Преобразование значения в число или null.
    /// Для значений null, <see cref="DBNull"/> и пустой строки возвращается null. 
    /// Для других значений выполняется попытка преобразования.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Число или null</returns>
    public static double? GetNullableDouble(object value)
    {
      if (Object.ReferenceEquals(value, null))
        return null;
      if (value is DBNull)
        return null;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return null;
        else
          return StdConvert.ToDouble(s);
      }

      if (value is Boolean)
        if ((bool)value)
          return 1.0;
        else
          return 0.0;

      return Convert.ToDouble(value);
    }

    /// <summary>
    /// Возвращает значение поля как число.
    /// Если поле содержит <see cref="DBNull"/>, возвращается null.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static double? GetNullableDouble(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        if (row.RowState == DataRowState.Deleted)
          return GetNullableDouble(row[columnName, DataRowVersion.Original]);
        else
          return GetNullableDouble(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(int));
      }
#endif
    }

    #endregion

    #region GetDecimal()

    /// <summary>
    /// Возвращает значение поля как число.
    /// Если поле содержит <see cref="DBNull"/>, возвращается 0.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static decimal GetDecimal(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        // Убрано 29.06.2020
        //if (row.IsNull(columnName))
        //  return 0;
        //else
        if (row.RowState == DataRowState.Deleted)
          return GetDecimal(row[columnName, DataRowVersion.Original]);
        else
          return GetDecimal(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(decimal));
      }
#endif
    }

    /// <summary>
    /// Тоже, что и <see cref="Convert.ToDecimal(object)"/>, но пустая строка и <see cref="DBNull"/> преобразуются в 0m, а не выбрасывают исключение.
    /// Тип <see cref="Boolean"/> преобразуется в значение 0 или 1.
    /// Строковый тип преобразуется с использованием <see cref="StdConvert.ToDecimal(string)"/> и не зависит от <see cref="CultureInfo.CurrentCulture"/>.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Значение типа <see cref="Decimal"/></returns>
    public static decimal GetDecimal(object value)
    {
      if (value is Boolean)
        if ((bool)value)
          return 1m;
        else
          return 0m;

      if (value is DBNull)
        return 0m;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return 0m;
        else
          return StdConvert.ToDecimal(s);
      }

      return Convert.ToDecimal(value); // преобразуется, в том числе, значение null
    }

    /// <summary>
    /// Преобразование значения в число или null.
    /// Для значений null, <see cref="DBNull"/> и пустой строки возвращается null. 
    /// Для других значений выполняется попытка преобразования.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Число или null</returns>
    public static decimal? GetNullableDecimal(object value)
    {
      if (Object.ReferenceEquals(value, null))
        return null;
      if (value is DBNull)
        return null;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return null;
        else
          return StdConvert.ToDecimal(s);
      }

      if (value is Boolean)
        if ((bool)value)
          return 1m;
        else
          return 0m;

      return Convert.ToDecimal(value);
    }

    /// <summary>
    /// Возвращает значение поля как число.
    /// Если поле содержит <see cref="DBNull"/>, возвращается null.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static decimal? GetNullableDecimal(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        if (row.RowState == DataRowState.Deleted)
          return GetNullableDecimal(row[columnName, DataRowVersion.Original]);
        else
          return GetNullableDecimal(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(int));
      }
#endif
    }

    #endregion

    #region GetBoolean()

    /// <summary>
    /// Возвращает значение поля как значение <see cref="Boolean"/>.
    /// Если поле содержит <see cref="DBNull"/>, возвращается false.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static bool GetBoolean(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        // Убрано 29.06.2020
        //if (row.IsNull(columnName))
        //  return false;
        //else
        if (row.RowState == DataRowState.Deleted)
          return GetBoolean(row[columnName, DataRowVersion.Original]);
        else
          return GetBoolean(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(bool));
      }
#endif
    }


    /// <summary>
    /// Тоже, что и <see cref="Convert.ToBoolean(object)"/>, но пустая строка и <see cref="DBNull"/> преобразуются в false, а не выбрасывают исключение.
    /// Для типа <see cref="String"/> воспринимаются значения "0" и "1".
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Значение типа <see cref="Boolean"/></returns>
    public static bool GetBoolean(object value)
    {
      if (value is DBNull)
        return false;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return false;
        switch (s)
        {
          case "0": return false;
          case "1": return true;
          default: return Convert.ToBoolean(s);
        }
      }

      return Convert.ToBoolean(value); // преобразуется, в том числе, значение null
    }

    // Без боксинга. Не уверен, что нужен такой метод
    internal static readonly object TrueObject = true;
    internal static readonly object FalseObject = false;

    internal static object GetBooleanObject(object value)
    {
      if (GetBoolean(value))
        return TrueObject;
      else
        return FalseObject;
    }

    #endregion

    #region GetString()

    /// <summary>
    /// Возвращает значение поля как строку.
    /// Если поле содержит <see cref="DBNull"/>, возвращается пустая строка.
    /// Подробности см. в описании перегрузки <see cref="GetString(Object)"/>.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static string GetString(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        // Убрано 29.06.2020
        //if (row.IsNull(columnName))
        //  return String.Empty;
        //else
        if (row.RowState == DataRowState.Deleted)
          return GetString(row[columnName, DataRowVersion.Original]);
        else
          return GetString(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(string));
      }
#endif
    }

    /// <summary>
    /// Преобразование произвольного значения в строку.
    /// null преобразуется в пустую строку.
    /// <see cref="DBNull"/> преобразуется в пустую строку.
    /// Строковый тип обрезается вызовом <see cref="String.Trim()"/>.
    /// Тип <see cref="DateTime"/> преобразуется с помощью <see cref="StdConvert"/>.
    /// Числовые значения и другие типы, реализующие интерфейс <see cref="IConvertible"/>, преобразуются с использованием <see cref="StdConvert.NumberFormat"/>.
    /// Для прочих типов используется обычное преобразование с помощью <see cref="Object.ToString()"/>.
    /// 
    /// Обычно следует использовать методы <see cref="Object.ToString()"/> или <see cref="Convert.ToString(Object)"/>.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Строкое значение</returns>
    public static string GetString(object value)
    {
      if (value == null)
        return String.Empty;
      if (value is DBNull)
        return String.Empty;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
        return s.Trim();

      if (value is DateTime)
      {
        DateTime dt = (DateTime)value;
        return StdConvert.ToString(dt, true); // 16.05.2023
      }

      IConvertible value2 = value as IConvertible;
      if (value2 != null)
        return value2.ToString(StdConvert.NumberFormat); // 16.05.2023

      return value.ToString();
    }

    #endregion

    #region GetDateTime()

    /// <summary>
    /// Получает объект <see cref="DateTime"/> в пределах суток 01.01.0001.
    /// Если <paramref name="value"/> превышает 86400 секунд, берется значение по модулю.
    /// Отрицательных значения заменяются, например, если <paramref name="value"/> равно минус 15 минут, то возвращается 01.01.0001 23:45
    /// </summary>
    /// <param name="value">Произвольный интервал времени</param>
    /// <returns>Значение в пределах даты <see cref="DateTime.MinValue"/></returns>
    public static DateTime GetDateTime(TimeSpan value)
    {
      long ticks = value.Ticks % TimeSpan.TicksPerDay;
      // Значение может быть положительным или отрицательным
      if (ticks < 0L)
        ticks += TimeSpan.TicksPerDay;
      return new DateTime(ticks);
    }

    /// <summary>
    /// Получает объект <see cref="DateTime"/> в пределах суток указанной даты <paramref name="date"/>.
    /// Если <paramref name="value"/> превышает 86400 секунд, берется значение по модулю.
    /// Отрицательных значения заменяются, например, если <paramref name="value"/> равно минус 15 минут, то возвращается 23:45.
    /// </summary>
    /// <param name="value">Произвольный интервал времени</param>
    /// <param name="date">Базовая дата. Берется только дата, компонент времени игнорируется</param>
    /// <returns>Значение в пределах даты <paramref name="date"/></returns>
    public static DateTime GetDateTime(TimeSpan value, DateTime date)
    {
      long ticks = value.Ticks % TimeSpan.TicksPerDay;
      // Значение может быть положительным или отрицательным
      if (ticks < 0L)
        ticks += TimeSpan.TicksPerDay;
      return new DateTime(date.Date.Ticks + ticks);
    }

    /// <summary>
    /// Преобразование значения в тип <see cref="DateTime"/> без значения null.
    /// Значения null и <see cref="DBNull"/> преобразуется в <see cref="DateTime.MinValue"/>.
    /// Пустая строка также преобразуется в <see cref="DateTime.MinValue"/>, для непустой строки выполняется попытка преобразования с помощью <see cref="StdConvert.ToDateTime(string, bool)"/>.
    /// Для остальных типов будет выброшено исключение. 
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Результат преобразования</returns>
    public static DateTime GetDateTime(object value)
    {
      if (value == null)
        return new DateTime();
      if (value is DBNull)
        return new DateTime();
      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return new DateTime();
        else
          return StdConvert.ToDateTime(s, true);
      }
      if (value is TimeSpan)
        return GetDateTime((TimeSpan)value); // 16.05.2023
      return Convert.ToDateTime(value);
    }

    /// <summary>
    /// Возвращает значение поля как <see cref="DateTime"/>.
    /// Если поле содержит <see cref="DBNull"/>, возвращается неинициализированная дата.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static DateTime GetDateTime(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        // Убрано 29.06.2020
        //if (row.IsNull(columnName))
        //  return new DateTime();
        //else
        if (row.RowState == DataRowState.Deleted)
          return GetDateTime(row[columnName, DataRowVersion.Original]);
        else
          return GetDateTime((row[columnName])); // исправлено 15.12.2021

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(DateTime));
      }
#endif
    }

    /// <summary>
    /// Преобразование значения в тип <see cref="Nullable{DateTime}"/>.
    /// Значения null и <see cref="DBNull"/> преобразуется в null.
    /// Пустая строка преобразуется в null, иначе выполняется попытка преобразования с помощью <see cref="StdConvert.ToDateTime(string, bool)"/>.
    /// Для остальных типов будет выброшено исключение. 
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Результат преобразования</returns>
    public static Nullable<DateTime> GetNullableDateTime(object value)
    {
      if (value == null)
        return null;
      if (value is DBNull)
        return null;
      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return null;
        else
          return StdConvert.ToDateTime(s, true);
      }
      if (value is TimeSpan)
        return GetDateTime((TimeSpan)value); // 16.05.2023
      return Convert.ToDateTime(value);
    }

    /// <summary>
    /// Возвращает значение поля как <see cref="Nullable{DateTime}"/>.
    /// Если поле содержит <see cref="DBNull"/>, возвращается null.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static Nullable<DateTime> GetNullableDateTime(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        //Убрано 29.06.2020
        //if (row.IsNull(columnName))
        //  return null;
        //else
        if (row.RowState == DataRowState.Deleted)
          return GetNullableDateTime(row[columnName, DataRowVersion.Original]);
        else
          return GetNullableDateTime(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(DateTime?));
      }
#endif
    }

    #endregion

    #region GetTimeSpan()

    /// <summary>
    /// Преобразование значения в тип <see cref="TimeSpan"/>.
    /// Значения null, <see cref="DBNull"/> и пустая строка преобразуется в <see cref="TimeSpan.Zero"/>. 
    /// Для непустой строки возвращается <see cref="StdConvert.ToTimeSpan(string)"/>.
    /// <see cref="TimeSpan"/> возвращается без преобразования.
    /// Для <see cref="DateTime"/> извлекается компонент времени <see cref="DateTime.TimeOfDay"/>.
    /// Для остальных типов будет выброшено исключение <see cref="InvalidCastException"/>.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Результат преобразования</returns>
    public static TimeSpan GetTimeSpan(object value)
    {
      if (value == null)
        return TimeSpan.Zero;
      if (value is DBNull)
        return TimeSpan.Zero;
      if (value is TimeSpan)
        return (TimeSpan)value;
      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return TimeSpan.Zero;
        else
          return StdConvert.ToTimeSpan(s);
      }
      if (value is DateTime)
        return ((DateTime)value).TimeOfDay; // 16.05.2023
      throw ExceptionFactory.Inconvertible(value, typeof(TimeSpan));
    }

    /// <summary>
    /// Возвращает значение поля как интервал времени.
    /// Если поле содержит <see cref="DBNull"/>, возвращается <see cref="TimeSpan.Zero"/>.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static TimeSpan GetTimeSpan(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        // Убрано 29.06.2020
        //if (row.IsNull(columnName))
        //  return TimeSpan.Zero;
        //else
        if (row.RowState == DataRowState.Deleted)
          return GetTimeSpan(row[columnName, DataRowVersion.Original]);
        else
          return GetTimeSpan(row[columnName]); // исправлено 15.12.2021

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(TimeSpan));
      }
#endif
    }

    #endregion

    #region GetGuid()

    /// <summary>
    /// Возвращает значение поля как <see cref="Guid"/>.
    /// Если поле содержит <see cref="DBNull"/>, возвращается <see cref="Guid.Empty"/>.
    /// Поле может содержать <see cref="Guid"/>, строку или массив байт.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static Guid GetGuid(DataRow row, string columnName)
    {
#if DEBUG
      try
      {
#endif

        // Убрано 29.06.2020
        //if (row.IsNull(columnName))
        //  return Guid.Empty;
        //else
        if (row.RowState == DataRowState.Deleted)
          return GetGuid(row[columnName, DataRowVersion.Original]);
        else
          return GetGuid(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(Guid));
      }
#endif
    }


    /// <summary>
    /// Преобразование значения в Guid.
    /// Допускаются значения <see cref="Guid"/>, <see cref="String"/> и <see cref="Byte"/>[16].
    /// Для значений null, <see cref="DBNull"/> и пустой строки возвращается <see cref="Guid.Empty"/>.
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Значение типа <see cref="Guid"/></returns>
    public static Guid GetGuid(object value)
    {
      if (value == null || value is DBNull)
        return Guid.Empty;

      if (value is Guid)
        return (Guid)value;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return Guid.Empty;
        else
          return StdConvert.ToGuid(s);
      }

      if (value is byte[])
        return new Guid((byte[])value);

      throw ExceptionFactory.Inconvertible(value, typeof(Guid));
    }

    /// <summary>
    /// Получение  значения <see cref="Guid"/> из <see cref="PropertyCollection"/>.
    /// Если коллекция не содержит свойства с именем <paramref name="propName"/>, то значение <paramref name="value"/> не изменяется.
    /// </summary>
    /// <param name="collection">Коллекция свойств</param>
    /// <param name="propName">Имя свойства</param>
    /// <param name="value">Значение</param>
    /// <returns>True, если значение прочитано, false, если оставлено без изменений</returns>
    public static bool GetGuid(PropertyCollection collection, string propName, ref Guid value)
    {
      object x = collection[propName];
      if (x == null)
        return false;
      value = GetGuid(x);
      return true;
    }

    /// <summary>
    /// Получение числового значения из <see cref="PropertyCollection"/>.
    /// Если коллекция не содержит свойства с именем <paramref name="propName"/>, то возвращается <see cref="Guid.Empty"/>.
    /// </summary>
    /// <param name="collection">Коллекция свойств</param>
    /// <param name="propName">Имя свойства</param>
    /// <returns>Значениес свойства</returns>
    public static Guid GetGuid(PropertyCollection collection, string propName)
    {
      return GetGuid(collection[propName]);
    }

    #endregion

    #region GetEnum()

    /// <summary>
    /// Возвращает значение поля как значение перечисления.
    /// Если поле содержит <see cref="DBNull"/>, возвращается нулевое значение для перечисления (default).
    /// Поле может содержать целочисленное значение или строку.
    /// Поддерживаются строки в состоянии <see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>.
    /// </summary>
    /// <typeparam name="T">Тип перечисления</typeparam>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Значение поля</returns>
    public static T GetEnum<T>(DataRow row, string columnName)
      where T : struct
    {
#if DEBUG
      try
      {
#endif

        if (row.RowState == DataRowState.Deleted)
          return GetEnum<T>(row[columnName, DataRowVersion.Original]);
        else
          return GetEnum<T>(row[columnName]);

#if DEBUG
      }
      catch (Exception e)
      {
        throw RecreateDataRowConvertException(e, row, columnName, typeof(Guid));
      }
#endif
    }


    /// <summary>
    /// Преобразование значения в перечисление.
    /// Допускаются значения типа <typeparamref name="T"/>, <see cref="Int32"/> или <see cref="String"/>.
    /// Для значений null, <see cref="DBNull"/> и пустой строки возвращается нулевое значение для перечисления (default).
    /// </summary>
    /// <param name="value">Преобразуемое значение</param>
    /// <returns>Значение перечислимого типа</returns>
    public static T GetEnum<T>(object value)
      where T : struct
    {
      if (value == null || value is DBNull)
        return default(T);

      if (value is T)
        return (T)value;

      string s = value as string;
      if (!Object.ReferenceEquals(s, null))
      {
        if (s.Length == 0)
          return default(T);
        else
          return StdConvert.ToEnum<T>(s);
      }

      int v2 = GetInt32(value);
      return (T)Enum.ToObject(typeof(T), v2);
    }

    /// <summary>
    /// Получение перечислимого значения из <see cref="PropertyCollection"/>.
    /// Если коллекция не содержит свойства с именем <paramref name="propName"/>, то значение <paramref name="value"/> не изменяется.
    /// </summary>
    /// <param name="collection">Коллекция свойств</param>
    /// <param name="propName">Имя свойства</param>
    /// <param name="value">Значение</param>
    /// <returns>True, если значение прочитано, false, если оставлено без изменений</returns>
    public static bool GetEnum<T>(PropertyCollection collection, string propName, ref T value)
      where T : struct
    {
      object x = collection[propName];
      if (x == null)
        return false;
      value = GetEnum<T>(x);
      return true;
    }

    /// <summary>
    /// Получение числового значения из <see cref="PropertyCollection"/>.
    /// Если коллекция не содержит свойства с именем <paramref name="propName"/>, то возвращается <see cref="Guid.Empty"/>.
    /// </summary>
    /// <param name="collection">Коллекция свойств</param>
    /// <param name="propName">Имя свойства</param>
    /// <returns>Значениес свойства</returns>
    public static T GetEnum<T>(PropertyCollection collection, string propName)
      where T : struct
    {
      return GetEnum<T>(collection[propName]);
    }

    #endregion

    #endregion

    #region SetXXX()

    #region SetString()

    /// <summary>
    /// Установка строки в поле. При этом выполняется обрезка строки
    /// до длины <see cref="DataColumn.MaxLength"/>. 
    /// Для пустой строки <paramref name="value"/> выполняется преобразование в <see cref="DBNull"/> 
    /// строки, если <see cref="DataColumn.AllowDBNull"/>=true. Если <see cref="DataColumn.AllowDBNull"/>=false,
    /// записывается значение по умолчанию для заданного типа.
    /// </summary>
    /// <param name="row">Строка данных, куда выполняется запись</param>
    /// <param name="columnName">Имя столбца</param>
    /// <param name="value">Записываемое значение</param>
    public static void SetString(DataRow row, string columnName, string value)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif
      DataColumn col = row.Table.Columns[columnName];
#if DEBUG
      if (col == null)
        throw ExceptionFactory.ArgUnknownColumnName("columnName", row.Table, columnName);
#endif

      if (String.IsNullOrEmpty(value))
        DoClearColumnValue(row, col);
      else
      {
        //int l = col.MaxLength;
        //if (l >= 0 && l < value.Length)
        //  row[columnName] = value.Substring(0, l);
        //else
        //  row[columnName] = value;

        // 20.06.2025
        object value2 = value;
        if (col.DataType == typeof(string) || col.DataType == null)
        {
          int l = col.MaxLength;
          if (l >= 0 && l < value.Length)
            value2 = value.Substring(0, l);
        }
        else
          value2 = StdConvert.ChangeType(value, col.DataType);
        row[columnName] = value2;
      }
    }

    private static void DoClearColumnValue(DataRow row, DataColumn col)
    {
      if (col.AllowDBNull)
        row[col] = DBNull.Value;
      else if (col.DefaultValue != null)
        row[col] = col.DefaultValue; // 24.06.2025
      else
      {
        // row[columnName] = "";
        // 20.06.2025
        object v0 = DataTools.GetEmptyValue(col.DataType);
        if (v0 == null)
          v0 = String.Empty;
        row[col] = v0;
      }
    }

    #endregion

    #region SetInt32()

    /// <summary>
    /// Установка числового значения поля. Выполняет преобразование значения в
    /// конкретный тип поля. Для нулевого значения выполняет преобразование в <see cref="DBNull"/>,
    /// если <see cref="DataColumn.AllowDBNull"/>=true.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя записываемого поля</param>
    /// <param name="value">Записываемое значение</param>
    public static void SetInt32(DataRow row, string columnName, int value)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif
      DataColumn col = row.Table.Columns[columnName];
#if DEBUG
      if (col == null)
        throw ExceptionFactory.ArgUnknownColumnName("columnName", row.Table, columnName);
#endif

      if (value == 0)
        DoClearColumnValue(row, col);
      else
      {
        Type t = col.DataType ?? typeof(string);
        row[columnName] = StdConvert.ChangeType(value, t);
      }
    }

    #endregion

    #region SetInt64()

    /// <summary>
    /// Установка числового значения поля. Выполняет преобразование значения в
    /// конкретный тип поля. Для нулевого значения выполняет преобразование в <see cref="DBNull"/>,
    /// если <see cref="DataColumn.AllowDBNull"/>=true.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя записываемого поля</param>
    /// <param name="value">Записываемое значение</param>
    public static void SetInt64(DataRow row, string columnName, long value)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif
      DataColumn col = row.Table.Columns[columnName];
#if DEBUG
      if (col == null)
        throw ExceptionFactory.ArgUnknownColumnName("columnName", row.Table, columnName);
#endif

      if (value == 0L)
        DoClearColumnValue(row, col);
      else
      {
        Type t = col.DataType ?? typeof(string);
        row[columnName] = StdConvert.ChangeType(value, t);
      }
    }

    #endregion

    #region SetSingle()

    /// <summary>
    /// Установка числового значения поля. Выполняет преобразование значения в
    /// конкретный тип поля. Для нулевого значения выполняет преобразование в <see cref="DBNull"/>,
    /// если <see cref="DataColumn.AllowDBNull"/>=true.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя записываемого поля</param>
    /// <param name="value">Записываемое значение</param>
    public static void SetSingle(DataRow row, string columnName, float value)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif
      DataColumn col = row.Table.Columns[columnName];
#if DEBUG
      if (col == null)
        throw ExceptionFactory.ArgUnknownColumnName("columnName", row.Table, columnName);
#endif

      if (value == 0f)
        DoClearColumnValue(row, col);
      else
      {
        Type t = col.DataType ?? typeof(string);
        row[columnName] = StdConvert.ChangeType(value, t);
      }
    }

    #endregion

    #region SetDouble()

    /// <summary>
    /// Установка числового значения поля. Выполняет преобразование значения в
    /// конкретный тип поля. Для нулевого значения выполняет преобразование в <see cref="DBNull"/>,
    /// если <see cref="DataColumn.AllowDBNull"/>=true.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя записываемого поля</param>
    /// <param name="value">Записываемое значение</param>
    public static void SetDouble(DataRow row, string columnName, double value)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif
      DataColumn col = row.Table.Columns[columnName];
#if DEBUG
      if (col == null)
        throw ExceptionFactory.ArgUnknownColumnName("columnName", row.Table, columnName);
#endif

      if (value == 0.0)
        DoClearColumnValue(row, col);
      else
      {
        Type t = col.DataType ?? typeof(string);
        row[columnName] = StdConvert.ChangeType(value, t);
      }
    }

    #endregion

    #region SetDecimal()

    /// <summary>
    /// Установка числового значения поля. Выполняет преобразование значения в
    /// конкретный тип поля. Для нулевого значения выполняет преобразование в <see cref="DBNull"/>,
    /// если <see cref="DataColumn.AllowDBNull"/>=true.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя записываемого поля</param>
    /// <param name="value">Записываемое значение</param>
    public static void SetDecimal(DataRow row, string columnName, decimal value)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif
      DataColumn col = row.Table.Columns[columnName];
#if DEBUG
      if (col == null)
        throw ExceptionFactory.ArgUnknownColumnName("columnName", row.Table, columnName);
#endif

      if (value == 0m)
        DoClearColumnValue(row, col);
      else
      {
        Type t = col.DataType ?? typeof(string);
        row[columnName] = StdConvert.ChangeType(value, t);
      }
    }

    #endregion

    #region SetNullableDateTime()

    /// <summary>
    /// Установка значения поля типа Дата/Время. 
    /// Для значения null выполняет преобразование в <see cref="DBNull"/>,
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя записываемого поля</param>
    /// <param name="value">Записываемое значение</param>
    public static void SetNullableDateTime(DataRow row, string columnName, Nullable<DateTime> value)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif
      DataColumn col = row.Table.Columns[columnName];
#if DEBUG
      if (col == null)
        throw ExceptionFactory.ArgUnknownColumnName("columnName", row.Table, columnName);
#endif

      if (col.DataType == typeof(DateTime))
      {
        if (value.HasValue)
          row[columnName] = value.Value;
        else
          row[columnName] = DBNull.Value;
        return;
      }
      if (col.DataType == typeof(String))
      {
        // Для текстового столбца выполняем преобразование, кроме нулевого значения
        if (value.HasValue)
          SetString(row, columnName, StdConvert.ToString(value.Value, true));
        else
          SetString(row, columnName, null);
        return;
      }
      throw ExceptionFactory.ArgInvalidColumnType("columnName", col);
    }

    #endregion

    #region SetTimeSpan()

    /// <summary>
    /// Установка значения поля типа <see cref="TimeSpan"/> или <see cref="String"/>. 
    /// Для нулевого значения выполняет преобразование в <see cref="DBNull"/>,
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя записываемого поля</param>
    /// <param name="value">Записываемое значение</param>
    public static void SetTimeSpan(DataRow row, string columnName, TimeSpan value)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif
      DataColumn col = row.Table.Columns[columnName];
#if DEBUG
      if (col == null)
        throw ExceptionFactory.ArgUnknownColumnName("columnName", row.Table, columnName);
#endif

      if (value.Ticks == 0L)
        DoClearColumnValue(row, col);
      else
      {
        if (col.DataType == typeof(TimeSpan))
        {
          row[columnName] = value;
          return;
        }
        if (col.DataType == typeof(String))
        {
          // Для текстового столбца выполняем преобразование, кроме нулевого значения
          SetString(row, columnName, StdConvert.ToString(value));
          return;
        }
        throw ExceptionFactory.ArgInvalidColumnType("columnName", col);
      }
    }

    #endregion

    #region SetGuid()

    /// <summary>
    /// Установка значения поля типа <see cref="Guid"/>, <see cref="String"/> или <see cref="Byte"/>[], в зависимости от типа поля.
    /// Для значения <see cref="Guid.Empty"/> записывается значение <see cref="DBNull"/>.
    /// </summary>
    /// <param name="row">Строка</param>
    /// <param name="columnName">Имя записываемого поля</param>
    /// <param name="value">Записываемое значение</param>
    public static void SetGuid(DataRow row, string columnName, Guid value)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif
      DataColumn col = row.Table.Columns[columnName];
#if DEBUG
      if (col == null)
        throw ExceptionFactory.ArgUnknownColumnName("columnName", row.Table, columnName);
#endif
      if (value == Guid.Empty)
        row[columnName] = DBNull.Value;
      else
      {
        if (col.DataType == typeof(Guid))
          row[columnName] = value;
        else if (col.DataType == typeof(string))
          row[columnName] = StdConvert.ToString(value);
        else if (col.DataType == typeof(byte[]))
          row[columnName] = value.ToByteArray();
        else
          throw ExceptionFactory.ArgInvalidColumnType("columnName", col);
      }
    }

    #endregion

    #endregion

    #endregion

    #region Инкремент значения

    // Не стоит все методы называть одинаково ("Inc"), т.к. легко перепутать тип
    // и получить ошибку округления

    #region IncInt32

    /// <summary>
    /// Увеличение значения поля типа <see cref="Int32"/>
    /// </summary>
    /// <param name="row">Изменяемая строка (объект <see cref="DataRow"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncInt32(DataRow row, string columnName, int delta)
    {
      if (delta == 0)
        return;
      int v = GetInt32(row, columnName);
      checked { v += delta; }
      row[columnName] = v;
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="Int32"/> на значение того же поля в другой 
    /// строке. Применяется для расчета итоговых строк.
    /// </summary>
    /// <param name="srcRow">Строка, содержащее прибавляемое значение</param>
    /// <param name="dstRow">Изменяемая (итоговая) строка</param>
    /// <param name="columnName">Имя поля</param>
    public static void IncInt32(DataRow srcRow, DataRow dstRow, string columnName)
    {
      int v = GetInt32(srcRow, columnName);
      IncInt32(dstRow, columnName, v);
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="Int32"/>
    /// </summary>
    /// <param name="drv">Изменяемая строка (объект <see cref="DataRowView"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncInt32(DataRowView drv, string columnName, int delta)
    {
      if (delta == 0)
        return;
      int v = GetInt32(drv[columnName]);
      checked { v += delta; }
      drv[columnName] = v;
    }

    #endregion

    #region IncInt64

    /// <summary>
    /// Увеличение значения поля типа <see cref="Int64"/>
    /// </summary>
    /// <param name="row">Изменяемая строка (объект <see cref="DataRow"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncInt64(DataRow row, string columnName, long delta)
    {
      if (delta == 0)
        return;
      long v = GetInt64(row, columnName);
      checked { v += delta; }
      row[columnName] = v;
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="Int64"/> на значение того же поля в другой 
    /// строке. Применяется для расчета итоговых строк.
    /// </summary>
    /// <param name="srcRow">Строка, содержащее прибавляемое значение</param>
    /// <param name="dstRow">Изменяемая (итоговая) строка</param>
    /// <param name="columnName">Имя поля</param>
    public static void IncInt64(DataRow srcRow, DataRow dstRow, string columnName)
    {
      long v = GetInt64(srcRow, columnName);
      IncInt64(dstRow, columnName, v);
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="Int64"/>
    /// </summary>
    /// <param name="drv">Изменяемая строка (объект <see cref="DataRowView"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncInt64(DataRowView drv, string columnName, long delta)
    {
      if (delta == 0L)
        return;
      long v = GetInt64(drv[columnName]);
      checked { v += delta; }
      drv[columnName] = v;
    }

    #endregion

    #region IncSingle

    /// <summary>
    /// Увеличение значения поля типа <see cref="Single"/>
    /// </summary>
    /// <param name="row">Изменяемая строка (объект <see cref="DataRow"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncSingle(DataRow row, string columnName, float delta)
    {
      if (delta == 0f)
        return;
      float v = GetSingle(row, columnName);
      checked { v += delta; }
      row[columnName] = v;
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="Single"/> на значение того же поля в другой 
    /// строке. Применяется для расчета итоговых строк.
    /// </summary>
    /// <param name="srcRow">Строка, содержащее прибавляемое значение</param>
    /// <param name="dstRow">Изменяемая (итоговая) строка</param>
    /// <param name="columnName">Имя поля</param>
    public static void IncSingle(DataRow srcRow, DataRow dstRow, string columnName)
    {
      float v = GetSingle(srcRow, columnName);
      IncSingle(dstRow, columnName, v);
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="Single"/>
    /// </summary>
    /// <param name="drv">Изменяемая строка (объект <see cref="DataRowView"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncSingle(DataRowView drv, string columnName, float delta)
    {
      if (delta == 0f)
        return;
      float v = GetSingle(drv[columnName]);
      checked { v += delta; }
      drv[columnName] = v;
    }

    #endregion

    #region IncDouble

    /// <summary>
    /// Увеличение значения поля типа <see cref="Double"/>
    /// </summary>
    /// <param name="row">Изменяемая строка (объект <see cref="DataRow"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncDouble(DataRow row, string columnName, double delta)
    {
      if (delta == 0.0)
        return;
      double v = GetDouble(row, columnName);
      checked { v += delta; }
      row[columnName] = v;
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="Double"/> на значение того же поля в другой 
    /// строке. Применяется для расчета итоговых строк.
    /// </summary>
    /// <param name="srcRow">Строка, содержащее прибавляемое значение</param>
    /// <param name="dstRow">Изменяемая (итоговая) строка</param>
    /// <param name="columnName">Имя поля</param>
    public static void IncDouble(DataRow srcRow, DataRow dstRow, string columnName)
    {
      double v = GetDouble(srcRow, columnName);
      IncDouble(dstRow, columnName, v);
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="Double"/>
    /// </summary>
    /// <param name="drv">Изменяемая строка (объект <see cref="DataRowView"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncDouble(DataRowView drv, string columnName, double delta)
    {
      if (delta == 0.0)
        return;
      double v = GetDouble(drv[columnName]);
      checked { v += delta; }
      drv[columnName] = v;
    }

    #endregion

    #region IncDecimal

    /// <summary>
    /// Увеличение значения поля типа <see cref="Decimal"/>
    /// </summary>
    /// <param name="row">Изменяемая строка (объект <see cref="DataRow"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncDecimal(DataRow row, string columnName, decimal delta)
    {
      if (delta == 0m)
        return;
      decimal v = GetDecimal(row, columnName);
      checked { v += delta; }
      row[columnName] = v;
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="Decimal"/> на значение того же поля в другой 
    /// строке. Применяется для расчета итоговых строк
    /// </summary>
    /// <param name="srcRow">Строка, содержащее прибавляемое значение</param>
    /// <param name="dstRow">Изменяемая (итоговая) строка</param>
    /// <param name="columnName">Имя поля</param>
    public static void IncDecimal(DataRow srcRow, DataRow dstRow, string columnName)
    {
      decimal v = GetDecimal(srcRow, columnName);
      IncDecimal(dstRow, columnName, v);
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="Decimal"/>
    /// </summary>
    /// <param name="drv">Изменяемая строка (объект <see cref="DataRowView"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncDecimal(DataRowView drv, string columnName, decimal delta)
    {
      if (delta == 0m)
        return;
      decimal v = GetDecimal(drv[columnName]);
      checked { v += delta; }
      drv[columnName] = v;
    }

    #endregion

    #region IncTimeSpan

    /// <summary>
    /// Увеличение значения поля типа <see cref="TimeSpan"/>
    /// </summary>
    /// <param name="row">Изменяемая строка (объект <see cref="DataRow"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncTimeSpan(DataRow row, string columnName, TimeSpan delta)
    {
      if (delta.Ticks == 0L)
        return;
      TimeSpan v = GetTimeSpan(row, columnName);
      checked { v += delta; }
      row[columnName] = v;
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="TimeSpan"/> на значение того же поля в другой 
    /// строке. Применяется для расчета итоговых строк.
    /// </summary>
    /// <param name="srcRow">Строка, содержащее прибавляемое значение</param>
    /// <param name="dstRow">Изменяемая (итоговая) строка</param>
    /// <param name="columnName">Имя поля</param>
    public static void IncTimeSpan(DataRow srcRow, DataRow dstRow, string columnName)
    {
      TimeSpan v = GetTimeSpan(srcRow, columnName);
      IncTimeSpan(dstRow, columnName, v);
    }

    /// <summary>
    /// Увеличение значения поля типа <see cref="TimeSpan"/>
    /// </summary>
    /// <param name="drv">Изменяемая строка (объект <see cref="DataRowView"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncTimeSpan(DataRowView drv, string columnName, TimeSpan delta)
    {
      if (delta.Ticks == 0L)
        return;
      TimeSpan v = GetTimeSpan(drv[columnName]);
      checked { v += delta; }
      drv[columnName] = v;
    }

    #endregion

    #region IncValue

    /// <summary>
    /// Увеличение значения поля произвольного числового типа или <see cref="TimeSpan"/>
    /// </summary>
    /// <param name="drv">Изменяемая строка (объект <see cref="DataRowView"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncValue(DataRowView drv, string columnName, object delta)
    {
      IncValue(drv.Row, columnName, delta); // не стоит делать повторяющийся код
    }

    /// <summary>
    /// Увеличение значения поля произвольного числового типа или <see cref="TimeSpan"/>
    /// </summary>
    /// <param name="row">Изменяемая строка (объект <see cref="DataRow"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="delta">Прибавляемое значение</param>
    public static void IncValue(DataRow row, string columnName, object delta)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif

      DataColumn col = row.Table.Columns[columnName];
      if (col == null)
        throw ExceptionFactory.ArgUnknownColumnName("columnName", row.Table, columnName);

      switch (MathTools.GetSumType(col.DataType))
      {
        case MathTools.SumType.Int32: IncInt32(row, columnName, DataTools.GetInt32(delta)); break;
        case MathTools.SumType.Int64: IncInt64(row, columnName, DataTools.GetInt32(delta)); break;
        case MathTools.SumType.Single: IncSingle(row, columnName, DataTools.GetSingle(delta)); break;
        case MathTools.SumType.Double: IncDouble(row, columnName, DataTools.GetDouble(delta)); break;
        case MathTools.SumType.Decimal: IncDecimal(row, columnName, DataTools.GetDecimal(delta)); break;
        case MathTools.SumType.TimeSpan: IncTimeSpan(row, columnName, DataTools.GetTimeSpan(delta)); break;
        default:
          throw ExceptionFactory.ArgInvalidColumnType("columnName", col);
      }
    }

    /// <summary>
    /// Увеличить значение числового поля в одной строке на значение этого же поля
    /// в другой строке. Поле может быть любого числового типа.
    /// Вызывает соответствующую типу поля функцию IncXXX. Используется, когда
    /// конкретный тип числового поля заранее неизвестен.
    /// Если тип поля известен, то рекомендуется вызывать конкретную функцию, т.к.
    /// она работает быстрее.
    /// </summary>
    /// <param name="srcRow">Строка, содержащее прибавляемое значение</param>
    /// <param name="dstRow">Изменяемая (итоговая) строка</param>
    /// <param name="columnName">Имя поля</param>
    public static void IncValue(DataRow srcRow, DataRow dstRow, string columnName)
    {
#if DEBUG
      if (srcRow == null)
        throw new ArgumentNullException("srcRow");
      if (dstRow == null)
        throw new ArgumentNullException("dstRow");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif

      DataColumn col = srcRow.Table.Columns[columnName];
      if (col == null)
        throw ExceptionFactory.ArgUnknownColumnName("columnName", srcRow.Table, columnName);

      switch (MathTools.GetSumType(col.DataType))
      {
        case MathTools.SumType.Int32: IncInt32(srcRow, dstRow, columnName); break;
        case MathTools.SumType.Int64: IncInt64(srcRow, dstRow, columnName); break;
        case MathTools.SumType.Single: IncSingle(srcRow, dstRow, columnName); break;
        case MathTools.SumType.Double: IncDouble(srcRow, dstRow, columnName); break;
        case MathTools.SumType.Decimal: IncDecimal(srcRow, dstRow, columnName); break;
        case MathTools.SumType.TimeSpan: IncTimeSpan(srcRow, dstRow, columnName); break;
        default:
          throw ExceptionFactory.ArgInvalidColumnType("columnName", col);
      }
    }

    #endregion

    #region AddStrIfNotEmpty()

    // Остальные перегрузки в модуле DataTools.Strings.cs

    /// <summary>
    /// Добавляет строку <paramref name="addedStr"/> к текущему значению строкового поля, если <paramref name="addedStr"/> непустая. 
    /// Перед <paramref name="addedStr"/> добавляется сепаратор <paramref name="separator"/>. 
    /// Если <paramref name="addedStr"/> - пустая строка, то значение поля остается без изменений. 
    /// Сепаратор не добавляется, если поле содержит null или пустую строку.
    /// Версия для <see cref="DataRow"/>.
    /// </summary>
    /// <param name="row">Изменяемая строка (объект <see cref="DataRow"/>)</param>
    /// <param name="columnName">Имя поля, которое будет изменено</param>
    /// <param name="addedStr">Добавляемая строка</param>
    /// <param name="separator">Разделитель</param>
    public static void AddStrIfNotEmpty(DataRow row, string columnName, string addedStr, string separator)
    {
      if (String.IsNullOrEmpty(addedStr))
        return;

      string resStr = DataTools.GetString(row, columnName);

      if (String.IsNullOrEmpty(resStr))
        resStr = addedStr;
      else
      {
        if (!String.IsNullOrEmpty(separator))
          resStr += separator;
        resStr += addedStr;
      }

      row[columnName] = resStr;
    }

    #endregion

    #endregion

    #region Пары "Имя поля - значение"

    /// <summary>
    /// Преобразование массивов имен полей и значений в список пар для последующей модификации
    /// </summary>
    /// <param name="columnNames">Массив имен полей</param>
    /// <param name="columnValues">Массив значений</param>
    /// <returns>Список пар имен и значений</returns>
    public static Hashtable NamesAndValuesToPairs(string[] columnNames, object[] columnValues)
    {
#if DEBUG
      if (columnNames == null)
        throw new ArgumentNullException("columnNames");
      if (columnValues == null)
        throw new ArgumentNullException("columnValues");
#endif
      if (columnNames.Length != columnValues.Length)
        throw ExceptionFactory.ArgWrongCollectionCount("columnValues", columnValues, columnNames.Length);

      Hashtable res = new Hashtable();
      for (int i = 0; i < columnNames.Length; i++)
        res.Add(columnNames[i], columnValues[i]);
      return res;
    }

    /// <summary>
    /// Преобразование хэш-таблицы, содержащей значения полей с ключами
    /// по их именам в отдельные массивы имен полей и значений.
    /// </summary>
    /// <param name="columnNamesAndValues">Исходные поля и значения</param>
    /// <param name="columnNames">Результирующий массив имен полей</param>
    /// <param name="columnValues">Результирующий массив значений</param>
    public static void PairsToNamesAndValues(IDictionary columnNamesAndValues,
      out string[] columnNames, out object[] columnValues)
    {
      if (columnNamesAndValues == null)
        throw new ArgumentNullException("columnNamesAndValues");

      int n = columnNamesAndValues.Count;
      columnNames = new string[n];
      columnValues = new object[n];
      int i = 0;
      foreach (object Key in columnNamesAndValues.Keys)
      {
        columnNames[i] = (string)Key;
        columnValues[i] = columnNamesAndValues[Key];
        i++;
      }
    }

    #endregion

    #region Коллекции

    /// <summary>
    /// Выполняет сравнение двух перечисляемых объектов, реализующих интерфейс <see cref="IEnumerable{T}"/>
    /// Возвращает true, если оба перечислителя содержат одинаковое число элементов и элементы попарно совпадают.
    /// Порядок элементов в перечислители имеет значение.
    /// Для сравнение элементов используется <see cref="Object.Equals(object, object)"/>.
    /// </summary>
    /// <typeparam name="T">Тип объектов</typeparam>
    /// <param name="list1">Первый сравниваемый объек</param>
    /// <param name="list2">Второй сравниваемый объек</param>
    /// <returns>true, если перечислители содержат одинаковые объекты</returns>
    public static bool AreEnumerablesEqual<T>(IEnumerable<T> list1, IEnumerable<T> list2)
    {
#if DEBUG
      if (list1 == null)
        throw new ArgumentNullException("list1");
      if (list2 == null)
        throw new ArgumentNullException("list2");
#endif

      // Нельзя использовать оператор foreach, придется работать с IEnumerator
      using (IEnumerator<T> en1 = list1.GetEnumerator())
      {
        using (IEnumerator<T> en2 = list2.GetEnumerator())
        {
          en1.Reset();
          en2.Reset();
          while (true)
          {
            bool has1 = en1.MoveNext();
            bool has2 = en2.MoveNext();
            if (has1 != has2)
              return false; // число элементов не совпадает
            if (!has1)
              break;

            if (!object.Equals(en1.Current, en2.Current))
              return false;
          }
        }
      }
      return true;
    }

    /// <summary>
    /// Выполняет сравнение двух перечисляемых объектов, реализующих интерфейс <see cref="IEnumerable{T}"/>.
    /// Возвращает true, если оба перечислителя содержат одинаковое число элементов и элементы попанрно совпадают.
    /// Порядок элементов в перечислители имеет значение
    /// Для сравнение элементов используется интерфейс <see cref="IEqualityComparer{T}"/>.
    /// </summary>
    /// <typeparam name="T">Тип объектов</typeparam>
    /// <param name="list1">Первый сравниваемый объек</param>
    /// <param name="list2">Второй сравниваемый объек</param>
    /// <param name="comparer">Компаратор</param>
    /// <returns>true, если перечислители содержат одинаковые объекты</returns>
    public static bool AreEnumerablesEqual<T>(IEnumerable<T> list1, IEnumerable<T> list2, IEqualityComparer<T> comparer)
    {
      if (comparer == null)
        return AreEnumerablesEqual<T>(list1, list2);
#if DEBUG
      if (list1 == null)
        throw new ArgumentNullException("list1");
      if (list2 == null)
        throw new ArgumentNullException("list2");
#endif

      using (IEnumerator<T> en1 = list1.GetEnumerator())
      {
        using (IEnumerator<T> en2 = list2.GetEnumerator())
        {
          en1.Reset();
          en2.Reset();
          while (true)
          {
            bool has1 = en1.MoveNext();
            bool has2 = en2.MoveNext();
            if (has1 != has2)
              return false; // число элементов не совпадает
            if (!has1)
              break;

            if (!comparer.Equals(en1.Current, en2.Current))
              return false;
          }
        }
      }
      return true;
    }

    /// <summary>
    /// Выполняет сравнение двух перечисляемых объектов, реализующих интерфейс <see cref="IEnumerable{T}"/>
    /// Возвращает true, если оба перечислителя содержат одинаковое число элементов и элементы попарно совпадают.
    /// Порядок элементов в перечислители имеет значение
    /// Для сравнение элементов используется <see cref="object.Equals(object, object)"/>.
    /// </summary>
    /// <param name="list1">Первый сравниваемый объек</param>
    /// <param name="list2">Второй сравниваемый объек</param>
    /// <returns>true, если перечислители содержат одинаковые объекты</returns>
    public static bool AreEnumerablesEqual(IEnumerable list1, IEnumerable list2)
    {
      // Нельзя использовать оператор foreach, придется работать с IEnumerator
      IEnumerator en1 = list1.GetEnumerator();
      IEnumerator en2 = list2.GetEnumerator();
      en1.Reset();
      en2.Reset();
      while (true)
      {
        bool has1 = en1.MoveNext();
        bool has2 = en2.MoveNext();
        if (has1 != has2)
          return false; // число элементов не совпадает
        if (!has1)
          break;

        if (!object.Equals(en1.Current, en2.Current))
          return false;
      }
      return true;
    }

    /// <summary>
    /// Выполняет сравнение двух перечисляемых объектов, реализующих интерфейс <see cref="IEnumerable{String}"/> для строк.
    /// Возвращает true, если оба перечислителя содержат одинаковое число элементов и элементы попарно совпадают.
    /// Порядок элементов в перечислители имеет значение.
    /// </summary>
    /// <param name="list1">Первый сравниваемый объек</param>
    /// <param name="list2">Второй сравниваемый объек</param>
    /// <param name="comparisonType">Режим сравнения для строк</param>
    /// <returns>true, если перечислители содержат одинаковые объекты</returns>
    public static bool AreEnumerablesEqual(IEnumerable<string> list1, IEnumerable<string> list2, StringComparison comparisonType)
    {
#if DEBUG
      if (list1 == null)
        throw new ArgumentNullException("list1");
      if (list2 == null)
        throw new ArgumentNullException("list2");
#endif

      // Нельзя использовать оператор foreach, придется работать с IEnumerator
      using (IEnumerator<string> en1 = list1.GetEnumerator())
      {
        using (IEnumerator<string> en2 = list2.GetEnumerator())
        {
          en1.Reset();
          en2.Reset();
          while (true)
          {
            bool has1 = en1.MoveNext();
            bool has2 = en2.MoveNext();
            if (has1 != has2)
              return false; // число элементов не совпадает
            if (!has1)
              break;

            if (!String.Equals(en1.Current, en2.Current, comparisonType))
              return false;
          }
        }
      }
      return true;
    }

    #endregion

    #region Словари

    /// <summary>
    /// Сравнение двух типизированных словарей.
    /// Возвращает true, если совпадает количество элементов в словарях, ключи и соответствующие значения
    /// Для сравнения используется <see cref="Object.Equals(object, object)"/>.
    /// </summary>
    /// <typeparam name="TKey">Тип ключа в коллекциях</typeparam>
    /// <typeparam name="TValue">Тип значения в коллекциях</typeparam>
    /// <param name="dict1">Первая коллекция</param>
    /// <param name="dict2">Вторая коллекция</param>
    /// <returns>true, если к</returns>
    public static bool AreDictionariesEqual<TKey, TValue>(IDictionary<TKey, TValue> dict1, IDictionary<TKey, TValue> dict2)
    {
      if (dict1.Count != dict2.Count)
        return false;
      foreach (KeyValuePair<TKey, TValue> pair in dict1)
      {
        TValue value2;
        if (!dict2.TryGetValue(pair.Key, out value2))
          return false;

        if (!object.Equals(pair.Value, value2))
          return false;
      }

      return true;
    }

    /// <summary>
    /// Сравнение двух нетипизированных словарей.
    /// Возвращает true, если совпадает количество элементов в словарях, ключи и соответствующие значения
    /// Для сравнения используется <see cref="Object.Equals(object, object)"/>.
    /// </summary>
    /// <param name="dict1">Первая коллекция</param>
    /// <param name="dict2">Вторая коллекция</param>
    /// <returns>true, если словари совпадают</returns>
    public static bool AreDictionariesEqual(IDictionary dict1, IDictionary dict2)
    {
      if (dict1.Count != dict2.Count)
        return false;
      foreach (DictionaryEntry pair in dict1)
      {
        if (!dict2.Contains(pair.Key))
          return false;

        object value2 = dict2[pair.Key];

        if (!object.Equals(pair.Value, value2))
          return false;
      }

      return true;
    }

    #endregion

    #region Первичный ключ в DataTable

    /// <summary>
    /// Установка первичного ключа таблицы (свойство <see cref="DataTable.PrimaryKey"/>).
    /// Если <paramref name="columnNames"/> - пустая строка, первичный ключ удаляется из таблицы.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnNames">Список полей первичного ключа, разделенных запятыми</param>
    public static void SetPrimaryKey(DataTable table, string columnNames)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
#endif

      if (String.IsNullOrEmpty(columnNames))
      {
        table.PrimaryKey = null;
        return;
      }

      if (columnNames.IndexOf(',') < 0)
      {
        // 14.06.2017 Оптимизация
        DataColumn[] cols = new DataColumn[1];
        cols[0] = table.Columns[columnNames];
        if (cols[0] == null)
        {
          ArgumentException e = new ArgumentException(String.Format(Res.DataTools_Err_DataTableHasNoKeyColumn,
            table.TableName, columnNames), "columnNames");
          AddExceptionColumnsInfo(e, table);
          throw e;
        }
        table.PrimaryKey = cols;
      }
      else
      {
        string[] names = columnNames.Split(',');
        SetPrimaryKey(table, names);
      }
    }

    /// <summary>
    /// Установка первичного ключа таблицы (свойство <see cref="DataTable.PrimaryKey"/>)
    /// Если <paramref name="columnNames"/> - пустой массив или null, первичный ключ удаляется из таблицы.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnNames">Список полей первичного ключа</param>
    public static void SetPrimaryKey(DataTable table, string[] columnNames)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
#endif

      if (columnNames == null || columnNames.Length == 0)
      {
        table.PrimaryKey = null;
        return;
      }
      DataColumn[] cols = new DataColumn[columnNames.Length];
      for (int i = 0; i < columnNames.Length; i++)
      {
        cols[i] = table.Columns[columnNames[i]];
        if (cols[i] == null)
        {
          ArgumentException e = new ArgumentException(String.Format(Res.DataTools_Err_DataTableHasNoKeyColumn,
            table.TableName, columnNames[i]), "columnNames");
          AddExceptionColumnsInfo(e, table);
          throw e;
        }
      }
      table.PrimaryKey = cols;
    }

    internal static int GetPrimaryKeyLength(DataTable table)
    {
      if (table.PrimaryKey == null)
        return 0;
      else
        return table.PrimaryKey.Length;
    }

    /// <summary>
    /// Получение первичного ключа таблицы в виде строки-списка полей,
    /// разделенных запятыми
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <returns>Строка имен ключевых полей. Если ключевых полей нет, то пустая строка ""</returns>
    public static string GetPrimaryKey(DataTable table)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
#endif

      int nPK = GetPrimaryKeyLength(table);
      switch (nPK)
      {
        case 0:
          return String.Empty;
        case 1:
          return table.PrimaryKey[0].ColumnName;
        default:
          StringBuilder sb = new StringBuilder();
          for (int i = 0; i < nPK; i++)
          {
            if (i > 0)
              sb.Append(',');
            sb.Append(table.PrimaryKey[i].ColumnName);
          }
          return sb.ToString();
      }
    }

    /// <summary>
    /// Установка первичного ключа таблицы, если он отличается от требуемого
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnNames">Список требуемых ключевых полей, разделенный запятями</param>
    public static void CheckPrimaryKey(DataTable table, string columnNames)
    {
      string s = GetPrimaryKey(table);
      if (columnNames != s)
        SetPrimaryKey(table, columnNames);
    }

    /// <summary>
    /// Получить значения полей первичного ключа для массива строк для таблицы данных.
    /// Возвращается двумерный массив, первая размерность которого соответствует
    /// количеству полей первичного ключа (обычна равна 1), а вторая - количеству.
    /// строк
    /// </summary>
    /// <param name="table">Таблица, в которой находятся строки</param>
    /// <param name="rows">Массив строк, для которых надо получить значения. В массиве могут быть ссылки null</param>
    /// <returns>Двумерный массив</returns>
    public static object[,] GetPrimaryKeyValues(DataTable table, DataRow[] rows)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
#endif

      int nPK = GetPrimaryKeyLength(table);
      if (nPK == 0)
        throw ExceptionFactory.ArgDataTableWithoutPrimaryKey("table", table);

#if DEBUG
      if (rows == null)
        throw new ArgumentNullException("rows");
#endif

      object[,] keyValues = new object[rows.Length, nPK];
      for (int i = 0; i < rows.Length; i++)
      {
        if (rows[i] == null)
          continue;
        for (int j = 0; j < nPK; j++)
          keyValues[i, j] = rows[i][table.PrimaryKey[j]];
      }
      return keyValues;
    }

    /// <summary>
    /// Получение массива значений ключевых полей для одной строки.
    /// Возвращает null, если таблица не имеет первичного ключа или строка не задана.
    /// </summary>
    /// <param name="row">Строка <see cref="DataRow"/></param>
    /// <returns>Значения ключевых полей</returns>
    public static object[] GetPrimaryKeyValues(DataRow row)
    {
      if (row == null)
        return null;
      return GetPrimaryKeyValues(row, row.Table);
    }

    /// <summary>
    /// Получение массива значений ключевых полей для одной строки.
    /// Возвращает null, если таблица не имеет первичного ключа или строка не задана.
    /// Строка <paramref name="row"/> может принадлежать другой таблице, чем та, в которой определяется ключ.
    /// </summary>
    /// <param name="row">Строка DataRow</param>
    /// <param name="table">Таблица, в которой определен <see cref="DataTable.PrimaryKey"/></param>
    /// <returns>Значения ключевых полей</returns>
    public static object[] GetPrimaryKeyValues(DataRow row, DataTable table)
    {
      if (row == null)
        return null;
      int nPK = GetPrimaryKeyLength(table);
      if (nPK == 0)
        return null;
      object[] keyValues = new object[nPK];
      for (int i = 0; i < nPK; i++)
      {
        string colName = table.PrimaryKey[i].ColumnName;
        keyValues[i] = row[colName];
      }
      return keyValues;
    }

    /// <summary>
    /// Возвращает массив строк <see cref="DataRow"/>, в которых значения первичного ключа равны значениям
    /// в соответствующей строке двумерного массива.
    /// Если для очередной строки со значениями нет строки в таблице, соответствующий элемент в
    /// результирующем массиве равен null.
    /// </summary>
    /// <param name="table">Таблица данных, в которой задан первичный ключ по одному или нескольким полям</param>
    /// <param name="keyValues">Массив значений для поиска. Строки двумерного массива определяют длину 
    /// результирующего массива. Каждая строка задает значения для поиска первичного ключа.
    /// Количество столбцов в двумерном массиве должно быть равно количеству полей в первичном ключе таблицы</param>
    /// <returns>Массив найденных строк таблицы. В массиве могут быть значения null</returns>
    public static DataRow[] GetPrimaryKeyRows(DataTable table, object[,] keyValues)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
#endif

      int nPK = GetPrimaryKeyLength(table);
      if (nPK == 0)
        throw ExceptionFactory.ArgDataTableWithoutPrimaryKey("table", table);

#if DEBUG
      if (keyValues == null)
        throw new ArgumentNullException("keyValues");
#endif

      if (keyValues.GetLength(1) != nPK)
        throw ExceptionFactory.ArgWrongCollectionCount("keyValues", keyValues, nPK);

      object[] findKeys = null;
      if (nPK > 1)
        findKeys = new object[nPK]; // сюда будем копировать ключи для поиска

      DataRow[] rows = new DataRow[keyValues.GetLength(0)];
      for (int i = 0; i < rows.Length; i++)
      {
        if (keyValues[i, 0] == null)
          continue;
        if (nPK == 1)
          // Простой поиск по одному столбцу. Копирование не нужно
          rows[i] = table.Rows.Find(keyValues[i, 0]);
        else
        {
          // Требуется дополнительное копирование
          for (int j = 0; j < nPK; j++)
            findKeys[j] = keyValues[i, j];
          rows[i] = table.Rows.Find(findKeys);
        }
      }

      return rows;
    }

    /// <summary>
    /// Найти строку в таблице с заданным значением ключевого поля. Если таблица
    /// не содержит строки с заданным ключом, то строка добавляется
    /// </summary>
    /// <param name="table">Таблица, содержащая первичный ключ для одного поля</param>
    /// <param name="keyValue">Значение ключевого поля</param>
    /// <returns>Найденная или созданная строка</returns>
    public static DataRow FindOrAddPrimaryKeyRow(DataTable table, object keyValue)
    {
      DataRow row;
      FindOrAddPrimaryKeyRow(table, keyValue, out row);
      return row;
    }

    /// <summary>
    /// Найти строку в таблице с заданным значением ключевого поля. Если таблица
    /// не содержит строки с заданным ключом, то строка добавляется.
    /// Возвращает true, если была создана новая строка.
    /// </summary>
    /// <param name="table">Таблица, содержащая первичный ключ для одного поля</param>
    /// <param name="keyValue">Значение ключевого поля</param>
    /// <param name="row">Найденная или созданная строка</param>
    /// <returns>Признак добавления строки</returns>
    public static bool FindOrAddPrimaryKeyRow(DataTable table, object keyValue, out DataRow row)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("Table");
#endif
      int nPK = GetPrimaryKeyLength(table); // 27.12.2020
      if (nPK != 1)
        throw ExceptionFactory.ArgDataTableMustHaveSingleColumnPrimaryKey("table", table);

      row = table.Rows.Find(keyValue);
      if (row == null)
      {
        row = table.NewRow();
        row[table.PrimaryKey[0]] = keyValue;
        table.Rows.Add(row);
        return true;
      }

      return false;
    }

    /// <summary>
    /// Найти строку в таблице с заданными значениями ключевых полей. Если таблица
    /// не содержит строки с заданным ключом, то строка добавляется.
    /// </summary>
    /// <param name="table">Таблица, содержащая первичный ключ для одного или нескольких полей</param>
    /// <param name="keyValues">Значения ключевых полей</param>
    /// <returns>Найденная или созданная строка</returns>
    public static DataRow FindOrAddPrimaryKeyRow(DataTable table, object[] keyValues)
    {
      DataRow row;
      FindOrAddPrimaryKeyRow(table, keyValues, out row);
      return row;
    }

    /// <summary>
    /// Найти строку в таблице с заданными значениями ключевых полей. Если таблица
    /// не содержит строки с заданным ключом, то строка добавляется.
    /// Возвращает true, если была создана новая строка
    /// </summary>
    /// <param name="table">Таблица, содержащая первичный ключ для одного или нескольких полей</param>
    /// <param name="keyValues">Значения ключевых полей</param>
    /// <param name="row">Найденная или созданная строка</param>
    /// <returns>Признак добавления строки</returns>
    public static bool FindOrAddPrimaryKeyRow(DataTable table, object[] keyValues, out DataRow row)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("Table");
      if (keyValues == null)
        throw new ArgumentNullException("KeyValues");

      int nPK = GetPrimaryKeyLength(table);
      if (nPK != keyValues.Length)
        throw new ArgumentException(String.Format(Res.DataTools_Arg_KeyValuesLengthDiffWithPrimaryKey,
          keyValues.Length, nPK, table.TableName), "keyValues");
#endif

      row = table.Rows.Find(keyValues);
      if (row == null)
      {
        row = table.NewRow();
        for (int i = 0; i < keyValues.Length; i++)
          row[table.PrimaryKey[i]] = keyValues[i];
        table.Rows.Add(row);
        return true;
      }
      return false;
    }

    #endregion

    #region Отношения "Мастер-детали" между DataTable

    /// <summary>
    /// Создание объекта <see cref="DataRelation"/> для отношения "Мастер-детали" между двумя
    /// таблицами. Мастер-таблица должна иметь первичный ключ.
    /// </summary>
    /// <param name="masterTable">Главная таблица ("Customers")</param>
    /// <param name="detailsTable">Подчиненная таблица ("Orders")</param>
    /// <param name="referenceColumn">Имя столбца ("CustomerId") в подчиненной таблице, которое
    /// будет связано с ключевым полем в <paramref name="masterTable"/>.
    /// Может содержать несколько имен столбцов, если таблица <paramref name="masterTable"/> имеет составной первичный ключ.</param>
    /// <param name="relationName">Имя связи (свойство <see cref="DataRelation.RelationName"/>.
    /// Если не задано, то будет сгенерировано автоматически</param>
    public static void AddRelation(DataTable masterTable,
      DataTable detailsTable, string referenceColumn, string relationName)
    {
#if DEBUG
      if (masterTable == null)
        throw new ArgumentNullException("masterTable");
      if (detailsTable == null)
        throw new ArgumentNullException("detailsTable");
      if (String.IsNullOrEmpty(referenceColumn))
        throw new ArgumentNullException("referenceColumn");
#endif
      if (masterTable.DataSet != detailsTable.DataSet)
        throw ExceptionFactory.ArgDataTablesNotSameDataSet("masteTable", masterTable, "detailsTable", detailsTable);
      int nPK = GetPrimaryKeyLength(masterTable);
      if (nPK == 0)
        throw ExceptionFactory.ArgDataTableWithoutPrimaryKey("masterTable", masterTable);

      string[] aColNames = referenceColumn.Split(',');
      DataColumn[] refCols = new DataColumn[aColNames.Length];
      for (int i = 0; i < refCols.Length; i++)
      {
        refCols[i] = detailsTable.Columns[aColNames[i]];
        if (refCols[i] == null)
          throw new InvalidOperationException(String.Format(Res.DataTools_Err_DataTableHasNoRefColumn,
            detailsTable.TableName, aColNames[i]));
      }
      if (refCols.Length != nPK)
        throw new InvalidOperationException(String.Format(Res.DataTable_Err_DataTableRefColumnArrayLengthMismatch,
          masterTable.TableName, GetPrimaryKey(masterTable), nPK,
          referenceColumn, refCols.Length));

      if (String.IsNullOrEmpty(relationName))
        relationName = referenceColumn.Replace(',', '_') + "_Ref";
      DataRelation rel = new DataRelation(relationName, masterTable.PrimaryKey, refCols);
      detailsTable.DataSet.Relations.Add(rel);
    }

    #endregion

    #region Клонирование таблиц с выборочными строками

    /// <summary>
    /// Клонирование таблицы и ее строк, для которых выставлены флаги.
    /// Строки, для которых флаг не установлен, не добавляются в новую таблицу.
    /// Всегда возвращается копия таблицы, даже если флаги выставлены для всех строк.
    /// </summary>
    /// <param name="table">Исходная таблица</param>
    /// <param name="flags">Массив флагов, по одному для каждой строки</param>
    /// <returns>Таблица-копия</returns>
    public static DataTable CloneTableForSelectedRows(DataTable table, bool[] flags)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
      if (flags == null)
        throw new ArgumentNullException("flags");
#endif
      if (flags.Length != table.Rows.Count)
        throw ExceptionFactory.ArgWrongCollectionCount("flags", flags, table.Rows.Count);

      DataTable resTable = table.Clone();
      for (int i = 0; i < flags.Length; i++)
      {
        if (flags[i])
          resTable.Rows.Add(table.Rows[i].ItemArray);
      }
      return resTable;
    }

    /// <summary>
    /// Клонирование таблицы и ее строк, для которых выставлены флаги. Строки,
    /// для которых флаг не установлен, не добавляются в новую таблицу.
    /// Если флаги выставлены для всех строк, то клонирование не выполняется, а
    /// возвращается оригинальная таблица <paramref name="table"/>.
    /// </summary>
    /// <param name="table">Исходная таблица</param>
    /// <param name="flags">Массив флагов, по одному для каждой строки</param>
    /// <returns>Таблица-копия</returns>
    public static DataTable CloneOrSameTableForSelectedRows(DataTable table, bool[] flags)
    {
      if (Array.IndexOf<bool>(flags, false) < 0)
        // Все строки выбраны
        return table;
      else
        return CloneTableForSelectedRows(table, flags);
    }

    #endregion

    #region Вспомогательные функции для работы с DataSet'ом

    #region GetRowCount

    /// <summary>
    /// Подсчет числа всех строк во всех таблицах
    /// </summary>
    /// <param name="ds">Набор данных, в котором перебираютися таблицы</param>
    /// <returns>Общее количество строк</returns>
    public static int GetRowCount(DataSet ds)
    {
      if (ds == null)
        return 0;

      int n = 0;
      for (int i = 0; i < ds.Tables.Count; i++)
        n += ds.Tables[i].Rows.Count;
      return n;
    }

    #endregion

    #region AddTableToDataSet

    /// <summary>
    /// Присоединение таблицы к датасету. Если таблица уже присоединена к другому
    /// набору, то она оттуда удаляется.
    /// Если в целевом наборе <paramref name="ds"/> уже есть таблица с совпадающим именем,
    /// она удаляется из набора
    /// </summary>
    /// <param name="ds">Целевой набор данных. Не может быть null</param>
    /// <param name="table">Присоединяемыая таблицы. Не может быть null</param>
    public static void AddTableToDataSet(DataSet ds, DataTable table)
    {
      if (ds == null) // эта проверка обязательно нужна
        throw new ArgumentNullException("ds");
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
#endif
      if (Object.ReferenceEquals(table.DataSet, ds))
        return; // 17.12.2021

      if (table.DataSet != null)
        table.DataSet.Tables.Remove(table);

      // 14.09.2015
      // Убираем существующую таблицу с совпадающим именем
      if (!String.IsNullOrEmpty(table.TableName))
      {
        if (ds.Tables.Contains(table.TableName))
          ds.Tables.Remove(table.TableName);
      }

      // 27.05.2022
      // Восстанавливаем значения свойств для DefaultView
      // При добавлении таблицы в DataSet, свойство DataTable.DefaultView очищается (см. исходники Net Framework, внутренний метод DataTable.SetDataSet()).

      string rf = table.DefaultView.RowFilter;
      DataViewRowState rsf = table.DefaultView.RowStateFilter;
      string sort = table.DefaultView.Sort;

      ds.Tables.Add(table);

      table.DefaultView.RowFilter = rf;
      table.DefaultView.RowStateFilter = rsf;
      table.DefaultView.Sort = sort;
    }

    #endregion

    #region GetValues

    /// <summary>
    /// Извлечение массива значений полей из строки.
    /// Для не существующих имен полей возвращается null.
    /// <see cref="DBNull"/> также заменяется на null.
    /// </summary>
    /// <param name="row">Строка данных (иожет быть null)</param>
    /// <param name="columnNames">Массив имен полей, разделенных запятыми</param>
    /// <returns>Значения полей</returns>
    public static object[] GetValues(DataRow row, string columnNames)
    {
      string[] aNames = columnNames.Split(',');
      object[] res = new object[aNames.Length];
      if (row == null)
        return res;
      for (int i = 0; i < aNames.Length; i++)
      {
        int p = row.Table.Columns.IndexOf(aNames[i]);
        if (p < 0)
          continue;
        if (row.IsNull(p))
          continue;
        res[i] = row[p];
      }
      return res;
    }

    #endregion

    #region GetDataTableRows()

    /// <summary>
    /// Копирование строк таблицы <see cref="DataTable"/> в массив.
    /// </summary>
    /// <param name="table">Таблица, откуда берутся строки.
    /// Если null, то будет возвращен пустой массив.</param>
    /// <returns>Массив строк</returns>
    /// <seealso cref="GetDataViewRows(DataView)"/>
    public static DataRow[] GetDataTableRows(DataTable table)
    {
      if (table == null || table.Rows.Count == 0)
        return EmptyArray<DataRow>.Empty;

      DataRow[] res = new DataRow[table.Rows.Count];
      table.Rows.CopyTo(res, 0);
      return res;
    }

    /// <summary>
    /// Копирование строк таблицы <see cref="DataTable"/> в массив.
    /// Копируются строки из выбранного диапазона.
    /// Параметры диапазона <paramref name="startIndex"/> и <paramref name="count"/> должны находится в пределах <paramref name="table"/>.Rows.Count.
    /// </summary>
    /// <param name="table">Таблица, откуда берутся строки. Не может быть null</param>
    /// <param name="startIndex">Начальный индекс</param>
    /// <param name="count">Количество строк</param>
    /// <returns>Массив строк</returns>
    public static DataRow[] GetDataTableRows(DataTable table, int startIndex, int count)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
#endif

      DataRow[] res = new DataRow[count];
      for (int i = 0; i < count; i++)
        res[i] = table.Rows[startIndex + i];
      return res;
    }

    // Есть метод GetDataViewRows()

    ///// <summary>
    ///// Копирование строк таблицы <see cref="DataView.Table"/> в массив
    ///// </summary>
    ///// <param name="dv">Просмотр таблицы, откуда берутся строки.
    ///// Если null, то будет возвращен пустой массив.</param>
    ///// <returns>Массив строк</returns>
    //public static DataRow[] GetDataTableRows(DataView dv)
    //{
    //  if (dv == null)
    //    return new DataRow[0];

    //  DataRow[] res = new DataRow[dv.Count];
    //  for (int i = 0; i < dv.Count; i++)
    //    res[i] = dv[i].Row;
    //  return res;
    //}


    #endregion

    #region GetDataRowEnumerable()

#if XXX
    /// <summary>
    /// Возвращает объект, реализующий перечислитель по строкам множества таблиц.
    /// В списке таблиц могут быть элементы null
    /// </summary>
    /// <param name="Tables">Перечислитель таблиц (например, массив)</param>
    /// <returns>Объект, реализующий перечислитель строк</returns>
    public static IEnumerable<DataRow> GetDataRowEnumerable(IEnumerable<DataTable> Tables)
    {
      if (Tables != null)
      {
        foreach (DataTable Table in Tables)
        {
          if (Table != null)
          {
            foreach (DataRow Row in Table.Rows)
              yield return Row;
          }
        }
      }
    }

    /// <summary>
    /// Возвращает объект, реализующий перечислитель по строкам множества таблиц, заданных объектами DataView.
    /// В списке просмотров могут быть элементы null
    /// </summary>
    /// <param name="Views">Перечислитель объектов DataView (например, массив)</param>
    /// <returns>Объект, реализующий перечислитель строк</returns>
    public static IEnumerable<DataRow> GetDataRowEnumerable(IEnumerable<DataView> Views)
    {
      if (Views != null)
      {
        foreach (DataView View in Views)
        {
          if (View != null)
          {
            foreach (DataRowView drv in View)
              yield return drv.Row;
          }
        }
      }
    }
#endif

    /// <summary>
    /// Получение объекта для перебора строк <see cref="DataRow"/>.
    /// В качестве источника строк могут выступать: <see cref="DataTable"/>, <see cref="DataView"/>, массивы любой размерности, 
    /// включая jagged, коллекции, реализующие <see cref="IEnumerable"/>, одиночные <see cref="DataRow"/> и <see cref="DataRowView"/>.
    /// Значения null пропускаются.
    /// Для массивов используется рекурсивное перечисление элементов.
    /// Если источник данных содержит ссылку на объект неподдерживаемого типа, генерируется исключение.
    /// </summary>
    /// <param name="source">Источник данных</param>
    /// <returns>Объект, реализующий интерфейс <see cref="IEnumerable{DataRow}"/></returns>
    public static IEnumerable<DataRow> GetDataRowEnumerable(object source)
    {
      return GetDataRowEnumerable(source, false);
    }

    /// <summary>
    /// Получение объекта для перебора строк <see cref="DataRow"/>.
    /// В качестве источника строк могут выступать: <see cref="DataTable"/>, <see cref="DataView"/>, массивы любой размерности, 
    /// включая jagged, коллекции, реализующие <see cref="IEnumerable"/>, одиночные <see cref="DataRow"/> и <see cref="DataRowView"/>.
    /// Значения null пропускаются.
    /// Для массивов используется рекурсивное перечисление элементов.
    /// </summary>
    /// <param name="source">Источник данных</param>
    /// <param name="skipBadSource">Определяет действие, когда в источнике данных обнаружен 
    /// элемент неизвестного типа.
    /// Если true, то элемент пропускается. Если false, то будет сгенерировано исключение</param>
    /// <returns>Объект, реализующий интерфейс <see cref="IEnumerable{DataRow}"/></returns>
    public static IEnumerable<DataRow> GetDataRowEnumerable(object source, bool skipBadSource)
    {
      // Используем готовые перечислители
      // Нельзя, т.к. DataRowCollection реализует только IEnumerable, но не IEnumerable<DataRow>
      // if (Source is DataTable)
      //   return ((DataTable)Source).Rows;

      IEnumerable<DataRow> source2 = source as IEnumerable<DataRow>;
      if (source2 != null)
        return source2;

      // Реализуем перечислитель через "машину состояний" (оператор yield return)
      // Обязательно требуется отдельный метод
      return GetDataRowEnumerable2(source, skipBadSource);
    }

    /// <summary>
    /// Этот метод реализует "машину состояний"
    /// </summary>
    /// <param name="source"></param>
    /// <param name="skipBadSource"></param>
    /// <returns></returns>
    private static IEnumerable<DataRow> GetDataRowEnumerable2(object source, bool skipBadSource)
    {
      if (source != null)
      {
        if (source is DataTable)
        {
          foreach (DataRow row1 in ((DataTable)source).Rows)
            yield return row1;
        }
        else if (source is DataView)
        {
          foreach (DataRowView drv1 in (DataView)source)
            yield return drv1.Row;
        }
        else if (source is DataRow)
        {
          yield return (DataRow)source;
        }
        else if (source is DataRowView)
        {
          yield return ((DataRowView)source).Row;
        }
        else if (source is IEnumerable)
        {
          if (source is IEnumerable<DataRowView>)
          {
            foreach (DataRowView drv1 in (IEnumerable<DataRowView>)source)
              yield return drv1.Row;
          }
          else
          {
            foreach (object Item1 in (IEnumerable)source)
            {
              IEnumerable<DataRow> en2 = GetDataRowEnumerable(Item1);
              foreach (DataRow row2 in en2)
                yield return row2;
            }
          }
        }
        else
        {
          if (!skipBadSource)
            throw ExceptionFactory.ArgUnknownType("source", source);
        }
      }
    }

    #endregion

    #region GetStringsFromColumn()

    /// <summary>
    /// Получение списка строковых значений поля. 
    /// Поле может быть не-строковым, используется <see cref="GetString(DataRow, string)"/>.
    /// Пустые строки и повторы отбрасываются.
    /// Регистр символов учитывается.
    /// Возвращаемый массив сортируется.
    /// </summary>
    /// <param name="table">Таблица данных</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Массив идентификаторов</returns>
    public static string[] GetStringsFromColumn(DataTable table, string columnName)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
      if (String.IsNullOrEmpty(columnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("columnName");
#endif

      int colPos = GetColumnPosWithCheck(table, columnName);

      SingleScopeList<string> values = null;
      foreach (DataRow row in table.Rows)
      {
        string s = DataTools.GetString(row[colPos]);
        if (String.IsNullOrEmpty(s))
          continue;

        if (values == null)
          values = new SingleScopeList<string>();
        if (!values.Contains(s))
          values.Add(s);
      }

      if (values == null)
        return EmptyArray<string>.Empty;
      else
      {
        string[] a = values.ToArray();
        Array.Sort<string>(a);
        return a;
      }
    }

    /// <summary>
    /// Получение списка строковых значений поля для строк, относящихся к 
    /// объекту <see cref="DataView"/>.
    /// Поле может быть не-строковым, используется <see cref="GetString(DataRow, string)"/>.
    /// Пустые строки и повторы отбрасываются.
    /// Регистр символов учитывается.
    /// Возвращаемый массив сортируется.
    /// </summary>
    /// <param name="dv">Коллекция строк таблицы данных</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Массив идентификаторов</returns>
    public static string[] GetStringsFromColumn(DataView dv, string columnName)
    {
#if DEBUG
      if (dv == null)
        throw new ArgumentNullException("dv");
#endif

      if (dv.Count == 0)
        return EmptyArray<string>.Empty;

      int colPos = GetColumnPosWithCheck(dv.Table, columnName);

      SingleScopeList<String> values = null;
      for (int i = 0; i < dv.Count; i++)
      {
        string s = DataTools.GetString(dv[i].Row[colPos]);
        if (String.IsNullOrEmpty(s))
          continue;

        if (values == null)
          values = new SingleScopeList<string>();
        values.Add(s);
      }

      if (values == null)
        return EmptyArray<string>.Empty;
      else
      {
        string[] a = values.ToArray();
        Array.Sort<string>(a);
        return a;
      }
    }

    /// <summary>
    /// Получение списка строковых значений поля для строк таблицы в массиве. 
    /// Пустые строки и повторы отбрасываются.
    /// Строки в массиве должны относиться либо к одной таблице, либо к таблицам,
    /// имеющим одинаковую структуру.
    /// Регистр символов учитывается.
    /// Возвращаемый массив сортируется.
    /// </summary>
    /// <param name="rows">Массив однотипных строк</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Массив идентификаторов</returns>
    public static string[] GetStringsFromColumn(ICollection<DataRow> rows, string columnName)
    {
#if DEBUG
      if (rows == null)
        throw new ArgumentNullException("rows");
#endif

      if (rows.Count == 0)
        return EmptyArray<string>.Empty;

      SingleScopeList<string> values = null;
      int colPos = -1;
      foreach (DataRow row in rows)
      {
        if (colPos < 1)
          colPos = GetColumnPosWithCheck(row.Table, columnName);

        string s = DataTools.GetString(row[colPos]);
        if (String.IsNullOrEmpty(s))
          continue;

        if (values == null)
          values = new SingleScopeList<string>();
        values.Add(s);
      }
      if (values == null)
        return EmptyArray<string>.Empty;
      else
      {
        string[] a = values.ToArray();
        Array.Sort<string>(a);
        return a;
      }
    }

    #endregion

    #region GetValuesFromColumn()

    /// <summary>
    /// Получить значения поля для всех строк таблицы в виде массива.
    /// Повторы и пустые значения не отбрасываются. Количество и порядок элементов в массиве соответствуют строкам в таблице
    /// Хранящиеся в таблице значения <see cref="DBNull"/> заменяются на default/null.
    /// Если тип массива <typeparamref name="T"/> не совпадает с типом данных в столбце таблицы, используется метод <see cref="Convert.ChangeType(object, Type)"/>(). Методы типа GetXxx() не применяются
    /// 
    /// Замечания для строковых полей:
    /// - Не выполняется обрезка концевых пробелов, как для <see cref="DataTools.GetString(DataRow, string)"/>.
    /// - Для значения <see cref="DBNull"/> возвращается null, а не пустая строка.
    /// - Может быть удобнее использовать метод <see cref="GetStringsFromColumn(DataTable, string)"/>, но он убирает повторы и пустые строки.
    /// </summary>
    /// <typeparam name="T">Тип поля данных (один из поддерживаемых типов <see cref="DataColumn.DataType"/>)</typeparam>
    /// <param name="table">Таблица исходных данных</param>
    /// <param name="columnName">Имя столбца, из которого извлекаются значения</param>
    /// <returns>Массив значений поля</returns>
    public static T[] GetValuesFromColumn<T>(DataTable table, string columnName)
    {
      int colPos = GetColumnPosWithCheck(table, columnName);

      T[] res = new T[table.Rows.Count];

      Type resType = typeof(T);
      if (resType == table.Columns[colPos].DataType)
      {
        for (int i = 0; i < table.Rows.Count; i++)
        {
          if (!table.Rows[i].IsNull(colPos))
            res[i] = (T)(table.Rows[i][colPos]);
        }
      }
      else
      {
        for (int i = 0; i < table.Rows.Count; i++)
        {
          if (!table.Rows[i].IsNull(colPos))
            res[i] = (T)(Convert.ChangeType(table.Rows[i][colPos], resType));
        }
      }
      return res;
    }

    /// <summary>
    /// Получить значения поля для всех строк <see cref="DataView"/> в виде массива.
    /// Повторы и пустые значения не отбрасываются. Количество и порядок элементов в массиве соответствуют строкам в просмотре
    /// Хранящиеся в таблице значения <see cref="DBNull"/> заменяются на default.
    /// </summary>
    /// <typeparam name="T">Тип поля данных (один из поддерживаемых типов <see cref="DataColumn.DataType"/>)</typeparam>
    /// <param name="dv">Просмотр для таблицы исходных данных</param>
    /// <param name="columnName">Имя столбца, из которого извлекаются значения</param>
    /// <returns>Массив значений поля</returns>
    public static T[] GetValuesFromColumn<T>(DataView dv, string columnName)
    {
#if DEBUG
      if (dv == null)
        throw new ArgumentNullException("dv");
#endif
      int colPos = GetColumnPosWithCheck(dv.Table, columnName);

      T[] res = new T[dv.Count];
      Type resType = typeof(T);
      if (resType == dv.Table.Columns[colPos].DataType)
      {
        for (int i = 0; i < dv.Count; i++)
        {
          DataRow Row = dv[i].Row;
          if (!Row.IsNull(colPos))
            res[i] = (T)(Row[colPos]);
        }
      }
      else
      {
        for (int i = 0; i < dv.Count; i++)
        {
          DataRow Row = dv[i].Row;
          if (!Row.IsNull(colPos))
            res[i] = (T)(Convert.ChangeType(Row[colPos], resType));
        }
      }
      return res;
    }

    /// <summary>
    /// Получить значения поля для строк таблицы в массиве. 
    /// Повторы и пустые значения не отбрасываются. Количество и порядок элементов в результируюшем массиве соответствуют <paramref name="rows"/>.
    /// Хранящиеся в таблице значения <see cref="DBNull"/> заменяются на default.
    /// </summary>
    /// <typeparam name="T">Тип поля данных (один из поддерживаемых типов <see cref="DataColumn.DataType"/>)</typeparam>
    /// <param name="rows">Массив однотипных строк</param>
    /// <param name="columnName">Имя столбца, из которого извлекаются значения</param>
    /// <returns>Массив значений поля</returns>
    public static T[] GetValuesFromColumn<T>(DataRow[] rows, string columnName)
    {
#if DEBUG
      if (rows == null)
        throw new ArgumentNullException("rows");
#endif

      T[] res = new T[rows.Length];
      for (int i = 0; i < rows.Length; i++)
      {
        object x = rows[i][columnName];
        if (!(x is DBNull))
          res[i] = (T)(Convert.ChangeType(x, typeof(T)));
      }
      return res;
    }

    #endregion

    #region GetUniqueXXXs

    #region Int

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="dv">Просмотр</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static int[] GetUniqueInt32Values(DataView dv, string columnName, bool skipNulls)
    {
      if (dv == null)
        return EmptyArray<Int32>.Empty;
      if (dv.Count == 0)
        return EmptyArray<Int32>.Empty;
      int p = GetColumnPosWithCheck(dv.Table, columnName);
      SingleScopeList<int> lst = new SingleScopeList<int>();
      foreach (DataRowView drv in dv)
      {
        if (skipNulls)
        {
          if (drv.Row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetInt32(drv.Row[p]));
      }
      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static int[] GetUniqueInt32Values(DataTable table, string columnName, bool skipNulls)
    {
      if (table == null)
        return EmptyArray<Int32>.Empty;
      if (table.Rows.Count == 0)
        return EmptyArray<Int32>.Empty;
      int p = GetColumnPosWithCheck(table, columnName);

      SingleScopeList<int> lst = new SingleScopeList<int>();
      foreach (DataRow row in table.Rows)
      {
        if (row.RowState == DataRowState.Deleted)
          continue;
        if (skipNulls)
        {
          if (row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetInt32(row[p]));
      }

      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="rows">Коллекция строк. В массиве могут быть ссылки null</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static int[] GetUniqueInt32Values(IEnumerable<DataRow> rows, string columnName, bool skipNulls)
    {
      if (rows == null)
        return EmptyArray<Int32>.Empty;
      // Строки могут относиться к разным таблицам
      DataRowValues rowVals = new DataRowValues();
      SingleScopeList<int> lst = new SingleScopeList<int>();
      foreach (DataRow row in rows)
      {
        if (row == null)
          continue;
        if (row.RowState == DataRowState.Deleted)
          continue;
        rowVals.CurrentRow = row;
        int? v = rowVals[columnName].AsNullableInt32;
        if (skipNulls)
        {
          if (!v.HasValue)
            continue;
        }
        lst.Add(v ?? 0);
      }
      return lst.ToArray();
    }

    #endregion

    #region Int64

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="dv">Просмотр</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static long[] GetUniqueInt64Values(DataView dv, string columnName, bool skipNulls)
    {
      if (dv == null)
        return EmptyArray<Int64>.Empty;
      if (dv.Count == 0)
        return EmptyArray<Int64>.Empty;
      int p = GetColumnPosWithCheck(dv.Table, columnName);

      SingleScopeList<long> lst = new SingleScopeList<long>();
      foreach (DataRowView drv in dv)
      {
        if (skipNulls)
        {
          if (drv.Row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetInt64(drv.Row[p]));
      }
      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static long[] GetUniqueInt64Values(DataTable table, string columnName, bool skipNulls)
    {
      if (table == null)
        return EmptyArray<Int64>.Empty;
      if (table.Rows.Count == 0)
        return EmptyArray<Int64>.Empty;
      int p = GetColumnPosWithCheck(table, columnName);

      SingleScopeList<long> lst = new SingleScopeList<long>();
      foreach (DataRow row in table.Rows)
      {
        if (row.RowState == DataRowState.Deleted)
          continue;
        if (skipNulls)
        {
          if (row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetInt64(row[p]));
      }

      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="rows">Коллекция строк. В массиве могут быть ссылки null</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static long[] GetUniqueInt64Values(IEnumerable<DataRow> rows, string columnName, bool skipNulls)
    {
      if (rows == null)
        return EmptyArray<Int64>.Empty;
      // Строки могут относиться к разным таблицам
      DataRowValues rowVals = new DataRowValues();
      SingleScopeList<long> lst = new SingleScopeList<long>();
      foreach (DataRow row in rows)
      {
        if (row == null)
          continue;
        if (row.RowState == DataRowState.Deleted)
          continue;

        rowVals.CurrentRow = row;
        long? v = rowVals[columnName].AsNullableInt64;
        if (skipNulls)
        {
          if (!v.HasValue)
            continue;
        }
        lst.Add(v ?? 0L);
      }
      return lst.ToArray();
    }

    #endregion

    #region Single

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="dv">Просмотр</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static float[] GetUniqueSingleValues(DataView dv, string columnName, bool skipNulls)
    {
      if (dv == null)
        return EmptyArray<Single>.Empty;
      if (dv.Count == 0)
        return EmptyArray<Single>.Empty;
      int p = GetColumnPosWithCheck(dv.Table, columnName);
      SingleScopeList<float> lst = new SingleScopeList<float>();
      foreach (DataRowView drv in dv)
      {
        if (skipNulls)
        {
          if (drv.Row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetSingle(drv.Row[p]));
      }
      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static float[] GetUniqueSingleValues(DataTable table, string columnName, bool skipNulls)
    {
      if (table == null)
        return EmptyArray<Single>.Empty;
      if (table.Rows.Count == 0)
        return EmptyArray<Single>.Empty;
      int p = GetColumnPosWithCheck(table, columnName);
      SingleScopeList<float> lst = new SingleScopeList<float>();
      foreach (DataRow row in table.Rows)
      {
        if (row.RowState == DataRowState.Deleted)
          continue;
        if (skipNulls)
        {
          if (row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetSingle(row[p]));
      }

      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="rows">Коллекция строк. В массиве могут быть ссылки null</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static float[] GetUniqueSingleValues(IEnumerable<DataRow> rows, string columnName, bool skipNulls)
    {
      if (rows == null)
        return EmptyArray<Single>.Empty;
      // Строки могут относиться к разным таблицам
      DataRowValues rowVals = new DataRowValues();
      SingleScopeList<float> lst = new SingleScopeList<float>();
      foreach (DataRow row in rows)
      {
        if (row == null)
          continue;
        if (row.RowState == DataRowState.Deleted)
          continue;

        rowVals.CurrentRow = row;
        float? v = rowVals[columnName].AsNullableSingle;
        if (skipNulls)
        {
          if (!v.HasValue)
            continue;
        }
        lst.Add(v ?? 0f);
      }
      return lst.ToArray();
    }

    #endregion

    #region Double

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="dv">Просмотр</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static double[] GetUniqueDoubleValues(DataView dv, string columnName, bool skipNulls)
    {
      if (dv == null)
        return EmptyArray<Double>.Empty;
      if (dv.Count == 0)
        return EmptyArray<Double>.Empty;
      int p = GetColumnPosWithCheck(dv.Table, columnName);
      SingleScopeList<double> lst = new SingleScopeList<double>();
      foreach (DataRowView drv in dv)
      {
        if (skipNulls)
        {
          if (drv.Row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetDouble(drv.Row[p]));
      }
      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static double[] GetUniqueDoubleValues(DataTable table, string columnName, bool skipNulls)
    {
      if (table == null)
        return EmptyArray<Double>.Empty;
      if (table.Rows.Count == 0)
        return EmptyArray<Double>.Empty;
      int p = GetColumnPosWithCheck(table, columnName);
      SingleScopeList<double> lst = new SingleScopeList<double>();
      foreach (DataRow row in table.Rows)
      {
        if (row.RowState == DataRowState.Deleted)
          continue;
        if (skipNulls)
        {
          if (row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetDouble(row[p]));
      }

      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="rows">Коллекция строк. В массиве могут быть ссылки null</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static double[] GetUniqueDoubleValues(IEnumerable<DataRow> rows, string columnName, bool skipNulls)
    {
      if (rows == null)
        return EmptyArray<Double>.Empty;
      // Строки могут относиться к разным таблицам
      DataRowValues rowVals = new DataRowValues();
      SingleScopeList<double> lst = new SingleScopeList<double>();
      foreach (DataRow row in rows)
      {
        if (row == null)
          continue;
        if (row.RowState == DataRowState.Deleted)
          continue;

        rowVals.CurrentRow = row;
        double? v = rowVals[columnName].AsNullableDouble;
        if (skipNulls)
        {
          if (!v.HasValue)
            continue;
        }
        lst.Add(v ?? 0.0);
      }
      return lst.ToArray();
    }

    #endregion

    #region Decimal

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="dv">Просмотр</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static decimal[] GetUniqueDecimalValues(DataView dv, string columnName, bool skipNulls)
    {
      if (dv == null)
        return EmptyArray<Decimal>.Empty;
      if (dv.Count == 0)
        return EmptyArray<Decimal>.Empty;
      int p = GetColumnPosWithCheck(dv.Table, columnName);

      SingleScopeList<decimal> lst = new SingleScopeList<decimal>();
      foreach (DataRowView drv in dv)
      {
        if (skipNulls)
        {
          if (drv.Row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetDecimal(drv.Row[p]));
      }
      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static decimal[] GetUniqueDecimalValues(DataTable table, string columnName, bool skipNulls)
    {
      if (table == null)
        return EmptyArray<Decimal>.Empty;
      if (table.Rows.Count == 0)
        return EmptyArray<Decimal>.Empty;
      int p = GetColumnPosWithCheck(table, columnName);

      SingleScopeList<decimal> lst = new SingleScopeList<decimal>();
      foreach (DataRow row in table.Rows)
      {
        if (row.RowState == DataRowState.Deleted)
          continue;
        if (skipNulls)
        {
          if (row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetDecimal(row[p]));
      }

      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="rows">Коллекция строк. В массиве могут быть ссылки null</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static decimal[] GetUniqueDecimalValues(IEnumerable<DataRow> rows, string columnName, bool skipNulls)
    {
      if (rows == null)
        return EmptyArray<Decimal>.Empty;
      // Строки могут относиться к разным таблицам
      DataRowValues rowVals = new DataRowValues();
      SingleScopeList<decimal> lst = new SingleScopeList<decimal>();
      foreach (DataRow row in rows)
      {
        if (row == null)
          continue;
        if (row.RowState == DataRowState.Deleted)
          continue;
        rowVals.CurrentRow = row;
        decimal? v = rowVals[columnName].AsNullableDecimal;
        if (skipNulls)
        {
          if (!v.HasValue)
            continue;
        }
        lst.Add(v ?? 0m);
      }
      return lst.ToArray();
    }

    #endregion

    #region DateTime

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// Значения <see cref="DBNull"/> пропускаются.
    /// </summary>
    /// <param name="dv">Просмотр</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static DateTime[] GetUniqueDateTimeValues(DataView dv, string columnName)
    {
      if (dv == null)
        return EmptyArray<DateTime>.Empty;
      if (dv.Count == 0)
        return EmptyArray<DateTime>.Empty;
      int p = GetColumnPosWithCheck(dv.Table, columnName);
      SingleScopeList<DateTime> lst = new SingleScopeList<DateTime>();
      foreach (DataRowView drv in dv)
      {
        DateTime? v = DataTools.GetNullableDateTime(drv.Row[p]);
        if (v.HasValue)
          lst.Add(v.Value);
      }
      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// Значения <see cref="DBNull"/> пропускаются.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static DateTime[] GetUniqueDateTimeValues(DataTable table, string columnName)
    {
      if (table == null)
        return EmptyArray<DateTime>.Empty;
      if (table.Rows.Count == 0)
        return EmptyArray<DateTime>.Empty;
      int p = GetColumnPosWithCheck(table, columnName);

      SingleScopeList<DateTime> lst = new SingleScopeList<DateTime>();
      foreach (DataRow row in table.Rows)
      {
        if (row.RowState == DataRowState.Deleted)
          continue;
        DateTime? v = DataTools.GetNullableDateTime(row[p]);
        if (v.HasValue)
          lst.Add(v.Value);
      }

      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// Значения <see cref="DBNull"/> пропускаются.
    /// </summary>
    /// <param name="rows">Коллекция строк. В массиве могут быть ссылки null</param>
    /// <param name="columnName">Имя поля</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static DateTime[] GetUniqueDateTimeValues(IEnumerable<DataRow> rows, string columnName)
    {
      if (rows == null)
        return EmptyArray<DateTime>.Empty;
      // Строки могут относиться к разным таблицам
      DataRowValues rowVals = new DataRowValues();
      SingleScopeList<DateTime> lst = new SingleScopeList<DateTime>();
      foreach (DataRow row in rows)
      {
        if (row == null)
          continue;
        if (row.RowState == DataRowState.Deleted)
          continue;

        rowVals.CurrentRow = row;
        DateTime? v = rowVals[columnName].AsNullableDateTime;
        if (v.HasValue)
          lst.Add(v.Value);
      }
      return lst.ToArray();
    }

    #endregion

    #region TimeSpan

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="dv">Просмотр</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static TimeSpan[] GetUniqueTimeSpanValues(DataView dv, string columnName, bool skipNulls)
    {
      if (dv == null)
        return EmptyArray<TimeSpan>.Empty;
      if (dv.Count == 0)
        return EmptyArray<TimeSpan>.Empty;
      int p = GetColumnPosWithCheck(dv.Table, columnName);

      SingleScopeList<TimeSpan> lst = new SingleScopeList<TimeSpan>();
      foreach (DataRowView drv in dv)
      {
        if (skipNulls)
        {
          if (drv.Row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetTimeSpan(drv.Row[p]));
      }
      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static TimeSpan[] GetUniqueTimeSpanValues(DataTable table, string columnName, bool skipNulls)
    {
      if (table == null)
        return EmptyArray<TimeSpan>.Empty;
      if (table.Rows.Count == 0)
        return EmptyArray<TimeSpan>.Empty;
      int p = GetColumnPosWithCheck(table, columnName);

      SingleScopeList<TimeSpan> lst = new SingleScopeList<TimeSpan>();
      foreach (DataRow row in table.Rows)
      {
        if (row.RowState == DataRowState.Deleted)
          continue;
        if (skipNulls)
        {
          if (row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetTimeSpan(row[p]));
      }

      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="rows">Коллекция строк. В массиве могут быть ссылки null</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как 0</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static TimeSpan[] GetUniqueTimeSpanValues(IEnumerable<DataRow> rows, string columnName, bool skipNulls)
    {
      if (rows == null)
        return EmptyArray<TimeSpan>.Empty;
      // Строки могут относиться к разным таблицам
      DataRowValues rowVals = new DataRowValues();
      SingleScopeList<TimeSpan> lst = new SingleScopeList<TimeSpan>();
      foreach (DataRow row in rows)
      {
        if (row == null)
          continue;
        if (row.RowState == DataRowState.Deleted)
          continue;

        rowVals.CurrentRow = row;
        TimeSpan? v = null;
        if (!rowVals[columnName].IsNull)
          v = rowVals[columnName].AsTimeSpan;
        if (skipNulls)
        {
          if (!v.HasValue)
            continue;
        }
        lst.Add(v ?? TimeSpan.Zero);
      }
      return lst.ToArray();
    }

    #endregion

    #region Guid

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="dv">Просмотр</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как <see cref="Guid.Empty"/></param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static Guid[] GetUniqueGuidValues(DataView dv, string columnName, bool skipNulls)
    {
      if (dv == null)
        return EmptyArray<Guid>.Empty;
      if (dv.Count == 0)
        return EmptyArray<Guid>.Empty;
      int p = GetColumnPosWithCheck(dv.Table, columnName);

      SingleScopeList<Guid> lst = new SingleScopeList<Guid>();
      foreach (DataRowView drv in dv)
      {
        if (skipNulls)
        {
          if (drv.Row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetGuid(drv.Row[p]));
      }
      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как Guid.Empty</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static Guid[] GetUniqueGuidValues(DataTable table, string columnName, bool skipNulls)
    {
      if (table == null)
        return EmptyArray<Guid>.Empty;
      if (table.Rows.Count == 0)
        return EmptyArray<Guid>.Empty;
      int p = GetColumnPosWithCheck(table, columnName);

      SingleScopeList<Guid> lst = new SingleScopeList<Guid>();
      foreach (DataRow row in table.Rows)
      {
        if (row.RowState == DataRowState.Deleted)
          continue;
        if (skipNulls)
        {
          if (row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetGuid(row[p]));
      }

      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="rows">Коллекция строк. В массиве могут быть ссылки null</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как <see cref="Guid.Empty"/></param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static Guid[] GetUniqueGuidValues(IEnumerable<DataRow> rows, string columnName, bool skipNulls)
    {
      if (rows == null)
        return EmptyArray<Guid>.Empty;
      // Строки могут относиться к разным таблицам
      DataRowValues rowVals = new DataRowValues();
      SingleScopeList<Guid> lst = new SingleScopeList<Guid>();
      foreach (DataRow row in rows)
      {
        if (row == null)
          continue;
        if (row.RowState == DataRowState.Deleted)
          continue;

        rowVals.CurrentRow = row;
        Guid? v = null;
        if (!rowVals[columnName].IsNull)
          v = rowVals[columnName].AsGuid;
        if (skipNulls)
        {
          if (!v.HasValue)
            continue;
        }
        lst.Add(v ?? Guid.Empty);
      }
      return lst.ToArray();
    }

    #endregion

    #region Enum

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="dv">Просмотр</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как значение default</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static T[] GetUniqueEnumValues<T>(DataView dv, string columnName, bool skipNulls)
      where T : struct
    {
      if (dv == null)
        return EmptyArray<T>.Empty;
      if (dv.Count == 0)
        return EmptyArray<T>.Empty;
      int p = GetColumnPosWithCheck(dv.Table, columnName);

      SingleScopeList<T> lst = new SingleScopeList<T>();
      foreach (DataRowView drv in dv)
      {
        if (skipNulls)
        {
          if (drv.Row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetEnum<T>(drv.Row[p]));
      }
      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как значение default</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static T[] GetUniqueEnumValues<T>(DataTable table, string columnName, bool skipNulls)
      where T : struct
    {
      if (table == null)
        return EmptyArray<T>.Empty;
      if (table.Rows.Count == 0)
        return EmptyArray<T>.Empty;
      int p = GetColumnPosWithCheck(table, columnName);

      SingleScopeList<T> lst = new SingleScopeList<T>();
      foreach (DataRow row in table.Rows)
      {
        if (row.RowState == DataRowState.Deleted)
          continue;
        if (skipNulls)
        {
          if (row.IsNull(p))
            continue;
        }
        lst.Add(DataTools.GetEnum<T>(row[p]));
      }

      return lst.ToArray();
    }

    /// <summary>
    /// Получить все уникальные значения для одного поля таблицы.
    /// Возвращаемый массив не является отсортированным.
    /// </summary>
    /// <param name="rows">Коллекция строк. В массиве могут быть ссылки null</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="skipNulls">Пропускать значения <see cref="DBNull"/>. Если false, то <see cref="DBNull"/> будут считаться как значение default</param>
    /// <returns>Массив уникальных значений или пустой массив</returns>
    public static T[] GetUniqueEnumValues<T>(IEnumerable<DataRow> rows, string columnName, bool skipNulls)
      where T : struct
    {
      if (rows == null)
        return EmptyArray<T>.Empty;
      // Строки могут относиться к разным таблицам
      DataRowValues rowVals = new DataRowValues();
      SingleScopeList<T> lst = new SingleScopeList<T>();
      foreach (DataRow row in rows)
      {
        if (row == null)
          continue;
        if (row.RowState == DataRowState.Deleted)
          continue;

        rowVals.CurrentRow = row;
        T? v = null;
        if (!rowVals[columnName].IsNull)
          v = rowVals[columnName].GetEnum<T>();
        if (skipNulls)
        {
          if (!v.HasValue)
            continue;
        }
        lst.Add(v ?? default(T));
      }
      return lst.ToArray();
    }

    #endregion

    #endregion

    #region GetColumnNames(), GetTableNames()

    /// <summary>
    /// Получить список имен столбцов в таблице
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <returns>Массив имен</returns>
    public static string[] GetColumnNames(DataTable table)
    {
      string[] names = new string[table.Columns.Count];
      for (int i = 0; i < names.Length; i++)
        names[i] = table.Columns[i].ColumnName;
      return names;
    }

    /// <summary>
    /// Получить список имен таблиц в наборе <see cref="DataSet"/>
    /// </summary>
    /// <param name="ds">Набор данных</param>
    /// <returns>Массив имен таблиц</returns>
    public static string[] GetTableNames(DataSet ds)
    {
      string[] names = new string[ds.Tables.Count];
      for (int i = 0; i < names.Length; i++)
        names[i] = ds.Tables[i].TableName;
      return names;
    }

    #endregion

    #region AreColumnNamesEqual(), AreTableNamesEqual()

    /// <summary>
    /// Сравнение списка имен столбцов в двух таблицах.
    /// Имена столбцов не чувствительны к регистру.
    /// Сравниваются только имена столбов, но не тип данных и другие свойства <see cref="DataColumn"/>.
    /// </summary>
    /// <param name="table1">Первая таблица</param>
    /// <param name="table2">Вторая таблица</param>
    /// <param name="ignoreOrder">Если true, то порядок столбцов в таблицах может не совпадать.
    /// Если false, то требуется совпадения порядка столбцов</param>
    /// <returns>true, если имена полей одинаковые</returns>
    public static bool AreColumnNamesEqual(DataTable table1, DataTable table2, bool ignoreOrder)
    {
#if DEBUG
      if (table1 == null)
        throw new ArgumentNullException("table1");
      if (table2 == null)
        throw new ArgumentNullException("table2");
#endif

      if (table1.Columns.Count != table2.Columns.Count)
        return false;

      if (Object.ReferenceEquals(table1, table2))
        return true;

      if (ignoreOrder)
      {
        string[] names2 = GetColumnNames(table2);
        StringArrayIndexer indexer2 = new StringArrayIndexer(names2, true);
        for (int i = 0; i < table1.Columns.Count; i++)
        {
          if (!indexer2.Contains(table1.Columns[i].ColumnName))
            return false;
        }
      }
      else
      {
        for (int i = 0; i < table1.Columns.Count; i++)
        {
          if (!String.Equals(table1.Columns[i].ColumnName, table2.Columns[i].ColumnName, StringComparison.OrdinalIgnoreCase))
            return false;
        }
      }

      return true;
    }

    /// <summary>
    /// Сравнение списка имен таблиц в двух наборах.
    /// Имена таблиц не чувствительны к регистру.
    /// Сравниваются только имена таблиц, но не не список полей в них.
    /// Также не сравниваются <see cref="DataSet.Relations"/>, <see cref="DataSet.ExtendedProperties"/> и прочие свойства.
    /// </summary>
    /// <param name="ds1">Первый набор данных</param>
    /// <param name="ds2">Второй набор данных</param>
    /// <param name="ignoreOrder">Если true, то порядок таблиц в наборах может не совпадать.
    /// Если false, то требуется совпадения порядка таблиц</param>
    /// <returns>true, если имена таблиц одинаковые</returns>
    public static bool AreTableNamesEqual(DataSet ds1, DataSet ds2, bool ignoreOrder)
    {
#if DEBUG
      if (ds1 == null)
        throw new ArgumentNullException("ds1");
      if (ds2 == null)
        throw new ArgumentNullException("ds2");
#endif

      if (ds1.Tables.Count != ds2.Tables.Count)
        return false;

      if (Object.ReferenceEquals(ds1, ds2))
        return true;

      if (ignoreOrder)
      {
        string[] names2 = GetTableNames(ds2);
        StringArrayIndexer indexer2 = new StringArrayIndexer(names2, true);
        for (int i = 0; i < ds1.Tables.Count; i++)
        {
          if (!indexer2.Contains(ds1.Tables[i].TableName))
            return false;
        }
      }
      else
      {
        for (int i = 0; i < ds1.Tables.Count; i++)
        {
          if (!String.Equals(ds1.Tables[i].TableName, ds2.Tables[i].TableName, StringComparison.OrdinalIgnoreCase))
            return false;
        }
      }

      return true;
    }

    #endregion

    #region SetBoundariesFlags

    /// <summary>
    /// Установка логических полей для обозначения начала и конца групп в таблице.
    /// Группа - это последовательность строк в таблице, содержащая одинаковые 
    /// значения поля <paramref name="keyColumnNames"/>. Перебираются все строки таблицы по порядку.
    /// Начало и окончание каждой группы отмечается установкой в true значений полей.
    /// <paramref name="beginFlagColumnName"/> и <paramref name="endFlagColumnName"/> соответственно.
    /// Для "полосатой" раскраски табличного просмотра используйте метод <see cref="SetGroupSequenceNumber(DataTable, string, string)"/>.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="keyColumnNames">Имена полей (одного или нескольких), которые содержит одинаковые значения
    /// для выделения групп. Имена разделяется запятыми. Поля могут быть любого типа</param>
    /// <param name="beginFlagColumnName">Имя логического поля, в котором устанавливается значение
    /// true для первой строки в группе. Может быть не задано, если установка флага начала группы не требуется</param>
    /// <param name="endFlagColumnName">Имя логического поля, в котором устанавливается значение
    /// true для последней строки в группе. Может быть не задано, если установка флага конца группы не требуется</param>
    public static void SetBoundariesFlags(DataTable table, string keyColumnNames, string beginFlagColumnName, string endFlagColumnName)
    {
      // Проверка аргуементов и получение позиций столбцов для ускорения доступа
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
      if (String.IsNullOrEmpty(keyColumnNames))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("keyColumnNames");
#endif

      int[] aKeyColumnPos = GetColumnPosArrayWithCheck(table, keyColumnNames);

      int beginFlagColumnPos, endFlagColumnPos;

      if (String.IsNullOrEmpty(beginFlagColumnName))
        beginFlagColumnPos = -1;
      else
      {
        beginFlagColumnPos = GetColumnPosWithCheck(table, beginFlagColumnName);
#if DEBUG
        if (table.Columns[beginFlagColumnPos].DataType != typeof(bool))
          throw ExceptionFactory.ArgInvalidColumnType("beginFlagColumnName", table.Columns[beginFlagColumnPos]);
#endif
      }

      if (String.IsNullOrEmpty(endFlagColumnName))
        endFlagColumnPos = -1;
      else
      {
        endFlagColumnPos = GetColumnPosWithCheck(table, endFlagColumnName);
#if DEBUG
        if (table.Columns[endFlagColumnPos].DataType != typeof(bool))
          throw ExceptionFactory.ArgInvalidColumnType("endFlagColumnName", table.Columns[endFlagColumnPos]);
#endif
      }

      if (table.Rows.Count == 0)
        return;

      // Перебор строк
      for (int i = 1; i < table.Rows.Count; i++)
      {
        DataRow prevRow = table.Rows[i - 1];
        DataRow thisRow = table.Rows[i];
        bool flag = !AreValuesArrayEqual(prevRow, thisRow, aKeyColumnPos);
        if (beginFlagColumnPos >= 0)
          thisRow[beginFlagColumnPos] = flag;
        if (endFlagColumnPos >= 0)
          prevRow[endFlagColumnPos] = flag;
      }
      // Для первой и последней строки флаги устанавливаются принудительно
      if (beginFlagColumnPos >= 0)
        table.Rows[0][beginFlagColumnPos] = true;
      if (endFlagColumnPos >= 0)
        table.Rows[table.Rows.Count - 1][endFlagColumnPos] = true;
    }


    // !!!
    // Не проверял. М.Б. нужны DataRowView.Begin/EndEdit()

    /// <summary>
    /// Установка логических полей для обозначения начала и конца групп в таблице.
    /// Группа - это последовательность строк в таблице, содержащая одинаковые 
    /// значения полей <paramref name="keyColumnNames"/>. Перебираются все строки таблицы по порядку.
    /// Начало и окончание каждой группы отмечается установкой в true значений полей
    /// <paramref name="beginFlagColumnName"/> и <paramref name="endFlagColumnName"/> соответственно.
    /// Перебор строк осуществляется для заданного просмотра <see cref="DataView"/>.
    /// Для "полосатой" раскраски табличного просмотра используйте метод <see cref="SetGroupSequenceNumber(DataView, string, string)"/>.
    /// </summary>
    /// <param name="dv">Просмотр <see cref="DataView"/></param>
    /// <param name="keyColumnNames">Имена полей (одного или нескольких), которые содержит одинаковые значения
    /// для выделения групп. Имена разделяется запятыми. Поля могут быть любого типа</param>
    /// <param name="beginFlagColumnName">Имя логического поля, в котором устанавливается значение
    /// true для первой строки в группе. Может быть не задано, если установка флага начала группы не требуется</param>
    /// <param name="endFlagColumnName">Имя логического поля, в котором устанавливается значение
    /// true для последней строки в группе. Может быть не задано, если установка флага конца группы не требуется</param>
    public static void SetBoundariesFlags(DataView dv, string keyColumnNames, string beginFlagColumnName, string endFlagColumnName)
    {
      // Проверка аргуементов и получение позиций столбцов для ускорения доступа
#if DEBUG
      if (dv == null)
        throw new ArgumentNullException("dv");
#endif

      int[] aKeyColumnPos = GetColumnPosArrayWithCheck(dv.Table, keyColumnNames);

      int beginFlagColumnPos, endFlagColumnPos;

      if (String.IsNullOrEmpty(beginFlagColumnName))
        beginFlagColumnPos = -1;
      else
      {
        beginFlagColumnPos = GetColumnPosWithCheck(dv.Table, beginFlagColumnName);
#if DEBUG
        if (dv.Table.Columns[beginFlagColumnPos].DataType != typeof(bool))
          throw ExceptionFactory.ArgInvalidColumnType("beginFlagColumnName", dv.Table.Columns[beginFlagColumnPos]);
#endif
      }

      if (String.IsNullOrEmpty(endFlagColumnName))
        endFlagColumnPos = -1;
      else
      {
        endFlagColumnPos = GetColumnPosWithCheck(dv.Table, endFlagColumnName);
#if DEBUG
        if (dv.Table.Columns[endFlagColumnPos].DataType != typeof(bool))
          throw ExceptionFactory.ArgInvalidColumnType("endFlagColumnName", dv.Table.Columns[endFlagColumnPos]);
#endif
      }

      if (dv.Count == 0)
        return;

      // Перебор строк
      for (int i = 1; i < dv.Count; i++)
      {
        DataRowView prevRow = dv[i - 1];
        DataRowView thisRow = dv[i];
        bool flag = !AreValuesArrayEqual(prevRow.Row, thisRow.Row, aKeyColumnPos);
        if (beginFlagColumnPos >= 0)
          thisRow[beginFlagColumnPos] = flag;
        if (endFlagColumnPos >= 0)
          prevRow[endFlagColumnPos] = flag;
      }
      // Для первой и последней строки флаги устанавливаются принудительно
      if (beginFlagColumnPos >= 0)
        dv[0][beginFlagColumnPos] = true;
      if (endFlagColumnPos >= 0)
        dv[dv.Count - 1][endFlagColumnPos] = true;
    }

    #endregion

    #region SetGroupSequenceNumber

    /// <summary>
    /// Установка числового поля для нумерации групп в таблице.
    /// Группа - это последовательность строк в таблице, содержащая одинаковые 
    /// значения полей <paramref name="keyColumnNames"/>. Перебираются все строки таблицы по порядку.
    /// Для каждой группы задается порядковый номер 1,2,3,... в поле <paramref name="orderColumnName"/>.
    /// Такое поле может использоваться для организации "полосатой" раскраски в табличном просмотре.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="keyColumnNames">Имена полей (одного или нескольких), которые содержит одинаковые значения
    /// для выделения групп. Имена разделяется запятыми. Поля могут быть любого типа</param>
    /// <param name="orderColumnName">Имя числового поля, в котором устанавливается номер группы</param>
    public static void SetGroupSequenceNumber(DataTable table, string keyColumnNames, string orderColumnName)
    {
      // Проверка аргуементов и получение позиций столбцов для ускорения доступа
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
      if (String.IsNullOrEmpty(keyColumnNames))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("keyColumnNames");
      if (String.IsNullOrEmpty(orderColumnName))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("orderColumnName");
#endif

      int[] aKeyColumnPos = GetColumnPosArrayWithCheck(table, keyColumnNames);
      int orderColumnPos = GetColumnPosWithCheck(table, orderColumnName);

#if DEBUG
      if (!MathTools.IsIntegerType(table.Columns[orderColumnPos].DataType))
        throw ExceptionFactory.ArgInvalidColumnType("orderColumnName", table.Columns[orderColumnPos]);
#endif

      if (table.Rows.Count == 0)
        return;

      // Перебор строк
      int order = 1;
      table.Rows[0][orderColumnPos] = order;
      for (int i = 1; i < table.Rows.Count; i++)
      {
        DataRow prevRow = table.Rows[i - 1];
        DataRow thisRow = table.Rows[i];
        if (!AreValuesArrayEqual(prevRow, thisRow, aKeyColumnPos))
          order++;
        thisRow[orderColumnPos] = order;
      }
    }


    /// <summary>
    /// Установка числового поля для нумерации групп в таблице.
    /// Группа - это последовательность строк в таблице, содержащая одинаковые 
    /// значения полей <paramref name="keyColumnNames"/>. Перебираются все строки таблицы по порядку.
    /// Для каждой группы задается порядковый номер 1,2,3,... в поле <paramref name="orderColumnName"/>.
    /// Такое поле может использоваться для организации "полосатой" раскраски в табличном просмотре.
    /// Перебор строк осуществляется для заданного просмотра <see cref="DataView"/>.
    /// </summary>
    /// <param name="dv">Просмотр <see cref="DataView"/></param>
    /// <param name="keyColumnNames">Имена полей (одного или нескольких), которые содержит одинаковые значения
    /// для выделения групп. Имена разделяется запятыми. Поля могут быть любого типа</param>
    /// <param name="orderColumnName">Имя числового поля, в котором устанавливается номер группы</param>
    public static void SetGroupSequenceNumber(DataView dv, string keyColumnNames, string orderColumnName)
    {
      // Проверка аргуементов и получение позиций столбцов для ускорения доступа
#if DEBUG
      if (dv == null)
        throw new ArgumentNullException("dv");
#endif

      int[] aKeyColumnPos = GetColumnPosArrayWithCheck(dv.Table, keyColumnNames);
      int orderColumnPos = GetColumnPosWithCheck(dv.Table, orderColumnName);

#if DEBUG
      if (!MathTools.IsIntegerType(dv.Table.Columns[orderColumnPos].DataType))
        throw ExceptionFactory.ArgInvalidColumnType("orderColumnName", dv.Table.Columns[orderColumnPos]);
#endif

      if (dv.Count == 0)
        return;

      // Перебор строк
      int order = 1;
      dv[0].Row[orderColumnPos] = order;
      for (int i = 1; i < dv.Count; i++)
      {
        DataRowView prevRow = dv[i - 1];
        DataRowView thisRow = dv[i];
        if (!AreValuesArrayEqual(prevRow.Row, thisRow.Row, aKeyColumnPos))
          order++;
        thisRow[orderColumnPos] = order;
      }
    }

    #endregion

    #region AreValuesEqual

    /// <summary>
    /// Сравнение значений одного поля для двух строк.
    /// Возвращает значение true, если значения одинаковы. Если есть пустые
    /// значения <see cref="DBNull"/>, то строки считаются одинаковыми, если обе строки содержат
    /// <see cref="DBNull"/>.
    /// </summary>
    /// <param name="row1">Первая сравниваемая строка</param>
    /// <param name="row2">Вторая сравниваемая строка</param>
    /// <param name="columnPos">Позиция столбца</param>
    /// <returns>true, если значения одинаковы</returns>
    public static bool AreValuesEqual(DataRow row1, DataRow row2, int columnPos)
    {
      if (row1.IsNull(columnPos))
        return row2.IsNull(columnPos);
      if (row2.IsNull(columnPos))
        return false;
      return row1[columnPos].Equals(row2[columnPos]);
    }

    private static bool AreValuesArrayEqual(DataRow row1, DataRow row2, int[] aColumnPos)
    {
      for (int i = 0; i < aColumnPos.Length; i++)
      {
        if (!AreValuesEqual(row1, row2, aColumnPos[i]))
          return false;
      }
      return true;
    }


    /// <summary>
    /// Сравнение значений одного поля для двух строк.
    /// Возвращает значение true, если значения одинаковы. Если есть пустые
    /// значения <see cref="DBNull"/>, то строки считаются одинаковыми, если обе строки содержат
    /// <see cref="DBNull"/>.
    /// Предполагается, что строки имеют одинаковую струтуру
    /// </summary>
    /// <param name="row1">Первая сравниваемая строка</param>
    /// <param name="row2">Вторая сравниваемая строка</param>
    /// <param name="columnName">Имя столбца</param>
    /// <returns>true, если значения одинаковы</returns>
    public static bool AreValuesEqual(DataRow row1, DataRow row2, string columnName)
    {
      return AreValuesEqual(row1, row2, row1.Table.Columns.IndexOf(columnName));
    }

    /// <summary>
    /// Сравнение значений одного поля для двух строк.
    /// Возвращает значение true, если значения одинаковы. Если есть пустые
    /// значения <see cref="DBNull"/>, то строки считаются одинаковыми, если обе строки содержат
    /// <see cref="DBNull"/>.
    /// </summary>
    /// <param name="row1">Первая сравниваемая строка</param>
    /// <param name="row2">Вторая сравниваемая строка</param>
    /// <param name="columnPos">Позиция столбца</param>
    /// <returns>true, если значения одинаковы</returns>
    public static bool AreValuesEqual(DataRowView row1, DataRowView row2, int columnPos)
    {
      object v1 = row1[columnPos];
      object v2 = row2[columnPos];
      if (v1 is DBNull)
        return v2 is DBNull;
      if (v2 is DBNull)
        return false;
      return v1.Equals(v2);
    }

    /// <summary>
    /// Сравнение значений одного поля для двух строк.
    /// Возвращает значение true, если значения одинаковы. Если есть пустые
    /// значения <see cref="DBNull"/>, то строки считаются одинаковыми, если обе строки содержат
    /// <see cref="DBNull"/>.
    /// </summary>
    /// <param name="row1">Первая сравниваемая строка</param>
    /// <param name="row2">Вторая сравниваемая строка</param>
    /// <param name="columnName">Имя столбца</param>
    /// <returns>true, если значения одинаковы</returns>
    public static bool AreValuesEqual(DataRowView row1, DataRowView row2, string columnName)
    {
      object v1 = row1[columnName];
      object v2 = row2[columnName];
      if (v1 is DBNull)
        return v2 is DBNull;
      if (v2 is DBNull)
        return false;
      return v1.Equals(v2);
    }

    /// <summary>
    /// Расширенное сравнение двух значений на равенство. Значения null и <see cref="DBNull"/>
    /// считаются одинаковыми. Для сравнения используется метод <see cref="Object.Equals(object, object)"/>.
    /// Если одно значение содержит null или <see cref="DBNull"/>, а второе - нет, то возвращается
    /// false.
    /// </summary>
    /// <param name="value1">Первое сравниваемое значение</param>
    /// <param name="value2">Второе сравниваемое значение</param>
    /// <returns>true, если значения совпадают</returns>
    public static bool AreValuesEqual(object value1, object value2)
    {
      if (value1 == null)
        value1 = DBNull.Value;
      if (value2 == null)
        value2 = DBNull.Value;

      if (value1 is DBNull)
        return value2 is DBNull;
      if (value2 is DBNull)
        return false;
      if (value1.GetType() != value2.GetType())
      {
        // 28.08.2009
        // обычное сравнение не работает, например, для типов byte и short
        // !! Надо бы как-нибудь, используя Convert.GetTypeCode()
        int level1 = GetEqLevel(value1);
        int level2 = GetEqLevel(value2);
        if (level1 > 0 && level2 > 0)
        {
          int level = Math.Max(level1, level2);
          value1 = ToEqLevel(value1, level);
          value2 = ToEqLevel(value2, level);
        }
      }
      // 13.05.2015, 24.03.2016
      else if (value1 is String)
      {
        string s1 = ((string)value1).TrimEnd();
        string s2 = ((string)value2).TrimEnd();
        return String.Equals(s1, s2);
      }

      return value1.Equals(value2);
    }

    /// <summary>
    /// Возвращает "уровень" для числовых типов:
    /// 1-int
    /// 2-long
    /// 3-decimal
    /// Для других типов возвращает 0
    /// </summary>
    /// <param name="value"></param>
    /// <returns></returns>
    private static int GetEqLevel(object value)
    {
      if (value is Byte || value is SByte ||
        value is Int16 || value is UInt16 ||
        value is Int32 || value is UInt32)
        return 1;

      if (value is Int64 || value is UInt64)
        return 2;

      if (value is Single || value is Double || value is decimal)
        return 3;

      return 0;
    }

    private static object ToEqLevel(object value, int level)
    {
      switch (level)
      {
        case 1:
          return Convert.ToInt32(value);
        case 2:
          return Convert.ToInt64(value);
        case 3:
          return Convert.ToDecimal(value);
        default:
          throw ExceptionFactory.ArgUnknownValue("Level", level);
      }
    }

    #endregion

    #region GetRandomId

    /// <summary>
    /// Используется для глобальных блокировок lock в пределах библотеки ExtTools,
    /// когда нет своих объектов для синхронизации
    /// </summary>
    internal static object InternalSyncRoot { get { return _TheRandom; } }

    /// <summary>
    /// Генератор случайных чисел
    /// Это свойство не является потокобезопасным.
    /// При обращении должна выполняться блокировка объекта
    /// </summary>
    internal static Random TheRandom { get { return _TheRandom; } }
    private static readonly Random _TheRandom = new Random();


    /// <summary>
    /// Возвращает значение ключевого поля, которого нет в таблице данных.
    /// Таблица должна иметь первичный ключ по полю типа <see cref="Int32"/>.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <returns>Идентификатор для новой строки</returns>
    public static Int32 GetRandomInt32Id(DataTable table)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
#endif
      if (GetPrimaryKeyLength(table) != 1)
        throw ExceptionFactory.ArgDataTableMustHaveSingleColumnPrimaryKey("table", table);
      if (table.PrimaryKey[0].DataType != typeof(Int32))
        throw ExceptionFactory.ArgDataTablePrimaryKeyWrongType("table", table, typeof(Int32));

      lock (_TheRandom)
      {
        while (true)
        {
          Int32 KeyValue = -_TheRandom.Next(); // отрицательные значения для наглядности
          if (KeyValue == 0)
            continue;
          if (table.Rows.Find(KeyValue) == null)
            return KeyValue;
        }
      }
    }

    #endregion

    #region GroupRows

    #region DataTable


    /// <summary>
    /// Распределение строк таблицы по группам с одинаковыми значениями ключевых
    /// полей. На входе задается таблица <paramref name="srcTable"/> с произвольным набором строк.
    /// Создаются массивы <paramref name="rows"/>  ссылок на строки этой таблицы, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>.
    /// Во вспомогательную таблицу <paramref name="keyTable"/>  помещаются строки с уникальными 
    /// комбинациями значений полей <paramref name="keyColumnNames"/> (других полей в таблице нет).
    /// Число строк в <paramref name="keyTable"/> совпадает с числом массивов <paramref name="rows"/>.
    /// Значения DBNull и нулевые значения/пустые строки различаются
    /// </summary>
    /// <param name="srcTable">Исходная таблица, из которой берутся строки.
    /// Таблица должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// <param name="keyTable">Сюда записывается вспомогательная таблица значений полей</param>
    /// <param name="rows">Сюда записывается двумерный массив ссылок на строки таблицы
    /// SrcTable. Первая размерность совпадает со строками в <paramref name="keyTable"/> и соответствует
    /// уникальным комбинациям значений полей</param>
    public static void GroupRows(DataTable srcTable, string keyColumnNames, out DataTable keyTable, out DataRow[][] rows)
    {
      GroupRows(srcTable, keyColumnNames, out keyTable, out rows, false);
    }

    /// <summary>
    /// Распределение строк таблицы по группам с одинаковыми значениями ключевых
    /// полей. На входе задается таблица <paramref name="srcTable"/> с произвольным набором строк.
    /// Создаются массивы <paramref name="rows"/>  ссылок на строки этой таблицы, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>.
    /// Во вспомогательную таблицу <paramref name="keyTable"/>  помещаются строки с уникальными 
    /// комбинациями значений полей <paramref name="keyColumnNames"/> (других полей в таблице нет).
    /// Число строк в <paramref name="keyTable"/> совпадает с числом массивов <paramref name="rows"/>.
    /// Эта версия позволяет выполнить замену значений DBNull на 0 или пустую строку, в зависимости от типа данных
    /// </summary>
    /// <param name="srcTable">Исходная таблица, из которой берутся строки.
    /// Таблица должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// <param name="keyTable">Сюда записывается вспомогательная таблица значений полей</param>
    /// <param name="rows">Сюда записывается двумерный массив ссылок на строки таблицы
    /// <paramref name="srcTable"/>. Первая размерность совпадает со строками в <paramref name="keyTable"/> и соответствует
    /// уникальным комбинациям значений полей</param>
    /// <param name="dbNullAsZero">Если true, то значения <see cref="DBNull"/> полей <paramref name="keyColumnNames"/>
    /// в исходной таблице трактоваться как 0 (или пустая строка)</param>
    public static void GroupRows(DataTable srcTable, string keyColumnNames, out DataTable keyTable, out DataRow[][] rows, bool dbNullAsZero)
    {
#if DEBUG
      if (srcTable == null)
        throw new ArgumentNullException("srcTable");
      if (String.IsNullOrEmpty(keyColumnNames))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("keyColumnNames");
#endif

      string[] aKeyColumnNames = keyColumnNames.Split(',');
      int[] keyColumnPoss = new int[aKeyColumnNames.Length];
      keyTable = new DataTable();
      for (int i = 0; i < aKeyColumnNames.Length; i++)
      {
        keyColumnPoss[i] = GetColumnPosWithCheck(srcTable, aKeyColumnNames[i]);
        DataColumn SrcCol = srcTable.Columns[keyColumnPoss[i]];
        keyTable.Columns.Add(SrcCol.ColumnName, SrcCol.DataType); // другие ограничения не применяем
      }

      // 26.01.2016
      // Среди значений полей, по которым выполняется группировка, могут быть DBNull.
      // Их нельзя применять в качестве первичных ключей таблицы, но можно использовать в сортировке DataView.Sort

      //DataTools.SetPrimaryKey(KeyTable, KeyColumnNames);
      object[] keyValues = new object[aKeyColumnNames.Length];
      keyTable.DefaultView.Sort = keyColumnNames;

      // 15.02.2019
      // Сначала добавляем все строки в ключевую таблицу, а затем - сортируем ее
      foreach (DataRow srcRow in srcTable.Rows)
      {
        InitGroupRowsKeyValues(srcRow, keyValues, keyColumnPoss, dbNullAsZero);
        DataTools.FindOrAddDataRow(keyTable.DefaultView, keyValues);
      }
      keyTable = keyTable.DefaultView.ToTable();
      keyTable.DefaultView.Sort = keyColumnNames;

      List<List<DataRow>> rows2 = new List<List<DataRow>>(keyTable.Rows.Count);
      for (int i = 0; i < keyTable.Rows.Count; i++)
        rows2.Add(new List<DataRow>());

      foreach (DataRow srcRow in srcTable.Rows)
      {
        InitGroupRowsKeyValues(srcRow, keyValues, keyColumnPoss, dbNullAsZero);
        DataRow keyRow = DataTools.FindOrAddDataRow(keyTable.DefaultView, keyValues); // 26.01.2017

        int keyRowIndex = keyTable.Rows.IndexOf(keyRow);
        List<DataRow> currList = rows2[keyRowIndex];
        currList.Add(srcRow);
      }

      // Преобразование списков в массив
      rows = new DataRow[rows2.Count][];
      for (int i = 0; i < rows2.Count; i++)
        rows[i] = rows2[i].ToArray();
    }

    private static void InitGroupRowsKeyValues(DataRow srcRow, object[] keyValues, int[] keyColumnPoss, bool dbNullAsZero)
    {
      for (int i = 0; i < keyColumnPoss.Length; i++)
      {
        keyValues[i] = srcRow[keyColumnPoss[i]];
        if (dbNullAsZero && (keyValues[i] is DBNull)) // 26.01.2017
          keyValues[i] = GetEmptyValue(srcRow.Table.Columns[keyColumnPoss[i]].DataType);
      }
    }

    /// <summary>
    /// Распределение строк таблицы по группам с одинаковыми значениями ключевых
    /// полей. На входе задается таблица <paramref name="srcTable"/> с произвольным набором строк.
    /// Возвращаются массивы ссылок на строки этой таблицы, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>.
    /// Значения <see cref="DBNull"/> и нулевые значения/пустые строки различаются.
    /// </summary>
    /// <param name="srcTable">Исходная таблица, из которой берутся строки.
    /// Таблица должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// <returns>Сюда записывается двумерный массив ссылок на строки таблицы
    /// SrcTable. Первая размерность соответствует
    /// уникальным комбинациям значений полей</returns>
    public static DataRow[][] GroupRows(DataTable srcTable, string keyColumnNames)
    {
      DataTable keyTable;
      DataRow[][] rows;
      GroupRows(srcTable, keyColumnNames, out keyTable, out rows, false);
      return rows;
    }

    /// <summary>
    /// Распределение строк таблицы по группам с одинаковыми значениями ключевых
    /// полей. На входе задается таблица <paramref name="srcTable"/> с произвольным набором строк.
    /// Возвращаются массивы ссылок на строки этой таблицы, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>.
    /// Эта версия позволяет выполнить замену значений DBNull на 0 или пустую строку, в зависимости от типа данных
    /// </summary>
    /// <param name="srcTable">Исходная таблица, из которой берутся строки.
    /// Таблица должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// Эта версия позволяет выполнить замену значений <see cref="DBNull"/> на 0 или пустую строку, в зависимости от типа данных
    /// <param name="dbNullAsZero">Если true, то значения <see cref="DBNull"/> полей <paramref name="keyColumnNames"/>
    /// в исходной таблице трактоваться как 0 (или пустая строка)</param>
    /// <returns>Сюда записывается двумерный массив ссылок на строки таблицы
    /// <paramref name="srcTable"/>. Первая размерность соответствует
    /// уникальным комбинациям значений полей</returns>
    public static DataRow[][] GroupRows(DataTable srcTable, string keyColumnNames, bool dbNullAsZero)
    {
      DataTable keyTable;
      DataRow[][] rows;
      GroupRows(srcTable, keyColumnNames, out keyTable, out rows, dbNullAsZero);
      return rows;
    }

    #endregion

    #region DataView

    /// <summary>
    /// Распределение строк таблицы, выбранных в <see cref="DataView"/> по группам с одинаковыми значениями ключевых
    /// полей. На входе задается список <paramref name="srcDataView"/> с произвольным набором строк.
    /// Создаются массивы <paramref name="rows"/> ссылок на строки таблицы, базовой для <paramref name="srcDataView"/>, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>.
    /// Во вспомогательную таблицу <paramref name="keyTable"/> помещаются строки с уникальными 
    /// комбинациями значений полей <paramref name="keyColumnNames "/> (других полей в таблице нет).
    /// Число строк в <paramref name="keyTable"/> совпадает с числом массивов <paramref name="rows"/>.
    /// Значения <see cref="DBNull"/> и нулевые значения/пустые строки различаются.
    /// </summary>
    /// <param name="srcDataView">Исходная просмотр таблицы , из которого берутся строки.
    /// Таблица, на основе которой построен <paramref name="srcDataView"/>, должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// <param name="keyTable">Сюда записывается вспомогательная таблица значений полей</param>
    /// <param name="rows">Сюда записывается двумерный массив ссылок на строки таблицы
    /// <paramref name="srcDataView"/>.Table. Первая размерность совпадает со строками в <paramref name="keyTable"/> и соответствует
    /// уникальным комбинациям значений полей</param>
    public static void GroupRows(DataView srcDataView, string keyColumnNames, out DataTable keyTable, out DataRow[][] rows)
    {
      GroupRows(srcDataView, keyColumnNames, out keyTable, out rows, false);
    }

    /// <summary>
    /// Распределение строк таблицы, выбранных в <see cref="DataView"/> по группам с одинаковыми значениями ключевых
    /// полей. На входе задается список <paramref name="srcDataView"/> с произвольным набором строк.
    /// Создаются массивы <paramref name="rows"/> ссылок на строки таблицы, базовой для <paramref name="srcDataView"/>, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>.
    /// Во вспомогательную таблицу <paramref name="keyTable"/> помещаются строки с уникальными 
    /// комбинациями значений полей <paramref name="keyColumnNames "/> (других полей в таблице нет).
    /// Число строк в <paramref name="keyTable"/> совпадает с числом массивов <paramref name="rows"/>.
    /// Эта версия позволяет выполнить замену значений <see cref="DBNull"/> на 0 или пустую строку, в зависимости от типа данных
    /// </summary>
    /// <param name="srcDataView">Исходный <see cref="DataView"/>, из которого берутся строки.
    /// Таблица, на основе которой построен <paramref name="srcDataView"/>, должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// <param name="keyTable">Сюда записывается вспомогательная таблица значений полей</param>
    /// <param name="rows">Сюда записывается двумерный массив ссылок на строки таблицы
    /// <paramref name="srcDataView"/>.Table. Первая размерность совпадает со строками в <paramref name="keyTable"/> и соответствует
    /// уникальным комбинациям значений полей</param>
    /// <param name="dbNullAsZero">Если true, то значения <see cref="DBNull"/> полей <paramref name="keyColumnNames"/>
    /// в исходной таблице трактоваться как 0 (или пустая строка)</param>
    public static void GroupRows(DataView srcDataView, string keyColumnNames, out DataTable keyTable, out DataRow[][] rows, bool dbNullAsZero)
    {
#if DEBUG
      if (srcDataView == null)
        throw new ArgumentNullException("srcDataView");
      if (String.IsNullOrEmpty(keyColumnNames))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("keyColumnNames");
#endif
      string[] aKeyColumnNames = keyColumnNames.Split(',');
      int[] keyColumnPoss = new int[aKeyColumnNames.Length];
      keyTable = new DataTable();
      for (int i = 0; i < aKeyColumnNames.Length; i++)
      {
        keyColumnPoss[i] = GetColumnPosWithCheck(srcDataView.Table, aKeyColumnNames[i]);
        DataColumn srcCol = srcDataView.Table.Columns[keyColumnPoss[i]];
        keyTable.Columns.Add(srcCol.ColumnName, srcCol.DataType); // другие ограничения не применяем
      }
      // 26.01.2016
      // Среди значений полей, по которым выполняется группировка, могут быть DBNull.
      // Их нельзя применять в качестве первичных ключей таблицы, но можно использовать в сортировке DataView.Sort

      //DataTools.SetPrimaryKey(KeyTable, KeyColumnNames);
      object[] keyValues = new object[aKeyColumnNames.Length];
      keyTable.DefaultView.Sort = keyColumnNames;

      // 15.02.2019
      // Сначала добавляем все строки в ключевую таблицу, а затем - сортируем ее
      foreach (DataRowView srcDRV in srcDataView)
      {
        InitGroupRowsKeyValues(srcDRV.Row, keyValues, keyColumnPoss, dbNullAsZero);
        DataTools.FindOrAddDataRow(keyTable.DefaultView, keyValues);
      }
      keyTable = keyTable.DefaultView.ToTable();
      keyTable.DefaultView.Sort = keyColumnNames;

      List<List<DataRow>> rows2 = new List<List<DataRow>>(keyTable.Rows.Count);
      for (int i = 0; i < keyTable.Rows.Count; i++)
        rows2.Add(new List<DataRow>());

      foreach (DataRowView srcDRV in srcDataView)
      {
        InitGroupRowsKeyValues(srcDRV.Row, keyValues, keyColumnPoss, dbNullAsZero);
        DataRow keyRow = DataTools.FindOrAddDataRow(keyTable.DefaultView, keyValues); // 26.01.2017

        int keyRowIndex = keyTable.Rows.IndexOf(keyRow);
        List<DataRow> currList = rows2[keyRowIndex];
        currList.Add(srcDRV.Row);
      }

      // Преобразование списков в массив
      rows = new DataRow[rows2.Count][];
      for (int i = 0; i < rows2.Count; i++)
        rows[i] = rows2[i].ToArray();
    }

    /// <summary>
    /// Распределение строк таблицы, выбранных в <see cref="DataView"/> по группам с одинаковыми значениями ключевых
    /// полей. На входе задается список <paramref name="srcDataView"/> с произвольным набором строк.
    /// Создаются массивы ссылок на строки таблицы, базовой для <paramref name="srcDataView"/>, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>.
    /// Значения <see cref="DBNull"/> и нулевые значения/пустые строки различаются.
    /// </summary>
    /// <param name="srcDataView">Исходный <see cref="DataView"/>, из которого берутся строки.
    /// Таблица, на основе которой построен <paramref name="srcDataView"/>, должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// <returns>Возвращается двумерный массив ссылок на строки таблицы
    /// <paramref name="srcDataView"/>.Table. Первая размерность соответствует
    /// уникальным комбинациям значений полей</returns>
    public static DataRow[][] GroupRows(DataView srcDataView, string keyColumnNames)
    {
      DataTable keyTable;
      DataRow[][] rows;
      GroupRows(srcDataView, keyColumnNames, out keyTable, out rows, false);
      return rows;
    }

    /// <summary>
    /// Распределение строк таблицы, выбранных в <see cref="DataView"/> по группам с одинаковыми значениями ключевых
    /// полей. На входе задается список <paramref name="srcDataView"/> с произвольным набором строк.
    /// Создаются массивы Rows ссылок на строки таблицы, базовой для <paramref name="srcDataView"/>, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>/
    /// Эта версия позволяет выполнить замену значений <see cref="DBNull"/> на 0 или пустую строку, в зависимости от типа данных
    /// </summary>
    /// <param name="srcDataView">Исходная <see cref="DataView"/>, из которого берутся строки.
    /// Таблица, на основе которой построен <paramref name="srcDataView"/>, должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// <param name="dbNullAsZero">Если true, то значения <see cref="DBNull"/> полей <paramref name="keyColumnNames"/>
    /// в исходной таблице трактоваться как 0 (или пустая строка)</param>
    /// <returns>Возвращается двумерный массив ссылок на строки таблицы
    /// <paramref name="srcDataView"/>.Table. Первая размерность соответствует уникальным комбинациям значений полей</returns>
    public static DataRow[][] GroupRows(DataView srcDataView, string keyColumnNames, bool dbNullAsZero)
    {
      DataTable keyTable;
      DataRow[][] rows;
      GroupRows(srcDataView, keyColumnNames, out keyTable, out rows, dbNullAsZero);
      return rows;
    }

    #endregion

    #region DataRow[]

    /// <summary>
    /// Распределение строк таблицы по группам с одинаковыми значениями ключевых
    /// полей. На входе задается произвольный массив строк. Строки должны относится
    /// к одной таблице или однотипным таблицам.
    /// Создаются массивы <paramref name="rows"/> ссылок на строки исходного массива, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>.
    /// Во вспомогательную таблицу <paramref name="keyTable"/> помещаются строки с уникальными 
    /// комбинациями значений полей <paramref name="keyColumnNames"/> (других полей в таблице нет).
    /// Число строк в <paramref name="keyTable"/> совпадает с числом массивов <paramref name="rows"/>.
    /// В этой версии, если исходный массив строк пустой, то <paramref name="keyTable"/> не будет содержать ни одного поля
    /// Значения <see cref="DBNull"/> и нулевые значения/пустые строки различаются.
    /// </summary>
    /// <param name="srcRows">Исходные строки.
    /// Таблица, к которой относятся строки, должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// <param name="keyTable">Сюда записывается вспомогательная таблица значений полей</param>
    /// <param name="rows">Сюда записывается двумерный массив ссылок на строки 
    /// <paramref name="srcRows"/>. Первая размерность совпадает со строками в <paramref name="keyTable"/> и соответствует
    /// уникальным комбинациям значений полей</param>
    public static void GroupRows(DataRow[] srcRows, string keyColumnNames, out DataTable keyTable, out DataRow[][] rows)
    {
      GroupRows(srcRows, keyColumnNames, out keyTable, out rows, false);
    }

    /// <summary>
    /// Распределение строк таблицы по группам с одинаковыми значениями ключевых
    /// полей. На входе задается произвольный массив строк. Строки должны относится
    /// к одной таблице или однотипным таблицам
    /// Создаются массивы <paramref name="rows"/> ссылок на строки исходного массива, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>.
    /// Во вспомогательную таблицу <paramref name="keyTable"/> помещаются строки с уникальными 
    /// комбинациями значений полей <paramref name="keyColumnNames"/> (других полей в таблице нет).
    /// Число строк в <paramref name="keyTable"/> совпадает с числом массивов <paramref name="rows"/>.
    /// В этой версии, если исходный массив строк пустой, то <paramref name="keyTable"/> не будет содержать ни одного поля
    /// Эта версия позволяет выполнить замену значений <see cref="DBNull"/> на 0 или пустую строку, в зависимости от типа данных
    /// </summary>
    /// <param name="srcRows">Исходные строки.
    /// Таблица, к которой относятся строки, должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// <param name="keyTable">Сюда записывается вспомогательная таблица значений полей</param>
    /// <param name="rows">Сюда записывается двумерный массив ссылок на строки из массива <paramref name="srcRows"/>.
    /// Первая размерность совпадает со строками в <paramref name="keyTable"/> и соответствует
    /// уникальным комбинациям значений полей</param>
    /// <param name="dbNullAsZero">Если true, то значения <see cref="DBNull"/> полей <paramref name="keyColumnNames"/>
    /// в исходной таблице трактоваться как 0 (или пустая строка)</param>
    public static void GroupRows(DataRow[] srcRows, string keyColumnNames, out DataTable keyTable, out DataRow[][] rows, bool dbNullAsZero)
    {
#if DEBUG
      if (srcRows == null)
        throw new ArgumentNullException("srcTable");
      if (String.IsNullOrEmpty(keyColumnNames))
        throw ExceptionFactory.ArgStringIsNullOrEmpty("keyColumnNames");
#endif
      //if (srcRows == null)
      if (srcRows.Length == 0) // 27.12.2020
      {
        keyTable = new DataTable(); // пустышка
        rows = new DataRow[0][];
        return;
      }


      string[] aKeyColumnNames = keyColumnNames.Split(',');
      int[] keyColumnPoss = new int[aKeyColumnNames.Length];
      keyTable = new DataTable();
      for (int i = 0; i < aKeyColumnNames.Length; i++)
      {
        keyColumnPoss[i] = GetColumnPosWithCheck(srcRows[0].Table, aKeyColumnNames[i]);
        DataColumn SrcCol = srcRows[0].Table.Columns[keyColumnPoss[i]];
        keyTable.Columns.Add(SrcCol.ColumnName, SrcCol.DataType); // другие ограничения не применяем
      }

      // 26.01.2016
      // Среди значений полей, по которым выполняется группировка, могут быть DBNull.
      // Их нельзя применять в качестве первичных ключей таблицы, но можно использовать в сортировке DataView.Sort

      //DataTools.SetPrimaryKey(KeyTable, KeyColumnNames);
      object[] keyValues = new object[aKeyColumnNames.Length];
      keyTable.DefaultView.Sort = keyColumnNames;

      // 15.02.2019
      // Сначала добавляем все строки в ключевую таблицу, а затем - сортируем ее
      for (int j = 0; j < srcRows.Length; j++)
      {
        InitGroupRowsKeyValues(srcRows[j], keyValues, keyColumnPoss, dbNullAsZero);
        DataTools.FindOrAddDataRow(keyTable.DefaultView, keyValues);
      }
      keyTable = keyTable.DefaultView.ToTable();
      keyTable.DefaultView.Sort = keyColumnNames;

      List<List<DataRow>> rows2 = new List<List<DataRow>>(keyTable.Rows.Count);
      for (int i = 0; i < keyTable.Rows.Count; i++)
        rows2.Add(new List<DataRow>());

      for (int j = 0; j < srcRows.Length; j++)
      {
        InitGroupRowsKeyValues(srcRows[j], keyValues, keyColumnPoss, dbNullAsZero);
        DataRow keyRow = DataTools.FindOrAddDataRow(keyTable.DefaultView, keyValues); // 26.01.2017

        int keyRowIndex = keyTable.Rows.IndexOf(keyRow);
        List<DataRow> currList = rows2[keyRowIndex];
        currList.Add(srcRows[j]);
      }

      // Преобразование списков в массив
      rows = new DataRow[rows2.Count][];
      for (int i = 0; i < rows2.Count; i++)
        rows[i] = rows2[i].ToArray();
    }

    /// <summary>
    /// Распределение строк таблицы по группам с одинаковыми значениями ключевых
    /// полей. На входе задается произвольный массив строк. Строки должны относится
    /// к одной таблице или однотипным таблицам.
    /// Возвращаются массивы ссылок на строки исходного массива, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>.
    /// </summary>
    /// <param name="srcRows">Исходные строки.
    /// Таблица, к которой относятся строки, должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// <returns>Возвращается двумерный массив ссылок на строки масива
    /// <paramref name="srcRows"/>. Первая размерность соответствует уникальным комбинациям значений полей.</returns>
    public static DataRow[][] GroupRows(DataRow[] srcRows, string keyColumnNames)
    {
      DataTable keyTable;
      DataRow[][] rows;
      GroupRows(srcRows, keyColumnNames, out keyTable, out rows);
      return rows;
    }

    /// <summary>
    /// Распределение строк таблицы по группам с одинаковыми значениями ключевых
    /// полей. На входе задается произвольный массив строк. Строки должны относится
    /// к одной таблице или однотипным таблицам.
    /// Возвращаются массивы ссылок на строки исходного массива, каждый массив содержит
    /// строки с одинаковыми значеними полей в списке <paramref name="keyColumnNames"/>.
    /// </summary>
    /// <param name="srcRows">Исходные строки.
    /// Таблица, к которой относятся строки, должна содержать все поля, перечисленные в <paramref name="keyColumnNames"/></param>
    /// <param name="keyColumnNames">Список имен полей, разделенных запятыми</param>
    /// <param name="dbNullAsZero">Если true, то значения <see cref="DBNull"/> полей <paramref name="keyColumnNames"/>
    /// в исходной таблице трактоваться как 0 (или пустая строка)</param>
    /// <returns>Возвращается двумерный массив ссылок на строки масива
    /// <paramref name="srcRows"/>. Первая размерность соответствует уникальным комбинациям значений полей</returns>
    public static DataRow[][] GroupRows(DataRow[] srcRows, string keyColumnNames, bool dbNullAsZero)
    {
      DataTable keyTable;
      DataRow[][] rows;
      GroupRows(srcRows, keyColumnNames, out keyTable, out rows, dbNullAsZero);
      return rows;
    }

    #endregion

    #endregion

    #region SetRowState

    /// <summary>
    /// Установка требуемого состояния строки <see cref="DataRow"/>.
    /// Свойство <see cref="DataRow.RowState"/> доступно только для чтения.
    /// Вызывает методы <see cref="DataRow.SetAdded()"/>, <see cref="DataRow.SetModified()"/>, <see cref="DataRow.AcceptChanges()"/> или <see cref="DataRow.Delete()"/>.
    /// </summary>
    /// <param name="row">Строка, свойство <see cref="DataRow.RowState"/> которой требуется установить</param>
    /// <param name="newState">Требуемое значение свойства</param>
    public static void SetRowState(DataRow row, DataRowState newState)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
#endif

      if (row.RowState == newState)
        return; // Не требуется вносить изменения

      if (row.RowState == DataRowState.Detached)
      {
#if DEBUG
        if (row.Table == null)
          throw ExceptionFactory.ArgProperty("row", row, "DataRow.Table", row.Table, null);
#endif

        row.Table.Rows.Add(row);
        row.AcceptChanges(); // Нужно ли?
        if (newState == DataRowState.Unchanged)
          return;
      }

      switch (newState)
      {
        case DataRowState.Unchanged:
          switch (row.RowState)
          {
            case DataRowState.Added:
            case DataRowState.Modified:
              row.AcceptChanges();
              break;
            case DataRowState.Deleted:
              row.RejectChanges();
              break;
            default:
              throw new InvalidOperationException();
          }
          break;

        case DataRowState.Modified:
          switch (row.RowState)
          {
            case DataRowState.Added:
              row.AcceptChanges();
              row.SetModified();
              break;
            case DataRowState.Unchanged:
              row.SetModified();
              break;
            case DataRowState.Deleted:
              row.RejectChanges();
              row.SetModified();
              break;
            default:
              throw new InvalidOperationException();
          }
          break;

        case DataRowState.Added:
          switch (row.RowState)
          {
            case DataRowState.Modified:
              row.AcceptChanges();
              row.SetAdded();
              break;
            case DataRowState.Unchanged:
              row.SetAdded();
              break;
            case DataRowState.Deleted:
              row.RejectChanges();
              row.SetAdded();
              break;
            default:
              throw new InvalidOperationException();
          }
          break;

        case DataRowState.Deleted:
          switch (row.RowState)
          {
            case DataRowState.Unchanged:
              row.Delete();
              break;
            case DataRowState.Added:
            case DataRowState.Modified:
              row.AcceptChanges();
              row.Delete();
              break;
            default:
              throw new InvalidOperationException();
          }
          break;

        case DataRowState.Detached:
          row.Table.Rows.Remove(row);
          break;

        default:
          throw ExceptionFactory.ArgUnknownValue("newState", newState);
      }
    }

    #endregion

    #region CloneDataColumn

    /// <summary>
    /// Создание копии столбца <see cref="DataColumn"/>.
    /// Функция полезна когда требуется выполнить <see cref="DataTable.Clone()"/>, но не для всех столбцов таблицы.
    /// Возвращаемый объект <see cref="DataColumn"/> не присоединен ни к какой коллекции.
    /// </summary>
    /// <param name="srcColumn">Исходный столбец</param>
    /// <returns>Копия столбца</returns>
    public static DataColumn CloneDataColumn(DataColumn srcColumn)
    {
#if DEBUG
      if (srcColumn == null)
        throw new ArgumentNullException("srcColumn");
#endif

      DataColumn res = new DataColumn();

      res.ColumnName = srcColumn.ColumnName;
      res.DataType = srcColumn.DataType;
      res.Caption = srcColumn.Caption;
      res.Expression = srcColumn.Expression;
      res.DefaultValue = srcColumn.DefaultValue;
      res.AllowDBNull = srcColumn.AllowDBNull;
      res.AutoIncrement = srcColumn.AutoIncrement;
      res.AutoIncrementSeed = srcColumn.AutoIncrementSeed;
      res.AutoIncrementStep = srcColumn.AutoIncrementStep;
      res.ColumnMapping = srcColumn.ColumnMapping;
      res.DateTimeMode = srcColumn.DateTimeMode;
      res.MaxLength = srcColumn.MaxLength;
      res.Namespace = srcColumn.Namespace;
      res.ReadOnly = srcColumn.ReadOnly;
      res.Unique = srcColumn.Unique;

      CopyProperties(srcColumn.ExtendedProperties, res.ExtendedProperties);

      return res;
    }

    #endregion

    #region GetRowValues

    /// <summary>
    /// Возвращает массив значений полей строки (аналогичный свойству <see cref="DataRow.ItemArray"/>),
    /// но для заданной версии значений строки.
    /// Позволяет, в частности, получить значения для удаленной строки.
    /// </summary>
    /// <param name="row">Строка, откуда извлекаются данные</param>
    /// <param name="rowVersion">Требуемая версия значений</param>
    /// <returns>Массив значений</returns>
    public static object[] GetRowValues(DataRow row, DataRowVersion rowVersion)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
#endif
      object[] a = new object[row.Table.Columns.Count];
      for (int i = 0; i < a.Length; i++)
        a[i] = row[i, rowVersion];
      return a;
    }

    /// <summary>
    /// Возвращает значения полей строки в виде коллекции Имя-Значение для заданной версии значений строки.
    /// В основном, предназначено для отладочных целей.
    /// </summary>
    /// <param name="row">Строка, откуда извлекаются данные</param>
    /// <param name="rowVersion">Требуемая версия значений</param>
    /// <returns>Коллекция, где ключ - имя поля, значение - значение поля</returns>
    public static IDictionary<string, object> GetRowValueDictionary(DataRow row, DataRowVersion rowVersion)
    {
#if DEBUG
      if (row == null)
        throw new ArgumentNullException("row");
#endif

      Dictionary<string, object> dict = new Dictionary<string, object>(row.Table.Columns.Count);
      for (int i = 0; i < row.Table.Columns.Count; i++)
        dict.Add(row.Table.Columns[i].ColumnName, row[i, rowVersion]);
      return dict;
    }

    /// <summary>
    /// Возвращает значения полей строки в виде коллекции Имя-Значение.
    /// В основном, предназначено для отладочных целей.
    /// </summary>
    /// <param name="row">Строка, откуда извлекаются данные</param>
    /// <returns>Коллекция, где ключ - имя поля, значение - значение поля</returns>
    public static IDictionary<string, object> GetRowValueDictionary(DataRow row)
    {
      return GetRowValueDictionary(row, DataRowVersion.Default);
    }

    #endregion

    #region TrimEnd

    /// <summary>
    /// Во всех строках таблицы для всех строковых полей (<see cref="DataColumn.DataType"/>==typeof(<see cref="string"/>)) выполняется удаление
    /// конечных пробелов с помощью <see cref="String.TrimEnd(char[])"/>.
    /// В таблице не должно быть удаленных строк, иначе возникнет исключение при чтении значений.
    /// После вызова метода рекомендуется вызвать <see cref="DataTable.AcceptChanges()"/>.
    /// </summary>
    /// <param name="table">Обрабатываемая таблица данных</param>
    public static void TrimEnd(DataTable table)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
#endif

      switch (table.Rows.Count)
      {
        case 0:
          break;

        case 1:
          DataRow row = table.Rows[0];
          for (int i = 0; i < table.Columns.Count; i++)
          {
            if (table.Columns[i].DataType == typeof(string))
            {
              string s = row[i] as string;
              if (s != null)
              {
                s = s.TrimEnd();
                row[i] = s;
              }
            }
          }
          break;

        default:
          // Если несколько строк, собираем список полей
          List<int> colPoss = null;
          for (int i = 0; i < table.Columns.Count; i++)
          {
            if (table.Columns[i].DataType == typeof(string))
            {
              if (colPoss == null)
                colPoss = new List<int>();
              colPoss.Add(i);
            }
          }
          if (colPoss != null) // если нет строковых полей, незачем перебирать строки
          {
            foreach (DataRow row2 in table.Rows)
            {
              for (int j = 0; j < colPoss.Count; j++)
              {
                string s = row2[colPoss[j]] as string;
                if (s != null)
                {
                  s = s.TrimEnd();
                  row2[colPoss[j]] = s;
                }
              }
            }
          }
          break;
      }
    }

    /// <summary>
    /// Во всех строках таблиц набора, для всех строковых полей (<see cref="DataColumn.DataType"/>==typeof(<see cref="string"/>)) выполняется удаление
    /// конечных пробелов с помощью <see cref="String.TrimEnd(char[])"/>.
    /// В таблицах не должно быть удаленных строк, иначе возникнет исключение при чтении значений.
    /// После вызова метода рекомендуется вызвать <see cref="DataSet.AcceptChanges()"/>.
    /// </summary>
    /// <param name="ds">Обрабатываемые таблицы данных</param>
    public static void TrimEnd(DataSet ds)
    {
#if DEBUG
      if (ds == null)
        throw new ArgumentNullException("ds");
#endif

      for (int i = 0; i < ds.Tables.Count; i++)
        TrimEnd(ds.Tables[i]);
    }

    #endregion

    #region SortDataRows

    /// <summary>
    /// Сортировка массива строк в соответствии с заданным выражением.
    /// Строки могут относится к разным таблицам, но таблицы должны иметь одинаковую структуру.
    /// Создает временный объект <see cref="DataTable"/>/<see cref="DataView"/> для выполнения сортировки.
    /// </summary>
    /// <param name="rows">Массив строк, которые требуется сортировать. Если в массиве меньше 2 строк, то никаких действий не выполняется</param>
    /// <param name="sort">Выражение для сортировки. Если пустая строка или null, то никаких действий не выполняется</param>
    public static void SortDataRows(DataRow[] rows, string sort)
    {
#if DEBUG
      if (rows == null)
        throw new ArgumentNullException("rows");
#endif
      if (rows.Length < 2)
        return;
      if (String.IsNullOrEmpty(sort))
        return;

      DataTable table = rows[0].Table.Clone();
      table.Columns.Add("_$ORDER$_2c0dfea6832644e4ba55a994e0bedd10", typeof(int)); // чтобы точно такого имени небыло
      int ordColPos = table.Columns.Count - 1;
      table.BeginLoadData();
      for (int i = 0; i < rows.Length; i++)
      {
        DataRow row2 = table.Rows.Add(rows[i].ItemArray);
        row2[ordColPos] = i;
      }
      table.EndLoadData();
      table.DefaultView.Sort = sort;

      DataRow[] rows2 = new DataRow[rows.Length];
      for (int i = 0; i < table.DefaultView.Count; i++)
      {
        int order = (int)(table.DefaultView[i].Row[ordColPos]);
        rows2[i] = rows[order];
      }

      // Лучше замену массива выполнить в самом конце, тут меньше вероятность исключения
      rows2.CopyTo(rows, 0);
    }

    #endregion

    #region FormatDataValue()

    /// <summary>
    /// Форматирование константного значения для <see cref="DataColumn.Expression"/>, метода <see cref="DataTable.Select(string)"/>.
    /// Строки заключаются в апострофы и т.п. См. справку по свойству <see cref="DataColumn.Expression"/>.
    /// Идентичные действия выполняются методом BaseDBxSqlFormatter.OnFormatValue() в ExtDB.dll.
    /// </summary>
    /// <param name="value">Значение</param>
    /// <returns>Текстовое представление</returns>
    public static string FormatDataValue(object value)
    {
      if (value == null || value is DBNull)
        return "NULL";
      if (value is String)
        return FormatDataString((string)value);
      if (value is Guid)
        return FormatDataString(((Guid)value).ToString("D"));
      if (value is Boolean)
        return (bool)value ? "TRUE" : "FALSE";
      if (value is DateTime)
        return FormatDataDateTime((DateTime)value);
      if (value is TimeSpan)
      {
        // Изучил стек вызовов при ошибке
        // Преобразование работает правильно.
        // К сожалению (?), нельзя использовать TimeSpan в выражении Select, так как операции сравнения (в частности, "=") не поддерживаются вычислителем выражений

        string s = System.Xml.XmlConvert.ToString((TimeSpan)value); // весьма странное представление
        // Так нельзя: return s;
        return "CONVERT(" + FormatDataString(s) + ",\'System.TimeSpan\')";
      }
      if (value is char)
        return FormatDataString(new string((char)value, 1));

      IFormattable fv = value as IFormattable;
      if (fv != null)
        return fv.ToString(String.Empty, StdConvert.NumberFormat);
      else if (value.GetType().IsArray)
        throw ExceptionFactory.ArgUnknownType("value", value);
      else
        return value.ToString();
    }

    private static string FormatDataString(string value)
    {
      int p = value.IndexOf('\'');
      if (p >= 0)
      {
        // Требуется экранирование
        StringBuilder sb = new StringBuilder(value.Length + 3);
        sb.Append(@"'");
        for (int i = 0; i < value.Length; i++)
        {
          if (value[i] == '\'')
            sb.Append(@"''");
          else
            sb.Append(value[i]);
        }
        sb.Append(@"'");
        return sb.ToString();
      }
      else
        return @"'" + value + @"'";
    }

    private static string FormatDataDateTime(DateTime value)
    {
      bool useTime = value.TimeOfDay.Ticks != 0L;

      StringBuilder sb = new StringBuilder();
      sb.Append('#');

      sb.Append(StdConvert.ToString(value.Month));
      sb.Append('/');
      sb.Append(StdConvert.ToString(value.Day));
      sb.Append('/');
      sb.Append(StdConvert.ToString(value.Year));

      if (useTime)
      {
        sb.Append(' ');
        sb.Append(StdConvert.ToString(value.Hour));
        sb.Append(':');
        sb.Append(StdConvert.ToString(value.Minute));
        sb.Append(':');
        sb.Append(StdConvert.ToString(value.Second));
      }

      sb.Append('#');

      return sb.ToString();
    }

    #endregion

    #endregion

    #region Копирование данных

    /// <summary>
    /// Копирование "Строка в строку".
    /// Копируются все таблицы из исходного набора в конечный набор.
    /// Копируются только таблицы, существующие в обоих наборах. Они должны иметь одинаковую структуру.
    /// Строки заменяются, а не добавляются, то есть при копировании таблицы используются аргументы useColumnNames=false
    /// и addRows=false.
    /// Копируются ExtendedProperties как для <see cref="DataSet"/>, так и для копируемых таблиц.
    /// </summary>
    /// <param name="srcDS">Исходный набор данных</param>
    /// <param name="dstDS">Заполняемый набор данным</param>
    public static void CopyRowsToRows(DataSet srcDS, DataSet dstDS)
    {
#if DEBUG
      if (srcDS == null)
        throw new ArgumentNullException("srcDS");
      if (dstDS == null)
        throw new ArgumentNullException("dstDS");
#endif
      if (object.ReferenceEquals(srcDS, dstDS))
        throw ExceptionFactory.ArgAreSame("srcDS", "dstDS");

      for (int i = 0; i < srcDS.Tables.Count; i++)
      {
        DataTable srcTable = srcDS.Tables[i];
        DataTable dstTable = dstDS.Tables[srcTable.TableName];
        if (dstTable != null)
          CopyRowsToRows(srcTable, dstTable, false, false);
      }
      CopyProperties(srcDS.ExtendedProperties, dstDS.ExtendedProperties);
    }

    private static void CopyProperties(PropertyCollection src, PropertyCollection dst)
    {
      if (src.Count == 0)
        return;
      foreach (object key in src.Keys)
        dst[key] = src[key];
    }

    /// <summary>
    /// Построчное копирование таблиц.
    /// Все строки копируются по порядку номеров, исключая удаленные, т.к. нет доступа
    /// к полям
    /// Копирование значений полей может выполняться либо по номерам столбцов 
    /// (<paramref name="useColumnNames"/>=false), либо по именам столбцов.
    /// Копируются свойства ExtendedProperties таблицы.
    /// Копируются свойства ExtendedProperties каждого столбца.
    /// </summary>
    /// <param name="srcTable">Исходная таблица</param>
    /// <param name="dstTable">Конечная таблица</param>
    /// <param name="useColumnNames">true-использовать имена столбцов (таблицы могут иметь разную структуру), 
    /// false- использовать позиции столбцов (таблицы с одинаковой структурой)</param>
    /// <param name="addRows">true - добавлять строки в конечную таблицу, false-заменять значения в строках по номерам</param>
    public static void CopyRowsToRows(DataTable srcTable, DataTable dstTable, bool useColumnNames, bool addRows)
    {
#if DEBUG
      if (srcTable == null)
        throw new ArgumentNullException("srcTable");
      if (dstTable == null)
        throw new ArgumentNullException("dstTable");
#endif
      if (object.ReferenceEquals(srcTable, dstTable))
        throw ExceptionFactory.ArgAreSame("srcTable", "dstTable");

      // Таблица может содержать первичный ключ. 
      // При построчном копировании мы не используем поиск, поэтому ключ не нужен.
      // Если ключ оставить как есть, то может возникнуть ошибка копирования.
      //
      // Например, пусть исходная таблица SrcTable содержит две строки, со значениями 
      // ключевого поля "2" и "3". Перезаписываемая таблица пусть содержит строки
      // с ключами "1" и "2". Тогда, при копировании первой строки произойдет
      // ошибка, т.к. в DstTable окажутся строки с ключами "2" и "2".
      //
      // На время копирования первичный ключ убираем
      DataColumn[] oldPrimaryKey = dstTable.PrimaryKey;
      dstTable.PrimaryKey = null;
      try
      {
        if (useColumnNames)
        {
          // При копировании по именам столбцов сначала создаем список пар, которые можно копировать
          List<int> srcColPos = new List<int>();
          List<int> dstColPos = new List<int>();
          for (int i = 0; i < srcTable.Columns.Count; i++)
          {
            int p = dstTable.Columns.IndexOf(srcTable.Columns[i].ColumnName);
            if (p >= 0)
            {
              srcColPos.Add(i);
              dstColPos.Add(p);
              // Копируем свойства столбцов
              DataColumn srcCol = srcTable.Columns[i];
              DataColumn dstCol = dstTable.Columns[p];
              CopyProperties(srcCol.ExtendedProperties, dstCol.ExtendedProperties);
            }
          }
          if (srcColPos.Count > 0)
          {
            for (int i = 0; i < srcTable.Rows.Count; i++)
            {
              DataRow srcRow = srcTable.Rows[i];
              if (srcRow.RowState == DataRowState.Deleted)
                continue;
              DataRow dstRow = addRows ? dstTable.NewRow() : dstTable.Rows[i];
              for (int j = 0; j < srcColPos.Count; j++)
                dstRow[dstColPos[j]] = srcRow[srcColPos[j]];
              if (addRows)
                dstTable.Rows.Add(dstRow);
            }
          }
        }
        else
        {
          for (int i = 0; i < srcTable.Rows.Count; i++)
          {
            DataRow srcRow = srcTable.Rows[i];
            if (srcRow.RowState == DataRowState.Deleted)
              continue;
            DataRow dstRow = addRows ? dstTable.NewRow() : dstTable.Rows[i];
            CopyRowValues(srcRow, dstRow, false);
            if (addRows)
              dstTable.Rows.Add(dstRow);
          }
          // Копируем свойства столбцов
          for (int j = 0; j < srcTable.Columns.Count; j++)
          {
            DataColumn srcCol = srcTable.Columns[j];
            DataColumn dstCol = dstTable.Columns[j];
            CopyProperties(srcCol.ExtendedProperties, dstCol.ExtendedProperties);
          }
        }
      }
      finally
      {
        dstTable.PrimaryKey = oldPrimaryKey;
      }

      // Копируем свойства таблицы 
      CopyProperties(srcTable.ExtendedProperties, dstTable.ExtendedProperties);
    }

    /// <summary>
    /// Копирование одной строки в другую.
    /// При <paramref name="useColumnNames"/>=false копируются все поля по номерам. Предполагается, что таблицы,
    /// к которым относятся строки, имеют идентичный список полей.
    /// При <paramref name="useColumnNames"/>=true копируются только одноименные поля. Таблицы могут 
    /// иметь несовпадающую структуру полей (медленнее, т.к. требуется выполнять
    /// поиск для каждого поля).
    /// Если исходная строка помечена на удаление (<see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>), то используются значения полей в
    /// <paramref name="srcRow"/> версии <see cref="DataRowVersion.Original"/>, чтобы не возникало исключение <see cref="System.Data.DeletedRowInaccessibleException"/>.
    /// </summary>
    /// <param name="srcRow">Исходная строка</param>
    /// <param name="dstRow">Строка, принимающая значения</param>
    /// <param name="useColumnNames">true - использовать имена полей, false-использовать номера полей</param>
    public static void CopyRowValues(DataRow srcRow, DataRow dstRow, bool useColumnNames)
    {
#if DEBUG
      if (srcRow == null)
        throw new ArgumentNullException("srcRow");
      if (dstRow == null)
        throw new ArgumentNullException("dstRow");

      // Это ужасно, но работать будет
      if (object.ReferenceEquals(srcRow, dstRow))
        throw ExceptionFactory.ArgAreSame("srcRow", "dstRow");
#endif

      if (useColumnNames)
      {
        DataColumnCollection srcColumns = srcRow.Table.Columns;
        DataColumnCollection dstColumns = dstRow.Table.Columns;
        DataRowVersion srcVer = DataRowVersion.Default;
        if (srcRow.RowState == DataRowState.Deleted)
          srcVer = DataRowVersion.Original; // 17.07.2020

        for (int i = 0; i < srcColumns.Count; i++)
        {
          int p = dstColumns.IndexOf(srcColumns[i].ColumnName);
          if (p >= 0)
            dstRow[p] = srcRow[i, srcVer];
        }
      }
      else
      {
        if (srcRow.RowState == DataRowState.Deleted) // 17.07.2020
        {
          int n = srcRow.Table.Columns.Count;
          for (int i = 0; i < n; i++)
            dstRow[i] = srcRow[i, DataRowVersion.Original];
        }
        else
        {
          object[] a = srcRow.ItemArray;
          dstRow.ItemArray = a;
        }
      }
    }

    /// <summary>
    /// Копирование значений полей из одной строки в другую для заданных имен полей.
    /// Если исходная строка помечена на удаление (<see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>), то используются значения полей в
    /// <paramref name="srcRow"/> версии <see cref="DataRowVersion.Original"/>, чтобы не возникало исключение <see cref="System.Data.DeletedRowInaccessibleException"/>.
    /// </summary>
    /// <param name="srcRow">Исходная строка</param>
    /// <param name="dstRow">Конечная строка</param>
    /// <param name="columnNames">Список имен столбцов, разделенных запятыми</param>
    public static void CopyRowValues(DataRow srcRow, DataRow dstRow, string columnNames)
    {
      CopyRowValues(srcRow, dstRow, columnNames.Split(','));
    }

    /// <summary>
    /// Копирование значений полей из одной строки в другую для заданных имен полей.
    /// Если исходная строка помечена на удаление (<see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>), то используются значения полей в
    /// <paramref name="srcRow"/> версии <see cref="DataRowVersion.Original"/>, чтобы не возникало исключение <see cref="System.Data.DeletedRowInaccessibleException"/>.
    /// </summary>
    /// <param name="srcRow">Исходная строка</param>
    /// <param name="dstRow">Конечная строка</param>
    /// <param name="columnNames">Массив имен столбцов</param>
    public static void CopyRowValues(DataRow srcRow, DataRow dstRow, string[] columnNames)
    {
#if DEBUG
      if (srcRow == null)
        throw new ArgumentNullException("srcRow");
      if (dstRow == null)
        throw new ArgumentNullException("dstRow");

      // Это ужасно, но работать будет
      if (object.ReferenceEquals(srcRow, dstRow))
        throw ExceptionFactory.ArgAreSame("srcRow", "dstRow");
#endif

      DataRowVersion srcVer = DataRowVersion.Default;
      if (srcRow.RowState == DataRowState.Deleted)
        srcVer = DataRowVersion.Original; // 17.07.2020

      for (int i = 0; i < columnNames.Length; i++)
        dstRow[columnNames[i]] = srcRow[columnNames[i], srcVer];
    }

    /// <summary>
    /// Копирует все поля, имена которых начинаются с префикса <paramref name="srcColumnPrefix"/>, из строки <paramref name="srcRow"/> в
    /// строку <paramref name="dstRow"/> в поле, имя которого начинается с <paramref name="dstColumnPrefix"/>.
    /// Если исходная строка помечена на удаление (<see cref="DataRow.RowState"/>=<see cref="DataRowState.Deleted"/>), то используются значения полей в
    /// <paramref name="srcRow"/> версии <see cref="DataRowVersion.Original"/>, чтобы не возникало исключение <see cref="System.Data.DeletedRowInaccessibleException"/>.
    /// </summary>
    /// <param name="srcRow">Исходная строка</param>
    /// <param name="dstRow">Конечная строка</param>
    /// <param name="srcColumnPrefix">Префикс имени поля в исходной строке. Регистр символов учитывается</param>
    /// <param name="dstColumnPrefix">Префикс имени поля в конечной строке. Регистр символов учитывается</param>
    public static void CopyRowValuesForPrefix(DataRow srcRow, DataRow dstRow, string srcColumnPrefix, string dstColumnPrefix)
    {
#if DEBUG
      if (srcRow == null)
        throw new ArgumentNullException("srcRow");
      if (dstRow == null)
        throw new ArgumentNullException("dstRow");

      // Строки могут совпадать
      //if (object.ReferenceEquals(srcRow, dstRow))
      //  throw new ArgumentException("Нельзя копировать строку саму в себя", "dstRow");
#endif

      DataRowVersion srcVer = DataRowVersion.Default;
      if (srcRow.RowState == DataRowState.Deleted)
        srcVer = DataRowVersion.Original; // 17.07.2020

      for (int i = 0; i < srcRow.Table.Columns.Count; i++)
      {
        string columnName = srcRow.Table.Columns[i].ColumnName;
        if (!String.IsNullOrEmpty(srcColumnPrefix))
        {
          if (columnName.StartsWith(srcColumnPrefix, StringComparison.Ordinal))
            columnName = columnName.Substring(srcColumnPrefix.Length);
          else
            continue;
        }
        if (!String.IsNullOrEmpty(dstColumnPrefix))
          columnName = dstColumnPrefix + columnName;
        int p = dstRow.Table.Columns.IndexOf(columnName);
        if (p >= 0)
          dstRow[p] = srcRow[i, srcVer];
      }
    }

    #endregion

    #region Замена значений

    /// <summary>
    /// Заменяет значения поля <paramref name="columnName"/>, содержащие <see cref="DBNull"/> на значение <paramref name="newValue"/>
    /// </summary>
    /// <param name="table">Таблица, в которой выполняется замена</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="newValue">Новое значение</param>
    public static void ReplaceNulls(DataTable table, string columnName, object newValue)
    {
#if DEBUG
      if (newValue == null)
        throw new ArgumentNullException("newValue");
#endif

      int fp = GetColumnPosWithCheck(table, columnName);

      for (int i = 0; i < table.Rows.Count; i++)
      {
        if (table.Rows[i].IsNull(fp))
          table.Rows[i][fp] = newValue;
      }
    }

    /// <summary>
    /// Заменяет значения поля <paramref name="columnName"/>, содержащие <see cref="DBNull"/> на значение <paramref name="newValue"/>.
    /// Т.к. замена значения может привести к перестроению <see cref="DataView"/>, собираем
    /// сначала массив строк, в котором выполняем замену.
    /// </summary>
    /// <param name="dv">Просмотр для таблицы, в которой выполняется замена</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="newValue">Новое значение</param>
    public static void ReplaceNulls(DataView dv, string columnName, object newValue)
    {
      DataRow[] rows = GetDataViewRows(dv);
      ReplaceNulls(rows, columnName, newValue);
    }

    /// <summary>
    /// Заменяет значения поля <paramref name="columnName"/>, содержащие <see cref="DBNull"/> на значение <paramref name="newValue"/>
    /// Строки должны относиться к одной таблице или нескольким таблицам, чтобы
    /// позиция поля была одинаковой для всех строк.
    /// </summary>
    /// <param name="rows">Массив строк, в которых выполняется замена</param>
    /// <param name="columnName">Имя поля</param>
    /// <param name="newValue">Новое значение</param>
    public static void ReplaceNulls(DataRow[] rows, string columnName, object newValue)
    {
#if DEBUG
      if (newValue == null)
        throw new ArgumentNullException("newValue");
#endif

      if (rows == null)
        return;
      if (rows.Length == 0)
        return;
      int fp = GetColumnPosWithCheck(rows[0].Table, columnName);

      for (int i = 0; i < rows.Length; i++)
      {
        if (rows[i].IsNull(fp))
          rows[i][fp] = newValue;
      }
    }

    #endregion

    #region Обрезка текстовых полей

    /// <summary>
    /// Обрезать строки значений заданного текстового поля в таблице.
    /// Необходимость в обрезке может появится, если таблица загружена из базы данныз,
    /// но для доступа не используются метод <see cref="GetString(DataRow, string)"/>, который выполняет обрезку
    /// при извлечении строки.
    /// Если для столбца <see cref="DataColumn.AllowDBNull"/>, то пустые строки,
    /// а также строки, содержащие только пробелы, будут заменены на <see cref="DBNull"/>.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnName">Имя текстового поля</param>
    public static void StrTrim(DataTable table, string columnName)
    {
      StrTrim(table, GetColumnPosWithCheck(table, columnName));
    }

    /// <summary>
    /// Обрезать строки значений заданного текстового поля в таблице.
    /// Необходимость в обрезке может появится, если таблица загружена из базы данныз,
    /// но для доступа не используются метод <see cref="GetString(DataRow, string)"/>, который выполняет обрезку
    /// при извлечении строки.
    /// Если для столбца <see cref="DataColumn.AllowDBNull"/>, то пустые строки,
    /// а также строки, содержащие только пробелы, будут заменены на <see cref="DBNull"/>.
    /// </summary>
    /// <param name="table">Таблица</param>
    /// <param name="columnIndex">Индекс текстового поля</param>
    public static void StrTrim(DataTable table, int columnIndex)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
      if (columnIndex < 0 || columnIndex >= table.Columns.Count)
        throw ExceptionFactory.ArgOutOfRange("columnIndex", columnIndex, 0, table.Columns.Count - 1);
#endif
      DataColumn col = table.Columns[columnIndex];

      if (col.DataType != typeof(string))
        throw ExceptionFactory.ArgInvalidColumnType("columnIndex", col);

      foreach (DataRow row in table.Rows)
      {
        if (row.IsNull(columnIndex))
          continue;
        string s1 = (string)row[columnIndex];
        string s2 = s1.Trim();
        if (s2.Length == s1.Length)
          continue;
        if (s2.Length == 0 && col.AllowDBNull)
          row[columnIndex] = DBNull.Value;
        else
          row[columnIndex] = s2;
      }
    }

    /// <summary>
    /// Обрезать строки значений всех текстовых полей в таблице.
    /// Необходимость в обрезке может появится, если таблица загружена из базы данныз,
    /// но для доступа не используются метод <see cref="GetString(DataRow, string)"/>, который выполняет обрезку
    /// при извлечении строки.
    /// Если для столбца <see cref="DataColumn.AllowDBNull"/>, то пустые строки,
    /// а также строки, содержащие только пробелы, будут заменены на <see cref="DBNull"/>.
    /// </summary>
    /// <param name="table">Таблица</param>
    public static void StrTrim(DataTable table)
    {
#if DEBUG
      if (table == null)
        throw new ArgumentNullException("table");
#endif
      if (table.Rows.Count == 0)
        return;

      for (int i = 0; i < table.Columns.Count; i++)
      {
        if (table.Columns[i].DataType == typeof(string))
          StrTrim(table, i);
      }
    }

    /// <summary>
    /// Обрезать строки значений всех текстовых полей в таблицах набора DataSet.
    /// Необходимость в обрезке может появится, если таблица загружена из базы данныз,
    /// но для доступа не используются метод <see cref="GetString(DataRow, string)"/>, который выполняет обрезку
    /// при извлечении строки.
    /// Если для столбца <see cref="DataColumn.AllowDBNull"/>, то пустые строки,
    /// а также строки, содержащие только пробелы, будут заменены на <see cref="DBNull"/>.
    /// </summary>
    /// <param name="ds">Набор данных</param>
    public static void StrTrim(DataSet ds)
    {
#if DEBUG
      if (ds == null)
        throw new ArgumentNullException("ds");
#endif

      for (int i = 0; i < ds.Tables.Count; i++)
        StrTrim(ds.Tables[i]);
    }

    #endregion

    #region Обновление строк таблицы

    /// <summary>
    /// Обновление строк таблицы приемника строками из таблицы-источника по значению первичного ключа
    /// Таблица-приемник должна иметь первичный ключ. Строки в исходной таблице
    /// должны иметь поля для вычисления первичного ключа во второй таблице.
    /// Копирование значений полей может выполняться либо по номерам столбцов 
    /// (<paramref name="useColumnNames"/>=false), либо по именам столбцов.
    /// Cвойства ExtendedProperties не копируются.
    /// Если таблица-приемник не имеет строки, соответствуюшей какой-либо строке в исходной таблице, такая строка пропускается.
    /// Количество строк в таблице-приемнике не меняется.
    /// Для полного обновления таблицы используйте метод <see cref="UpdateTableByPrimaryKey(DataTable, DataTable, bool)"/>.
    /// </summary>
    /// <param name="srcTable">Таблица-источник строк</param>
    /// <param name="dstTable">Таблица-приемник строк (обновляемая таблица)</param>
    /// <param name="useColumnNames">Если true, то будут использоваться имена столбцов, а не позиции</param>
    public static void UpdateRowsByPrimaryKey(DataTable srcTable, DataTable dstTable, bool useColumnNames)
    {
#if DEBUG
      if (srcTable == null)
        throw new ArgumentNullException("srcTable");
      if (dstTable == null)
        throw new ArgumentNullException("dstTable");
#endif
      if (Object.ReferenceEquals(srcTable, dstTable))
        throw ExceptionFactory.ArgAreSame("srcTable", "dstTable");

      foreach (DataRow srcRow in srcTable.Rows)
        UpdateRowByPrimaryKey(srcRow, dstTable, useColumnNames);
    }

    /// <summary>
    /// Обновление строки таблицы-приемника значениями из другой строки по значению ключа
    /// </summary>
    /// <param name="srcRow">Исходная строка. Если null, то никаких действий не выполняется</param>
    /// <param name="dstTable">Обновляемая таблица</param>
    /// <param name="useColumnNames">true, если при копировании значений будут использоваться имена полей,
    /// false-будет выполняться копирование столбцов по порядку</param>
    /// <returns>true, если в таблице <paramref name="dstTable"/> найдена строка для обновления</returns>
    private static bool UpdateRowByPrimaryKey(DataRow srcRow, DataTable dstTable, bool useColumnNames)
    {
      if (srcRow == null)
        return false;

#if DEBUG
      if (dstTable == null)
        throw new ArgumentNullException("dstTable");
#endif

      if (srcRow.RowState == DataRowState.Deleted)
        return false;

      // Поиск по ключу
      object[] keys = GetPrimaryKeyValues(srcRow, dstTable);
      if (keys == null)
        throw ExceptionFactory.ArgDataTableWithoutPrimaryKey("dstTable", dstTable);

      DataRow dstRow = dstTable.Rows.Find(keys);
      if (dstRow == null)
        return false;

      CopyRowValues(srcRow, dstRow, useColumnNames);
      return true;
    }

    /// <summary>
    /// Обновление таблицы строками из другой таблицы по первичному ключу.
    /// Таблица-приемник должна иметь первичный ключ. Строки в исходной таблице
    /// должны иметь поля для вычисления первичного ключа во второй таблице.
    /// После выполнения действия конечная таблица будет иметь столько же строк (кроме
    /// удаленных), сколько и исходная таблица. В конечной таблице строки могут
    /// добавляться, удаляться, изменяться или оставаться неизменными.
    /// Копирование значений полей может выполняться либо по номерам столбцов 
    /// (<paramref name="useColumnNames"/>=false), либо по именам столбцов.
    /// Cвойства ExtendedProperties не копируются.
    /// В <paramref name="dstTable"/> могут оставаться удаленные строки. 
    /// После выполнения обновления рекомендуется вызвать <paramref name="dstTable"/>.AcceptChanges(), чтобы полностью убрать удаленные строки.
    /// </summary>
    /// <param name="srcTable">Исходная таблица</param>
    /// <param name="dstTable">Таблица, в которой выполняются замены</param>
    /// <param name="useColumnNames">true, если при копировании значений будут использоваться имена полей,
    /// false-будет выполняться копирование столбцов по порядку</param>
    public static void UpdateTableByPrimaryKey(DataTable srcTable, DataTable dstTable, bool useColumnNames)
    {
#if DEBUG
      if (srcTable == null)
        throw new ArgumentNullException("srcTable");
      if (dstTable == null)
        throw new ArgumentNullException("dstTable");
#endif
      if (Object.ReferenceEquals(srcTable, dstTable))
        throw ExceptionFactory.ArgAreSame("srcTable", "dstTable");

      // Список строк в DstTable, которые были использованы
      Dictionary<DataRow, object> usedRows = new Dictionary<DataRow, object>(dstTable.Rows.Count);

      int orgRowCount = dstTable.Rows.Count;

      dstTable.BeginLoadData();
      try
      {
        #region Первый проход - добавление / изменение строк

        foreach (DataRow srcRow in srcTable.Rows)
        {
          // Поиск по ключу
          object[] keys = GetPrimaryKeyValues(srcRow, dstTable);
          if (keys == null)
            throw ExceptionFactory.ArgDataTableWithoutPrimaryKey("dstTable", dstTable);

          DataRow dstRow = dstTable.Rows.Find(keys);
          if (dstRow == null)
          {
            dstRow = dstTable.NewRow();
            CopyRowValues(srcRow, dstRow, useColumnNames);
            dstTable.Rows.Add(dstRow);
          }
          else
          {
            CopyRowValues(srcRow, dstRow, useColumnNames);
            usedRows.Add(dstRow, null);
          }
        }

        #endregion

        #region Второй проход - удаление ненужных строк

        for (int i = orgRowCount - 1; i >= 0; i--)
        {
          if (!usedRows.ContainsKey(dstTable.Rows[i]))
            dstTable.Rows[i].Delete();
        }

        #endregion
      }
      finally
      {
        dstTable.EndLoadData();
      }
    }

    #endregion

    #region Функции для работы с DataView

    /// <summary>
    /// Поиск строки <see cref="DataRowView"/>, соответствующей исходной строке <see cref="DataRow"/> в объекте <see cref="DataView"/>.
    /// </summary>
    /// <param name="dv">Объект <see cref="DataView"/></param>
    /// <param name="row">Строка <see cref="DataRow"/></param>
    /// <returns>Найденный объект <see cref="DataRowView "/> или null</returns>
    public static DataRowView FindDataRowView(DataView dv, DataRow row)
    {
      int idx = FindDataRowViewIndex(dv, row);
      if (idx < 0)
        return null;
      else
        return dv[idx];
    }

    /// <summary>
    /// Поиск индекса исходной строки <see cref="DataRow"/> в объекте <see cref="DataView"/>.
    /// </summary>
    /// <param name="dv">Объект <see cref="DataView"/></param>
    /// <param name="row">Строка <see cref="DataRow"/></param>
    /// <returns>Индекс соответствующего объекта <see cref="DataRowView"/> в <see cref="DataView"/> или
    /// (-1), если строка не входит в <see cref="DataView"/> (например, отфильтрована)</returns>
    public static int FindDataRowViewIndex(DataView dv, DataRow row)
    {
#if DEBUG
      if (dv == null)
        throw new ArgumentNullException("dv");
#endif
      if (row == null)
        return -1;

      if (!Object.ReferenceEquals(row.Table, dv.Table))
        return -1; // 04.07.2021 - строка относится к другой таблице. Поиск не имеет смысла

      if (dv.Count > 50 && (!String.IsNullOrEmpty(dv.Sort)))
      {
        // 04.07.2021
        // Оптимизированный поиск с использованием DataView.Find()

        string[] colNames = GetDataViewSortColumnNames(dv.Sort);
        int[] colPoss = new int[colNames.Length];
        object[] rowVals = new object[colNames.Length];
        for (int j = 0; j < colNames.Length; j++)
        {
          colPoss[j] = row.Table.Columns.IndexOf(colNames[j]);
#if DEBUG
          if (colPoss[j] < 0)
            throw new BugException("Column not found: \"" + colNames[j] + "\"");
#endif

          rowVals[j] = row[colPoss[j]];
        }

        int p0 = dv.Find(rowVals);
        if (p0 < 0)
          return -1;

        for (int i = p0; i < dv.Count; i++)
        {
          if (object.ReferenceEquals(dv[i].Row, row))
            return i; // нашли

          bool sameKeys = true;
          for (int j = 0; j < colNames.Length; j++)
          {
            if (!Object.Equals(dv[i].Row[colPoss[j]], rowVals[j]))
            {
              sameKeys = false;
              break;
            }
          }
          if (!sameKeys)
            break;
        }

        // Нет 100% гарантии, что не осталось строк перед найденной.
        // На всякий случай, выполняем поиск назад.
        // Скорее всего, цикл завершится после первого же такта
        for (int i = p0 - 1; i >= 0; i--)
        {
          if (object.ReferenceEquals(dv[i].Row, row))
            return i; // нашли

          bool sameKeys = true;
          for (int j = 0; j < colNames.Length; j++)
          {
            if (!Object.Equals(dv[i].Row[colPoss[j]], rowVals[j]))
            {
              sameKeys = false;
              break;
            }
          }
          if (!sameKeys)
            break;
        }
      }

      // Придется перебирать все строки вручную
      for (int i = 0; i < dv.Count; i++)
      {
        if (object.ReferenceEquals(dv[i].Row, row))
          return i;
      }
      return -1;
    }

    /// <summary>
    /// Получение массива строк <see cref="DataRow"/> соответствующих объекту <see cref="DataView"/>
    /// </summary>
    /// <param name="dv">Объект <see cref="DataView"/>. Если null, то будет возвращен пустой массив строк</param>
    /// <returns>Массив строк</returns>
    /// <seealso cref="GetDataTableRows(DataTable)"/>
    public static DataRow[] GetDataViewRows(DataView dv)
    {
      if (dv == null || dv.Count == 0)
        return EmptyArray<DataRow>.Empty;
      DataRow[] res = new DataRow[dv.Count];
      for (int i = 0; i < dv.Count; i++)
        res[i] = dv[i].Row;
      return res;
    }

    /// <summary>
    /// Преобразует массив <see cref="DataRowView"/> в массив <see cref="DataRow"/>.
    /// Может быть полезно при обработке результатов вызова метода <see cref="DataView.FindRows(object)"/>.
    /// </summary>
    /// <param name="drvs">Массив <see cref="DataRowView"/></param>
    /// <returns>Массив строк таблицы</returns>
    public static DataRow[] GetDataRowViewRows(DataRowView[] drvs)
    {
      if (drvs == null || drvs.Length == 0)
        return EmptyArray<DataRow>.Empty;

      DataRow[] a = new DataRow[drvs.Length];
      for (int i = 0; i < drvs.Length; i++)
        a[i] = drvs[i].Row;
      return a;
    }

#if XXXXXXXXXXXXXXX
    // Есть метод DataView.ToTable()


    /// <summary>
    /// Создает новую таблицу DataTable, куда попадают копии строк из таблицы,
    /// на которой основан объект DataView. Учитывается порядок строк и фильтр,
    /// заданный в просмотре
    /// </summary>
    /// <param name="dv">Просмотр DataView</param>
    /// <returns>Новая таблица</returns>
    public static DataTable CreateTableForDataView(DataView dv)
    {
      DataTable Table = dv.Table.Clone();
      Table.TableName = dv.Table.TableName;
      for (int i = 0; i < dv.Count; i++)
      {
        DataRow SrcRow = dv[i].Row;
        Table.Rows.Add(SrcRow.ItemArray);
      }
      return Table;
    }
#endif

    /// <summary>
    /// Создает словарь пар "Значение поле Id" - "Индекс строки в просмотре" для
    /// набора данных <see cref="DataView"/>.
    /// Предупреждение: после изменения параметров <see cref="DataView"/> или данных в таблице,
    /// полученный словарь становится недействительным.
    /// </summary>
    /// <param name="dv">Объект DataView</param>
    /// <returns>Словарь</returns>
    public static Dictionary<Int32, int> GetDataViewIdIndexDictionary(DataView dv)
    {
      Dictionary<Int32, int> res = new Dictionary<Int32, int>(dv.Count);
      for (int i = 0; i < dv.Count; i++)
      {
        Int32 id = (Int32)(dv[i].Row["Id"]);
        res.Add(id, i);
      }
      return res;
    }

    #region GetDataViewSortColumnNames

    /// <summary>
    /// Извлечь имена столбцов из свойства <see cref="DataView.Sort"/>.
    /// Строка может содержать пробелы и суффиксы "ASC" и "DESC" (игнорируются)
    /// Если строка <paramref name="sort"/> пустая, возвращается пустой массив.
    /// В этой версии информация о порядке сортировки теряется.
    /// Имя столбца может быть заключено в квадратные скобки, которые удаляются.
    /// </summary>
    /// <param name="sort">Значение свойства <see cref="DataView.Sort"/></param>
    /// <returns>Массис имен полей или null</returns>
    /// <remarks>
    /// <see cref="DataView.Sort"/> не может содержать функции и математические операции, а только имена полей и порядок сортировки.
    /// </remarks>
    public static string[] GetDataViewSortColumnNames(string sort)
    {
      string[] columnNames;
      ListSortDirection[] directions;
      GetDataViewSortColumnNames(sort, out columnNames, out directions);
      return columnNames;
    }

    /// <summary>
    /// Извлечь имена столбцов из свойства <see cref="DataView.Sort"/>.
    /// Строка может содержать пробелы и суффиксы "ASC" и "DESC" (игнорируются)
    /// Расширенная версия. Возвращается массив значений порядка сортировки.
    /// Имя столбца может быть заключено в квадратные скобки, которые удаляются.
    /// Если строка <paramref name="sort"/> пустая, возвращаются пустые массивы.
    /// </summary>
    /// <param name="sort">Значение свойства <see cref="DataView.Sort"/></param>
    /// <param name="columnNames">Сюда записывается массив имен столбцов</param>
    /// <param name="directions">Сюда записывается массив признаков сортировки</param>
    /// <returns>Массис имен полей или null</returns>
    /// <remarks>
    /// <see cref="DataView.Sort"/> не может содержать функции и математические операции, а только имена полей и порядок сортировки.
    /// </remarks>
    public static void GetDataViewSortColumnNames(string sort, out string[] columnNames, out ListSortDirection[] directions)
    {
      if (String.IsNullOrEmpty(sort))
      {
        columnNames = EmptyArray<string>.Empty;
        directions = EmptyArray<ListSortDirection>.Empty;
        return;
      }

      columnNames = sort.Split(',');
      directions = new ListSortDirection[columnNames.Length];

      for (int i = 0; i < columnNames.Length; i++)
      {
        directions[i] = ListSortDirection.Ascending;

        string s = columnNames[i].Trim();
        if (s.EndsWith(" DESC", StringComparison.OrdinalIgnoreCase))
        {
          s = s.Substring(0, s.Length - 5);
          directions[i] = ListSortDirection.Descending;
        }
        else
        {
          if (s.EndsWith(" ASC", StringComparison.OrdinalIgnoreCase))
            s = s.Substring(0, s.Length - 4);
        }
        if (s.Length == 0)
          throw ExceptionFactory.ArgUnknownValue("sort", sort);
        if (s[0] == '[' && s[s.Length - 1] == ']') // 21.04.2023
          s = s.Substring(1, s.Length - 2);
        columnNames[i] = s;
      }
    }

    /// <summary>
    /// Извлечь имя столбца из свойства <see cref="DataView.Sort"/>.
    /// Строка может содержать пробелы и суффикс "ASC" и "DESC" (игнорируются).
    /// Если строка <paramref name="sort"/> пустая, возвращается пустая строка.
    /// Имя столбца может быть заключено в квадратные скобки, которые удаляются.
    /// В этой версии информация о порядке сортировки теряется.
    /// Если задан порядок сортировки по нескольким полям, генерируется исключение.
    /// </summary>
    /// <param name="sort">Значение свойства <see cref="DataView.Sort"/></param>
    /// <returns>Имя поля или пустая строка</returns>                          
    /// <remarks>
    /// <see cref="DataView.Sort"/> не может содержать функции и математические операции, а только имена полей и порядок сортировки.
    /// </remarks>
    public static string GetDataViewSortSingleColumnName(string sort)
    {
      string columnName;
      ListSortDirection direction;
      GetDataViewSortSingleColumnName(sort, out columnName, out direction);
      return columnName;
    }

    /// <summary>
    /// Извлечь имя столбца из свойства <see cref="DataView.Sort"/>.
    /// Строка может содержать пробелы и суффикс ASC и DESC.
    /// Если строка <paramref name="sort"/> пустая, возвращается пустая строка и порядок сортировки по возрастанию.
    /// Имя столбца может быть заключено в квадратные скобки, которые удаляются.
    /// Если задан порядок сортировки по нескольким полям, генерируется исключение.
    /// </summary>
    /// <param name="sort">Свойство DataView.Sort</param>
    /// <param name="columnName">Сюда записывается имя поля</param>
    /// <param name="direction">Сюда записывается направление сортировки</param>
    /// <remarks>
    /// <see cref="DataView.Sort"/> не может содержать функции и математические операции, а только имена полей и порядок сортировки.
    /// </remarks>
    public static void GetDataViewSortSingleColumnName(string sort, out string columnName, out ListSortDirection direction)
    {
      direction = ListSortDirection.Ascending;
      if (String.IsNullOrEmpty(sort))
      {
        columnName = String.Empty;
        return;
      }

      if (sort.IndexOf(',') >= 0)
        throw ExceptionFactory.ArgInvalidChar("sort", sort, ",");

      columnName = sort.Trim();
      if (columnName.EndsWith(" DESC", StringComparison.OrdinalIgnoreCase))
      {
        columnName = columnName.Substring(0, columnName.Length - 5);
        direction = ListSortDirection.Descending;
      }
      else
      {
        if (columnName.EndsWith(" ASC", StringComparison.OrdinalIgnoreCase))
          columnName = columnName.Substring(0, columnName.Length - 4);
      }
      if (columnName.Length == 0)
        throw ExceptionFactory.ArgUnknownValue("sort", sort);
      if (columnName[0] == '[' && columnName[columnName.Length - 1] == ']')
        columnName = columnName.Substring(1, columnName.Length - 2);
    }

    /// <summary>
    /// Получение выражения для сортировки <see cref="DataView.Sort"/>.
    /// Длина массивов <paramref name="columnNames"/> и <paramref name="directions"/> должна быть одинаковой.
    /// Если длина массивов равна 0, возвращается пустая строка.
    /// В текущей реализации квадратные скобки вокруг имен полей не добавляются.
    /// Функция является обратной по отношению к <see cref="GetDataViewSortColumnNames(string, out string[], out ListSortDirection[])"/>.
    /// </summary>
    /// <param name="columnNames">Массив имен столбцов</param>
    /// <param name="directions">Массив направлений</param>
    /// <returns></returns>
    public static string GetDataViewSort(string[] columnNames, ListSortDirection[] directions)
    {
#if DEBUG
      if (columnNames == null)
        throw new ArgumentNullException("columnNames");
      if (directions == null)
        throw new ArgumentNullException("directions");
#endif
      if (directions.Length != columnNames.Length)
        throw ExceptionFactory.ArgWrongCollectionCount("directions", directions, columnNames.Length);

      if (columnNames.Length == 0)
        return String.Empty;
      if (columnNames.Length == 1 && directions[0] == ListSortDirection.Ascending)
      {
        if (String.IsNullOrEmpty(columnNames[0]))
          throw ExceptionFactory.ArgInvalidListItem("columnNames", columnNames, 0);
        return columnNames[0];
      }

      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < columnNames.Length; i++)
      {
        if (String.IsNullOrEmpty(columnNames[i]))
          throw ExceptionFactory.ArgInvalidListItem("columnNames", columnNames, i);

        if (i > 0)
          sb.Append(',');
        sb.Append(columnNames[i]);
        if (directions[i] == ListSortDirection.Descending)
          sb.Append(" DESC");
      }
      return sb.ToString();
    }

    #endregion

    /// <summary>
    /// Получение выражения LIKE для <see cref="DataView.RowFilter"/>.
    /// Возвращает строку LIKE '<paramref name="str"/>*' с экранированием некоторых символов.
    /// </summary>
    /// <param name="str">Начало шаблона поиска</param>
    /// <returns>Строка для фильтра</returns>
    public static string GetDataViewLikeExpressionString(string str)
    {
      // Аналогичный метод есть в ExtDB.dll
      // Метод DataViewDBxSqlFormatter.OnFormatStartsWithFilter()


      str = str.Replace("\'", "\'\'"); // 21.08.2017. Апострофы удваиваются
      return "LIKE \'" + MakeEscapedChars(str, new char[] { '*', '%', '[', ']' }, "[", "]") + "*\'";
    }

    /// <summary>
    /// Окружение специальных символов в строке
    /// </summary>
    /// <param name="str">Строка, возможно содержащая символы</param>
    /// <param name="escapedChars">Символы, которые требуется окружить</param>
    /// <param name="prefix">Окружение слева</param>
    /// <param name="suffix">Окружение справа</param>
    /// <returns></returns>
    private static string MakeEscapedChars(string str, char[] escapedChars, string prefix, string suffix)
    {
      if (String.IsNullOrEmpty(str))
        return String.Empty;
      if (str.IndexOfAny(escapedChars) < 0)
        return str;
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < str.Length; i++)
      {
        char c = str[i];
        if (Array.IndexOf<char>(escapedChars, c) >= 0)
        {
          // Спецсимвол
          sb.Append(prefix);
          sb.Append(c);
          sb.Append(suffix);
        }
        else
          // Обычный символ
          sb.Append(c);
      }
      return sb.ToString();
    }


    #region FindOrAddRow

    /// <summary>
    /// Найти строку в таблице с заданным значением поля для поиска. Если таблица
    /// не содержит такой строки, то строка добавляется.
    /// Для поиска используется объект <see cref="DataView"/>, в котором задано свойство <see cref="DataView.Sort"/>.
    /// Эта перегрузка не позволяет определить, была найдена существующая строка или добавлена новая.
    /// </summary>
    /// <param name="dv">Просмотр таблицы, в котором свойство <see cref="DataView.Sort"/> задает одно поле для поиска</param>
    /// <param name="searchValue">Значение поля для поиска</param>
    /// <returns>Найденная или созданная строка</returns>
    public static DataRow FindOrAddDataRow(DataView dv, object searchValue)
    {
      DataRow row;
      FindOrAddDataRow(dv, searchValue, out row);
      return row;
    }

    /// <summary>
    /// Найти строку в таблице с заданным значением поля для поиска. Если таблица
    /// не содержит такой строки, то строка добавляется.
    /// Для поиска используется объект <see cref="DataView"/>, в котором задано свойство <see cref="DataView.Sort"/>.
    /// Возвращает true, если была создана новая строка.
    /// </summary>
    /// <param name="dv">Просмотр таблицы, в котором свойство <see cref="DataView.Sort"/> задает одно поле для поиска</param>
    /// <param name="searchValue">Значение поля для поиска</param>
    /// <param name="row">Найденная или созданная строка</param>
    /// <returns>Признак добавления строки</returns>
    public static bool FindOrAddDataRow(DataView dv, object searchValue, out DataRow row)
    {
#if DEBUG
      if (dv == null)
        throw new ArgumentNullException("dv");
      if (String.IsNullOrEmpty(dv.Sort))
        throw ExceptionFactory.ArgProperty("dv", dv, "DataView.Sort", dv.Sort, null);
#endif
      if (dv.Sort.IndexOf(',') >= 0)
        throw ExceptionFactory.ArgInvalidChar("dv", dv.Sort, ",");

      int p = dv.Find(searchValue);
      if (p < 0)
      {
        row = dv.Table.NewRow();
        string colName = GetDataViewSortSingleColumnName(dv.Sort);
        row[colName] = searchValue;
        dv.Table.Rows.Add(row);
        return true;
      }
      else
      {
        row = dv[p].Row;
        return false;
      }
    }

    /// <summary>
    /// Найти строку в таблице с заданными значениями полей для поиска. Если таблица
    /// не содержит такой строки, то строка добавляется.
    /// Для поиска используется объект <see cref="DataView"/>, в котором задано свойство <see cref="DataView.Sort"/>.
    /// Эта перегрузка не позволяет определить, была найдена существующая строка или добавлена новая.
    /// </summary>
    /// <param name="dv">Просмотр таблицы, в котором свойство <see cref="DataView.Sort"/> задает поля для поиска</param>
    /// <param name="searchValues">Значения полей для поиска</param>
    /// <returns>Найденная или созданная строка</returns>
    public static DataRow FindOrAddDataRow(DataView dv, object[] searchValues)
    {
      DataRow row;
      FindOrAddDataRow(dv, searchValues, out row);
      return row;
    }

    /// <summary>
    /// Найти строку в таблице с заданными значениями полей для поиска. Если таблица
    /// не содержит такой строки, то строка добавляется.
    /// Для поиска используется объект <see cref="DataView"/>, в котором задано свойство <see cref="DataView.Sort"/>.
    /// Возвращает true, если была создана новая строка.
    /// </summary>
    /// <param name="dv">Просмотр таблицы, в котором свойство <see cref="DataView.Sort"/> задает поля для поиска</param>
    /// <param name="searchValues">Значения полей для поиска</param>
    /// <param name="row">Найденная или созданная строка</param>
    /// <returns>Признак добавления строки</returns>
    public static bool FindOrAddDataRow(DataView dv, object[] searchValues, out DataRow row)
    {
#if DEBUG
      if (dv == null)
        throw new ArgumentNullException("dv");
      if (String.IsNullOrEmpty(dv.Sort))
        throw ExceptionFactory.ArgProperty("dv", dv, "DataView.Sort", dv.Sort, null);
      if (searchValues == null)
        throw new ArgumentNullException("searchValues");
#endif

      int p = dv.Find(searchValues);
      if (p < 0)
      {
        row = dv.Table.NewRow();
        string[] colNames = GetDataViewSortColumnNames(dv.Sort); // не может вернуть null, т.к. dvSort - непустая строка
        if (searchValues.Length != colNames.Length)
          throw ExceptionFactory.ArgWrongCollectionCount("searchValues", searchValues, colNames.Length);
        for (int i = 0; i < colNames.Length; i++)
          row[colNames[i]] = searchValues[i];
        dv.Table.Rows.Add(row);
        return true;
      }
      else
      {
        row = dv[p].Row;
        return false;
      }
    }

    #endregion

    #endregion

    #region Уникальные значения

    /// <summary>
    /// Создает копию исходной таблицы <paramref name="srcTable"/>, в которую добавляются только строки,
    /// содержащие уникальные значения полей, заданных <paramref name="uniqueColumnNames"/>.
    /// Результирующая таблица имеет такую же структуру, как и исходная.
    /// Удаленные строки исходной таблицы пропускаются.
    /// </summary>
    /// <param name="srcTable">Исходная таблица данных</param>
    /// <param name="uniqueColumnNames">Массив имен полей, которые должны содержать исходные значения</param>
    /// <returns>Копия таблицы, содержащая меньшее число строк</returns>
    public static DataTable CreateUniqueTable(DataTable srcTable, string[] uniqueColumnNames)
    {
#if DEBUG
      if (srcTable == null)
        throw new ArgumentNullException("srcTable");
      if (uniqueColumnNames == null)
        throw new ArgumentNullException("uniqueColumnNames");
#endif

      DataTable resTable = srcTable.Clone();
      if (srcTable.Rows.Count == 0)
        return resTable;
      int[] uniqueColPoss = new int[uniqueColumnNames.Length];
      for (int j = 0; j < uniqueColumnNames.Length; j++)
        uniqueColPoss[j] = GetColumnPosWithCheck(srcTable, uniqueColumnNames[j]);

      resTable.DefaultView.Sort = String.Join(",", uniqueColumnNames);
      resTable.DefaultView.RowFilter = String.Empty;

      object[] keys = new object[uniqueColumnNames.Length];
      for (int i = 0; i < srcTable.Rows.Count; i++)
      {
        DataRow srcRow = srcTable.Rows[i];
        if (srcRow.RowState == DataRowState.Deleted)
          continue;

        for (int j = 0; j < uniqueColumnNames.Length; j++)
          keys[j] = srcRow[uniqueColPoss[j]];

        if (resTable.DefaultView.Find(keys) < 0)
          resTable.Rows.Add(srcRow.ItemArray);
      }

      resTable.DefaultView.Sort = srcTable.DefaultView.Sort;
      resTable.DefaultView.RowFilter = srcTable.DefaultView.RowFilter;
      return resTable;
    }

    /// <summary>
    /// Создает копию исходной таблицы <paramref name="srcTable"/>, в которую добавляются только строки,
    /// содержащие уникальные значения полей, заданных <paramref name="uniqueColumnNames"/>.
    /// Результирующая таблица имеет такую же структуру, как и исходная.
    /// Удаленные строки исходной таблицы пропускаются.
    /// </summary>
    /// <param name="srcTable">Исходная таблица данных</param>
    /// <param name="uniqueColumnNames">Список имен полей, разделенных запятыми, которые должны содержать исходные значения</param>
    /// <returns>Копия таблицы, содержащая меньшее число строк</returns>
    public static DataTable CreateUniqueTable(DataTable srcTable, string uniqueColumnNames)
    {
#if DEBUG
      if (String.IsNullOrEmpty(uniqueColumnNames))
        throw new ArgumentNullException("uniqueColumnNames");
#endif

      return CreateUniqueTable(srcTable, uniqueColumnNames.Split(','));
    }

    /// <summary>
    /// Создает копию исходной таблицы <paramref name="srcDV"/>.Table, в которую добавляются только строки,
    /// содержащие уникальные значения полей, заданных <paramref name="uniqueColumnNames"/>.
    /// Результирующая таблица имеет такую же структуру, как и исходная.
    /// Порядок строк в <paramref name="srcDV"/> определяет, какая именно строка будет добавлена в 
    /// результирующую таблицу. Добавляется первая строка, содержащая уникальные значения полей.
    /// </summary>
    /// <param name="srcDV">Просмотр для исходной таблицы данных</param>
    /// <param name="uniqueColumnNames">Массив имен полей, которые должны содержать исходные значения</param>
    /// <returns>Копия таблицы, содержащая меньшее число строк</returns>
    public static DataTable CreateUniqueTable(DataView srcDV, string[] uniqueColumnNames)
    {
#if DEBUG
      if (srcDV == null)
        throw new ArgumentNullException("srcDV");
      if (uniqueColumnNames == null)
        throw new ArgumentNullException("uniqueColumnNames");
#endif

      DataTable resTable = srcDV.Table.Clone();
      if (srcDV.Count == 0)
        return resTable;
      int[] uniqueColPoss = new int[uniqueColumnNames.Length];
      for (int j = 0; j < uniqueColumnNames.Length; j++)
        uniqueColPoss[j] = GetColumnPosWithCheck(srcDV.Table, uniqueColumnNames[j]);

      resTable.DefaultView.Sort = String.Join(",", uniqueColumnNames);
      resTable.DefaultView.RowFilter = String.Empty;

      object[] keys = new object[uniqueColumnNames.Length];
      for (int i = 0; i < srcDV.Count; i++)
      {
        DataRow SrcRow = srcDV[i].Row;

        for (int j = 0; j < uniqueColumnNames.Length; j++)
          keys[j] = SrcRow[uniqueColPoss[j]];

        if (resTable.DefaultView.Find(keys) < 0)
          resTable.Rows.Add(SrcRow.ItemArray);
      }

      resTable.DefaultView.Sort = String.Empty;
      resTable.DefaultView.RowFilter = String.Empty;
      return resTable;
    }

    /// <summary>
    /// Создает копию исходной таблицы <paramref name="srcDV"/>.Table, в которую добавляются только строки,
    /// содержащие уникальные значения полей, заданных <paramref name="uniqueColumnNames"/>.
    /// Результирующая таблица имеет такую же структуру, как и исходная.
    /// Порядок строк в <paramref name="srcDV"/> определяет, какая именно строка будет добавлена в 
    /// результирующую таблицу. Добавляется первая строка, содержащая уникальные значения полей.
    /// </summary>
    /// <param name="srcDV">Просмотр для исходной таблицы данных</param>
    /// <param name="uniqueColumnNames">Список имен полей, разделенных запятыми, которые должны содержать исходные значения</param>
    /// <returns>Копия таблицы, содержащая меньшее число строк</returns>
    public static DataTable CreateUniqueTable(DataView srcDV, string uniqueColumnNames)
    {
#if DEBUG
      if (String.IsNullOrEmpty(uniqueColumnNames))
        throw new ArgumentNullException("uniqueColumnNames");
#endif

      return CreateUniqueTable(srcDV, uniqueColumnNames.Split(','));
    }

    #endregion

    #region Методы работы с Generic-коллекциями

    /// <summary>
    /// Получить массив ключей из коллекции.
    /// Этот метод нельзя применять к асинхронным коллекциям.
    /// </summary>
    /// <typeparam name="TKey">Тип ключей в коллекции</typeparam>
    /// <typeparam name="TValue">Тип значений в коллекции</typeparam>
    /// <param name="source">Исходная коллекция. Если null, то возвращается пустой массив.</param>
    /// <returns>Массив ключей</returns>
    public static TKey[] GetKeys<TKey, TValue>(Dictionary<TKey, TValue> source)
    {
      if (source == null)
        return new TKey[0];
      TKey[] res = new TKey[source.Count];
      source.Keys.CopyTo(res, 0);
      return res;
    }

    /// <summary>
    /// Получить массив значений, хранящихся в коллекции.
    /// Этот метод нельзя применять к асинхронным коллекциям.
    /// </summary>
    /// <typeparam name="TKey">Тип ключей в коллекции</typeparam>
    /// <typeparam name="TValue">Тип значений в коллекции</typeparam>
    /// <param name="source">Исходная коллекция. Если null, то возвращается пустой массив.</param>
    /// <returns>Массив значений</returns>
    public static TValue[] GetValues<TKey, TValue>(Dictionary<TKey, TValue> source)
    {
      if (source == null)
        return new TValue[0];
      TValue[] res = new TValue[source.Count];
      source.Values.CopyTo(res, 0);
      return res;
    }

    #endregion


    #region Прочие функции

    /// <summary>
    /// Возвращает true, если <paramref name="testValue"/> содержит пустое значение в смысле
    /// записи в базу данных, то есть пустую строку, число 0, false, и.т.д.
    /// Для массивов возвращает true, если длина массива равна 0.
    /// </summary>
    /// <param name="testValue"></param>
    /// <returns>True, если значение пустое</returns>
    public static bool IsEmptyValue(object testValue)
    {
      if (testValue == null)
        return true;
      if (testValue is DBNull)
        return true;

      // 13.08.2018
      if (testValue is Array)
        return ((Array)testValue).Length == 0;

      // 17.04.2015
      object emptyValue = GetEmptyValue(testValue.GetType());
      return testValue.Equals(emptyValue);

      /*

      if (value is String)
        return ((string)value).Length == 0;

      if (value is SByte)
        return ((SByte)value) == 0;
      if (value is Byte)
        return ((Byte)value) == 0;

      if (value is Int16)
        return ((Int16)value) == 0;
      if (value is UInt16)
        return ((UInt16)value) == 0;

      if (value is Int32)
        return ((Int32)value) == 0;
      if (value is UInt32)
        return ((UInt32)value) == 0;

      if (value is Int64)
        return ((Int64)value) == 0;
      if (value is UInt64)
        return ((UInt64)value) == 0;

      if (value is Single)
        return ((Single)value) == 0f;
      if (value is Double)
        return ((Double)value) == 0.0;
      if (value is Decimal)
        return ((Decimal)value) == 0m;

      if (value is DateTime)
        return (DateTime)value == new DateTime(); // 06.04.2015

      if (value is TimeSpan)
        return ((TimeSpan)value) == TimeSpan.Zero; // 06.04.2015

      if (value is Boolean)
        return !((Boolean)value);

      throw new BugException("Неизвестный тип: " + value.GetType().ToString());
       * */
    }

    /// <summary>
    /// Получить пустое значение указанного типа.
    /// Для строк возвращается пустая строка, для числовых значений возвращается 0.
    /// </summary>
    /// <param name="typ">Тип данных</param>
    /// <returns>Пустое значение</returns>
    public static object GetEmptyValue(Type typ)
    {
      if (typ == null)
        return null;
      if (typ == typeof(string))
        return String.Empty;

      if (typ == typeof(DBNull))
        return DBNull.Value;

      return Activator.CreateInstance(typ); // 17.04.2015
      /*
      ConstructorInfo ci = type.GetConstructor(Type.EmptyTypes);
      if (ci == null)
        throw new BugException("Для типа " + type.ToString() + " не найден конструктор по умолчанию");
      return ci.Invoke(null);
       * */
    }


    /// <summary>
    /// Возвращает true, если все указанные поля (типа <see cref="Decimal"/>) имеют значение 0.
    /// </summary>
    /// <param name="row">Строка таблицы</param>
    /// <param name="columnNames">Список имен полей, разделенных запятыми</param>
    /// <returns>true, если все указанные поля имеют значение 0m или <see cref="DBNull"/></returns>
    public static bool AreAllDecimalZeros(DataRow row, string columnNames)
    {
      string[] aNames = columnNames.Split(',');
      for (int i = 0; i < aNames.Length; i++)
      {
        if (GetDecimal(row, aNames[i]) != 0m)
          return false;
      }
      return true;
    }

    /// <summary>
    /// Возвращает true, если все поля типа <see cref="Decimal"/> в строке имеют значение 0 или <see cref="DBNull"/>.
    /// Перебираются все поля в таблице, имеющие тип <see cref="Decimal"/>.
    /// </summary>
    /// <param name="row">Строка таблицы</param>
    /// <returns>true, если все указанные поля имеют значение 0m или <see cref="DBNull"/></returns>
    public static bool AreAllDecimalZeros(DataRow row)
    {
      for (int i = 0; i < row.Table.Columns.Count; i++)
      {
        if (row.Table.Columns[i].DataType == typeof(decimal))
        {
          if (row.IsNull(i))
            continue;
          if ((decimal)(row[i]) != 0m)
            return false;
        }
      }
      return true;
    }

    /// <summary>
    /// Возвращает true, если значения заданных полей типа <see cref="Decimal"/> во всех строках содержат <see cref="DBNull"/> или 0.
    /// </summary>
    /// <param name="table">Таблица данных</param>
    /// <param name="columnNames">Имена полей, разделенных запятыми</param>
    /// <returns>true, если все нули</returns>
    public static bool AreAllDecimalZeros(DataTable table, string columnNames)
    {
      foreach (DataRow row in table.Rows)
      {
        if (row.RowState == DataRowState.Deleted)
          continue;
        if (!AreAllDecimalZeros(row, columnNames))
          return false;
      }
      return true;
    }

    /// <summary>
    /// Возвращает true, если значения полей типа <see cref="Decimal"/> во всех строках содержат <see cref="DBNull"/> или 0.
    /// </summary>
    /// <param name="table">Таблица данных</param>
    /// <returns>true, если все нули</returns>
    public static bool AreAllDecimalZeros(DataTable table)
    {
      foreach (DataRow row in table.Rows)
      {
        if (row.RowState == DataRowState.Deleted)
          continue;
        if (!AreAllDecimalZeros(row))
          return false;
      }
      return true;
    }

    /// <summary>
    /// Возвращает true, если значения заданных полей типа <see cref="Decimal"/> во всех строках содержат <see cref="DBNull"/> или 0.
    /// </summary>
    /// <param name="dv">Объект DataView</param>
    /// <param name="columnNames">Имена полей, разделенных запятыми</param>
    /// <returns>true, если все нули</returns>
    public static bool AreAllDecimalZeros(DataView dv, string columnNames)
    {
      foreach (DataRowView drv in dv)
      {
        if (!AreAllDecimalZeros(drv.Row, columnNames))
          return false;
      }
      return true;
    }

    /// <summary>
    /// Возвращает true, если значения полей типа <see cref="Decimal"/> во всех строках содержат <see cref="DBNull"/> или 0.
    /// </summary>
    /// <param name="dv">Объект DataView</param>
    /// <returns>true, если все нули</returns>
    public static bool AreAllDecimalZeros(DataView dv)
    {
      foreach (DataRowView drv in dv)
      {
        if (!AreAllDecimalZeros(drv.Row))
          return false;
      }
      return true;
    }


    /// <summary>
    /// Возвращает минимальное и максимальное значение для заданного перечисления.
    /// Возвращаемое значение может не иметь смысла, если у перечисления задан атрибут <see cref="FlagsAttribute"/>.
    /// Используется вызов <see cref="Enum.GetValues(Type)"/>.
    /// </summary>
    /// <param name="enumTyp">Тип перечисления</param>
    /// <returns>Минимальное и максимальное значения</returns>
    public static MinMax<Int32> GetEnumRange(Type enumTyp)
    {
      Array a = Enum.GetValues(enumTyp);

      MinMax<Int32> mm = new MinMax<Int32>();
      for (int i = 0; i < a.Length; i++)
        mm += (int)(a.GetValue(i));
      return mm;
    }

    /// <summary>
    /// "Классическая" функция обмена двух значений по ссылке
    /// </summary>
    /// <typeparam name="T">Тип данных</typeparam>
    /// <param name="refValue1">Ссылка на первый объект или значение</param>
    /// <param name="refValue2">Ссылка на второй объект или значение</param>
    public static void Swap<T>(ref T refValue1, ref T refValue2)
    {
      T V3 = refValue1;
      refValue1 = refValue2;
      refValue2 = V3;
    }

    /// <summary>
    /// Вызывает для переданной ссылки метод <see cref="IDisposable.Dispose()"/>, а затем присваивает ссылке значение null.
    /// Если <paramref name="refValue"/> равно null, никаких действий не выполняется.
    /// Используется для упрощения кода в реализациях метода <see cref="IDisposable.Dispose()"/> для очистки вложенных объектов.
    /// </summary>
    /// <typeparam name="T">Тип объекта, реализующего интерфейс <see cref="IDisposable"/>.
    /// Не может быть типом значения, даже если он реализует интерфейс</typeparam>
    /// <param name="refValue">Ссылка на поле, содержащее ссылку на объект с интерфейсом <see cref="IDisposable"/></param>
    public static void Dispose<T>(ref T refValue)
      where T : class, IDisposable
    {
      if (refValue != null)
      {
        refValue.Dispose();
        refValue = default(T); // обычно, null
      }
    }

    ///// <summary>
    ///// Возвращает код типа для заданного типа <see cref=" System.Type"/>.
    ///// Для получения кода типа для значения используется <see cref="System.Convert.GetTypeCode(object)"/>.
    ///// Для не-примитивных типов возвращается <see cref="TypeCode.Object"/>.
    ///// Если <paramref name="typ"/>==null, возвращается <see cref="TypeCode.Empty"/>.
    ///// </summary>
    ///// <param name="typ">Тип данных</param>
    ///// <returns>Код типа</returns>
    //public static TypeCode GetTypeCode(Type typ)
    //{
    //}

    #endregion

    #region Эксперимент
#if XXX
    public static DataTable SimpleCloneTable(DataTable SrcTable)
    {
      DataTable ResTable = new DataTable();
      for (int i = 0; i < SrcTable.Columns.Count; i++)
      {
        DataColumn SrcCol = SrcTable.Columns[i];
        DataColumn ResCol = new DataColumn(SrcCol.ColumnName, SrcCol.DataType);
        ResTable.Columns.Add(ResCol);
      }
      return ResTable;
    }
#endif

    #endregion
  }

#if XXX //Пока не знаю, надо ли
  public sealed class ReetranceLock
  {
    internal bool Entered;
  }

  public struct ReetranceLockKey : IDisposable
  {
    private static readonly object _SyncRoot = new object();

    private ReetranceLock _Lock;

    public ReetranceLockKey(ref ReetranceLock lockRef)
    {
      if (lockRef == null)
      {
        lock (_SyncRoot)
        {
          if (lockRef == null)
            lockRef = new ReetranceLock();
        }
      }

      System.Threading.Monitor.Enter(lockRef);
      try
      {
        if (lockRef.Entered)
          throw new ReenteranceException();
      }
      catch
      {
        System.Threading.Monitor.Exit(lockRef);
        throw;
      }
      lockRef.Entered=true;
      _Lock = lockRef;
    }

    public void Dispose()
    {
      if (_Lock != null)
      {
        _Lock.Entered = false;
        System.Threading.Monitor.Exit(_Lock);
        _Lock = null;
      }
    }
  }
#endif
}
