﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;
using System.Globalization;
using AgeyevAV.IO;

/*
 * The BSD License
 * 
 * Copyright (c) 2012-2015, Ageyev A.V.
 * Copyright (c) 2007, wilsone8 
 * 
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without modification, 
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, 
 * this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice, 
 * this list of conditions and the following disclaimer in the documentation 
 * and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

namespace AgeyevAV.Win32
{
  /*
   * A Complete Win32 INI File Utility Class
   * By wilsone8,  22 Dec 2007
   * http://www.codeproject.com/Articles/20053/A-Complete-Win32-INI-File-Utility-Class
   */

  /// <summary>
  /// Доступ к INI-файлу с использованием функций Windows, без загрузки и сохранения файла.
  /// Записываемые значения сохраняются немедленно.
  /// Не может использоваться на платформах, отличных от Windows. Используйте класс IniFile.
  /// </summary>
  public class IniFileWindows : IIniFile
  {
    #region Константы

    /// <summary>
    /// The maximum size of a section in an ini file.
    /// </summary>
    /// <remarks>
    /// This property defines the maximum size of the buffers 
    /// used to retreive data from an ini file.  This value is 
    /// the maximum allowed by the win32 functions 
    /// GetPrivateProfileSectionNames() or 
    /// GetPrivateProfileString().
    /// </remarks>
    public const int MaxSectionSize = 32767; // 32 KB

    #endregion

    #region Поля

    //The path of the file we are operating on.
    private string _Path;

    #endregion

    #region P/Invoke declares

    /// <summary>
    /// A static class that provides the win32 P/Invoke signatures 
    /// used by this class.
    /// </summary>
    /// <remarks>
    /// Note:  In each of the declarations below, we explicitly set CharSet to 
    /// Auto.  By default in C#, CharSet is set to Ansi, which reduces 
    /// performance on windows 2000 and above due to needing to convert strings
    /// from Unicode (the native format for all .Net strings) to Ansi before 
    /// marshalling.  Using Auto lets the marshaller select the Unicode version of 
    /// these functions when available.
    /// </remarks>
    [System.Security.SuppressUnmanagedCodeSecurity]
    private static class NativeMethods
    {
      [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
      public static extern int GetPrivateProfileSectionNames(IntPtr lpszReturnBuffer,
                                                             uint nSize,
                                                             string lpFileName);

      [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
      public static extern uint GetPrivateProfileString(string lpAppName,
                                                        string lpKeyName,
                                                        string lpDefault,
                                                        StringBuilder lpReturnedString,
                                                        int nSize,
                                                        string lpFileName);

      [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
      public static extern uint GetPrivateProfileString(string lpAppName,
                                                        string lpKeyName,
                                                        string lpDefault,
                                                        [In, Out] char[] lpReturnedString,
                                                        int nSize,
                                                        string lpFileName);

      [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
      public static extern int GetPrivateProfileString(string lpAppName,
                                                       string lpKeyName,
                                                       string lpDefault,
                                                       IntPtr lpReturnedString,
                                                       uint nSize,
                                                       string lpFileName);

      [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
      public static extern int GetPrivateProfileInt(string lpAppName,
                                                    string lpKeyName,
                                                    int lpDefault,
                                                    string lpFileName);

      [DllImport("kernel32.dll", CharSet = CharSet.Auto)]
      public static extern int GetPrivateProfileSection(string lpAppName,
                                                        IntPtr lpReturnedString,
                                                        uint nSize,
                                                        string lpFileName);

      //We explicitly enable the SetLastError attribute here because
      // WritePrivateProfileString returns errors via SetLastError.
      // Failure to set this can result in errors being lost during 
      // the marshal back to managed code.
      [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
      public static extern bool WritePrivateProfileString(string lpAppName,
                                                          string lpKeyName,
                                                          string lpString,
                                                          string lpFileName);


    }
    #endregion

    #region Конструктор

    /// <summary>
    /// Initializes a new instance of the <see cref="AgeyevAV.Win32.IniFileWindows"/> class.
    /// </summary>
    /// <param name="path">The ini file to read and write from.</param>
    public IniFileWindows(string path)
      : this(path, false)
    {
    }

    /// <summary>
    /// Initializes a new instance of the <see cref="AgeyevAV.Win32.IniFileWindows"/> class.
    /// </summary>
    /// <param name="path">The ini file to read and write from.</param>
    /// <param name="isReadOnly">true, если разрешено только чтение, но не запись значений</param>
    public IniFileWindows(string path, bool isReadOnly)
    {
      if (String.IsNullOrEmpty(path))
        throw new ArgumentNullException("path");

      switch (Environment.OSVersion.Platform)
      {
        case PlatformID.Win32NT:
        case PlatformID.Win32Windows:
        case PlatformID.Win32S:
        case PlatformID.WinCE:
          break;
        default:
          throw new PlatformNotSupportedException();
      }


      //Convert to the full path.  Because of backward compatibility, 
      // the win32 functions tend to assume the path should be the 
      // root Windows directory if it is not specified.  By calling 
      // GetFullPath, we make sure we are always passing the full path
      // the win32 functions.
      _Path = System.IO.Path.GetFullPath(path);
      _IsReadOnly = isReadOnly;
    }

    /// <summary>
    /// Gets the full path of ini file this object instance is operating on.
    /// </summary>
    /// <value>A file path.</value>
    public string Path { get { return _Path; } }

    /// <summary>
    /// Выводит путь к INI-файлу (свойство Path)
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
      return Path;
    }

    #endregion

    #region Get Value Methods

    /// <summary>
    /// Чтение и запись строкового значения.
    /// Если при чтении нет такой секции или ключа, возвращается пустое значение.
    /// При записи несуществующего значения выполняется создание секции или ключа
    /// </summary>
    /// <param name="section">Имя секции</param>
    /// <param name="key">Имя параметра</param>
    /// <returns>Строковое значение</returns>
    public string this[string section, string key]
    {
      get { return GetString(section, key, String.Empty); }
      set { SetString(section, key, value); }
    }

    /// <summary>
    /// Gets the value of a setting in an ini file as a <see cref="T:System.String"/>.
    /// </summary>
    /// <param name="sectionName">The name of the section to read from.</param>
    /// <param name="keyName">The name of the key in section to read.</param>
    /// <param name="defaultValue">The default value to return if the key
    /// cannot be found.</param>
    /// <returns>The value of the key, if found.  Otherwise, returns 
    /// <paramref name="defaultValue"/></returns>
    /// <remarks>
    /// The retreived value must be less than 32KB in length.
    /// </remarks>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> or <paramref name="keyName"/> are 
    /// a null reference  (Nothing in VB)
    /// </exception>
    public string GetString(string sectionName,
                            string keyName,
                            string defaultValue)
    {
      if (String.IsNullOrEmpty(sectionName))
        throw new ArgumentNullException("sectionName");

      if (String.IsNullOrEmpty(keyName))
        throw new ArgumentNullException("keyName");

      StringBuilder retval = new StringBuilder(IniFileWindows.MaxSectionSize);

      NativeMethods.GetPrivateProfileString(sectionName,
                                            keyName,
                                            defaultValue,
                                            retval,
                                            IniFileWindows.MaxSectionSize,
                                            _Path);

      return retval.ToString();
    }

#if XXX
    /// <summary>
    /// Gets the value of a setting in an ini file as a <see cref="T:System.Int16"/>.
    /// </summary>
    /// <param name="sectionName">The name of the section to read from.</param>
    /// <param name="keyName">The name of the key in section to read.</param>
    /// <param name="defaultValue">The default value to return if the key
    /// cannot be found.</param>
    /// <returns>The value of the key, if found.  Otherwise, returns 
    /// <paramref name="defaultValue"/>.</returns>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> or <paramref name="keyName"/> are 
    /// a null reference  (Nothing in VB)
    /// </exception>
    public int GetInt16(string sectionName,
                        string keyName,
                        short defaultValue)
    {
      int retval = GetInt32(sectionName, keyName, defaultValue);

      return Convert.ToInt16(retval);
    }

    /// <summary>
    /// Gets the value of a setting in an ini file as a <see cref="T:System.Int32"/>.
    /// </summary>
    /// <param name="sectionName">The name of the section to read from.</param>
    /// <param name="keyName">The name of the key in section to read.</param>
    /// <param name="defaultValue">The default value to return if the key
    /// cannot be found.</param>
    /// <returns>The value of the key, if found.  Otherwise, returns 
    /// <paramref name="defaultValue"/></returns>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> or <paramref name="keyName"/> are 
    /// a null reference  (Nothing in VB)
    /// </exception>
    public int GetInt32(string sectionName,
                        string keyName,
                        int defaultValue)
    {
      if (sectionName == null)
        throw new ArgumentNullException("sectionName");

      if (keyName == null)
        throw new ArgumentNullException("keyName");


      return NativeMethods.GetPrivateProfileInt(sectionName, keyName, defaultValue, m_path);
    }

    /// <summary>
    /// Gets the value of a setting in an ini file as a <see cref="T:System.Double"/>.
    /// </summary>
    /// <param name="sectionName">The name of the section to read from.</param>
    /// <param name="keyName">The name of the key in section to read.</param>
    /// <param name="defaultValue">The default value to return if the key
    /// cannot be found.</param>
    /// <returns>The value of the key, if found.  Otherwise, returns 
    /// <paramref name="defaultValue"/></returns>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> or <paramref name="keyName"/> are 
    /// a null reference  (Nothing in VB)
    /// </exception>
    public double GetDouble(string sectionName,
                            string keyName,
                            double defaultValue)
    {
      string retval = GetString(sectionName, keyName, "");

      if (retval == null || retval.Length == 0)
      {
        return defaultValue;
      }

      return Convert.ToDouble(retval, CultureInfo.InvariantCulture);
    }
#endif

    #endregion

    #region GetSectionValues Methods

    /// <summary>
    /// Gets all of the values in a section as a list.
    /// </summary>
    /// <param name="sectionName">
    /// Name of the section to retrieve values from.
    /// </param>
    /// <returns>
    /// A <see cref="List{T}"/> containing <see cref="KeyValuePair{T1, T2}"/> objects 
    /// that describe this section.  Use this verison if a section may contain
    /// multiple items with the same key value.  If you know that a section 
    /// cannot contain multiple values with the same key name or you don't 
    /// care about the duplicates, use the more convenient 
    /// <see cref="GetSectionValues"/> function.
    /// </returns>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> is a null reference  (Nothing in VB)
    /// </exception>
    public List<KeyValuePair<string, string>> GetSectionValuesAsList(string sectionName)
    {
      List<KeyValuePair<string, string>> retval;
      string[] keyValuePairs;
      string key, value;
      int equalSignPos;

      if (String.IsNullOrEmpty(sectionName))
        throw new ArgumentNullException("sectionName");

      //Allocate a buffer for the returned section names.
      IntPtr ptr = Marshal.AllocCoTaskMem(IniFileWindows.MaxSectionSize);

      try
      {
        //Get the section key/value pairs into the buffer.
        int len = NativeMethods.GetPrivateProfileSection(sectionName,
                                                         ptr,
                                                         IniFileWindows.MaxSectionSize,
                                                         _Path);

        keyValuePairs = ConvertNullSeperatedStringToStringArray(ptr, len);
      }
      finally
      {
        //Free the buffer
        Marshal.FreeCoTaskMem(ptr);
      }

      //Parse keyValue pairs and add them to the list.
      retval = new List<KeyValuePair<string, string>>(keyValuePairs.Length);

      for (int i = 0; i < keyValuePairs.Length; ++i)
      {
        //Parse the "key=value" string into its constituent parts
        equalSignPos = keyValuePairs[i].IndexOf('=');

        key = keyValuePairs[i].Substring(0, equalSignPos);

        value = keyValuePairs[i].Substring(equalSignPos + 1,
                                           keyValuePairs[i].Length - equalSignPos - 1);

        retval.Add(new KeyValuePair<string, string>(key, value));
      }

      return retval;
    }

    /// <summary>
    /// Gets all of the values in a section as a dictionary.
    /// </summary>
    /// <param name="sectionName">
    /// Name of the section to retrieve values from.
    /// </param>
    /// <returns>
    /// A <see cref="Dictionary{T, T}"/> containing the key/value 
    /// pairs found in this section.  
    /// </returns>
    /// <remarks>
    /// If a section contains more than one key with the same name, 
    /// this function only returns the first instance.  If you need to 
    /// get all key/value pairs within a section even when keys have the 
    /// same name, use <see cref="GetSectionValuesAsList"/>.
    /// </remarks>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> is a null reference  (Nothing in VB)
    /// </exception>
    public Dictionary<string, string> GetSectionValues(string sectionName)
    {
      if (String.IsNullOrEmpty(sectionName))
        throw new ArgumentNullException("sectionName");

      List<KeyValuePair<string, string>> keyValuePairs;
      Dictionary<string, string> retval;

      keyValuePairs = GetSectionValuesAsList(sectionName);

      //Convert list into a dictionary.
      retval = new Dictionary<string, string>(keyValuePairs.Count);

      foreach (KeyValuePair<string, string> keyValuePair in keyValuePairs)
      {
        //Skip any key we have already seen.
        if (!retval.ContainsKey(keyValuePair.Key))
        {
          retval.Add(keyValuePair.Key, keyValuePair.Value);
        }
      }

      return retval;
    }

    #endregion

    #region Get Key/Section Names

    /// <summary>
    /// Gets the names of all keys under a specific section in the ini file.
    /// </summary>
    /// <param name="sectionName">
    /// The name of the section to read key names from.
    /// </param>
    /// <returns>An array of key names.</returns>
    /// <remarks>
    /// The total length of all key names in the section must be 
    /// less than 32KB in length.
    /// </remarks>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> is a null reference  (Nothing in VB)
    /// </exception>
    public string[] GetKeyNames(string sectionName)
    {
      int len;
      string[] retval;

      if (String.IsNullOrEmpty(sectionName))
        throw new ArgumentNullException("sectionName");


      //Allocate a buffer for the returned section names.
      IntPtr ptr = Marshal.AllocCoTaskMem(IniFileWindows.MaxSectionSize);

      try
      {
        //Get the section names into the buffer.
        len = NativeMethods.GetPrivateProfileString(sectionName,
                                                    null,
                                                    null,
                                                    ptr,
                                                    IniFileWindows.MaxSectionSize,
                                                    _Path);

        retval = ConvertNullSeperatedStringToStringArray(ptr, len);
      }
      finally
      {
        //Free the buffer
        Marshal.FreeCoTaskMem(ptr);
      }

      return retval;
    }

    /// <summary>
    /// Gets the names of all sections in the ini file.
    /// </summary>
    /// <returns>An array of section names.</returns>
    /// <remarks>
    /// The total length of all section names in the section must be 
    /// less than 32KB in length.
    /// </remarks>
    public string[] GetSectionNames()
    {
      string[] retval;
      int len;

      //Allocate a buffer for the returned section names.
      IntPtr ptr = Marshal.AllocCoTaskMem(IniFileWindows.MaxSectionSize);

      try
      {
        //Get the section names into the buffer.
        len = NativeMethods.GetPrivateProfileSectionNames(ptr,
            IniFileWindows.MaxSectionSize, _Path);

        retval = ConvertNullSeperatedStringToStringArray(ptr, len);
      }
      finally
      {
        //Free the buffer
        Marshal.FreeCoTaskMem(ptr);
      }

      return retval;
    }

    /// <summary>
    /// Converts the null seperated pointer to a string into a string array.
    /// </summary>
    /// <param name="ptr">A pointer to string data.</param>
    /// <param name="valLength">
    /// Length of the data pointed to by <paramref name="ptr"/>.
    /// </param>
    /// <returns>
    /// An array of strings; one for each null found in the array of characters pointed
    /// at by <paramref name="ptr"/>.
    /// </returns>
    private static string[] ConvertNullSeperatedStringToStringArray(IntPtr ptr, int valLength)
    {
      string[] retval;

      if (valLength == 0)
      {
        //Return an empty array.
        retval = new string[0];
      }
      else
      {
        //Convert the buffer into a string.  Decrease the length 
        //by 1 so that we remove the second null off the end.
        string buff = Marshal.PtrToStringAuto(ptr, valLength - 1);

        //Parse the buffer into an array of strings by searching for nulls.
        retval = buff.Split('\0');
      }

      return retval;
    }

    #endregion

    #region Write Methods

    /// <summary>
    /// Writes a <see cref="T:System.String"/> value to the ini file.
    /// </summary>
    /// <param name="sectionName">The name of the section to write to .</param>
    /// <param name="keyName">The name of the key to write to.</param>
    /// <param name="value">The string value to write</param>
    /// <exception cref="T:System.ComponentModel.Win32Exception">
    /// The write failed.
    /// </exception>
    private void WriteValueInternal(string sectionName, string keyName, string value)
    {
      CheckNotReadOnly();

      if (!NativeMethods.WritePrivateProfileString(sectionName, keyName, value, _Path))
      {
        throw new System.ComponentModel.Win32Exception();
      }
    }

    /// <summary>
    /// Writes a <see cref="T:System.String"/> value to the ini file.
    /// </summary>
    /// <param name="sectionName">The name of the section to write to .</param>
    /// <param name="keyName">The name of the key to write to.</param>
    /// <param name="value">The string value to write</param>
    /// <exception cref="T:System.ComponentModel.Win32Exception">
    /// The write failed.
    /// </exception>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> or <paramref name="keyName"/> or 
    /// <paramref name="value"/>  are a null reference  (Nothing in VB)
    /// </exception>
    public void SetString(string sectionName, string keyName, string value)
    {
      if (String.IsNullOrEmpty(sectionName))
        throw new ArgumentNullException("sectionName");

      if (String.IsNullOrEmpty(keyName))
        throw new ArgumentNullException("keyName");

      if (value == null)
        throw new ArgumentNullException("value");

      WriteValueInternal(sectionName, keyName, value);
    }

#if XXX
    /// <summary>
    /// Writes an <see cref="T:System.Int16"/> value to the ini file.
    /// </summary>
    /// <param name="sectionName">The name of the section to write to .</param>
    /// <param name="keyName">The name of the key to write to.</param>
    /// <param name="value">The value to write</param>
    /// <exception cref="T:System.ComponentModel.Win32Exception">
    /// The write failed.
    /// </exception>
    public void WriteValue(string sectionName, string keyName, short value)
    {
      WriteValue(sectionName, keyName, (int)value);
    }

    /// <summary>
    /// Writes an <see cref="T:System.Int32"/> value to the ini file.
    /// </summary>
    /// <param name="sectionName">The name of the section to write to .</param>
    /// <param name="keyName">The name of the key to write to.</param>
    /// <param name="value">The value to write</param>
    /// <exception cref="T:System.ComponentModel.Win32Exception">
    /// The write failed.
    /// </exception>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> or <paramref name="keyName"/> are 
    /// a null reference  (Nothing in VB)
    /// </exception>
    public void WriteValue(string sectionName, string keyName, int value)
    {
      SetString(sectionName, keyName, value.ToString(CultureInfo.InvariantCulture));
    }

    /// <summary>
    /// Writes an <see cref="T:System.Single"/> value to the ini file.
    /// </summary>
    /// <param name="sectionName">The name of the section to write to .</param>
    /// <param name="keyName">The name of the key to write to.</param>
    /// <param name="value">The value to write</param>
    /// <exception cref="T:System.ComponentModel.Win32Exception">
    /// The write failed.
    /// </exception>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> or <paramref name="keyName"/> are 
    /// a null reference  (Nothing in VB)
    /// </exception>
    public void WriteValue(string sectionName, string keyName, float value)
    {
      SetString(sectionName, keyName, value.ToString(CultureInfo.InvariantCulture));
    }

    /// <summary>
    /// Writes an <see cref="T:System.Double"/> value to the ini file.
    /// </summary>
    /// <param name="sectionName">The name of the section to write to .</param>
    /// <param name="keyName">The name of the key to write to.</param>
    /// <param name="value">The value to write</param>
    /// <exception cref="T:System.ComponentModel.Win32Exception">
    /// The write failed.
    /// </exception>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> or <paramref name="keyName"/> are 
    /// a null reference  (Nothing in VB)
    /// </exception>
    public void WriteValue(string sectionName, string keyName, double value)
    {
      SetString(sectionName, keyName, value.ToString(CultureInfo.InvariantCulture));
    }
#endif

    #endregion

    #region Delete Methods

    /// <summary>
    /// Deletes the specified key from the specified section.
    /// </summary>
    /// <param name="sectionName">
    /// Name of the section to remove the key from.
    /// </param>
    /// <param name="keyName">
    /// Name of the key to remove.
    /// </param>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> or <paramref name="keyName"/> are 
    /// a null reference  (Nothing in VB)
    /// </exception>
    public void DeleteKey(string sectionName, string keyName)
    {
      if (String.IsNullOrEmpty(sectionName))
        throw new ArgumentNullException("sectionName");

      if (String.IsNullOrEmpty(keyName))
        throw new ArgumentNullException("keyName");

      CheckNotReadOnly();

      WriteValueInternal(sectionName, keyName, null);
    }

    /// <summary>
    /// Deletes a section from the ini file.
    /// </summary>
    /// <param name="sectionName">
    /// Name of the section to delete.
    /// </param>
    /// <exception cref="ArgumentNullException">
    /// <paramref name="sectionName"/> is a null reference (Nothing in VB)
    /// </exception>
    public void DeleteSection(string sectionName)
    {
      if (String.IsNullOrEmpty(sectionName))
        throw new ArgumentNullException("sectionName");

      CheckNotReadOnly();

      WriteValueInternal(sectionName, null, null);
    }

    #endregion

    #region Перечислитель

    /// <summary>
    /// Возвращает объект, для которого можно вызвать foreach по парам "Ключ-Значение"
    /// </summary>
    /// <param name="section">Имя секции</param>
    /// <returns>Объект, реализующий интерфейс IEnumerable</returns>
    public IEnumerable<IniKeyValue> GetKeyValues(string section)
    {
      string[] Keys = GetKeyNames(section);
      IniKeyValue[] a = new IniKeyValue[Keys.Length];
      for (int i = 0; i < Keys.Length; i++)
        a[i] = new IniKeyValue(Keys[i], this[section, Keys[i]]);
      return a;
    }

    #endregion

    #region IReadOnlyObject

    /// <summary>
    /// Возвращает true, если разрешено только чтение, но не запись.
    /// Задается в конструкторе
    /// </summary>
    public bool IsReadOnly { get { return _IsReadOnly; } }
    private bool _IsReadOnly;

    /// <summary>
    /// Генерирует исключение, если IsReadOnly=true.
    /// </summary>
    public void CheckNotReadOnly()
    {
      if (_IsReadOnly)
        throw new ObjectReadOnlyException();
    }

    #endregion
  }
}
