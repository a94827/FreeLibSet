﻿// Part of FreeLibSet.
// See copyright notices in "license" file in the FreeLibSet root directory.

using System;
using System.Collections.Generic;
using System.Text;
using FreeLibSet.Core;

namespace FreeLibSet.IO
{
  #region Перечисление PathEnumerateKind

  /// <summary>
  /// Что должно перечисляться: файлы, каталоги или то и другое
  /// </summary>
  public enum PathEnumerateKind
  {
    /// <summary>
    /// Перечислитель будет возвращать имена файлов.
    /// </summary>
    Files,

    /// <summary>
    /// Перечислитель будет возвращать имена каталогов. Файлы просматриваться не будут.
    /// Корневой каталог не возвращается при перечислении.
    /// </summary>
    Directories,

    /// <summary>
    /// Перечислитель будет возвращать и имена файлов и имена каталогов.
    /// Корневой каталог не возвращается при перечислении.
    /// </summary>
    FilesAndDirectories
  }

  #endregion

  #region Перечисление PathEnumerateMode

  /// <summary>
  /// Порядок перебора файлов и каталогов в пределах родительского каталога с помощью <see cref="AbsPathEnumerable"/> и <see cref="RelPathEnumerable"/>.
  /// </summary>
  public enum PathEnumerateMode
  {
    /// <summary>
    /// Сначала файлы, потом каталоги. Этот режим используется по умолчанию.
    /// </summary>
    FilesAndDirectories,

    /// <summary>
    /// Сначала вложенные каталоги, потом - файлы в текущем каталоге
    /// </summary>
    DirectoriesAndFiles,

    /// <summary>
    /// Нерекурсивный перебор файлов
    /// </summary>
    FilesOnly,

    /// <summary>
    /// Рекурсивный просмотр вложенных каталогов без просмотра файлов в текущем каталоге
    /// </summary>
    DirectoriesOnly,

    /// <summary>
    /// Текущий каталог должен быть пропущен
    /// </summary>
    None
  }

  #endregion

  #region Перечисление PathEnumarateSort

  /// <summary>
  /// Порядок сортировки файлов и каталогов при переборе
  /// </summary>
  public enum PathEnumerateSort
  {
    /// <summary>
    /// Порядок не определен.
    /// </summary>
    None,

    /// <summary>
    /// Сортировка по имени
    /// </summary>
    ByName,

    /// <summary>
    /// Сортировка по расширению.
    /// Для сложных расширений, типа "*.fb2.zip" используется только последнее расширение
    /// </summary>
    ByExtension
  }

  #endregion

  #region Перечисление PathEnumerateStage

  internal enum PathEnumerateStage
  {
    Start,
    Files,
    Directories,
    Finish
  }

  #endregion

  /// <summary>
  /// Аргументы события.
  /// Аргументы создаются <see cref="AbsPathEnumerable.Enumerator"/> в процессе перебора перед просмотром очередного каталога.
  /// </summary>
  public sealed class EnumDirectoryEventArgs : EventArgs
  {
    #region Защищенный конструктор

    internal EnumDirectoryEventArgs(AbsPath directory, RelPath directoryRel, int level)
    {
      _Directory = directory;
      _DirectoryRel = directoryRel;
      _Level = level;

      _Stage = PathEnumerateStage.Start;
    }

    /// <summary>
    /// Инициализация настраиваемых свойств
    /// </summary>
    /// <param name="source"></param>
    internal void Init(PathEnumerableBase source)
    {
      _EnumerateMode = source.EnumerateMode;
      _FileSearchPattern = source.FileSearchPattern;
      _FileSort = source.FileSort;
      _ReverseFiles = source.ReverseFiles;
      _DirectorySearchPattern = source.DirectorySearchPattern;
      _DirectorySort = source.DirectorySort;
      _ReverseDirectories = source.ReverseDirectories;
    }

    #endregion

    #region Фиксированные свойства

    /// <summary>
    /// Просматриваемый каталог - Абсолютный путь
    /// </summary>
    public AbsPath Directory { get { return _Directory; } }
    private readonly AbsPath _Directory;


    /// <summary>
    /// Просматриваемый каталог - Путь относительно <see cref="PathEnumerableBase.RootDirectory"/>
    /// </summary>
    public RelPath DirectoryRel { get { return _DirectoryRel; } }
    private readonly RelPath _DirectoryRel;

    /// <summary>
    /// Уровень вложения каталога <see cref="Directory"/> относительно базового каталога <see cref="PathEnumerableBase.RootDirectory"/>, 
    /// с которого начинается перебор.
    /// При первом вызове события для каталога <see cref="PathEnumerableBase.RootDirectory"/> имеет значение 0. Для подкаталогов первого уровня - 1, и т.д.
    /// </summary>
    public int Level { get { return _Level; } }
    private readonly int _Level;

    /// <summary>
    /// Для отладки
    /// </summary>
    /// <returns>Текстовое представление</returns>
    public override string ToString()
    {
      return Directory.Path + " (Level=" + Level.ToString() + ")";
    }

    #endregion

    #region Настраиваемые свойства

    private void CheckNotReadOnly()
    {
      if (_Stage != PathEnumerateStage.Start)
        throw new ObjectReadOnlyException(Res.EnumDirectoryEventArgs_Err_IsReadOnly);
    }

    /// <summary>
    /// Режим просмотра каталога.
    /// Пользовательский обработчик может, например, пропустить ненужный каталог.
    /// </summary>
    public PathEnumerateMode EnumerateMode
    {
      get { return _EnumerateMode; }
      set
      {
        CheckNotReadOnly();
        _EnumerateMode = value;
      }
    }
    private PathEnumerateMode _EnumerateMode;

    /// <summary>
    /// Маска для перечисления файлов. 
    /// </summary>
    public string FileSearchPattern
    {
      get { return _FileSearchPattern; }
      set
      {
        CheckNotReadOnly();
        _FileSearchPattern = value;
      }
    }
    private string _FileSearchPattern;

    /// <summary>
    /// Сортировка файлов при переборе. 
    /// </summary>
    public PathEnumerateSort FileSort
    {
      get { return _FileSort; }
      set
      {
        CheckNotReadOnly();
        _FileSort = value;
      }
    }
    private PathEnumerateSort _FileSort;

    /// <summary>
    /// Если установить в true, то файлы будут перебираться в обратном порядке сортировки.
    /// </summary>
    public bool ReverseFiles
    {
      get { return _ReverseFiles; }
      set
      {
        CheckNotReadOnly();
        _ReverseFiles = value;
      }
    }
    private bool _ReverseFiles;

    /// <summary>
    /// Маска для перечисления каталогов. 
    /// </summary>
    public string DirectorySearchPattern
    {
      get { return _DirectorySearchPattern; }
      set
      {
        CheckNotReadOnly();
        _DirectorySearchPattern = value;
      }
    }
    private string _DirectorySearchPattern;

    /// <summary>
    /// Сортировка каталогов при переборе. 
    /// </summary>
    public PathEnumerateSort DirectorySort
    {
      get { return _DirectorySort; }
      set
      {
        CheckNotReadOnly();
        _DirectorySort = value;
      }
    }
    private PathEnumerateSort _DirectorySort;

    /// <summary>
    /// Если установить в true, то файлы будут перебираться в обратном порядке сортировки.
    /// </summary>
    public bool ReverseDirectories
    {
      get { return _ReverseDirectories; }
      set
      {
        CheckNotReadOnly();
        _ReverseDirectories = value;
      }
    }
    private bool _ReverseDirectories;

    #endregion

    #region Внутренние поля, используемые перечислителем

    internal string[] Items;

    internal int CurrentIndex;

    /// <summary>
    /// Используется в состоянии Stage=Directory.
    /// </summary>
    internal bool SubDirFlag;

    internal PathEnumerateStage Stage { get { return _Stage; } }
    private PathEnumerateStage _Stage;

    /// <summary>
    /// Переходит к следующему этапу перебора.
    /// Только меняет свойство Stage с текущего состояние на следующее, исходя из EnumerateMode.
    /// Загрузка элементов не выполняется
    /// Для состояния Finish ничего не делает.
    /// </summary>
    private void SetNextStageValue()
    {
      switch (_Stage)
      {
        case PathEnumerateStage.Start:
          switch (_EnumerateMode)
          {
            case PathEnumerateMode.FilesOnly:
            case PathEnumerateMode.FilesAndDirectories:
              _Stage = PathEnumerateStage.Files;
              break;
            case PathEnumerateMode.DirectoriesOnly:
            case PathEnumerateMode.DirectoriesAndFiles:
              _Stage = PathEnumerateStage.Directories;
              break;
            default:
              _Stage = PathEnumerateStage.Finish;
              break;
          }
          break;
        case PathEnumerateStage.Files:
          switch (_EnumerateMode)
          {
            case PathEnumerateMode.FilesAndDirectories:
              _Stage = PathEnumerateStage.Directories;
              break;
            default:
              _Stage = PathEnumerateStage.Finish;
              break;
          }
          break;
        case PathEnumerateStage.Directories:
          switch (_EnumerateMode)
          {
            case PathEnumerateMode.DirectoriesAndFiles:
              _Stage = PathEnumerateStage.Files;
              break;
            default:
              _Stage = PathEnumerateStage.Finish;
              break;
          }
          break;
        default:
          _Stage = PathEnumerateStage.Finish;
          break;
      }
    }

    /// <summary>
    /// Переходит к следующему этапу перебора.
    /// и загружает списки файлов или каталогов, в зависимости от Stage.
    /// CurrentIndex принимает значение (-1).
    /// </summary>
    internal void SetNextStage()
    {
      SetNextStageValue();

      switch (_Stage)
      {
        case PathEnumerateStage.Files:
          Items = System.IO.Directory.GetFiles(Directory.Path,
            String.IsNullOrEmpty(FileSearchPattern) ? "*" : FileSearchPattern,
            System.IO.SearchOption.TopDirectoryOnly);
          SortItems(FileSort, ReverseFiles);
          break;
        case PathEnumerateStage.Directories:
          Items = System.IO.Directory.GetDirectories(Directory.Path,
            String.IsNullOrEmpty(DirectorySearchPattern) ? "*" : DirectorySearchPattern,
            System.IO.SearchOption.TopDirectoryOnly);
          SortItems(DirectorySort, ReverseDirectories);
          break;
        default:
          Items = null;
          break;
      }

      CurrentIndex = -1;
      SubDirFlag = false;
    }

    private void SortItems(PathEnumerateSort sort, bool reverse)
    {
      switch (sort)
      {
        case PathEnumerateSort.ByName:
          Array.Sort<string>(Items, ByNameComparison);
          break;
        case PathEnumerateSort.ByExtension:
          Array.Sort<string>(Items, ByExtensionComparison);
          break;
      }

      if (reverse)
        Array.Reverse(Items);
    }

    private static int ByNameComparison(string x, string y)
    {
      string x2 = System.IO.Path.GetFileName(x);
      string y2 = System.IO.Path.GetFileName(y);

      int res = String.Compare(x2, y2, StringComparison.OrdinalIgnoreCase);
      if (res != 0)
        return res;

      // Эта проверка лишняя.
      // В Windows никогда не будет одинаковых имен, отличающихся регистром,
      // поэтому предыдущее условие всегда будет выполнено
      // if (AbsPath.ComparisonType == StringComparison.Ordinal)
      return String.Compare(x2, y2, StringComparison.Ordinal);
    }


    private static int ByExtensionComparison(string x, string y)
    {
      #region Сравнение расширения

      string x3 = System.IO.Path.GetExtension(x);
      string y3 = System.IO.Path.GetExtension(y);

      int res = String.Compare(x3, y3, StringComparison.OrdinalIgnoreCase);
      if (res != 0)
        return res;

      if (AbsPath.ComparisonType == StringComparison.Ordinal)
      {
        res = String.Compare(x3, y3, StringComparison.Ordinal);
        if (res != 0)
          return res;
      }

      #endregion

      #region Сравнение имени

      string x2 = System.IO.Path.GetFileNameWithoutExtension(x);
      string y2 = System.IO.Path.GetFileNameWithoutExtension(y);
      res = String.Compare(x2, y2, StringComparison.OrdinalIgnoreCase);
      if (res != 0)
        return res;

      return String.Compare(x2, y2, StringComparison.Ordinal);

      #endregion
    }

    #endregion
  }

  /// <summary>
  /// Делегат для событий <see cref="PathEnumerableBase.BeforeDirectory"/> и <see cref="PathEnumerableBase.AfterDirectory"/>
  /// </summary>
  /// <param name="sender">Ссылка на объект <see cref="AbsPathEnumerable"/> или <see cref="RelPathEnumerable"/></param>
  /// <param name="args">Аргументы события. В них для события <see cref="PathEnumerableBase.BeforeDirectory"/> 
  /// можно задавать правила перебора для очередного каталога</param>
  public delegate void EnumDirectoryEventHandler(object sender, EnumDirectoryEventArgs args);

  /// <summary>
  /// Базовый класс для <see cref="AbsPathEnumerable"/> и <see cref="RelPathEnumerable"/>
  /// </summary>
  public class PathEnumerableBase
  {
    #region Защищенный конструктор

    /// <summary>
    /// Создает объект, присваивая значения свойствам <see cref="RootDirectory"/> и <see cref="EnumerateKind"/>.
    /// </summary>
    /// <param name="rootDirectory">Корневой каталог для перечисления. Должен быть задан</param>
    /// <param name="enumerateKind">Что должно возвращаться при перечислении: файлы и/или каталоги</param>
    protected PathEnumerableBase(AbsPath rootDirectory, PathEnumerateKind enumerateKind)
    {
      if (rootDirectory.IsEmpty)
        throw ExceptionFactory.ArgIsEmpty("rootDirectory");

      _RootDirectory = rootDirectory;
      _EnumerateKind = enumerateKind;

      _FileSearchPattern = "*";
      _FileSort = PathEnumerateSort.None;
      _DirectorySearchPattern = "*";
      _DirectorySort = PathEnumerateSort.None;
    }

    #endregion

    #region Свойства, управляющие перебором

    /// <summary>
    /// Корневой каталог для перечисления.
    /// Не может быть пустым.
    /// Задается в конструкторе.
    /// </summary>
    public AbsPath RootDirectory { get { return _RootDirectory; } }
    private readonly AbsPath _RootDirectory;

    /// <summary>
    /// Что должно возвращаться при перечислении: файлы и/или каталоги.
    /// Задается в конструкторе.
    /// </summary>
    public PathEnumerateKind EnumerateKind { get { return _EnumerateKind; } }
    private readonly PathEnumerateKind _EnumerateKind;

    /// <summary>
    /// Режим перебора. По умолчанию - <see cref="PathEnumerateMode.FilesAndDirectories"/> - сначала файлы, потом - подкаталоги.
    /// Значение применяется в качестве начального для свойства <see cref="EnumDirectoryEventArgs.EnumerateMode"/> при
    /// обходе очередного каталога и может меняться в обработчике события <see cref="BeforeDirectory"/>.
    /// </summary>
    public PathEnumerateMode EnumerateMode { get { return _EnumerateMode; } set { _EnumerateMode = value; } }
    private PathEnumerateMode _EnumerateMode;

    /// <summary>
    /// Маска для перечисления файлов. По умолчанию - "*" - все файлы.
    /// </summary>
    public string FileSearchPattern { get { return _FileSearchPattern; } set { _FileSearchPattern = value; } }
    private string _FileSearchPattern;

    /// <summary>
    /// Сортировка файлов при переборе. По умолчанию - <see cref="PathEnumerateSort.None"/> - порядок не определен.
    /// </summary>
    public PathEnumerateSort FileSort { get { return _FileSort; } set { _FileSort = value; } }
    private PathEnumerateSort _FileSort;

    /// <summary>
    /// Если установить в true, то файлы будут перебираться в обратном порядке сортировки.
    /// По умолчанию - false.
    /// </summary>
    public bool ReverseFiles { get { return _ReverseFiles; } set { _ReverseFiles = value; } }
    private bool _ReverseFiles;

    /// <summary>
    /// Маска для перечисления каталогов. По умолчанию - "*" - все каталоги.
    /// </summary>
    public string DirectorySearchPattern { get { return _DirectorySearchPattern; } set { _DirectorySearchPattern = value; } }
    private string _DirectorySearchPattern;

    /// <summary>
    /// Сортировка каталогов при переборе. По умолчанию - <see cref="PathEnumerateSort.None"/> - порядок не определен.
    /// </summary>
    public PathEnumerateSort DirectorySort { get { return _DirectorySort; } set { _DirectorySort = value; } }
    private PathEnumerateSort _DirectorySort;

    /// <summary>
    /// Если установить в true, то файлы будут перебираться в обратном порядке сортировки.
    /// По умолчанию - false.
    /// </summary>
    public bool ReverseDirectories { get { return _ReverseDirectories; } set { _ReverseDirectories = value; } }
    private bool _ReverseDirectories;

    #endregion

    #region События перебора каталога

    /// <summary>
    /// Событие вызывается перед просмотром каждого каталога.
    /// Как минимум, вызывается один раз для просмотра корневого каталога.
    /// В аргументы события копируются настройки просмотра из этого объекта, а обработчик может их изменить.
    /// Например, можно пропустить ненужные каталоги.
    /// </summary>
    public event EnumDirectoryEventHandler BeforeDirectory;

    /// <summary>
    /// Событие вызывается после просмотра каждого каталога, для которого вызывалось событие <see cref="BeforeDirectory"/>.
    /// Событие вызывается, даже если каталог пропускается установкой свойство <see cref="EnumDirectoryEventArgs.EnumerateMode"/>=<see cref="PathEnumerateMode.None"/>.
    /// Обработчик события не может менять свойства в аргументах события но может, например, удалить каталог.
    /// </summary>
    public event EnumDirectoryEventHandler AfterDirectory;

    #endregion

    #region Общая реализация перечислителя

    internal bool MoveNext(Stack<EnumDirectoryEventArgs> stack)
    {
      if (stack.Count == 0)
        PushDirectory(stack, String.Empty, 0);

      while (stack.Count > 0)
      {
        EnumDirectoryEventArgs args = stack.Peek();
        switch (args.Stage)
        {
          case PathEnumerateStage.Files:
            args.CurrentIndex++;
            if (args.CurrentIndex < args.Items.Length)
            {
              switch (EnumerateKind)
              {
                case PathEnumerateKind.Files:
                case PathEnumerateKind.FilesAndDirectories:
                  return true;

              }
            }
            args.SetNextStage();
            break;

          case PathEnumerateStage.Directories:
            if (!args.SubDirFlag)
            {
              args.CurrentIndex++;
              if (args.CurrentIndex < args.Items.Length)
              {
                args.SubDirFlag = true;
                switch (EnumerateKind)
                {
                  case PathEnumerateKind.Directories:
                  case PathEnumerateKind.FilesAndDirectories:
                    return true;  // требуется вернуть текущий каталог
                }
              }
              else
              {
                args.SetNextStage();
                continue;
              }
            }
            args.SubDirFlag = false;
            switch (args.EnumerateMode)
            {
              case PathEnumerateMode.DirectoriesOnly:
              case PathEnumerateMode.FilesAndDirectories:
              case PathEnumerateMode.DirectoriesAndFiles:
                string rel2 = System.IO.Path.GetFileName(args.Items[args.CurrentIndex]);
                if (args.DirectoryRel.Path.Length > 0)
                  rel2 = args.DirectoryRel.Path + System.IO.Path.DirectorySeparatorChar + rel2;
                PushDirectory(stack, rel2, args.Level + 1);
                break;
              default:
                args.SetNextStage();
                break;
            }
            break;

          default: // Stage=Finish;
            PopDirectory(stack);
            break;
        }
      }
      return false;
    }

    /// <summary>
    /// Создает новый объект EnumDirectoryEventArgs, вызывает событие BeforeDirectory, и добавляет объект в стек
    /// </summary>
    private void PushDirectory(Stack<EnumDirectoryEventArgs> stack, string relDir, int level)
    {
      EnumDirectoryEventArgs args = new EnumDirectoryEventArgs(RootDirectory + relDir, new RelPath(relDir), level);
      args.Init(this);
      if (BeforeDirectory != null)
        BeforeDirectory(this, args);

      // Корректируем режим перебора.
      // Если перебираются только каталоги, отменяем перебор файлов
      if (this.EnumerateKind == PathEnumerateKind.Directories)
      {
        switch (args.EnumerateMode)
        {
          case PathEnumerateMode.FilesAndDirectories:
          case PathEnumerateMode.DirectoriesAndFiles:
            args.EnumerateMode = PathEnumerateMode.DirectoriesOnly;
            break;
          case PathEnumerateMode.FilesOnly:
            args.EnumerateMode = PathEnumerateMode.None;
            break;
        }
      }

      args.SetNextStage();
      stack.Push(args);
    }

    /// <summary>
    /// Вызывает событие AfterDirectory и удаляет EnumDirectoryEventArgs из стека
    /// </summary>
    private void PopDirectory(Stack<EnumDirectoryEventArgs> stack)
    {
#if DEBUG
      if (stack.Count == 0)
        throw new BugException("Stack is empty");
#endif
      EnumDirectoryEventArgs args = stack.Peek();
      if (AfterDirectory != null)
        AfterDirectory(this, args);

      stack.Pop();
    }

    #endregion
  }

  /// <summary>
  /// Рекурсивное перечисление файлов и подкаталогов в каталоге.
  /// В отличие от <see cref="System.IO.Directory.GetFiles(string)"/> и System.IO.Directory.EnumerateFiles() (в Net Framework 4),
  /// позволяет управлять процессом перебора, чтобы не просматривать каталоги, которые не нужны.
  /// Имена файлов и каталогов при перечислении задаются как полные пути (структуры <see cref="AbsPath"/>).
  /// </summary>
  public sealed class AbsPathEnumerable : PathEnumerableBase, IEnumerable<AbsPath>
  {
    #region Конструкторы

    /// <summary>
    /// Создает объект, присваивая значения свойствам RootDirectory и EnumerateKind.
    /// </summary>
    /// <param name="rootDirectory">Корневой каталог для перечисления. Должен быть задан</param>
    /// <param name="enumerateKind">Что должно возвращаться при перечислении: файлы и/или каталоги</param>
    public AbsPathEnumerable(AbsPath rootDirectory, PathEnumerateKind enumerateKind)
      : base(rootDirectory, enumerateKind)
    {
    }

    /// <summary>
    /// Создает объект, присваивая значения свойствам RootDirectory.
    /// EnumerateKind принимает значение <see cref="PathEnumerateKind.Files"/>, то есть перечисляться будут имена файлов без каталогов.
    /// </summary>
    /// <param name="rootDirectory">Корневой каталог для перечисления. Должен быть задан</param>
    public AbsPathEnumerable(AbsPath rootDirectory)
      : this(rootDirectory, PathEnumerateKind.Files)
    {
    }

    #endregion

    #region Перечислитель

    /// <summary>
    /// Перечислитель
    /// </summary>
    public struct Enumerator : IEnumerator<AbsPath>
    {
      #region Защищенный конструктор

      internal Enumerator(AbsPathEnumerable owner)
      {
        _Owner = owner;
        _Stack = null;
      }

      #endregion

      #region Поля

      private readonly AbsPathEnumerable _Owner;

      private Stack<EnumDirectoryEventArgs> _Stack;

      #endregion

      #region IEnumerator<AbsPath> Members

      /// <summary>
      /// Возвращает очередной файл или каталог
      /// </summary>
      public AbsPath Current
      {
        get
        {
          if (_Stack == null)
            return AbsPath.Empty;
          if (_Stack.Count == 0)
            return AbsPath.Empty;

          EnumDirectoryEventArgs args = _Stack.Peek();
          return new AbsPath(args.Items[args.CurrentIndex]);
        }
      }

      /// <summary>
      /// Ничего не делает
      /// </summary>
      public void Dispose()
      {
      }

      object System.Collections.IEnumerator.Current { get { return Current; } }

      /// <summary>
      /// Переход к следующему файлу или каталогу
      /// </summary>
      /// <returns>true, если перебор еще не закончен</returns>
      public bool MoveNext()
      {
        if (_Stack == null)
          _Stack = new Stack<EnumDirectoryEventArgs>();
        return _Owner.MoveNext(_Stack);
      }

      /// <summary>
      /// Сброс перечислителя в исходное состояние
      /// </summary>
      void System.Collections.IEnumerator.Reset()
      {
        _Stack = null;
      }

      #endregion
    }

    #endregion

    #region Интерфейс IEnumerable<AbsPath>

    /// <summary>
    /// Создает перечислитель
    /// </summary>
    /// <returns>Перечислитель</returns>
    public Enumerator GetEnumerator()
    {
      return new Enumerator(this);
    }

    IEnumerator<AbsPath> IEnumerable<AbsPath>.GetEnumerator()
    {
      return new Enumerator(this);
    }

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
    {
      return new Enumerator(this);
    }

    #endregion

    #region Вспомогательные методы

    /// <summary>
    /// Возвращает количество файлов и/или каталогов, выполнив перечисление
    /// </summary>
    /// <returns>Количество объектов файловой системы</returns>
    public int GetCount()
    {
      int cnt = 0;
      foreach (AbsPath item in this)
        cnt++;
      return cnt;
    }

    /// <summary>
    /// Возвращает массив путей, выполнив перечисление.
    /// </summary>
    public AbsPath[] ToArray()
    {
      List<AbsPath> lst = new List<AbsPath>();
      foreach (AbsPath item in this)
        lst.Add(item);
      return lst.ToArray();
    }

    #endregion
  }

  /// <summary>
  /// Рекурсивное перечисление файлов и подкаталогов в каталоге.
  /// В отличие от <see cref="System.IO.Directory.GetFiles(string)"/> и System.Directory.EnumerateFiles() (в Net Framework 4),
  /// позволяет управлять процессом перебора, чтобы не просматривать каталоги, которые не нужны.
  /// Имена файлов и каталогов задаются как относительные пути (структуры <see cref="RelPath"/>).
  /// Пути задаются относительно базового каталога RootDirectory, а не текущего рабочего каталога программы,
  /// что следует учитывать при получении информации о файле/каталоге.
  /// Обычно следует пользоваться объектом <see cref="AbsPathEnumerable"/>, который использует полные, а не относительные пути.
  /// </summary>
  public sealed class RelPathEnumerable : PathEnumerableBase, IEnumerable<RelPath>
  {
    #region Конструкторы

    /// <summary>
    /// Создает объект, присваивая значения свойствам RootDirectory и EnumerateKind.
    /// </summary>
    /// <param name="rootDirectory">Корневой каталог для перечисления. Должен быть задан</param>
    /// <param name="enumerateKind">Что должно возвращаться при перечислении: файлы и/или каталоги</param>
    public RelPathEnumerable(AbsPath rootDirectory, PathEnumerateKind enumerateKind)
      : base(rootDirectory, enumerateKind)
    {
      _RootDirectoryLen = rootDirectory.SlashedPath.Length;
    }


    /// <summary>
    /// Создает объект, присваивая значения свойствам RootDirectory.
    /// EnumerateKind принимает значение <see cref="PathEnumerateKind.Files"/>, то есть перечисляться будут имена файлов без каталогов.
    /// </summary>
    /// <param name="rootDirectory">Корневой каталог для перечисления. Должен быть задан</param>
    public RelPathEnumerable(AbsPath rootDirectory)
      : this(rootDirectory, PathEnumerateKind.Files)
    {
    }

    // Количество символов в базовом каталоге, чтобы быстрее обрезать путь при переборе
    private readonly int _RootDirectoryLen;

    #endregion

    #region Перечислитель

    /// <summary>
    /// Перечислитель
    /// </summary>
    public struct Enumerator : IEnumerator<RelPath>
    {
      #region Защищенный конструктор

      internal Enumerator(RelPathEnumerable owner)
      {
        _Owner = owner;
        _Stack = null;
      }

      #endregion

      #region Поля

      private readonly RelPathEnumerable _Owner;

      private Stack<EnumDirectoryEventArgs> _Stack;

      #endregion

      #region IEnumerator<RelPath> Members

      /// <summary>
      /// Возвращает очередной файл или каталог
      /// </summary>
      public RelPath Current
      {
        get
        {
          if (_Stack == null)
            return new RelPath(String.Empty); // заглушка
          if (_Stack.Count == 0)
            return new RelPath(String.Empty); // заглушка

          EnumDirectoryEventArgs args = _Stack.Peek();
          return new RelPath(args.Items[args.CurrentIndex].Substring(_Owner._RootDirectoryLen));
        }
      }

      /// <summary>
      /// Ничего не делает
      /// </summary>
      public void Dispose()
      {
      }

      object System.Collections.IEnumerator.Current { get { return Current; } }

      /// <summary>
      /// Переход к следующему файлу или каталогу
      /// </summary>
      /// <returns>true, если перебор еще не закончен</returns>
      public bool MoveNext()
      {
        if (_Stack == null)
          _Stack = new Stack<EnumDirectoryEventArgs>();
        return _Owner.MoveNext(_Stack);
      }

      /// <summary>
      /// Сброс перечислителя в исходное состояние
      /// </summary>
      void System.Collections.IEnumerator.Reset()
      {
        _Stack = null;
      }

      #endregion
    }

    #endregion

    #region Интерфейс IEnumerable<RelPath>

    /// <summary>
    /// Создает перечислитель
    /// </summary>
    /// <returns>Перечислитель</returns>
    public Enumerator GetEnumerator()
    {
      return new Enumerator(this);
    }

    IEnumerator<RelPath> IEnumerable<RelPath>.GetEnumerator()
    {
      return new Enumerator(this);
    }

    System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
    {
      return new Enumerator(this);
    }

    #endregion

    #region Вспомогательные методы

    /// <summary>
    /// Возвращает количество файлов и/или каталогов, выполнив перечисление
    /// </summary>
    /// <returns>Количенство объектов файловой системы</returns>
    public int GetCount()
    {
      int cnt = 0;
      foreach (RelPath item in this)
        cnt++;
      return cnt;
    }

    /// <summary>
    /// Возвращает массив путей, выполнив перечисление
    /// </summary>
    public RelPath[] ToArray()
    {
      List<RelPath> lst = new List<RelPath>();
      foreach (RelPath item in this)
        lst.Add(item);
      return lst.ToArray();
    }

    #endregion
  }
}
