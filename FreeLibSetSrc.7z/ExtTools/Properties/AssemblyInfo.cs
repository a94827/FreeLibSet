﻿// Part of FreeLibSet.
// See copyright notices in "license" file in the FreeLibSet root directory.

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ExtTools")]
[assembly: AssemblyDescription("General purpose classes")]
[assembly: Guid("2c0dfea6-8326-44e4-ba55-a994e0bedd10")]
