﻿// Part of FreeLibSet.
// See copyright notices in "license" file in the FreeLibSet root directory.
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ExtRussian")]
[assembly: AssemblyDescription("Russian language (ru-RU) supporting functions")]
[assembly: Guid("d7b411c3-9506-4e9d-994d-c5e608d61ff2")]
