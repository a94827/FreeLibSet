﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// Управление общими сведениями о сборке осуществляется с помощью 
// набора атрибутов. Измените значения этих атрибутов, чтобы изменить сведения,
// связанные со сборкой.
[assembly: AssemblyTitle("ExtRussian")]
[assembly: AssemblyDescription("Функции поддержки русского языка")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Агеев Александр Владимирович")]
[assembly: AssemblyProduct("Freeware Library Set")]
[assembly: AssemblyCopyright("© Агеев А.В., г.Тюмень, 2015-2021 г. Модуль ExtRussian.dll является свободным программным обеспечением (Free Software)")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Параметр ComVisible со значением FALSE делает типы в сборке невидимыми 
// для COM-компонентов.  Если требуется обратиться к типу в этой сборке через 
// COM, задайте атрибуту ComVisible значение TRUE для этого типа.
[assembly: ComVisible(false)]

// Следующий GUID служит для идентификации библиотеки типов, если этот проект будет видимым для COM
[assembly: Guid("d7b411c3-9506-4e9d-994d-c5e608d61ff2")]

// Сведения о версии сборки состоят из следующих четырех значений:
//
//      Основной номер версии
//      Дополнительный номер версии 
//      Номер построения
//      Редакция
//
// Можно задать все значения или принять номер построения и номер редакции по умолчанию, 
// используя "*", как показано ниже:
[assembly: AssemblyVersion("1.1.0.7")]
