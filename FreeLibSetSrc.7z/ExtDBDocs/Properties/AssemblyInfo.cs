﻿// Part of FreeLibSet.
// See copyright notices in "license" file in the FreeLibSet root directory.

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ExtDBDocs")]
[assembly: AssemblyDescription("Document storage database model. Extends ExtDB")]
[assembly: Guid("a4ae45d5-42cf-41ec-af62-e44155698f48")]
