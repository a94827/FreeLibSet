﻿// Part of FreeLibSet.
// See copyright notices in "license" file in the FreeLibSet root directory.

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Alexander Ageyev")]
[assembly: AssemblyProduct("Freeware Library Set")]
[assembly: AssemblyCopyright("© Alexander Ageyev, 2006-2025. Free Software")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("4.0.0.368")]
